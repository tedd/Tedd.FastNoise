; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 464
       lea      rbp, [rsp+0x1D0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1A0], xmm4
       mov      rax, -336
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x100], 0x3E8
       call     [Tedd.FastNoise.Internal.VectorOps:get_Count():int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x40], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      eax, dword ptr [rbp+0x28]
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG14
 
G_M000_IG03:                ;; offset=0x0099
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x50], edx
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x50]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x54]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x5C], xmm0
       mov      eax, dword ptr [rbp-0x4C]
       imul     eax, dword ptr [rbp-0x40]
       mov      dword ptr [rbp-0x60], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x64], eax
       jmp      G_M000_IG07
 
G_M000_IG04:                ;; offset=0x0103
       mov      rcx, 0x7FFC657B9758
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x104], xmm0
       vmovss   xmm1, dword ptr [rbp-0x104]
       lea      rcx, [rbp-0x90]
       vmovss   xmm2, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.VectorOps:Ramp(float,float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB0]
       vmovss   xmm1, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xD0]
       vmovss   xmm1, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x170], ymm0
       lea      r8, [rbp-0x130]
       lea      r9, [rbp-0x150]
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0xF0]
       mov      rdx, gword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x190], ymm0
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x01E3
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG06:                ;; offset=0x01EF
       lea      rcx, [rbp-0x190]
       lea      rdx, [rbp-0x1A0]
       mov      eax, dword ptr [rbp-0x60]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG07:                ;; offset=0x0216
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x022D
       lea      rcx, [rbp-0x100]
       mov      edx, 183
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x023E
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp-0x40]
       jle      G_M000_IG04
       jmp      G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0252
       mov      rcx, 0x7FFC657B975C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       add      eax, dword ptr [rbp-0x64]
       mov      rcx, bword ptr [rbp+0x20]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG18
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, dword ptr [rbp-0x64]
       mov      ecx, ecx
       lea      rax, bword ptr [rax+4*rcx]
       mov      bword ptr [rbp-0xF8], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x1A4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A4]
       mov      rcx, gword ptr [rbp+0x10]
       vmovss   xmm2, dword ptr [rbp-0x58]
       vmovss   xmm3, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      rax, bword ptr [rbp-0xF8]
       vmovss   dword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x64]
       inc      eax
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG11:                ;; offset=0x02E1
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x02F8
       lea      rcx, [rbp-0x100]
       mov      edx, 233
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x0309
       mov      eax, dword ptr [rbp-0x64]
       cmp      eax, dword ptr [rbp-0x40]
       jl       G_M000_IG10
       mov      rcx, 0x7FFC657B9760
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG14:                ;; offset=0x032C
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0343
       lea      rcx, [rbp-0x100]
       mov      edx, 244
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG16:                ;; offset=0x0354
       mov      eax, dword ptr [rbp+0x28]
       add      eax, dword ptr [rbp+0x30]
       cmp      dword ptr [rbp-0x4C], eax
       jl       G_M000_IG03
       mov      rcx, 0x7FFC657B9764
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG17:                ;; offset=0x0373
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x037C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 898

; Assembly listing for method (dynamicClass):lambda_method1(System.Runtime.CompilerServices.Closure,float,float,float):float (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 548 single block inlinees; 28 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 240
       vmovaps  xmmword ptr [rsp+0xE0], xmm6
       vmovaps  xmmword ptr [rsp+0xD0], xmm7
       vmovaps  xmmword ptr [rsp+0xC0], xmm8
       vmovaps  xmmword ptr [rsp+0xB0], xmm9
       vmovaps  xmmword ptr [rsp+0xA0], xmm10
       vmovaps  xmmword ptr [rsp+0x90], xmm11
       vmovaps  xmmword ptr [rsp+0x80], xmm12
       vmovaps  xmmword ptr [rsp+0x70], xmm13
       vmovaps  xmmword ptr [rsp+0x60], xmm14
       vmovaps  xmmword ptr [rsp+0x50], xmm15
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0061
       vmovaps  xmm6, xmm1
       vmovaps  xmm7, xmm2
       vmovaps  xmm8, xmm3
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 0
       jbe      G_M000_IG144
       mov      rdx, gword ptr [rcx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0087
       mov      rax, 0x7FFC6583B410
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG140
 
G_M000_IG04:                ;; offset=0x009A
       mov      eax, dword ptr [rcx+0x64]
       vmovss   xmm1, dword ptr [rcx+0x0C]
       vmulss   xmm2, xmm6, xmm1
       vmulss   xmm3, xmm7, xmm1
       vmulss   xmm1, xmm8, xmm1
       vmovaps  xmm0, xmm1
       dec      eax
       cmp      eax, 2
       ja       G_M000_IG09
 
G_M000_IG05:                ;; offset=0x00BD
       mov      eax, eax
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rax]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG06:                ;; offset=0x00D5
       vaddss   xmm1, xmm2, xmm3
       vaddss   xmm1, xmm1, xmm0
       vmulss   xmm1, xmm1, dword ptr [reloc @RWD12]
       vsubss   xmm2, xmm1, xmm2
       vsubss   xmm3, xmm1, xmm3
       vsubss   xmm0, xmm1, xmm0
       jmp      SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00F3
       vaddss   xmm1, xmm2, xmm0
       vmulss   xmm4, xmm1, dword ptr [reloc @RWD16]
       vmovss   xmm9, dword ptr [reloc @RWD20]
       vmulss   xmm3, xmm3, xmm9
       vsubss   xmm4, xmm4, xmm3
       vaddss   xmm2, xmm4, xmm2
       vaddss   xmm0, xmm4, xmm0
       vmulss   xmm1, xmm1, xmm9
       vaddss   xmm3, xmm1, xmm3
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x0123
       vaddss   xmm1, xmm2, xmm3
       vmulss   xmm4, xmm1, dword ptr [reloc @RWD16]
       vmovss   xmm9, dword ptr [reloc @RWD20]
       vmulss   xmm0, xmm0, xmm9
       vsubss   xmm5, xmm4, xmm0
       vaddss   xmm2, xmm5, xmm2
       vaddss   xmm3, xmm3, xmm4
       vsubss   xmm3, xmm3, xmm0
       vmulss   xmm1, xmm1, xmm9
       vaddss   xmm0, xmm1, xmm0
 
G_M000_IG09:                ;; offset=0x0155
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  xmm9, xmm2
       vmovaps  xmm10, xmm3
       vmovaps  xmm11, xmm0
       vmovss   xmm12, dword ptr [rcx+0x38]
       cmp      dword ptr [rsi], 0
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0179
       cmp      ebp, 1
       jg       G_M000_IG84
 
G_M000_IG11:                ;; offset=0x0182
       mov      ecx, edi
       vmovaps  xmm1, xmm2
       vmovaps  xmm2, xmm3
       vmovaps  xmm3, xmm0
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG91
 
G_M000_IG12:                ;; offset=0x019F
       vmovss   xmm1, dword ptr [rsi+0x18]
       mov      ecx, dword ptr [rsi]
       cmp      ecx, 2
       je       G_M000_IG90
 
G_M000_IG13:                ;; offset=0x01AF
       cmp      ecx, 3
       je       G_M000_IG86
 
G_M000_IG14:                ;; offset=0x01B8
       vmulss   xmm2, xmm0, xmm1
 
G_M000_IG15:                ;; offset=0x01BC
       vmulss   xmm13, xmm2, xmm12
 
G_M000_IG16:                ;; offset=0x01C1
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm10, xmm13, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 1
       jbe      G_M000_IG144
       mov      rdx, gword ptr [rcx+0x18]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x01E3
       mov      rax, 0x7FFC6583B410
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG141
 
G_M000_IG18:                ;; offset=0x01F6
       mov      eax, dword ptr [rcx+0x64]
       vmovss   xmm1, dword ptr [rcx+0x0C]
       vmulss   xmm2, xmm6, xmm1
       vmulss   xmm3, xmm7, xmm1
       vmulss   xmm1, xmm8, xmm1
       vmovaps  xmm0, xmm1
       dec      eax
       cmp      eax, 2
       ja       G_M000_IG23
 
G_M000_IG19:                ;; offset=0x0219
       mov      eax, eax
       lea      rdx, [reloc @RWD24]
       mov      edx, dword ptr [rdx+4*rax]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG20:                ;; offset=0x0231
       vaddss   xmm1, xmm2, xmm3
       vaddss   xmm1, xmm1, xmm0
       vmulss   xmm1, xmm1, dword ptr [reloc @RWD12]
       vsubss   xmm2, xmm1, xmm2
       vsubss   xmm3, xmm1, xmm3
       vsubss   xmm0, xmm1, xmm0
       jmp      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x024F
       vaddss   xmm1, xmm2, xmm0
       vmulss   xmm4, xmm1, dword ptr [reloc @RWD16]
       vmovss   xmm9, dword ptr [reloc @RWD20]
       vmulss   xmm3, xmm3, xmm9
       vsubss   xmm4, xmm4, xmm3
       vaddss   xmm2, xmm4, xmm2
       vaddss   xmm0, xmm4, xmm0
       vmulss   xmm1, xmm1, xmm9
       vaddss   xmm3, xmm1, xmm3
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x027F
       vaddss   xmm1, xmm2, xmm3
       vmulss   xmm4, xmm1, dword ptr [reloc @RWD16]
       vmovss   xmm9, dword ptr [reloc @RWD20]
       vmulss   xmm0, xmm0, xmm9
       vsubss   xmm5, xmm4, xmm0
       vaddss   xmm2, xmm5, xmm2
       vaddss   xmm3, xmm3, xmm4
       vsubss   xmm3, xmm3, xmm0
       vmulss   xmm1, xmm1, xmm9
       vaddss   xmm0, xmm1, xmm0
 
G_M000_IG23:                ;; offset=0x02B1
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  xmm9, xmm2
       vmovaps  xmm11, xmm3
       vmovaps  xmm12, xmm0
       vmovss   xmm13, dword ptr [rcx+0x38]
       cmp      dword ptr [rsi], 0
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x02D5
       cmp      ebp, 1
       jg       G_M000_IG76
 
G_M000_IG25:                ;; offset=0x02DE
       mov      ecx, edi
       vmovaps  xmm1, xmm2
       vmovaps  xmm2, xmm3
       vmovaps  xmm3, xmm0
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG83
 
G_M000_IG26:                ;; offset=0x02FB
       vmovss   xmm1, dword ptr [rsi+0x18]
       mov      ecx, dword ptr [rsi]
       cmp      ecx, 2
       je       G_M000_IG82
 
G_M000_IG27:                ;; offset=0x030B
       cmp      ecx, 3
       je       G_M000_IG78
 
G_M000_IG28:                ;; offset=0x0314
       vmulss   xmm2, xmm0, xmm1
 
G_M000_IG29:                ;; offset=0x0318
       vmulss   xmm14, xmm2, xmm13
 
G_M000_IG30:                ;; offset=0x031D
       vmulss   xmm1, xmm14, dword ptr [reloc @RWD36]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm10, xmm1, xmm10
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 2
       jbe      G_M000_IG144
       mov      rdx, gword ptr [rcx+0x20]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x034C
       mov      rax, 0x7FFC6583B410
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG142
 
G_M000_IG32:                ;; offset=0x035F
       mov      eax, dword ptr [rcx+0x64]
       vmovss   xmm1, dword ptr [rcx+0x0C]
       vmulss   xmm2, xmm6, xmm1
       vmulss   xmm3, xmm7, xmm1
       vmulss   xmm1, xmm8, xmm1
       vmovaps  xmm0, xmm1
       dec      eax
       cmp      eax, 2
       ja       G_M000_IG37
 
G_M000_IG33:                ;; offset=0x0382
       mov      eax, eax
       lea      rdx, [reloc @RWD40]
       mov      edx, dword ptr [rdx+4*rax]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG34:                ;; offset=0x039A
       vaddss   xmm1, xmm2, xmm3
       vaddss   xmm1, xmm1, xmm0
       vmulss   xmm1, xmm1, dword ptr [reloc @RWD12]
       vsubss   xmm2, xmm1, xmm2
       vsubss   xmm3, xmm1, xmm3
       vsubss   xmm0, xmm1, xmm0
       jmp      SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x03B8
       vaddss   xmm1, xmm2, xmm0
       vmulss   xmm4, xmm1, dword ptr [reloc @RWD16]
       vmovss   xmm9, dword ptr [reloc @RWD20]
       vmulss   xmm3, xmm3, xmm9
       vsubss   xmm4, xmm4, xmm3
       vaddss   xmm2, xmm4, xmm2
       vaddss   xmm0, xmm4, xmm0
       vmulss   xmm1, xmm1, xmm9
       vaddss   xmm3, xmm1, xmm3
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x03E8
       vaddss   xmm1, xmm2, xmm3
       vmulss   xmm4, xmm1, dword ptr [reloc @RWD16]
       vmovss   xmm9, dword ptr [reloc @RWD20]
       vmulss   xmm0, xmm0, xmm9
       vsubss   xmm5, xmm4, xmm0
       vaddss   xmm2, xmm5, xmm2
       vaddss   xmm3, xmm3, xmm4
       vsubss   xmm3, xmm3, xmm0
       vmulss   xmm1, xmm1, xmm9
       vaddss   xmm0, xmm1, xmm0
 
G_M000_IG37:                ;; offset=0x041A
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  xmm9, xmm2
       vmovaps  xmm11, xmm3
       vmovaps  xmm12, xmm0
       vmovss   xmm13, dword ptr [rcx+0x38]
       cmp      dword ptr [rsi], 0
       je       SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x043E
       cmp      ebp, 1
       jg       G_M000_IG68
 
G_M000_IG39:                ;; offset=0x0447
       mov      ecx, edi
       vmovaps  xmm1, xmm2
       vmovaps  xmm2, xmm3
       vmovaps  xmm3, xmm0
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG75
 
G_M000_IG40:                ;; offset=0x0464
       vmovss   xmm1, dword ptr [rsi+0x18]
       mov      ecx, dword ptr [rsi]
       cmp      ecx, 2
       je       G_M000_IG74
 
G_M000_IG41:                ;; offset=0x0474
       cmp      ecx, 3
       je       G_M000_IG70
 
G_M000_IG42:                ;; offset=0x047D
       vmulss   xmm2, xmm0, xmm1
 
G_M000_IG43:                ;; offset=0x0481
       vmulss   xmm14, xmm2, xmm13
 
G_M000_IG44:                ;; offset=0x0486
       vmulss   xmm1, xmm14, dword ptr [reloc @RWD52]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm10, xmm1, xmm10
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 3
       jbe      G_M000_IG144
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x04B5
       mov      rax, 0x7FFC6583B410
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG143
 
G_M000_IG46:                ;; offset=0x04C8
       mov      eax, dword ptr [rcx+0x64]
       vmovss   xmm1, dword ptr [rcx+0x0C]
       vmulss   xmm2, xmm6, xmm1
       vmulss   xmm3, xmm7, xmm1
       vmulss   xmm1, xmm8, xmm1
       vmovaps  xmm0, xmm1
       dec      eax
       cmp      eax, 2
       ja       G_M000_IG51
 
G_M000_IG47:                ;; offset=0x04EB
       mov      eax, eax
       lea      rdx, [reloc @RWD56]
       mov      edx, dword ptr [rdx+4*rax]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG48:                ;; offset=0x0503
       vaddss   xmm1, xmm2, xmm3
       vaddss   xmm1, xmm1, xmm0
       vmulss   xmm1, xmm1, dword ptr [reloc @RWD12]
       vsubss   xmm2, xmm1, xmm2
       vsubss   xmm3, xmm1, xmm3
       vsubss   xmm0, xmm1, xmm0
       jmp      SHORT G_M000_IG51
 
G_M000_IG49:                ;; offset=0x0521
       vaddss   xmm1, xmm2, xmm0
       vmulss   xmm4, xmm1, dword ptr [reloc @RWD16]
       vmovss   xmm9, dword ptr [reloc @RWD20]
       vmulss   xmm3, xmm3, xmm9
       vsubss   xmm4, xmm4, xmm3
       vaddss   xmm2, xmm4, xmm2
       vaddss   xmm0, xmm4, xmm0
       vmulss   xmm1, xmm1, xmm9
       vaddss   xmm3, xmm1, xmm3
       jmp      SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x0551
       vaddss   xmm1, xmm2, xmm3
       vmulss   xmm4, xmm1, dword ptr [reloc @RWD16]
       vmovss   xmm9, dword ptr [reloc @RWD20]
       vmulss   xmm0, xmm0, xmm9
       vsubss   xmm5, xmm4, xmm0
       vaddss   xmm2, xmm5, xmm2
       vaddss   xmm3, xmm3, xmm4
       vsubss   xmm3, xmm3, xmm0
       vmulss   xmm1, xmm1, xmm9
       vaddss   xmm0, xmm1, xmm0
 
G_M000_IG51:                ;; offset=0x0583
       lea      rbx, bword ptr [rcx+0x74]
       mov      esi, dword ptr [rcx+0x08]
       mov      edi, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  xmm6, xmm2
       vmovaps  xmm7, xmm3
       vmovaps  xmm8, xmm0
       vmovss   xmm9, dword ptr [rcx+0x38]
       cmp      dword ptr [rbx], 0
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x05A7
       cmp      edi, 1
       jg       G_M000_IG60
 
G_M000_IG53:                ;; offset=0x05B0
       mov      ecx, esi
       vmovaps  xmm1, xmm2
       vmovaps  xmm2, xmm3
       vmovaps  xmm3, xmm0
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float]
       cmp      dword ptr [rbx], 0
       je       G_M000_IG67
 
G_M000_IG54:                ;; offset=0x05CD
       vmovss   xmm1, dword ptr [rbx+0x18]
       mov      edx, dword ptr [rbx]
       cmp      edx, 2
       je       G_M000_IG66
 
G_M000_IG55:                ;; offset=0x05DD
       cmp      edx, 3
       je       G_M000_IG62
 
G_M000_IG56:                ;; offset=0x05E6
       vmulss   xmm2, xmm0, xmm1
 
G_M000_IG57:                ;; offset=0x05EA
       vmulss   xmm11, xmm2, xmm9
 
G_M000_IG58:                ;; offset=0x05EF
       vmulss   xmm0, xmm11, dword ptr [reloc @RWD68]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm10
 
G_M000_IG59:                ;; offset=0x0604
       vmovaps  xmm6, xmmword ptr [rsp+0xE0]
       vmovaps  xmm7, xmmword ptr [rsp+0xD0]
       vmovaps  xmm8, xmmword ptr [rsp+0xC0]
       vmovaps  xmm9, xmmword ptr [rsp+0xB0]
       vmovaps  xmm10, xmmword ptr [rsp+0xA0]
       vmovaps  xmm11, xmmword ptr [rsp+0x90]
       vmovaps  xmm12, xmmword ptr [rsp+0x80]
       vmovaps  xmm13, xmmword ptr [rsp+0x70]
       vmovaps  xmm14, xmmword ptr [rsp+0x60]
       vmovaps  xmm15, xmmword ptr [rsp+0x50]
       add      rsp, 240
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG60:                ;; offset=0x0663
       vxorps   xmm11, xmm11, xmm11
       vmovss   xmm12, dword ptr [rbx+0x18]
       vmovss   xmm13, dword ptr [rbx+0x08]
       vmovss   xmm14, dword ptr [rbx+0x0C]
       vmovss   xmm15, dword ptr [rbx+0x10]
       xor      ebp, ebp
       cmp      ebp, edi
       jl       G_M000_IG110
 
G_M000_IG61:                ;; offset=0x0686
       jmp      G_M000_IG58
 
G_M000_IG62:                ;; offset=0x068B
       vmovss   xmm4, dword ptr [reloc @RWD72]
       vmovaps  xmm11, xmm4
       vaddss   xmm2, xmm0, xmm11
       vmulss   xmm0, xmm2, dword ptr [rbx+0x14]
       vmulss   xmm2, xmm0, dword ptr [reloc @RWD36]
       vcmpordss xmm3, xmm2, xmm2
       vandps   xmm3, xmm3, xmm2
       mov      edx, 0x7FFFFFFF
       vcvttss2si ecx, xmm3
       vucomiss xmm2, dword ptr [reloc @RWD76]
       cmovb    edx, ecx
       vxorps   xmm2, xmm2, xmm2
       vcvtsi2ss xmm2, xmm2, edx
       vmovss   xmm3, dword ptr [reloc @RWD80]
       vmulss   xmm2, xmm2, xmm3
       vsubss   xmm0, xmm0, xmm2
       vucomiss xmm11, xmm0
       ja       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x06E4
       vsubss   xmm0, xmm3, xmm0
 
G_M000_IG64:                ;; offset=0x06E8
       vsubss   xmm0, xmm0, dword ptr [reloc @RWD36]
       vmulss   xmm0, xmm0, xmm3
       vmulss   xmm2, xmm0, xmm1
       jmp      G_M000_IG57
 
G_M000_IG65:                ;; offset=0x06FD
       jmp      SHORT G_M000_IG64
 
G_M000_IG66:                ;; offset=0x06FF
       vandps   xmm0, xmm0, xmmword ptr [reloc @RWD96]
       vmulss   xmm0, xmm0, dword ptr [reloc @RWD112]
       vmovss   xmm11, dword ptr [reloc @RWD72]
       vaddss   xmm0, xmm0, xmm11
       vmulss   xmm2, xmm0, xmm1
       jmp      G_M000_IG57
 
G_M000_IG67:                ;; offset=0x0725
       vmovaps  xmm2, xmm0
       jmp      G_M000_IG57
 
G_M000_IG68:                ;; offset=0x072E
       vxorps   xmm14, xmm14, xmm14
       vmovss   xmm15, dword ptr [rsi+0x18]
       vmovss   xmm1, dword ptr [rsi+0x08]
       vmovss   dword ptr [rsp+0x38], xmm1
       vmovss   xmm1, dword ptr [rsi+0x0C]
       vmovss   dword ptr [rsp+0x34], xmm1
       vmovss   xmm1, dword ptr [rsi+0x10]
       vmovss   dword ptr [rsp+0x30], xmm1
       xor      r14d, r14d
       cmp      r14d, ebp
       jl       G_M000_IG122
 
G_M000_IG69:                ;; offset=0x0765
       jmp      G_M000_IG44
 
G_M000_IG70:                ;; offset=0x076A
       vmovss   xmm4, dword ptr [reloc @RWD72]
       vmovaps  xmm9, xmm4
       vaddss   xmm2, xmm0, xmm9
       vmulss   xmm0, xmm2, dword ptr [rsi+0x14]
       vmulss   xmm2, xmm0, dword ptr [reloc @RWD36]
       vcmpordss xmm3, xmm2, xmm2
       vandps   xmm3, xmm3, xmm2
       mov      ecx, 0x7FFFFFFF
       vcvttss2si eax, xmm3
       vucomiss xmm2, dword ptr [reloc @RWD76]
       cmovb    ecx, eax
       vxorps   xmm2, xmm2, xmm2
       vcvtsi2ss xmm2, xmm2, ecx
       vmovss   xmm3, dword ptr [reloc @RWD80]
       vmulss   xmm2, xmm2, xmm3
       vsubss   xmm2, xmm0, xmm2
       vucomiss xmm9, xmm2
       ja       SHORT G_M000_IG73
 
G_M000_IG71:                ;; offset=0x07C3
       vsubss   xmm2, xmm3, xmm2
 
G_M000_IG72:                ;; offset=0x07C7
       vsubss   xmm2, xmm2, dword ptr [reloc @RWD36]
       vmulss   xmm2, xmm2, xmm3
       vmulss   xmm2, xmm2, xmm1
       jmp      G_M000_IG43
 
G_M000_IG73:                ;; offset=0x07DC
       jmp      SHORT G_M000_IG72
 
G_M000_IG74:                ;; offset=0x07DE
       vandps   xmm0, xmm0, xmmword ptr [reloc @RWD96]
       vmulss   xmm2, xmm0, dword ptr [reloc @RWD112]
       vmovss   xmm9, dword ptr [reloc @RWD72]
       vaddss   xmm2, xmm2, xmm9
       vmulss   xmm2, xmm2, xmm1
       jmp      G_M000_IG43
 
G_M000_IG75:                ;; offset=0x0804
       vmovaps  xmm2, xmm0
       jmp      G_M000_IG43
 
G_M000_IG76:                ;; offset=0x080D
       vxorps   xmm14, xmm14, xmm14
       vmovss   xmm15, dword ptr [rsi+0x18]
       vmovss   xmm1, dword ptr [rsi+0x08]
       vmovss   dword ptr [rsp+0x44], xmm1
       vmovss   xmm1, dword ptr [rsi+0x0C]
       vmovss   dword ptr [rsp+0x40], xmm1
       vmovss   xmm1, dword ptr [rsi+0x10]
       vmovss   dword ptr [rsp+0x3C], xmm1
       xor      r14d, r14d
       cmp      r14d, ebp
       jl       G_M000_IG134
 
G_M000_IG77:                ;; offset=0x0844
       jmp      G_M000_IG30
 
G_M000_IG78:                ;; offset=0x0849
       vmovss   xmm4, dword ptr [reloc @RWD72]
       vmovaps  xmm9, xmm4
       vaddss   xmm2, xmm0, xmm9
       vmulss   xmm0, xmm2, dword ptr [rsi+0x14]
       vmulss   xmm2, xmm0, dword ptr [reloc @RWD36]
       vcmpordss xmm3, xmm2, xmm2
       vandps   xmm3, xmm3, xmm2
       mov      ecx, 0x7FFFFFFF
       vcvttss2si eax, xmm3
       vucomiss xmm2, dword ptr [reloc @RWD76]
       cmovb    ecx, eax
       vxorps   xmm2, xmm2, xmm2
       vcvtsi2ss xmm2, xmm2, ecx
       vmovss   xmm3, dword ptr [reloc @RWD80]
       vmulss   xmm2, xmm2, xmm3
       vsubss   xmm2, xmm0, xmm2
       vucomiss xmm9, xmm2
       ja       SHORT G_M000_IG81
 
G_M000_IG79:                ;; offset=0x08A2
       vsubss   xmm2, xmm3, xmm2
 
G_M000_IG80:                ;; offset=0x08A6
       vsubss   xmm2, xmm2, dword ptr [reloc @RWD36]
       vmulss   xmm2, xmm2, xmm3
       vmulss   xmm2, xmm2, xmm1
       jmp      G_M000_IG29
 
G_M000_IG81:                ;; offset=0x08BB
       jmp      SHORT G_M000_IG80
 
G_M000_IG82:                ;; offset=0x08BD
       vandps   xmm0, xmm0, xmmword ptr [reloc @RWD96]
       vmulss   xmm2, xmm0, dword ptr [reloc @RWD112]
       vmovss   xmm9, dword ptr [reloc @RWD72]
       vaddss   xmm2, xmm2, xmm9
       vmulss   xmm2, xmm2, xmm1
       jmp      G_M000_IG29
 
G_M000_IG83:                ;; offset=0x08E3
       vmovaps  xmm2, xmm0
       jmp      G_M000_IG29
 
G_M000_IG84:                ;; offset=0x08EC
       vxorps   xmm13, xmm13, xmm13
       vmovss   xmm14, dword ptr [rsi+0x18]
       vmovss   xmm15, dword ptr [rsi+0x08]
       vmovss   xmm1, dword ptr [rsi+0x0C]
       vmovss   dword ptr [rsp+0x4C], xmm1
       vmovss   xmm1, dword ptr [rsi+0x10]
       vmovss   dword ptr [rsp+0x48], xmm1
       xor      r14d, r14d
       cmp      r14d, ebp
       jl       G_M000_IG98
 
G_M000_IG85:                ;; offset=0x091D
       jmp      G_M000_IG16
 
G_M000_IG86:                ;; offset=0x0922
       vmovss   xmm4, dword ptr [reloc @RWD72]
       vmovaps  xmm9, xmm4
       vaddss   xmm2, xmm0, xmm9
       vmulss   xmm0, xmm2, dword ptr [rsi+0x14]
       vmulss   xmm2, xmm0, dword ptr [reloc @RWD36]
       vcmpordss xmm3, xmm2, xmm2
       vandps   xmm3, xmm3, xmm2
       mov      ecx, 0x7FFFFFFF
       vcvttss2si eax, xmm3
       vucomiss xmm2, dword ptr [reloc @RWD76]
       cmovb    ecx, eax
       vxorps   xmm2, xmm2, xmm2
       vcvtsi2ss xmm2, xmm2, ecx
       vmovss   xmm3, dword ptr [reloc @RWD80]
       vmulss   xmm2, xmm2, xmm3
       vsubss   xmm2, xmm0, xmm2
       vucomiss xmm9, xmm2
       ja       SHORT G_M000_IG89
 
G_M000_IG87:                ;; offset=0x097B
       vsubss   xmm2, xmm3, xmm2
 
G_M000_IG88:                ;; offset=0x097F
       vsubss   xmm2, xmm2, dword ptr [reloc @RWD36]
       vmulss   xmm2, xmm2, xmm3
       vmulss   xmm2, xmm2, xmm1
       jmp      G_M000_IG15
 
G_M000_IG89:                ;; offset=0x0994
       jmp      SHORT G_M000_IG88
 
G_M000_IG90:                ;; offset=0x0996
       vandps   xmm0, xmm0, xmmword ptr [reloc @RWD96]
       vmulss   xmm2, xmm0, dword ptr [reloc @RWD112]
       vmovss   xmm9, dword ptr [reloc @RWD72]
       vaddss   xmm2, xmm2, xmm9
       vmulss   xmm2, xmm2, xmm1
       jmp      G_M000_IG15
 
G_M000_IG91:                ;; offset=0x09BC
       vmovaps  xmm2, xmm0
       jmp      G_M000_IG15
 
G_M000_IG92:                ;; offset=0x09C5
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm1, xmm0, xmm4
       vmulss   xmm0, xmm1, dword ptr [rsi+0x14]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD36]
       vcmpordss xmm2, xmm1, xmm1
       vandps   xmm2, xmm2, xmm1
       mov      ecx, 0x7FFFFFFF
       vcvttss2si eax, xmm2
       vucomiss xmm1, dword ptr [reloc @RWD76]
       cmovb    ecx, eax
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, ecx
       vmovss   xmm2, dword ptr [reloc @RWD80]
       vmulss   xmm1, xmm1, xmm2
       vsubss   xmm1, xmm0, xmm1
       vucomiss xmm4, xmm1
       ja       SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x0A17
       vsubss   xmm1, xmm2, xmm1
 
G_M000_IG94:                ;; offset=0x0A1B
       vsubss   xmm3, xmm1, dword ptr [reloc @RWD36]
       vmulss   xmm2, xmm3, xmm2
       vmulss   xmm2, xmm2, xmm14
       vaddss   xmm13, xmm2, xmm13
       jmp      SHORT G_M000_IG97
 
G_M000_IG95:                ;; offset=0x0A33
       jmp      SHORT G_M000_IG94
 
G_M000_IG96:                ;; offset=0x0A35
       vandps   xmm0, xmm0, xmmword ptr [reloc @RWD96]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD112]
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm1, xmm1, xmm4
       vmulss   xmm1, xmm1, xmm14
       vaddss   xmm13, xmm1, xmm13
       vsubss   xmm1, xmm4, xmm0
 
G_M000_IG97:                ;; offset=0x0A5D
       vsubss   xmm1, xmm1, xmm4
       vmovss   xmm2, dword ptr [rsp+0x48]
       vmulss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm4
       vmulss   xmm14, xmm1, xmm14
       vmulss   xmm9, xmm9, xmm15
       vmulss   xmm10, xmm10, xmm15
       vmulss   xmm11, xmm11, xmm15
       vmovss   xmm1, dword ptr [rsp+0x4C]
       vmulss   xmm14, xmm14, xmm1
       inc      r14d
       cmp      r14d, ebp
       jge      G_M000_IG85
 
G_M000_IG98:                ;; offset=0x0A99
       vmovss   xmm1, dword ptr [reloc @RWD72]
       vmovaps  xmm5, xmm1
       vmovss   dword ptr [rsp+0x2C], xmm5
       vucomiss xmm12, xmm5
       jp       SHORT G_M000_IG99
       je       SHORT G_M000_IG101
 
G_M000_IG99:                ;; offset=0x0AB3
       lea      ecx, [rbp-0x01]
       cmp      r14d, ecx
       jne      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x0ABB
       vmulss   xmm14, xmm14, xmm12
 
G_M000_IG101:                ;; offset=0x0AC0
       lea      ecx, [rdi+r14]
       vmovaps  xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmovaps  xmm3, xmm11
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float]
       mov      ecx, dword ptr [rsi]
       cmp      ecx, 2
       je       G_M000_IG96
 
G_M000_IG102:                ;; offset=0x0AE4
       cmp      ecx, 3
       je       G_M000_IG92
 
G_M000_IG103:                ;; offset=0x0AED
       vmulss   xmm1, xmm0, xmm14
       vaddss   xmm13, xmm1, xmm13
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm0, xmm0, xmm4
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD36]
       jmp      G_M000_IG97
 
G_M000_IG104:                ;; offset=0x0B0E
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm1, xmm0, xmm4
       vmulss   xmm0, xmm1, dword ptr [rbx+0x14]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD36]
       vcmpordss xmm2, xmm1, xmm1
       vandps   xmm2, xmm2, xmm1
       mov      ecx, 0x7FFFFFFF
       vcvttss2si eax, xmm2
       vucomiss xmm1, dword ptr [reloc @RWD76]
       cmovb    ecx, eax
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, ecx
       vmovss   xmm3, dword ptr [reloc @RWD80]
       vmulss   xmm1, xmm1, xmm3
       vsubss   xmm1, xmm0, xmm1
       vucomiss xmm4, xmm1
       ja       SHORT G_M000_IG107
 
G_M000_IG105:                ;; offset=0x0B60
       vsubss   xmm1, xmm3, xmm1
 
G_M000_IG106:                ;; offset=0x0B64
       vsubss   xmm2, xmm1, dword ptr [reloc @RWD36]
       vmulss   xmm2, xmm2, xmm3
       vmulss   xmm2, xmm2, xmm12
       vaddss   xmm11, xmm2, xmm11
       jmp      SHORT G_M000_IG109
 
G_M000_IG107:                ;; offset=0x0B7C
       jmp      SHORT G_M000_IG106
 
G_M000_IG108:                ;; offset=0x0B7E
       vandps   xmm0, xmm0, xmmword ptr [reloc @RWD96]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD112]
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm1, xmm1, xmm4
       vmulss   xmm1, xmm1, xmm12
       vaddss   xmm11, xmm1, xmm11
       vsubss   xmm1, xmm4, xmm0
 
G_M000_IG109:                ;; offset=0x0BA6
       vsubss   xmm1, xmm1, xmm4
       vmulss   xmm1, xmm1, xmm15
       vaddss   xmm1, xmm1, xmm4
       vmulss   xmm12, xmm1, xmm12
       vmulss   xmm6, xmm6, xmm13
       vmulss   xmm7, xmm7, xmm13
       vmulss   xmm8, xmm8, xmm13
       vmulss   xmm12, xmm12, xmm14
       inc      ebp
       cmp      ebp, edi
       jge      G_M000_IG61
 
G_M000_IG110:                ;; offset=0x0BD6
       vmovss   xmm1, dword ptr [reloc @RWD72]
       vmovaps  xmm4, xmm1
       vmovss   dword ptr [rsp+0x2C], xmm4
       vucomiss xmm9, xmm4
       jp       SHORT G_M000_IG111
       je       SHORT G_M000_IG113
 
G_M000_IG111:                ;; offset=0x0BF0
       lea      ecx, [rdi-0x01]
       cmp      ebp, ecx
       jne      SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x0BF7
       vmulss   xmm12, xmm12, xmm9
 
G_M000_IG113:                ;; offset=0x0BFC
       lea      ecx, [rsi+rbp]
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float]
       mov      ecx, dword ptr [rbx]
       cmp      ecx, 2
       je       G_M000_IG108
 
G_M000_IG114:                ;; offset=0x0C1D
       cmp      ecx, 3
       je       G_M000_IG104
 
G_M000_IG115:                ;; offset=0x0C26
       vmulss   xmm1, xmm0, xmm12
       vaddss   xmm11, xmm1, xmm11
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm0, xmm0, xmm4
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD36]
       jmp      G_M000_IG109
 
G_M000_IG116:                ;; offset=0x0C47
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm1, xmm0, xmm4
       vmulss   xmm0, xmm1, dword ptr [rsi+0x14]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD36]
       vcmpordss xmm2, xmm1, xmm1
       vandps   xmm2, xmm2, xmm1
       mov      ecx, 0x7FFFFFFF
       vcvttss2si eax, xmm2
       vucomiss xmm1, dword ptr [reloc @RWD76]
       cmovb    ecx, eax
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, ecx
       vmovss   xmm3, dword ptr [reloc @RWD80]
       vmulss   xmm1, xmm1, xmm3
       vsubss   xmm1, xmm0, xmm1
       vucomiss xmm4, xmm1
       ja       SHORT G_M000_IG119
 
G_M000_IG117:                ;; offset=0x0C99
       vsubss   xmm1, xmm3, xmm1
 
G_M000_IG118:                ;; offset=0x0C9D
       vsubss   xmm2, xmm1, dword ptr [reloc @RWD36]
       vmulss   xmm2, xmm2, xmm3
       vmulss   xmm2, xmm2, xmm15
       vaddss   xmm14, xmm2, xmm14
       jmp      SHORT G_M000_IG121
 
G_M000_IG119:                ;; offset=0x0CB5
       jmp      SHORT G_M000_IG118
 
G_M000_IG120:                ;; offset=0x0CB7
       vandps   xmm0, xmm0, xmmword ptr [reloc @RWD96]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD112]
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm1, xmm1, xmm4
       vmulss   xmm1, xmm1, xmm15
       vaddss   xmm14, xmm1, xmm14
       vsubss   xmm1, xmm4, xmm0
 
G_M000_IG121:                ;; offset=0x0CDF
       vsubss   xmm1, xmm1, xmm4
       vmovss   xmm2, dword ptr [rsp+0x30]
       vmulss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm4
       vmulss   xmm15, xmm1, xmm15
       vmovss   xmm1, dword ptr [rsp+0x38]
       vmulss   xmm9, xmm9, xmm1
       vmulss   xmm11, xmm11, xmm1
       vmulss   xmm12, xmm12, xmm1
       vmovss   xmm3, dword ptr [rsp+0x34]
       vmulss   xmm15, xmm15, xmm3
       inc      r14d
       cmp      r14d, ebp
       jge      G_M000_IG69
 
G_M000_IG122:                ;; offset=0x0D1E
       vmovss   xmm1, dword ptr [reloc @RWD72]
       vmovss   dword ptr [rsp+0x2C], xmm1
       vucomiss xmm13, xmm1
       jp       SHORT G_M000_IG123
       je       SHORT G_M000_IG125
 
G_M000_IG123:                ;; offset=0x0D34
       lea      ecx, [rbp-0x01]
       cmp      r14d, ecx
       jne      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0D3C
       vmulss   xmm15, xmm15, xmm13
 
G_M000_IG125:                ;; offset=0x0D41
       lea      ecx, [rdi+r14]
       vmovaps  xmm1, xmm9
       vmovaps  xmm2, xmm11
       vmovaps  xmm3, xmm12
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float]
       mov      ecx, dword ptr [rsi]
       cmp      ecx, 2
       je       G_M000_IG120
 
G_M000_IG126:                ;; offset=0x0D65
       cmp      ecx, 3
       je       G_M000_IG116
 
G_M000_IG127:                ;; offset=0x0D6E
       vmulss   xmm1, xmm0, xmm15
       vaddss   xmm14, xmm1, xmm14
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm0, xmm0, xmm4
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD36]
       jmp      G_M000_IG121
 
G_M000_IG128:                ;; offset=0x0D8F
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm1, xmm0, xmm4
       vmulss   xmm0, xmm1, dword ptr [rsi+0x14]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD36]
       vcmpordss xmm2, xmm1, xmm1
       vandps   xmm2, xmm2, xmm1
       mov      ecx, 0x7FFFFFFF
       vcvttss2si eax, xmm2
       vucomiss xmm1, dword ptr [reloc @RWD76]
       cmovb    ecx, eax
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, ecx
       vmovss   xmm3, dword ptr [reloc @RWD80]
       vmulss   xmm1, xmm1, xmm3
       vsubss   xmm1, xmm0, xmm1
       vucomiss xmm4, xmm1
       ja       SHORT G_M000_IG131
 
G_M000_IG129:                ;; offset=0x0DE1
       vsubss   xmm1, xmm3, xmm1
 
G_M000_IG130:                ;; offset=0x0DE5
       vsubss   xmm2, xmm1, dword ptr [reloc @RWD36]
       vmulss   xmm2, xmm2, xmm3
       vmulss   xmm2, xmm2, xmm15
       vaddss   xmm14, xmm2, xmm14
       jmp      SHORT G_M000_IG133
 
G_M000_IG131:                ;; offset=0x0DFD
       jmp      SHORT G_M000_IG130
 
G_M000_IG132:                ;; offset=0x0DFF
       vandps   xmm0, xmm0, xmmword ptr [reloc @RWD96]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD112]
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm1, xmm1, xmm4
       vmulss   xmm1, xmm1, xmm15
       vaddss   xmm14, xmm1, xmm14
       vsubss   xmm1, xmm4, xmm0
 
G_M000_IG133:                ;; offset=0x0E27
       vsubss   xmm1, xmm1, xmm4
       vmovss   xmm2, dword ptr [rsp+0x3C]
       vmulss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm4
       vmulss   xmm15, xmm1, xmm15
       vmovss   xmm1, dword ptr [rsp+0x44]
       vmulss   xmm9, xmm9, xmm1
       vmulss   xmm11, xmm11, xmm1
       vmulss   xmm12, xmm12, xmm1
       vmovss   xmm3, dword ptr [rsp+0x40]
       vmulss   xmm15, xmm15, xmm3
       inc      r14d
       cmp      r14d, ebp
       jge      G_M000_IG77
 
G_M000_IG134:                ;; offset=0x0E66
       vmovss   xmm1, dword ptr [reloc @RWD72]
       vmovss   dword ptr [rsp+0x2C], xmm1
       vucomiss xmm13, xmm1
       jp       SHORT G_M000_IG135
       je       SHORT G_M000_IG137
 
G_M000_IG135:                ;; offset=0x0E7C
       lea      ecx, [rbp-0x01]
       cmp      r14d, ecx
       jne      SHORT G_M000_IG137
 
G_M000_IG136:                ;; offset=0x0E84
       vmulss   xmm15, xmm15, xmm13
 
G_M000_IG137:                ;; offset=0x0E89
       lea      ecx, [rdi+r14]
       vmovaps  xmm1, xmm9
       vmovaps  xmm2, xmm11
       vmovaps  xmm3, xmm12
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float]
       mov      ecx, dword ptr [rsi]
       cmp      ecx, 2
       je       G_M000_IG132
 
G_M000_IG138:                ;; offset=0x0EAD
       cmp      ecx, 3
       je       G_M000_IG128
 
G_M000_IG139:                ;; offset=0x0EB6
       vmulss   xmm1, xmm0, xmm15
       vaddss   xmm14, xmm1, xmm14
       vmovss   xmm4, dword ptr [rsp+0x2C]
       vaddss   xmm0, xmm0, xmm4
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD36]
       jmp      G_M000_IG133
 
G_M000_IG140:                ;; offset=0x0ED7
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG141:                ;; offset=0x0EE1
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG142:                ;; offset=0x0EEB
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG143:                ;; offset=0x0EF5
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG144:                ;; offset=0x0EFF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000000C2h ; case G_M000_IG08
       	dd	00000092h ; case G_M000_IG07
       	dd	00000074h ; case G_M000_IG06
RWD12  	dd	3F2AAAABh		;  0.666667
RWD16  	dd	BE58658Ch		; -0.211325
RWD20  	dd	3F13CD3Ah		;   0.57735
RWD24  	dd	0000021Eh ; case G_M000_IG22
       	dd	000001EEh ; case G_M000_IG21
       	dd	000001D0h ; case G_M000_IG20
RWD36  	dd	3F000000h		;       0.5
RWD40  	dd	00000387h ; case G_M000_IG36
       	dd	00000357h ; case G_M000_IG35
       	dd	00000339h ; case G_M000_IG34
RWD52  	dd	3E800000h		;      0.25
RWD56  	dd	000004F0h ; case G_M000_IG50
       	dd	000004C0h ; case G_M000_IG49
       	dd	000004A2h ; case G_M000_IG48
RWD68  	dd	3E000000h		;     0.125
RWD72  	dd	3F800000h		;         1
RWD76  	dd	4F000000h		; 2.14748e+09
RWD80  	dd	40000000h		;         2
RWD84  	dd	00000000h, 00000000h, 00000000h
RWD96  	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD112 	dd	C0000000h		;        -2

; Total bytes of code 3845

; Assembly listing for method (dynamicClass):lambda_method2(System.Runtime.CompilerServices.Closure,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 549 single block inlinees; 9 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 0x470
       vmovaps  xmmword ptr [rsp+0x460], xmm6
       vmovaps  xmmword ptr [rsp+0x450], xmm7
       vmovaps  xmmword ptr [rsp+0x440], xmm8
       vmovaps  xmmword ptr [rsp+0x430], xmm9
       vmovaps  xmmword ptr [rsp+0x420], xmm10
       vmovaps  xmmword ptr [rsp+0x410], xmm11
       vmovaps  xmmword ptr [rsp+0x400], xmm12
       vmovaps  xmmword ptr [rsp+0x3F0], xmm13
       vmovaps  xmmword ptr [rsp+0x3E0], xmm14
       vmovaps  xmmword ptr [rsp+0x3D0], xmm15
       mov      rsi, rcx
       mov      rbx, rdx
       mov      rdx, bword ptr [rsp+0x4D0]
 
G_M000_IG02:                ;; offset=0x0079
       vmovups  ymm0, ymmword ptr [r8]
       vmovups  ymmword ptr [rsp+0x3B0], ymm0
       vmovups  ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [rsp+0x390], ymm0
       vmovups  ymm0, ymmword ptr [rdx]
       vmovups  ymmword ptr [rsp+0x370], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 0
       jbe      G_M000_IG110
       mov      rbp, gword ptr [rdx+0x10]
       mov      r14, 0x7FFC657B2E08
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00C7
       mov      rdx, rbp
       mov      rcx, r14
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG04:                ;; offset=0x00D3
       vmovups  ymm6, ymmword ptr [rbp+0x08]
       vmovups  ymmword ptr [rsp+0x350], ymm6
       cmp      dword ptr [rdi+0x08], 1
       jbe      G_M000_IG110
       mov      rdx, gword ptr [rdi+0x18]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x00F7
       mov      rcx, 0x7FFC6583B410
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG106
 
G_M000_IG06:                ;; offset=0x010A
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm7, ymm0, ymmword ptr [rsp+0x3B0]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x390]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x370]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG11
 
G_M000_IG07:                ;; offset=0x013A
       mov      edx, edx
       lea      r9, [reloc @RWD00]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG08:                ;; offset=0x0154
       vaddps   ymm0, ymm8, ymm7
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm7, ymm0, ymm7
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x0175
       vaddps   ymm0, ymm9, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm8, ymm8, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm8
       vaddps   ymm7, ymm1, ymm7
       vaddps   ymm9, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm8, ymm0, ymm8
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x01A6
       vaddps   ymm0, ymm8, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm9
       vaddps   ymm7, ymm2, ymm7
       vaddps   ymm1, ymm8, ymm1
       vsubps   ymm8, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
 
G_M000_IG11:                ;; offset=0x01D9
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovss   xmm13, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0202
       cmp      r15d, 1
       jg       G_M000_IG70
 
G_M000_IG13:                ;; offset=0x020C
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm7
       vmovups  ymmword ptr [rsp+0x50], ymm8
       vmovups  ymmword ptr [rsp+0x30], ymm9
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x2D0]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       je       G_M000_IG75
 
G_M000_IG14:                ;; offset=0x0263
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG74
 
G_M000_IG15:                ;; offset=0x0274
       cmp      edx, 3
       je       G_M000_IG73
 
G_M000_IG16:                ;; offset=0x027D
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x2D0]
 
G_M000_IG17:                ;; offset=0x0286
       vbroadcastss ymm0, ymm13
       vmulps   ymm7, ymm0, ymm1
 
G_M000_IG18:                ;; offset=0x028F
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 2
       jbe      G_M000_IG110
       mov      rbp, gword ptr [rdx+0x20]
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x02AA
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG20:                ;; offset=0x02C2
       vmulps   ymm0, ymm7, ymmword ptr [rbp+0x08]
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x350]
       vmovups  ymmword ptr [rsp+0x330], ymm7
       cmp      dword ptr [rdi+0x08], 3
       jbe      G_M000_IG110
       mov      rdx, gword ptr [rdi+0x28]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x02EF
       mov      rcx, 0x7FFC6583B410
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG107
 
G_M000_IG22:                ;; offset=0x0302
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x3B0]
       vmulps   ymm10, ymm0, ymmword ptr [rsp+0x390]
       vmulps   ymm11, ymm0, ymmword ptr [rsp+0x370]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG27
 
G_M000_IG23:                ;; offset=0x0332
       mov      edx, edx
       lea      r9, [reloc @RWD128]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG24:                ;; offset=0x034C
       vaddps   ymm0, ymm10, ymm9
       vaddps   ymm0, ymm0, ymm11
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm9, ymm0, ymm9
       vsubps   ymm10, ymm0, ymm10
       vsubps   ymm11, ymm0, ymm11
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x036F
       vaddps   ymm0, ymm11, ymm9
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm10, ymm10, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm10
       vaddps   ymm9, ymm1, ymm9
       vaddps   ymm11, ymm1, ymm11
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm10, ymm0, ymm10
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03A2
       vaddps   ymm0, ymm10, ymm9
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm11, ymm11, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm11
       vaddps   ymm9, ymm2, ymm9
       vaddps   ymm1, ymm10, ymm1
       vsubps   ymm10, ymm1, ymm11
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm11, ymm0, ymm11
 
G_M000_IG27:                ;; offset=0x03D7
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm12, ymm9
       vmovaps  ymm13, ymm10
       vmovaps  ymm14, ymm11
       vmovss   xmm15, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x0401
       cmp      r15d, 1
       jg       G_M000_IG64
 
G_M000_IG29:                ;; offset=0x040B
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm9
       vmovups  ymmword ptr [rsp+0x50], ymm10
       vmovups  ymmword ptr [rsp+0x30], ymm11
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x210]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       je       G_M000_IG69
 
G_M000_IG30:                ;; offset=0x0462
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG68
 
G_M000_IG31:                ;; offset=0x0473
       cmp      edx, 3
       je       G_M000_IG67
 
G_M000_IG32:                ;; offset=0x047C
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x210]
 
G_M000_IG33:                ;; offset=0x0485
       vbroadcastss ymm0, ymm15
       vmulps   ymm9, ymm0, ymm1
 
G_M000_IG34:                ;; offset=0x048E
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 4
       jbe      G_M000_IG110
       mov      rbp, gword ptr [rdx+0x30]
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x04A9
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm10, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm9, ymm9, xmm10
 
G_M000_IG36:                ;; offset=0x04C1
       vmulps   ymm0, ymm9, ymmword ptr [rbp+0x08]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x350]
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x330]
       vmovups  ymmword ptr [rsp+0x310], ymm7
       cmp      dword ptr [rdi+0x08], 5
       jbe      G_M000_IG110
       mov      rdx, gword ptr [rdi+0x38]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x04F7
       mov      rcx, 0x7FFC6583B410
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG108
 
G_M000_IG38:                ;; offset=0x050A
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x3B0]
       vmulps   ymm10, ymm0, ymmword ptr [rsp+0x390]
       vmulps   ymm11, ymm0, ymmword ptr [rsp+0x370]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG43
 
G_M000_IG39:                ;; offset=0x053A
       mov      edx, edx
       lea      r9, [reloc @RWD140]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG40:                ;; offset=0x0554
       vaddps   ymm0, ymm10, ymm9
       vaddps   ymm0, ymm0, ymm11
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm9, ymm0, ymm9
       vsubps   ymm10, ymm0, ymm10
       vsubps   ymm11, ymm0, ymm11
       jmp      SHORT G_M000_IG43
 
G_M000_IG41:                ;; offset=0x0577
       vaddps   ymm0, ymm11, ymm9
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm10, ymm10, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm10
       vaddps   ymm9, ymm1, ymm9
       vaddps   ymm11, ymm1, ymm11
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm10, ymm0, ymm10
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x05AA
       vaddps   ymm0, ymm10, ymm9
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm11, ymm11, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm11
       vaddps   ymm9, ymm2, ymm9
       vaddps   ymm1, ymm10, ymm1
       vsubps   ymm10, ymm1, ymm11
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm11, ymm0, ymm11
 
G_M000_IG43:                ;; offset=0x05DF
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm12, ymm9
       vmovaps  ymm13, ymm10
       vmovaps  ymm14, ymm11
       vmovss   xmm15, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0609
       cmp      r15d, 1
       jg       G_M000_IG58
 
G_M000_IG45:                ;; offset=0x0613
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm9
       vmovups  ymmword ptr [rsp+0x50], ymm10
       vmovups  ymmword ptr [rsp+0x30], ymm11
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x150]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       je       G_M000_IG63
 
G_M000_IG46:                ;; offset=0x066A
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG62
 
G_M000_IG47:                ;; offset=0x067B
       cmp      edx, 3
       je       G_M000_IG61
 
G_M000_IG48:                ;; offset=0x0684
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x150]
 
G_M000_IG49:                ;; offset=0x068D
       vbroadcastss ymm0, ymm15
       vmulps   ymm9, ymm0, ymm1
 
G_M000_IG50:                ;; offset=0x0696
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 6
       jbe      G_M000_IG110
       mov      rbp, gword ptr [rdx+0x40]
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x06B1
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm10, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm9, ymm9, xmm10
 
G_M000_IG52:                ;; offset=0x06C9
       vmulps   ymm0, ymm9, ymmword ptr [rbp+0x08]
       vmovups  ymm6, ymmword ptr [rsp+0x350]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x310]
       cmp      dword ptr [rdi+0x08], 7
       jbe      G_M000_IG110
       mov      rdx, gword ptr [rdi+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x06FA
       mov      rax, 0x7FFC6583B410
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG109
 
G_M000_IG54:                ;; offset=0x070D
       lea      rdx, [rsp+0x370]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x2F0]
       lea      r8, [rsp+0x3B0]
       lea      r9, [rsp+0x390]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 8
       jbe      G_M000_IG110
       mov      rbx, gword ptr [rdx+0x50]
       cmp      qword ptr [rbx], r14
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       je       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x0769
       mov      rdx, rbx
       mov      rcx, r14
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG56:                ;; offset=0x078D
       vmovups  ymm0, ymmword ptr [rsp+0x2F0]
       vmulps   ymm0, ymm0, ymmword ptr [rbx+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm7
       vmovups  ymmword ptr [rsi], ymm0
       mov      rax, rsi
 
G_M000_IG57:                ;; offset=0x07AA
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x460]
       vmovaps  xmm7, xmmword ptr [rsp+0x450]
       vmovaps  xmm8, xmmword ptr [rsp+0x440]
       vmovaps  xmm9, xmmword ptr [rsp+0x430]
       vmovaps  xmm10, xmmword ptr [rsp+0x420]
       vmovaps  xmm11, xmmword ptr [rsp+0x410]
       vmovaps  xmm12, xmmword ptr [rsp+0x400]
       vmovaps  xmm13, xmmword ptr [rsp+0x3F0]
       vmovaps  xmm14, xmmword ptr [rsp+0x3E0]
       vmovaps  xmm15, xmmword ptr [rsp+0x3D0]
       add      rsp, 0x470
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG58:                ;; offset=0x0819
       vxorps   ymm9, ymm9, ymm9
       vmovups  ymmword ptr [rsp+0x130], ymm9
       vbroadcastss ymm10, dword ptr [rdi+0x18]
       vbroadcastss ymm11, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x110], ymm11
       vbroadcastss ymm0, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0xF0], ymm0
       vbroadcastss ymm1, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0xD0], ymm1
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG90
 
G_M000_IG59:                ;; offset=0x0866
       vmovups  ymm9, ymmword ptr [rsp+0x130]
 
G_M000_IG60:                ;; offset=0x086F
       jmp      G_M000_IG50
 
G_M000_IG61:                ;; offset=0x0874
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm1, ymm2, ymmword ptr [rsp+0x150]
       vbroadcastss ymm3, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm3, ymm1
       vmulps   ymm3, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vcvtdq2ps ymm3, ymm3
       vbroadcastss ymm4, dword ptr [reloc @RWD256]
       vmulps   ymm3, ymm3, ymm4
       vsubps   ymm1, ymm1, ymm3
       vcmpltps ymm2, ymm1, ymm2
       vsubps   ymm3, ymm4, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm4
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG49
 
G_M000_IG62:                ;; offset=0x08F1
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG49
 
G_M000_IG63:                ;; offset=0x0920
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       jmp      G_M000_IG49
 
G_M000_IG64:                ;; offset=0x092E
       vxorps   ymm9, ymm9, ymm9
       vmovups  ymmword ptr [rsp+0x1F0], ymm9
       vbroadcastss ymm10, dword ptr [rdi+0x18]
       vbroadcastss ymm11, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x1D0], ymm11
       vbroadcastss ymm0, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x1B0], ymm0
       vbroadcastss ymm1, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x190], ymm1
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG100
 
G_M000_IG65:                ;; offset=0x097B
       vmovups  ymm9, ymmword ptr [rsp+0x1F0]
 
G_M000_IG66:                ;; offset=0x0984
       jmp      G_M000_IG34
 
G_M000_IG67:                ;; offset=0x0989
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm1, ymm2, ymmword ptr [rsp+0x210]
       vbroadcastss ymm3, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm3, ymm1
       vmulps   ymm3, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vcvtdq2ps ymm3, ymm3
       vbroadcastss ymm4, dword ptr [reloc @RWD256]
       vmulps   ymm3, ymm3, ymm4
       vsubps   ymm1, ymm1, ymm3
       vcmpltps ymm2, ymm1, ymm2
       vsubps   ymm3, ymm4, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm4
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG33
 
G_M000_IG68:                ;; offset=0x0A06
       vmovups  ymm1, ymmword ptr [rsp+0x210]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG33
 
G_M000_IG69:                ;; offset=0x0A35
       vmovups  ymm1, ymmword ptr [rsp+0x210]
       jmp      G_M000_IG33
 
G_M000_IG70:                ;; offset=0x0A43
       vxorps   ymm7, ymm7, ymm7
       vmovups  ymmword ptr [rsp+0x2B0], ymm7
       vbroadcastss ymm8, dword ptr [rdi+0x18]
       vbroadcastss ymm9, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x290], ymm9
       vbroadcastss ymm14, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x270], ymm14
       vbroadcastss ymm15, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x250], ymm15
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG80
 
G_M000_IG71:                ;; offset=0x0A8F
       vmovups  ymm7, ymmword ptr [rsp+0x2B0]
 
G_M000_IG72:                ;; offset=0x0A98
       jmp      G_M000_IG18
 
G_M000_IG73:                ;; offset=0x0A9D
       vbroadcastss ymm1, dword ptr [reloc @RWD152]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x2D0]
       vbroadcastss ymm3, dword ptr [rdi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vcvtdq2ps ymm3, ymm3
       vbroadcastss ymm9, dword ptr [reloc @RWD256]
       vmulps   ymm3, ymm3, ymm9
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vsubps   ymm3, ymm9, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm9
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG17
 
G_M000_IG74:                ;; offset=0x0B1C
       vmovups  ymm1, ymmword ptr [rsp+0x2D0]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG17
 
G_M000_IG75:                ;; offset=0x0B4B
       vmovups  ymm1, ymmword ptr [rsp+0x2D0]
       jmp      G_M000_IG17
 
G_M000_IG76:                ;; offset=0x0B59
       vbroadcastss ymm6, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm6, ymmword ptr [rsp+0x230]
       vbroadcastss ymm1, dword ptr [rdi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vcvtdq2ps ymm1, ymm1
       vbroadcastss ymm9, dword ptr [reloc @RWD256]
       vmulps   ymm1, ymm1, ymm9
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm6
       vsubps   ymm2, ymm9, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0x230], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vmulps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x2B0]
       vmovups  ymm0, ymmword ptr [rsp+0x230]
       jmp      SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x0BF1
       vmovups  ymm0, ymmword ptr [rsp+0x230]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x230], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm6, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm0, ymm6
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x2B0]
       vsubps   ymm0, ymm6, ymmword ptr [rsp+0x230]
 
G_M000_IG78:                ;; offset=0x0C37
       vsubps   ymm0, ymm0, ymm6
       vmovups  ymm15, ymmword ptr [rsp+0x250]
       vmulps   ymm0, ymm0, ymm15
       vaddps   ymm0, ymm0, ymm6
       vmulps   ymm8, ymm0, ymm8
       vmovups  ymm9, ymmword ptr [rsp+0x290]
       vmulps   ymm10, ymm10, ymm9
       vmulps   ymm11, ymm11, ymm9
       vmulps   ymm12, ymm12, ymm9
       vmovups  ymm14, ymmword ptr [rsp+0x270]
       vmulps   ymm8, ymm8, ymm14
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG72
 
G_M000_IG79:                ;; offset=0x0C84
       vmovups  ymmword ptr [rsp+0x2B0], ymm7
 
G_M000_IG80:                ;; offset=0x0C8D
       vucomiss xmm13, dword ptr [reloc @RWD152]
       jp       SHORT G_M000_IG81
       je       SHORT G_M000_IG83
 
G_M000_IG81:                ;; offset=0x0C99
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0CA2
       vbroadcastss ymm0, ymm13
       vmulps   ymm8, ymm0, ymm8
 
G_M000_IG83:                ;; offset=0x0CAC
       lea      edx, [rbp+r13]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm10
       vmovups  ymmword ptr [rsp+0x50], ymm11
       vmovups  ymmword ptr [rsp+0x30], ymm12
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x230]
       vextractf128 xmm14, ymm10
       vextractf128 xmm15, ymm11
       vextractf128 xmm7, ymm12
       vextractf128 xmm6, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm10, ymm10, xmm14
       vinsertf128 ymm11, ymm11, xmm15
       vinsertf128 ymm12, ymm12, xmm7
       vinsertf128 ymm8, ymm8, xmm6
       je       G_M000_IG77
 
G_M000_IG84:                ;; offset=0x0D3A
       cmp      edx, 3
       je       G_M000_IG76
 
G_M000_IG85:                ;; offset=0x0D43
       vmulps   ymm0, ymm8, ymmword ptr [rsp+0x230]
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x2B0]
       vbroadcastss ymm6, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm6, ymmword ptr [rsp+0x230]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       jmp      G_M000_IG78
 
G_M000_IG86:                ;; offset=0x0D74
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm2, ymmword ptr [rsp+0xB0]
       vbroadcastss ymm1, dword ptr [rdi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm1, ymm1
       vandps   ymm1, ymm3, ymm1
       vcmpgeps ymm3, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm1, ymm1
       vbroadcastss ymm4, dword ptr [reloc @RWD256]
       vmulps   ymm1, ymm1, ymm4
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm2
       vsubps   ymm3, ymm4, ymm0
       vblendvps ymm0, ymm3, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vmulps   ymm0, ymm0, ymm4
       vmulps   ymm0, ymm0, ymm10
       vaddps   ymm9, ymm0, ymmword ptr [rsp+0x130]
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0E0A
       vmovups  ymm2, ymmword ptr [rsp+0xB0]
       vandps   ymm0, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm0, ymm2
       vmulps   ymm0, ymm0, ymm10
       vaddps   ymm9, ymm0, ymmword ptr [rsp+0x130]
       vsubps   ymm0, ymm2, ymmword ptr [rsp+0xB0]
 
G_M000_IG88:                ;; offset=0x0E50
       vmovaps  ymm1, ymm2
       vsubps   ymm0, ymm0, ymm1
       vmovups  ymm2, ymmword ptr [rsp+0xD0]
       vmulps   ymm0, ymm0, ymm2
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm10, ymm0, ymm10
       vmovups  ymm11, ymmword ptr [rsp+0x110]
       vmulps   ymm12, ymm12, ymm11
       vmulps   ymm13, ymm13, ymm11
       vmulps   ymm14, ymm14, ymm11
       vmovups  ymm0, ymmword ptr [rsp+0xF0]
       vmulps   ymm10, ymm10, ymm0
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG60
 
G_M000_IG89:                ;; offset=0x0E9F
       vmovups  ymmword ptr [rsp+0x130], ymm9
 
G_M000_IG90:                ;; offset=0x0EA8
       vucomiss xmm15, dword ptr [reloc @RWD152]
       jp       SHORT G_M000_IG91
       je       SHORT G_M000_IG93
 
G_M000_IG91:                ;; offset=0x0EB4
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x0EBD
       vbroadcastss ymm2, ymm15
       vmulps   ymm10, ymm2, ymm10
 
G_M000_IG93:                ;; offset=0x0EC7
       lea      edx, [rbp+r13]
       vmovd    xmm2, edx
       vpbroadcastd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x90], ymm2
       vmovups  ymmword ptr [rsp+0x70], ymm12
       vmovups  ymmword ptr [rsp+0x50], ymm13
       vmovups  ymmword ptr [rsp+0x30], ymm14
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xB0]
       vextractf128 xmm8, ymm12
       vextractf128 xmm7, ymm13
       vextractf128 xmm6, ymm14
       vextractf128 xmm9, ymm10
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm12, ymm12, xmm8
       vinsertf128 ymm13, ymm13, xmm7
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm10, ymm10, xmm9
       je       G_M000_IG87
 
G_M000_IG94:                ;; offset=0x0F55
       cmp      edx, 3
       je       G_M000_IG86
 
G_M000_IG95:                ;; offset=0x0F5E
       vmulps   ymm0, ymm10, ymmword ptr [rsp+0xB0]
       vaddps   ymm9, ymm0, ymmword ptr [rsp+0x130]
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm2, ymmword ptr [rsp+0xB0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       jmp      G_M000_IG88
 
G_M000_IG96:                ;; offset=0x0F8F
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm2, ymmword ptr [rsp+0x170]
       vbroadcastss ymm1, dword ptr [rdi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm1, ymm1
       vandps   ymm1, ymm3, ymm1
       vcmpgeps ymm3, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm1, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD256]
       vmulps   ymm1, ymm1, ymm3
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm2
       vsubps   ymm4, ymm3, ymm0
       vblendvps ymm0, ymm4, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0x170], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vmulps   ymm0, ymm0, ymm3
       vmulps   ymm0, ymm0, ymm10
       vaddps   ymm9, ymm0, ymmword ptr [rsp+0x1F0]
       vmovups  ymm0, ymmword ptr [rsp+0x170]
       jmp      SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x1025
       vmovups  ymm2, ymmword ptr [rsp+0x170]
       vandps   ymm0, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x170], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm0, ymm2
       vmulps   ymm0, ymm0, ymm10
       vaddps   ymm9, ymm0, ymmword ptr [rsp+0x1F0]
       vsubps   ymm0, ymm2, ymmword ptr [rsp+0x170]
 
G_M000_IG98:                ;; offset=0x106B
       vmovaps  ymm1, ymm2
       vsubps   ymm0, ymm0, ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x190]
       vmulps   ymm0, ymm0, ymm2
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm10, ymm0, ymm10
       vmovups  ymm11, ymmword ptr [rsp+0x1D0]
       vmulps   ymm12, ymm12, ymm11
       vmulps   ymm13, ymm13, ymm11
       vmulps   ymm14, ymm14, ymm11
       vmovups  ymm0, ymmword ptr [rsp+0x1B0]
       vmulps   ymm10, ymm10, ymm0
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG66
 
G_M000_IG99:                ;; offset=0x10BA
       vmovups  ymmword ptr [rsp+0x1F0], ymm9
 
G_M000_IG100:                ;; offset=0x10C3
       vucomiss xmm15, dword ptr [reloc @RWD152]
       jp       SHORT G_M000_IG101
       je       SHORT G_M000_IG103
 
G_M000_IG101:                ;; offset=0x10CF
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x10D8
       vbroadcastss ymm2, ymm15
       vmulps   ymm10, ymm2, ymm10
 
G_M000_IG103:                ;; offset=0x10E2
       lea      edx, [rbp+r13]
       vmovd    xmm2, edx
       vpbroadcastd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x90], ymm2
       vmovups  ymmword ptr [rsp+0x70], ymm12
       vmovups  ymmword ptr [rsp+0x50], ymm13
       vmovups  ymmword ptr [rsp+0x30], ymm14
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x170]
       vextractf128 xmm8, ymm12
       vextractf128 xmm7, ymm13
       vextractf128 xmm6, ymm14
       vextractf128 xmm9, ymm10
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm12, ymm12, xmm8
       vinsertf128 ymm13, ymm13, xmm7
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm10, ymm10, xmm9
       je       G_M000_IG97
 
G_M000_IG104:                ;; offset=0x1170
       cmp      edx, 3
       je       G_M000_IG96
 
G_M000_IG105:                ;; offset=0x1179
       vmulps   ymm0, ymm10, ymmword ptr [rsp+0x170]
       vaddps   ymm9, ymm0, ymmword ptr [rsp+0x1F0]
       vbroadcastss ymm2, dword ptr [reloc @RWD152]
       vaddps   ymm0, ymm2, ymmword ptr [rsp+0x170]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       jmp      G_M000_IG98
 
G_M000_IG106:                ;; offset=0x11AA
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG107:                ;; offset=0x11B1
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG108:                ;; offset=0x11B8
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG109:                ;; offset=0x11BF
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG110:                ;; offset=0x11C9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	0000012Dh ; case G_M000_IG10
       	dd	000000FCh ; case G_M000_IG09
       	dd	000000DBh ; case G_M000_IG08
RWD12  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD32  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD64  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD96  	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD128 	dd	00000329h ; case G_M000_IG26
       	dd	000002F6h ; case G_M000_IG25
       	dd	000002D3h ; case G_M000_IG24
RWD140 	dd	00000531h ; case G_M000_IG42
       	dd	000004FEh ; case G_M000_IG41
       	dd	000004DBh ; case G_M000_IG40
RWD152 	dd	3F800000h		;         1
RWD156 	dd	00000000h
RWD160 	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD192 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD224 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD256 	dd	40000000h		;         2
RWD260 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD288 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h

; Total bytes of code 4559

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3(Tedd.FastNoise.Procedural.CompiledStack3D,Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int,bool) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 800
       lea      rbp, [rsp+0x320]
       xor      eax, eax
       mov      qword ptr [rbp-0x2E8], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -672
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0053
       mov      dword ptr [rbp-0x188], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x40], rax
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG03
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x007C
       mov      rcx, 0x7FFC6589E390
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG04:                ;; offset=0x009A
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x48], rax
       mov      dword ptr [rbp-0x4C], 8
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG19
 
G_M000_IG05:                ;; offset=0x00E0
       mov      eax, dword ptr [rbp-0x5C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x60], edx
       mov      eax, dword ptr [rbp-0x5C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x64], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x60]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x68], xmm0
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      eax, dword ptr [rbp-0x5C]
       imul     eax, dword ptr [rbp-0x50]
       mov      dword ptr [rbp-0x70], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x74], eax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG16
       jmp      G_M000_IG11
 
G_M000_IG06:                ;; offset=0x0155
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x18C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x18C]
       lea      rcx, [rbp-0xB0]
       vmovss   xmm2, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.VectorOps:Ramp(float,float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x110]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x178], rax
       mov      rcx, gword ptr [rbp-0x178]
       mov      rdx, 0x7FFC6589E398
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x1F8], rax
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1F0], ymm0
       mov      rax, gword ptr [rbp-0x1F8]
       lea      r8, [rbp-0x1B0]
       lea      r9, [rbp-0x1D0]
       lea      rcx, [rbp-0x1F0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x1F8]
       call     [rax+0x18]System.Func`4[System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]]:Invoke(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x250], ymm0
       lea      rcx, [rbp-0x230]
       lea      rdx, [rbp-0x250]
       call     [System.Numerics.Vector:EqualsAll[float](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):bool]
       test     eax, eax
       jne      G_M000_IG08
       mov      rcx, 0x7FFC6589E4A0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x150]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x170]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
 
G_M000_IG07:                ;; offset=0x02C3
       vmovups  ymmword ptr [rbp-0x270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2B0], ymm0
       lea      r8, [rbp-0x270]
       lea      r9, [rbp-0x290]
       lea      rax, [rbp-0x2B0]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0xD0]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG08:                ;; offset=0x0316
       mov      rcx, 0x7FFC6589E4A4
       call     CORINFO_HELP_COUNTPROFILE32
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x2D0], ymm0
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG09:                ;; offset=0x0339
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG10:                ;; offset=0x0345
       lea      rcx, [rbp-0x2D0]
       lea      rdx, [rbp-0x2E0]
       mov      eax, dword ptr [rbp-0x70]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x74]
       add      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG11:                ;; offset=0x036C
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0383
       lea      rcx, [rbp-0x188]
       mov      edx, 220
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x0394
       mov      eax, dword ptr [rbp-0x74]
       add      eax, dword ptr [rbp-0x4C]
       cmp      eax, dword ptr [rbp-0x50]
       jle      G_M000_IG06
       mov      rcx, 0x7FFC6589E4A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG16
 
G_M000_IG14:                ;; offset=0x03B7
       mov      rax, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, gword ptr [rbp-0x180]
       mov      rdx, 0x7FFC6589E4B0
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x2EC], xmm0
       mov      rax, gword ptr [rbp-0x2E8]
       vmovss   xmm1, dword ptr [rbp-0x2EC]
       vmovss   xmm2, dword ptr [rbp-0x68]
       vmovss   xmm3, dword ptr [rbp-0x6C]
       mov      rcx, gword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x2E8]
       call     [rax+0x18]System.Func`4[float,float,float,float]:Invoke(float,float,float):float:this
       vmovss   dword ptr [rbp-0xD4], xmm0
       vmovss   xmm0, dword ptr [rbp-0xD4]
       call     [System.Single:IsNaN(float):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rcx, 0x7FFC6589E5B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x2F0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x2F0]
       mov      rcx, gword ptr [rbp+0x18]
       vmovss   xmm2, dword ptr [rbp-0x68]
       vmovss   xmm3, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovss   dword ptr [rbp-0xD4], xmm0
 
G_M000_IG15:                ;; offset=0x04A2
       mov      rcx, 0x7FFC6589E5BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x70]
       add      eax, dword ptr [rbp-0x74]
       mov      rcx, bword ptr [rbp+0x28]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG23
       mov      rax, bword ptr [rbp+0x28]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x70]
       add      ecx, dword ptr [rbp-0x74]
       mov      ecx, ecx
       vmovss   xmm0, dword ptr [rbp-0xD4]
       vmovss   dword ptr [rax+4*rcx], xmm0
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG16:                ;; offset=0x04E8
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x04FF
       lea      rcx, [rbp-0x188]
       mov      edx, 309
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG18:                ;; offset=0x0510
       mov      eax, dword ptr [rbp-0x74]
       cmp      eax, dword ptr [rbp-0x50]
       jl       G_M000_IG14
       mov      rcx, 0x7FFC6589E5C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG19:                ;; offset=0x0533
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x054A
       lea      rcx, [rbp-0x188]
       mov      edx, 320
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG21:                ;; offset=0x055B
       mov      eax, dword ptr [rbp+0x30]
       add      eax, dword ptr [rbp+0x38]
       cmp      dword ptr [rbp-0x5C], eax
       jl       G_M000_IG05
       mov      rcx, 0x7FFC6589E5C4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG22:                ;; offset=0x057A
       add      rsp, 800
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x0583
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1417

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Tier1-OSR)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0xe9
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2
; 10 inlinees with PGO data; 904 single block inlinees; 10 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       mov      rax, qword ptr [rbp]
       push     rax
       lea      r11, [rsp-0x1070]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       mov      qword ptr [rsp+0x1248], r15
       mov      qword ptr [rsp+0x1240], r14
       mov      qword ptr [rsp+0x1238], r13
       mov      qword ptr [rsp+0x1230], r12
       mov      qword ptr [rsp+0x1228], rdi
       mov      qword ptr [rsp+0x1220], rsi
       mov      qword ptr [rsp+0x1218], rbx
       vmovaps  xmmword ptr [rsp+0x1020], xmm6
       vmovaps  xmmword ptr [rsp+0x1010], xmm7
       vmovaps  xmmword ptr [rsp+0x1000], xmm8
       vmovaps  xmmword ptr [rsp+0xFF0], xmm9
       vmovaps  xmmword ptr [rsp+0xFE0], xmm10
       vmovaps  xmmword ptr [rsp+0xFD0], xmm11
       vmovaps  xmmword ptr [rsp+0xFC0], xmm12
       vmovaps  xmmword ptr [rsp+0xFB0], xmm13
       vmovaps  xmmword ptr [rsp+0xFA0], xmm14
       vmovaps  xmmword ptr [rsp+0xF90], xmm15
       lea      rbp, [rsp+0x1070]
       xor      eax, eax
       mov      qword ptr [rbp-0xFF8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xFF0], xmm4
       vmovdqa  xmmword ptr [rbp-0xFE0], xmm4
       mov      rax, -0xED0
       vmovdqa  xmmword ptr [rbp+rax-0x100], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0xF0], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0xE0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x100], rax
       mov      rbx, gword ptr [rbp+0x1F0]
       mov      rdi, bword ptr [rbp+0x1F8]
       mov      rsi, bword ptr [rbp+0x200]
       mov      r14d, dword ptr [rbp+0x208]
       mov      r15d, dword ptr [rbp+0x210]
       mov      r9d, dword ptr [rbp+0x1A4]
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r11d, dword ptr [rbp+0x19C]
       vmovss   xmm6, dword ptr [rbp+0x198]
       mov      r12d, dword ptr [rbp+0x194]
       vmovss   xmm7, dword ptr [rbp+0x188]
       vmovss   xmm8, dword ptr [rbp+0x184]
       mov      r10d, dword ptr [rbp+0x180]
       mov      r13d, dword ptr [rbp+0x17C]
 
G_M000_IG02:                ;; offset=0x0163
       vbroadcastss ymm1, ymm6
       vcvtdq2ps ymm0, ymmword ptr [reloc @RWD00]
       vmulps   ymm9, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0xFD8], ymm9
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0181
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x1A4], r9d
       mov      dword ptr [rbp+0x19C], r11d
       mov      dword ptr [rbp+0x180], r10d
       lea      ecx, [r10+r13]
       cmp      ecx, dword ptr [rsi+0x08]
       jae      G_M000_IG66
       mov      eax, ecx
       mov      qword ptr [rbp-0x1000], rax
       mov      rdx, bword ptr [rsi]
       mov      bword ptr [rbp-0xFF8], rdx
       mov      rcx, rdi
       vextractf128 xmm10, ymm9
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r13d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm0, xmm1
       mov      rcx, rbx
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      rdx, bword ptr [rbp-0xFF8]
       mov      rax, qword ptr [rbp-0x1000]
       vmovss   dword ptr [rdx+4*rax], xmm0
       inc      r13d
       vinsertf128 ymm9, ymm9, xmm10
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r9d, dword ptr [rbp+0x1A4]
       mov      r10d, dword ptr [rbp+0x180]
       mov      r11d, dword ptr [rbp+0x19C]
 
G_M000_IG04:                ;; offset=0x0227
       cmp      r13d, r8d
       jl       G_M000_IG03
 
G_M000_IG05:                ;; offset=0x0230
       inc      r12d
       mov      dword ptr [rbp+0x208], r14d
       mov      dword ptr [rbp+0x210], r15d
       lea      eax, [r14+r15]
       cmp      eax, r12d
       jle      G_M000_IG32
 
G_M000_IG06:                ;; offset=0x024E
       mov      eax, r12d
       cdq      
       idiv     edx:eax, r11d
       mov      r10d, edx
       mov      dword ptr [rbp+0x19C], r11d
       mov      eax, r12d
       cdq      
       idiv     edx:eax, r11d
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r10d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm7, xmm1, dword ptr [rdi+0x04]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, eax
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm8, xmm1, dword ptr [rdi+0x08]
       mov      r10d, r12d
       imul     r10d, r8d
       mov      dword ptr [rbp+0x180], r10d
       xor      ecx, ecx
       xor      eax, eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x029D
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x1A4], r9d
       mov      dword ptr [rbp+0x19C], r11d
 
G_M000_IG08:                ;; offset=0x02B2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0xFA8], xmm0
 
G_M000_IG09:                ;; offset=0x02BE
       lea      rdx, [rbp-0xFA8]
       mov      dword ptr [rbp+0x180], r10d
       lea      r8d, [r10+r13]
       lea      rcx, [rbp-0x118]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      r13d, dword ptr [rbp-0xFDC]
       mov      dword ptr [rbp+0x208], r14d
       mov      dword ptr [rbp+0x210], r15d
       mov      eax, r13d
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r9d, dword ptr [rbp+0x1A4]
       vmovups  ymm9, ymmword ptr [rbp-0xFD8]
 
G_M000_IG10:                ;; offset=0x030B
       mov      dword ptr [rbp+0x1A4], r9d
       lea      edx, [rax+r9]
       mov      dword ptr [rbp+0x1A0], r8d
       cmp      edx, r8d
       mov      dword ptr [rbp-0xFDC], edx
       mov      r13d, eax
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r9d, dword ptr [rbp+0x1A4]
       mov      r10d, dword ptr [rbp+0x180]
       mov      r11d, dword ptr [rbp+0x19C]
       mov      r14d, dword ptr [rbp+0x208]
       mov      r15d, dword ptr [rbp+0x210]
       jg       G_M000_IG04
 
G_M000_IG11:                ;; offset=0x0359
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r13d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm1, dword ptr [rdi]
       vbroadcastss ymm1, ymm1
       vaddps   ymm10, ymm1, ymm9
       vbroadcastss ymm11, ymm7
       vmovss   dword ptr [rbp+0x184], xmm8
       vbroadcastss ymm12, ymm8
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x130], xmm1
       vmovdqu  xmmword ptr [rbp-0x12C], xmm1
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x150], xmm1
       vmovdqu  xmmword ptr [rbp-0x144], xmm1
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x118], ymm1
       xor      eax, eax
       vmovss   xmm8, dword ptr [rbp+0x184]
       jmp      G_M000_IG18
 
G_M000_IG12:                ;; offset=0x03C9
       vmovups  ymm0, ymmword ptr [rbp-0x178]
       vmovups  ymmword ptr [rbp-0x1F8], ymm0
       jmp      G_M000_IG17
 
G_M000_IG13:                ;; offset=0x03DE
       vmovss   dword ptr [rbp+0x184], xmm8
 
G_M000_IG14:                ;; offset=0x03E6
       vmovups  ymm0, ymmword ptr [rbp-0x318]
       vmovups  ymmword ptr [rbp-0x218], ymm0
       vmovss   xmm8, dword ptr [rbp+0x184]
 
G_M000_IG15:                ;; offset=0x03FE
       vmovups  ymm0, ymmword ptr [rbp-0x218]
       vmovups  ymmword ptr [rbp-0x178], ymm0
       mov      rcx, bword ptr [rbp-0xFF0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Amplitude():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x198]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x218]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x1B8]
       lea      r8, [rbp-0x198]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rcx, bword ptr [rbp-0xFF0]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Offset():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1D8]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x178]
       lea      rdx, [rbp-0x1B8]
       lea      r8, [rbp-0x1D8]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      r14, qword ptr [rbp-0xFE8]
       test     r14d, r14d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG12
 
G_M000_IG16:                ;; offset=0x04C4
       mov      rcx, bword ptr [rbp-0xFF0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Blend():int:this]
       mov      r15d, eax
       mov      rcx, bword ptr [rbp-0xFF0]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_BlendFactor():float:this]
       mov      edx, r15d
       vmovss   dword ptr [rsp+0x20], xmm0
       lea      r8, [rbp-0x118]
       lea      r9, [rbp-0x178]
       lea      rcx, [rbp-0x1F8]
       call     [Tedd.FastNoise.Internal.StackFill:Blend[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG17:                ;; offset=0x0529
       vmovups  ymm0, ymmword ptr [rbp-0x1F8]
       vmovups  ymmword ptr [rbp-0x118], ymm0
       inc      r14d
       mov      rax, r14
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r9d, dword ptr [rbp+0x1A4]
       mov      r10d, dword ptr [rbp+0x180]
       mov      r11d, dword ptr [rbp+0x19C]
       mov      r14d, dword ptr [rbp+0x208]
       mov      r15d, dword ptr [rbp+0x210]
 
G_M000_IG18:                ;; offset=0x0569
       mov      ecx, dword ptr [rbx+0x08]
       cmp      ecx, eax
       jle      G_M000_IG07
 
G_M000_IG19:                ;; offset=0x0574
       mov      dword ptr [rbp+0x210], r15d
       mov      qword ptr [rbp-0xFE8], rax
       imul     rcx, rax, 80
       lea      rcx, bword ptr [rbx+rcx+0x10]
       mov      bword ptr [rbp-0xFF0], rcx
       vmovdqu  xmm1, xmmword ptr [rcx]
       vmovdqu  xmmword ptr [rbp-0x130], xmm1
       mov      r15d, dword ptr [rcx+0x10]
       mov      dword ptr [rbp-0x120], r15d
       mov      r15d, dword ptr [rbp-0x12C]
       vbroadcastss ymm1, dword ptr [rcx+0x34]
       vmulps   ymm13, ymm1, ymm10
       vmulps   ymm14, ymm1, ymm11
       vmulps   ymm15, ymm1, ymm12
       dec      r15d
       cmp      r15d, 2
       mov      dword ptr [rbp+0x208], r14d
       ja       G_M000_IG24
 
G_M000_IG20:                ;; offset=0x05D9
       mov      dword ptr [rbp+0x19C], r11d
       mov      r15d, r15d
       lea      r14, [reloc @RWD32]
       mov      r14d, dword ptr [r14+4*r15]
       lea      r11, G_M000_IG02
       add      r14, r11
       jmp      r14
 
G_M000_IG21:                ;; offset=0x05FB
       vaddps   ymm1, ymm14, ymm13
       vaddps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD64]
       vsubps   ymm13, ymm1, ymm13
       vsubps   ymm14, ymm1, ymm14
       vsubps   ymm15, ymm1, ymm15
       mov      r11d, dword ptr [rbp+0x19C]
       jmp      SHORT G_M000_IG24
 
G_M000_IG22:                ;; offset=0x0625
       vaddps   ymm1, ymm15, ymm13
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD96]
       vbroadcastss ymm2, dword ptr [reloc @RWD128]
       vmulps   ymm14, ymm2, ymm14
       vsubps   ymm0, ymm0, ymm14
       vaddps   ymm13, ymm0, ymm13
       vaddps   ymm15, ymm0, ymm15
       vmulps   ymm2, ymm2, ymm1
       vaddps   ymm14, ymm2, ymm14
       mov      r11d, dword ptr [rbp+0x19C]
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x0661
       vaddps   ymm1, ymm14, ymm13
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD96]
       vbroadcastss ymm2, dword ptr [reloc @RWD128]
       vmulps   ymm15, ymm2, ymm15
       vsubps   ymm3, ymm0, ymm15
       vaddps   ymm13, ymm3, ymm13
       vaddps   ymm0, ymm14, ymm0
       vsubps   ymm14, ymm0, ymm15
       vmulps   ymm1, ymm2, ymm1
       vaddps   ymm15, ymm1, ymm15
       mov      r11d, dword ptr [rbp+0x19C]
 
G_M000_IG24:                ;; offset=0x069F
       vmovdqu  xmm1, xmmword ptr [rcx]
       vmovdqu  xmmword ptr [rbp-0x130], xmm1
       mov      r15d, dword ptr [rcx+0x10]
       mov      dword ptr [rbp-0x120], r15d
       vmovdqu  xmm1, xmmword ptr [rcx+0x14]
       vmovdqu  xmmword ptr [rbp-0x150], xmm1
       vmovdqu  xmm1, xmmword ptr [rcx+0x20]
       vmovdqu  xmmword ptr [rbp-0x144], xmm1
       mov      r15d, dword ptr [rcx+0x30]
       mov      r14d, dword ptr [rcx+0x48]
       vmovups  ymmword ptr [rbp-0x238], ymm13
       vmovups  ymmword ptr [rbp-0x258], ymm14
       vmovups  ymmword ptr [rbp-0x278], ymm15
       vmovss   xmm1, dword ptr [rcx+0x4C]
       vmovss   dword ptr [rbp-0x2BC], xmm1
       cmp      dword ptr [rbp-0x150], 0
       je       G_M000_IG33
       cmp      r14d, 1
       jle      G_M000_IG33
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       mov      dword ptr [rbp+0x19C], r11d
       lea      rcx, [rbp-0x318]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Bounding():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x338]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Lacunarity():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x358]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Gain():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x378]
 
G_M000_IG25:                ;; offset=0x07A7
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_WeightedStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x398]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       xor      eax, eax
       cmp      eax, r14d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jge      G_M000_IG13
 
G_M000_IG26:                ;; offset=0x07E8
       vmovss   xmm9, dword ptr [reloc @RWD132]
       vmovss   xmm13, dword ptr [rbp-0x2BC]
       vucomiss xmm13, xmm9
       jp       G_M000_IG60
       jne      G_M000_IG60
       vmovss   dword ptr [rbp+0x184], xmm8
 
G_M000_IG27:                ;; offset=0x0811
       mov      dword ptr [rbp-0x39C], eax
       lea      edx, [r15+rax]
       lea      rcx, [rbp-0x3D8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x238]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x258]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x278]
       vmovups  ymmword ptr [rbp-0xE78], ymm0
       lea      r9, [rbp-0xE38]
       lea      rcx, [rbp-0xE58]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xE78]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x3F8]
       lea      rdx, [rbp-0x130]
       lea      r8, [rbp-0x3D8]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Single3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       cmp      eax, 2
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
       je       G_M000_IG61
       cmp      eax, 3
       je       G_M000_IG64
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x658]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x318]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x318]
       lea      r8, [rbp-0x658]
 
G_M000_IG28:                ;; offset=0x0947
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x678]
       vmovaps  xmm1, xmm9
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x698]
       lea      rdx, [rbp-0x3F8]
       lea      r8, [rbp-0x678]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6B8]
       vmovss   xmm1, dword ptr [reloc @RWD136]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4D8]
       lea      rdx, [rbp-0x698]
       lea      r8, [rbp-0x6B8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
 
G_M000_IG29:                ;; offset=0x09BC
       lea      rcx, [rbp-0x4F8]
       vmovaps  xmm1, xmm9
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x398]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      r9, [rbp-0xE38]
       lea      rdx, [rbp-0x4F8]
       lea      r8, [rbp-0x4D8]
       lea      rcx, [rbp-0x518]
       call     [Tedd.FastNoise.Internal.NoiseMath:Lerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x338]
       lea      r8, [rbp-0x518]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x238]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x358]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x238]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x258]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x358]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x258]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x278]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x358]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x278]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x378]
 
G_M000_IG30:                ;; offset=0x0B06
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x338]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      eax, dword ptr [rbp-0x39C]
       inc      eax
       cmp      eax, r14d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
       jge      G_M000_IG14
 
G_M000_IG31:                ;; offset=0x0B4C
       vmovss   xmm8, dword ptr [rbp+0x184]
       jmp      G_M000_IG26
 
G_M000_IG32:                ;; offset=0x0B59
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1020]
       vmovaps  xmm7, xmmword ptr [rsp+0x1010]
       vmovaps  xmm8, xmmword ptr [rsp+0x1000]
       vmovaps  xmm9, xmmword ptr [rsp+0xFF0]
       vmovaps  xmm10, xmmword ptr [rsp+0xFE0]
       vmovaps  xmm11, xmmword ptr [rsp+0xFD0]
       vmovaps  xmm12, xmmword ptr [rsp+0xFC0]
       vmovaps  xmm13, xmmword ptr [rsp+0xFB0]
       vmovaps  xmm14, xmmword ptr [rsp+0xFA0]
       vmovaps  xmm15, xmmword ptr [rsp+0xF90]
       add      rsp, 0x1218
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG33:                ;; offset=0x0BCA
       vmovd    xmm1, r15d
       vpbroadcastd ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x298], ymm1
       mov      r14d, dword ptr [rbp-0x130]
       cmp      r14d, 5
       mov      dword ptr [rbp+0x19C], r11d
       ja       SHORT G_M000_IG35
       lea      r15, [reloc @RWD140]
       mov      r15d, dword ptr [r15+4*r14]
       lea      r11, G_M000_IG02
       add      r15, r11
       jmp      r15
 
G_M000_IG34:                ;; offset=0x0C08
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x0C1F
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
 
G_M000_IG36:                ;; offset=0x0C34
       lea      rcx, [rbp-0x6F8]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG57
 
G_M000_IG37:                ;; offset=0x0C6E
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       vmovups  ymmword ptr [rbp-0xE38], ymm13
       vmovups  ymmword ptr [rbp-0xE58], ymm14
       vmovups  ymmword ptr [rbp-0xE78], ymm15
       lea      r8, [rbp-0xE38]
       lea      r9, [rbp-0xE58]
       lea      r11, [rbp-0xE78]
       mov      qword ptr [rsp+0x20], r11
       lea      rdx, [rbp-0x298]
       lea      rcx, [rbp-0x6F8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG57
 
G_M000_IG38:                ;; offset=0x0CF2
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       vmovups  ymmword ptr [rbp-0xE38], ymm13
       vmovups  ymmword ptr [rbp-0xE58], ymm14
       vmovups  ymmword ptr [rbp-0xE78], ymm15
       mov      r11d, dword ptr [rbp-0x128]
       mov      dword ptr [rsp+0x28], r11d
       mov      r11d, dword ptr [rbp-0x124]
       mov      dword ptr [rsp+0x30], r11d
       vmovss   xmm1, dword ptr [rbp-0x120]
       vmovss   dword ptr [rsp+0x38], xmm1
       lea      r8, [rbp-0xE38]
       lea      r9, [rbp-0xE58]
       lea      r11, [rbp-0xE78]
       mov      qword ptr [rsp+0x20], r11
       lea      rdx, [rbp-0x298]
       lea      rcx, [rbp-0x6F8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.CellularKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,int,float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG57
 
G_M000_IG39:                ;; offset=0x0D9C
       vcmpeqps ymm1, ymm13, ymm13
       vandps   ymm1, ymm1, ymm13
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vcmpeqps ymm2, ymm14, ymm14
       vandps   ymm2, ymm2, ymm14
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vxorps   ymm3, ymm3, ymm3
       vcmpltps ymm3, ymm14, ymm3
       vpaddd   ymm2, ymm3, ymm2
       vcmpeqps ymm3, ymm15, ymm15
       vandps   ymm3, ymm3, ymm15
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vxorps   ymm4, ymm4, ymm4
       vcmpltps ymm4, ymm15, ymm4
       vpaddd   ymm3, ymm4, ymm3
       vcvtdq2ps ymm4, ymm1
       vsubps   ymm4, ymm13, ymm4
       vmovups  ymmword ptr [rbp-0x778], ymm4
       vcvtdq2ps ymm5, ymm2
       vsubps   ymm5, ymm14, ymm5
       vmovups  ymmword ptr [rbp-0x798], ymm5
       vcvtdq2ps ymm13, ymm3
       vsubps   ymm14, ymm15, ymm13
       vsubps   ymm15, ymm4, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x7B8], ymm15
       vsubps   ymm13, ymm5, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x7D8], ymm13
       vsubps   ymm13, ymm14, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x7F8], ymm13
       vmulps   ymm13, ymm4, ymm4
       vmulps   ymm13, ymm13, ymm4
       vmulps   ymm15, ymm4, ymmword ptr [reloc @RWD288]
       vsubps   ymm15, ymm15, ymmword ptr [reloc @RWD320]
       vmulps   ymm15, ymm15, ymm4
       vaddps   ymm15, ymm15, ymmword ptr [reloc @RWD352]
       vmulps   ymm13, ymm15, ymm13
       vmovups  ymmword ptr [rbp-0x818], ymm13
       vmulps   ymm15, ymm5, ymm5
       vmulps   ymm15, ymm15, ymm5
       vmulps   ymm13, ymm5, ymmword ptr [reloc @RWD288]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD320]
       vmulps   ymm13, ymm13, ymm5
       vaddps   ymm13, ymm13, ymmword ptr [reloc @RWD352]
       vmulps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x838], ymm13
       vmulps   ymm15, ymm14, ymm14
       vmulps   ymm15, ymm15, ymm14
       vmulps   ymm13, ymm14, ymmword ptr [reloc @RWD288]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD320]
       vmulps   ymm13, ymm13, ymm14
       vaddps   ymm13, ymm13, ymmword ptr [reloc @RWD352]
 
G_M000_IG40:                ;; offset=0x0F0B
       vmulps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x858], ymm13
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD416]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD448]
       vpaddd   ymm15, ymm1, ymmword ptr [reloc @RWD384]
       vmovups  ymmword ptr [rbp-0x878], ymm15
       vpaddd   ymm13, ymm2, ymmword ptr [reloc @RWD416]
       vmovups  ymmword ptr [rbp-0x898], ymm13
       vpaddd   ymm13, ymm3, ymmword ptr [reloc @RWD448]
       vmovups  ymmword ptr [rbp-0x8B8], ymm13
       vmovups  ymmword ptr [rbp-0x718], ymm1
       vpxor    ymm13, ymm1, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0x738], ymm2
       vpxor    ymm13, ymm13, ymm2
       vmovups  ymmword ptr [rbp-0x758], ymm3
       vpxor    ymm13, ymm13, ymm3
       vpmulld  ymm13, ymm13, ymmword ptr [reloc @RWD480]
       vpsrad   ymm1, ymm13, 15
       vpxor    ymm1, ymm1, ymm13
       vpand    ymm13, ymm1, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm1, ymm13, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm3, dword ptr [r11+4*xmm1], ymm13
       vpand    ymm1, ymm3, ymmword ptr [reloc @RWD544]
       vxorps   ymm13, ymm13, ymm13
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm1
       vpslld   ymm15, ymm3, 29
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymm4
       vblendvps ymm2, ymm15, ymm13, ymm2
       vpcmpeqd ymm15, ymm1, ymmword ptr [reloc @RWD608]
       vpslld   ymm4, ymm3, 28
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymm5
       vblendvps ymm4, ymm4, ymm13, ymm15
       vaddps   ymm2, ymm4, ymm2
       vpcmpeqd ymm1, ymm1, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm3, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vpxor    ymm3, ymm3, ymm14
       vblendvps ymm1, ymm3, ymm13, ymm1
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0x8D8], ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x878]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x738]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x758]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm13, ymm2, 15
       vpxor    ymm2, ymm13, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
 
G_M000_IG41:                ;; offset=0x108B
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm3, dword ptr [r11+4*xmm2], ymm13
       vpand    ymm2, ymm3, ymmword ptr [reloc @RWD544]
       vxorps   ymm13, ymm13, ymm13
       vxorps   ymm4, ymm4, ymm4
       vpcmpeqd ymm4, ymm4, ymm2
       vpslld   ymm15, ymm3, 29
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7B8]
       vblendvps ymm4, ymm15, ymm13, ymm4
       vpcmpeqd ymm15, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm1, ymm3, 28
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD576]
       vpxor    ymm1, ymm1, ymm5
       vblendvps ymm1, ymm1, ymm13, ymm15
       vaddps   ymm1, ymm1, ymm4
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm3, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vpxor    ymm3, ymm3, ymm14
       vblendvps ymm2, ymm3, ymm13, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x8D8]
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x818]
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0x8F8], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x718]
       vpxor    ymm3, ymm2, ymmword ptr [rbp-0x298]
       vmovups  ymm4, ymmword ptr [rbp-0x898]
       vpxor    ymm3, ymm3, ymm4
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x758]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpsrad   ymm2, ymm3, 15
       vpxor    ymm3, ymm2, ymm3
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm3, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm15, dword ptr [r11+4*xmm2], ymm3
       vpand    ymm2, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm2
       vpslld   ymm5, ymm15, 29
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x778]
       vblendvps ymm1, ymm5, ymm3, ymm1
       vpcmpeqd ymm5, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm13, ymm15, 28
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x7D8]
       vblendvps ymm5, ymm13, ymm3, ymm5
 
G_M000_IG42:                ;; offset=0x11E8
       vaddps   ymm1, ymm5, ymm1
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm15, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm14
       vblendvps ymm2, ymm5, ymm3, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x878]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymm4
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x758]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [r11+4*xmm2], ymm3
       vpand    ymm2, ymm5, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm2
       vpslld   ymm4, ymm5, 29
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x7B8]
       vblendvps ymm4, ymm4, ymm3, ymm13
       vpcmpeqd ymm13, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7D8]
       vblendvps ymm13, ymm15, ymm3, ymm13
       vaddps   ymm4, ymm13, ymm4
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm14
       vblendvps ymm2, ymm5, ymm3, ymm2
       vaddps   ymm2, ymm2, ymm4
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x818]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x918], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x718]
       vpxor    ymm3, ymm2, ymmword ptr [rbp-0x298]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x738]
       vmovups  ymm5, ymmword ptr [rbp-0x8B8]
       vpxor    ymm3, ymm3, ymm5
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpsrad   ymm14, ymm3, 15
       vpxor    ymm3, ymm14, ymm3
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
 
G_M000_IG43:                ;; offset=0x1349
       vpsrld   ymm3, ymm3, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm15, dword ptr [r11+4*xmm3], ymm14
       vpand    ymm3, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm14, ymm14, ymm14
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm3
       vpslld   ymm4, ymm15, 29
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x778]
       vblendvps ymm2, ymm4, ymm14, ymm2
       vpcmpeqd ymm4, ymm3, ymmword ptr [reloc @RWD608]
       vpslld   ymm1, ymm15, 28
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD576]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x798]
       vblendvps ymm1, ymm1, ymm14, ymm4
       vaddps   ymm1, ymm1, ymm2
       vpcmpeqd ymm2, ymm3, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm15, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vmovups  ymm4, ymmword ptr [rbp-0x7F8]
       vpxor    ymm3, ymm3, ymm4
       vblendvps ymm2, ymm3, ymm14, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x878]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x738]
       vpxor    ymm2, ymm2, ymm5
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm14, dword ptr [r11+4*xmm2], ymm3
       vpand    ymm2, ymm14, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm15, ymm15, ymm15
       vpcmpeqd ymm15, ymm15, ymm2
       vpslld   ymm5, ymm14, 29
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x7B8]
       vblendvps ymm5, ymm5, ymm3, ymm15
       vpcmpeqd ymm15, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm13, ymm14, 28
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x798]
       vblendvps ymm13, ymm13, ymm3, ymm15
       vaddps   ymm5, ymm13, ymm5
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm13, ymm14, 27
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymm4
       vblendvps ymm2, ymm13, ymm3, ymm2
 
G_M000_IG44:                ;; offset=0x14AD
       vaddps   ymm2, ymm2, ymm5
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x818]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x938], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x718]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x298]
       vmovups  ymm3, ymmword ptr [rbp-0x898]
       vpxor    ymm2, ymm2, ymm3
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x8B8]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm14, ymm2, 15
       vpxor    ymm2, ymm14, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm15, dword ptr [r11+4*xmm2], ymm14
       vpand    ymm2, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm14, ymm14, ymm14
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm2
       vpslld   ymm13, ymm15, 29
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x778]
       vblendvps ymm1, ymm13, ymm14, ymm1
       vpcmpeqd ymm13, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm5, ymm15, 28
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x7D8]
       vblendvps ymm5, ymm5, ymm14, ymm13
       vaddps   ymm1, ymm5, ymm1
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm15, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm4
       vblendvps ymm2, ymm5, ymm14, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x878]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymm3
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x8B8]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [r11+4*xmm2], ymm3
       vpand    ymm2, ymm5, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm2
 
G_M000_IG45:                ;; offset=0x1610
       vpslld   ymm14, ymm5, 29
       vpand    ymm14, ymm14, ymmword ptr [reloc @RWD576]
       vpxor    ymm14, ymm14, ymmword ptr [rbp-0x7B8]
       vblendvps ymm13, ymm14, ymm3, ymm13
       vpcmpeqd ymm14, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7D8]
       vblendvps ymm14, ymm15, ymm3, ymm14
       vaddps   ymm13, ymm14, ymm13
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm5, ymm4
       vblendvps ymm2, ymm4, ymm3, ymm2
       vaddps   ymm2, ymm2, ymm13
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x818]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x918]
       vmovups  ymm3, ymmword ptr [rbp-0x8F8]
       vsubps   ymm2, ymm2, ymm3
       vmovups  ymm13, ymmword ptr [rbp-0x838]
       vmulps   ymm2, ymm2, ymm13
       vaddps   ymm2, ymm2, ymm3
       vmovups  ymm3, ymmword ptr [rbp-0x938]
       vsubps   ymm1, ymm1, ymm3
       vmulps   ymm1, ymm1, ymm13
       vaddps   ymm1, ymm1, ymm3
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x858]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD672]
       vmovups  ymmword ptr [rbp-0x6F8], ymm1
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       jmp      G_M000_IG57
 
G_M000_IG46:                ;; offset=0x16FB
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       vcmpeqps ymm1, ymm13, ymm13
       vandps   ymm1, ymm1, ymm13
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x958], ymm1
       vcmpeqps ymm1, ymm14, ymm14
       vandps   ymm1, ymm1, ymm14
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm14, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x978], ymm1
       vcmpeqps ymm1, ymm15, ymm15
       vandps   ymm1, ymm1, ymm15
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm15, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x998], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x958]
       vsubps   ymm1, ymm13, ymm1
       vmovups  ymmword ptr [rbp-0x9B8], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x978]
       vsubps   ymm1, ymm14, ymm1
       vmovups  ymmword ptr [rbp-0x9D8], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x998]
       vsubps   ymm1, ymm15, ymm1
       vmovups  ymmword ptr [rbp-0x9F8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x958]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vmovups  ymmword ptr [rbp-0x958], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x978]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD416]
       vmovups  ymmword ptr [rbp-0x978], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x998]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD448]
       vmovups  ymmword ptr [rbp-0x998], ymm1
       vbroadcastss ymm1, dword ptr [reloc @RWD384]
       vbroadcastss ymm2, dword ptr [reloc @RWD416]
       vbroadcastss ymm3, dword ptr [reloc @RWD448]
       vmovups  ymm4, ymmword ptr [rbp-0x958]
       vpsubd   ymm4, ymm4, ymm1
       vmovups  ymmword ptr [rbp-0xA18], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x978]
       vpsubd   ymm4, ymm4, ymm2
       vmovups  ymmword ptr [rbp-0xA38], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x998]
       vpsubd   ymm4, ymm4, ymm3
 
G_M000_IG47:                ;; offset=0x188B
       vmovups  ymmword ptr [rbp-0xA58], ymm4
       vpaddd   ymm1, ymm1, ymmword ptr [rbp-0x958]
       vmovups  ymmword ptr [rbp-0xA78], ymm1
       vpaddd   ymm1, ymm2, ymmword ptr [rbp-0x978]
       vmovups  ymmword ptr [rbp-0xA98], ymm1
       vpaddd   ymm1, ymm3, ymmword ptr [rbp-0x998]
       vmovups  ymmword ptr [rbp-0xAB8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x958]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD704]
       vmovups  ymmword ptr [rbp-0xAD8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x978]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD736]
       vmovups  ymmword ptr [rbp-0xAF8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x998]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD768]
       vmovups  ymmword ptr [rbp-0xB18], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x298]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA18]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA38]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA58]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x958]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA38]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA58]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x298]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA78]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA38]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA58]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x298]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAD8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA38]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA58]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
 
G_M000_IG48:                ;; offset=0x1A23
       vmovups  ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm14, ymm13, ymm4
       vsubps   ymm15, ymm1, ymm2
       vsubps   ymm4, ymm15, ymm4
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm14
       vsubps   ymm1, ymm3, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9B8]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xBF8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x298]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA18]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x978]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA58]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x958]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x978]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA58]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x298]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA78]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x978]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA58]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x298]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAD8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x978]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA58]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
       vmovups  ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9B8]
 
G_M000_IG49:                ;; offset=0x1B9C
       vmulps   ymm13, ymm13, ymm4
       vsubps   ymm14, ymm1, ymm2
       vsubps   ymm4, ymm14, ymm4
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm13
       vsubps   ymm1, ymm3, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9B8]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xC18], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x298]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA18]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA98]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA58]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x958]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA98]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA58]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x298]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA78]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA98]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA58]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x298]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAD8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA98]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA58]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
       vmovups  ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm13, ymm13, ymm4
       vsubps   ymm14, ymm1, ymm2
       vsubps   ymm4, ymm14, ymm4
 
G_M000_IG50:                ;; offset=0x1D09
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm13
       vsubps   ymm1, ymm3, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9B8]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xC38], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0xA18]
       vmovups  ymmword ptr [rbp-0xEB8], ymm1
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      rcx, [rbp-0xDB8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       lea      r8, [rbp-0xE98]
       lea      rdx, [rbp-0xDB8]
       lea      rcx, [rbp-0xDD8]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xA58]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       lea      r8, [rbp-0xE98]
       lea      rdx, [rbp-0xDD8]
       lea      rcx, [rbp-0xDF8]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xE18]
       mov      edx, 0x27D4EB2D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xCF8]
       lea      rdx, [rbp-0xDF8]
       lea      r8, [rbp-0xE18]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF8]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       lea      rdx, [rbp-0xE98]
       lea      rcx, [rbp-0xD18]
       lea      r8, [rbp-0xCF8]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xD18]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
 
G_M000_IG51:                ;; offset=0x1E39
       lea      rdx, [rbp-0xE98]
       lea      rcx, [rbp-0xD38]
       mov      r8d, 19
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftLeft(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xD58]
       lea      rdx, [rbp-0xD18]
       lea      r8, [rbp-0xD38]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xD78]
       lea      rdx, [rbp-0xD58]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xD98]
       vmovss   xmm1, dword ptr [reloc @RWD800]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xC78]
       lea      rdx, [rbp-0xD78]
       lea      r8, [rbp-0xD98]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x958]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA58]
       vmovups  ymmword ptr [rbp-0xEF8], ymm0
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
       lea      rcx, [rbp-0xEF8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xC98]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA78]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA58]
       vmovups  ymmword ptr [rbp-0xEF8], ymm0
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
 
G_M000_IG52:                ;; offset=0x1F75
       lea      rcx, [rbp-0xEF8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xCB8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD8]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       lea      rdx, [rbp-0xA58]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
       lea      rcx, [rbp-0xCD8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xCD8]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9B8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xC78]
       lea      r8, [rbp-0xC98]
       lea      r9, [rbp-0xCB8]
       lea      rcx, [rbp-0xC58]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xC58]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9D8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xBF8]
       lea      r8, [rbp-0xC18]
       lea      r9, [rbp-0xC38]
       lea      rcx, [rbp-0xB38]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA18]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x958]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA78]
       vmovups  ymmword ptr [rbp-0xEF8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD8]
       vmovups  ymmword ptr [rbp-0xF18], ymm0
 
G_M000_IG53:                ;; offset=0x20D0
       vmovups  ymm0, ymmword ptr [rbp-0xA38]
       vmovups  ymmword ptr [rbp-0xF38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x978]
       vmovups  ymmword ptr [rbp-0xF58], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA98]
       vmovups  ymmword ptr [rbp-0xF78], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xF98], ymm0
       lea      rdx, [rbp-0x998]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9B8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D8]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
       lea      rcx, [rbp-0xEF8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xF18]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF38]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF58]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF78]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xF98]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE38]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE58]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB58]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA18]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x958]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA78]
       vmovups  ymmword ptr [rbp-0xEF8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD8]
       vmovups  ymmword ptr [rbp-0xF18], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA38]
       vmovups  ymmword ptr [rbp-0xF38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x978]
       vmovups  ymmword ptr [rbp-0xF58], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA98]
       vmovups  ymmword ptr [rbp-0xF78], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xF98], ymm0
       lea      rdx, [rbp-0xAB8]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9B8]
 
G_M000_IG54:                ;; offset=0x2262
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D8]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
       lea      rcx, [rbp-0xEF8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xF18]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF38]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF58]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF78]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xF98]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE38]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE58]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB78]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xA78]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xAD8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xA38]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0x978]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xA98]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xAF8]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xB18]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x9B8]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0x9D8]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB98]
       lea      rdx, [rbp-0x298]
       lea      r8, [rbp-0xA18]
       lea      r9, [rbp-0x958]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB98]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x9F8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xBB8]
       lea      rdx, [rbp-0xB38]
       lea      r8, [rbp-0xB58]
 
G_M000_IG55:                ;; offset=0x23B7
       lea      r9, [rbp-0xB78]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xBD8]
       vmovss   xmm1, dword ptr [reloc @RWD832]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6F8]
       lea      rdx, [rbp-0xBB8]
       lea      r8, [rbp-0xBD8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG57
 
G_M000_IG56:                ;; offset=0x240B
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       vmovups  ymmword ptr [rbp-0xE38], ymm13
       vmovups  ymmword ptr [rbp-0xE58], ymm14
       vmovups  ymmword ptr [rbp-0xE78], ymm15
       lea      r8, [rbp-0xE38]
       lea      r9, [rbp-0xE58]
       lea      r11, [rbp-0xE78]
       mov      qword ptr [rsp+0x20], r11
       lea      rdx, [rbp-0x298]
       lea      rcx, [rbp-0x6F8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.ValueKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG57:                ;; offset=0x248A
       lea      rcx, [rbp-0x150]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       test     eax, eax
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       je       SHORT G_M000_IG58
       vmovups  ymm0, ymmword ptr [rbp-0x6F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      r8, [rbp-0xE38]
       lea      rdx, [rbp-0x150]
       lea      rcx, [rbp-0x2B8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:ShapeSingle[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x2510
       vmovups  ymm1, ymmword ptr [rbp-0x6F8]
       vmovups  ymmword ptr [rbp-0x2B8], ymm1
 
G_M000_IG59:                ;; offset=0x2520
       lea      rcx, [rbp-0x2F8]
       vmovss   xmm1, dword ptr [rbp-0x2BC]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x218]
       lea      rdx, [rbp-0x2B8]
       lea      r8, [rbp-0x2F8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG15
 
G_M000_IG60:                ;; offset=0x2579
       lea      ecx, [r14-0x01]
       mov      dword ptr [rbp-0x39C], eax
       cmp      eax, ecx
       jne      G_M000_IG63
       lea      rcx, [rbp-0x6D8]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmmword ptr [rbp+0x120], ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x338]
       lea      r8, [rbp-0x6D8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmmword ptr [rbp+0x120]
       vmovss   dword ptr [rbp+0x184], xmm8
       mov      eax, dword ptr [rbp-0x39C]
       jmp      G_M000_IG27
 
G_M000_IG61:                ;; offset=0x2607
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x3F8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Abs(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x418]
       vmovss   xmm1, dword ptr [reloc @RWD836]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x438]
       lea      r8, [rbp-0x418]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x458]
       vmovaps  xmm1, xmm9
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x478]
       lea      rdx, [rbp-0x438]
       lea      r8, [rbp-0x458]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      r8, [rbp-0xE38]
       lea      rdx, [rbp-0x478]
       lea      rcx, [rbp-0x498]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x318]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x318]
       lea      r8, [rbp-0x498]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4B8]
       vmovaps  xmm1, xmm9
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4D8]
       lea      rdx, [rbp-0x4B8]
       lea      r8, [rbp-0x3F8]
 
G_M000_IG62:                ;; offset=0x2727
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
       jmp      G_M000_IG29
 
G_M000_IG63:                ;; offset=0x2744
       vmovss   dword ptr [rbp+0x184], xmm8
       mov      eax, dword ptr [rbp-0x39C]
       jmp      G_M000_IG27
 
G_M000_IG64:                ;; offset=0x2757
       lea      rcx, [rbp-0x538]
       vmovaps  xmm1, xmm9
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x558]
       lea      rdx, [rbp-0x3F8]
       lea      r8, [rbp-0x538]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_PingPongStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x578]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x598]
       lea      rdx, [rbp-0x558]
       lea      r8, [rbp-0x578]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x3F8]
       lea      rdx, [rbp-0x598]
       call     [Tedd.FastNoise.Internal.NoiseMath:PingPong[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5B8]
       vmovss   xmm1, dword ptr [reloc @RWD136]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x5D8]
       lea      r8, [rbp-0x5B8]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5F8]
       vmovss   xmm1, dword ptr [reloc @RWD840]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x618]
       lea      rdx, [rbp-0x5D8]
       lea      r8, [rbp-0x5F8]
 
G_M000_IG65:                ;; offset=0x284D
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      r8, [rbp-0xE38]
       lea      rdx, [rbp-0x618]
       lea      rcx, [rbp-0x638]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x318]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x318]
       lea      r8, [rbp-0x638]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0x4D8], ymm0
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
       jmp      G_M000_IG29
 
G_M000_IG66:                ;; offset=0x28D0
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dq	0000000100000000h, 0000000300000002h, 0000000500000004h, 0000000700000006h
RWD32  	dd	000004FEh ; case G_M000_IG23
       	dd	000004C2h ; case G_M000_IG22
       	dd	00000498h ; case G_M000_IG21
RWD44  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD64  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD96  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD128 	dd	3F13CD3Ah		;   0.57735
RWD132 	dd	3F800000h		;         1
RWD136 	dd	3F000000h		;       0.5
RWD140 	dd	00000B0Bh ; case G_M000_IG37
       	dd	00000AA5h ; case G_M000_IG34
       	dd	00000B8Fh ; case G_M000_IG38
       	dd	00000C39h ; case G_M000_IG39
       	dd	00001598h ; case G_M000_IG46
       	dd	000022A8h ; case G_M000_IG56
RWD164 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD192 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD224 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD256 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD288 	dq	40C0000040C00000h, 40C0000040C00000h, 40C0000040C00000h, 40C0000040C00000h
RWD320 	dq	4170000041700000h, 4170000041700000h, 4170000041700000h, 4170000041700000h
RWD352 	dq	4120000041200000h, 4120000041200000h, 4120000041200000h, 4120000041200000h
RWD384 	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD416 	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD448 	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD480 	dq	27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh
RWD512 	dq	000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh
RWD544 	dq	0000000300000003h, 0000000300000003h, 0000000300000003h, 0000000300000003h
RWD576 	dq	8000000080000000h, 8000000080000000h, 8000000080000000h, 8000000080000000h
RWD608 	dq	0000000100000001h, 0000000100000001h, 0000000100000001h, 0000000100000001h
RWD640 	dq	0000000200000002h, 0000000200000002h, 0000000200000002h, 0000000200000002h
RWD672 	dq	3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h
RWD704 	dq	3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h
RWD736 	dq	87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah
RWD768 	dq	CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh
RWD800 	dq	3000000030000000h, 3000000030000000h, 3000000030000000h, 3000000030000000h
RWD832 	dd	3E97B426h		;  0.296296
RWD836 	dd	C0000000h		;        -2
RWD840 	dd	40000000h		;         2

; Total bytes of code 10454

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 2 inlinees with PGO data; 182 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 544
       vmovaps  xmmword ptr [rsp+0x210], xmm6
       vmovaps  xmmword ptr [rsp+0x200], xmm7
       vmovaps  xmmword ptr [rsp+0x1F0], xmm8
       vmovaps  xmmword ptr [rsp+0x1E0], xmm9
       vmovaps  xmmword ptr [rsp+0x1D0], xmm10
       vmovaps  xmmword ptr [rsp+0x1C0], xmm11
       vmovaps  xmmword ptr [rsp+0x1B0], xmm12
       vmovaps  xmmword ptr [rsp+0x1A0], xmm13
       vmovaps  xmmword ptr [rsp+0x190], xmm14
       vmovaps  xmmword ptr [rsp+0x180], xmm15
       mov      rbx, rdx
       mov      rax, bword ptr [rsp+0x270]
 
G_M000_IG02:                ;; offset=0x0072
       mov      edx, dword ptr [rcx+0x64]
       vbroadcastss ymm0, dword ptr [rcx+0x0C]
       vmulps   ymm1, ymm0, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       dec      edx
       cmp      edx, 2
       jne      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x00A2
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm1, ymm0, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD00]
       vsubps   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [r8], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x00D3
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       vmovups  ymm6, ymmword ptr [r8]
       vmovups  ymm7, ymmword ptr [r9]
       vmovups  ymm8, ymmword ptr [rax]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  ymm9, ymm6
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovss   xmm12, dword ptr [rcx+0x38]
       vmovss   dword ptr [rsp+0x14C], xmm12
       cmp      dword ptr [rsi], 0
       je       G_M000_IG15
       cmp      ebp, 1
       jle      G_M000_IG15
       vxorps   ymm6, ymm6, ymm6
       vmovups  ymmword ptr [rsp+0x110], ymm6
       vbroadcastss ymm7, dword ptr [rsi+0x18]
       vbroadcastss ymm8, dword ptr [rsi+0x08]
       vbroadcastss ymm13, dword ptr [rsi+0x0C]
       vmovups  ymmword ptr [rsp+0xF0], ymm13
       vbroadcastss ymm14, dword ptr [rsi+0x10]
       vmovups  ymmword ptr [rsp+0xD0], ymm14
       xor      r14d, r14d
       cmp      r14d, ebp
       jge      G_M000_IG09
 
G_M000_IG05:                ;; offset=0x015F
       vucomiss xmm12, dword ptr [reloc @RWD32]
       jp       G_M000_IG21
       jne      G_M000_IG21
 
G_M000_IG06:                ;; offset=0x0173
       lea      edx, [rdi+r14]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm9
       vmovups  ymmword ptr [rsp+0x50], ymm10
       vmovups  ymmword ptr [rsp+0x30], ymm11
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xB0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm12, ymm7
       vextractf128 xmm6, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rsi]
       cmp      edx, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm10, ymm10, xmm13
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm12
       vinsertf128 ymm8, ymm8, xmm6
       je       G_M000_IG22
       cmp      edx, 3
       je       G_M000_IG24
       vmulps   ymm0, ymm7, ymmword ptr [rsp+0xB0]
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
 
G_M000_IG07:                ;; offset=0x0241
       vsubps   ymm0, ymm0, ymm12
       vmovups  ymm14, ymmword ptr [rsp+0xD0]
       vmulps   ymm0, ymm0, ymm14
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       vmulps   ymm9, ymm9, ymm8
       vmulps   ymm10, ymm10, ymm8
       vmulps   ymm11, ymm11, ymm8
       vmovups  ymm13, ymmword ptr [rsp+0xF0]
       vmulps   ymm7, ymm7, ymm13
       inc      r14d
       cmp      r14d, ebp
       vmovss   xmm12, dword ptr [rsp+0x14C]
       jge      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x028B
       vmovups  ymmword ptr [rsp+0x110], ymm6
       jmp      G_M000_IG05
 
G_M000_IG09:                ;; offset=0x0299
       vmovups  ymm6, ymmword ptr [rsp+0x110]
 
G_M000_IG10:                ;; offset=0x02A2
       vmovups  ymmword ptr [rbx], ymm6
       mov      rax, rbx
 
G_M000_IG11:                ;; offset=0x02A9
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x210]
       vmovaps  xmm7, xmmword ptr [rsp+0x200]
       vmovaps  xmm8, xmmword ptr [rsp+0x1F0]
       vmovaps  xmm9, xmmword ptr [rsp+0x1E0]
       vmovaps  xmm10, xmmword ptr [rsp+0x1D0]
       vmovaps  xmm11, xmmword ptr [rsp+0x1C0]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B0]
       vmovaps  xmm13, xmmword ptr [rsp+0x1A0]
       vmovaps  xmm14, xmmword ptr [rsp+0x190]
       vmovaps  xmm15, xmmword ptr [rsp+0x180]
       add      rsp, 544
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG12:                ;; offset=0x0314
       cmp      edx, 2
       ja       G_M000_IG04
       mov      edx, edx
       lea      r10, [reloc @RWD96]
       mov      r10d, dword ptr [r10+4*rdx]
       lea      r11, G_M000_IG02
       add      r10, r11
       jmp      r10
 
G_M000_IG13:                ;; offset=0x0337
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD128]
       vmovups  ymm2, ymmword ptr [rax]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD160]
       vmovups  ymmword ptr [rax], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [rax]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vaddps   ymm1, ymm1, ymmword ptr [r9]
       vsubps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       jmp      G_M000_IG04
 
G_M000_IG14:                ;; offset=0x038A
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD128]
       vmovups  ymm2, ymmword ptr [r9]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD160]
       vmovups  ymmword ptr [r9], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [r9]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vsubps   ymm1, ymm1, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       jmp      G_M000_IG04
 
G_M000_IG15:                ;; offset=0x03E0
       vmovd    xmm0, edi
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm6
       vmovups  ymmword ptr [rsp+0x50], ymm7
       vmovups  ymmword ptr [rsp+0x30], ymm8
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x150]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG19
       vbroadcastss ymm0, dword ptr [rsi+0x18]
       mov      eax, dword ptr [rsi]
       cmp      eax, 2
       je       SHORT G_M000_IG16
       cmp      eax, 3
       je       SHORT G_M000_IG17
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x150]
       jmp      G_M000_IG18
 
G_M000_IG16:                ;; offset=0x0457
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD192]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vbroadcastss ymm2, dword ptr [reloc @RWD32]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0486
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x150]
       vbroadcastss ymm3, dword ptr [rsi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD192], ymm4
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD288]
       vsubps   ymm3, ymm3, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD64]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vmulps   ymm1, ymm1, ymm0
 
G_M000_IG18:                ;; offset=0x0506
       jmp      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0508
       vmovups  ymm1, ymmword ptr [rsp+0x150]
 
G_M000_IG20:                ;; offset=0x0511
       vbroadcastss ymm0, ymm12
       vmulps   ymm6, ymm0, ymm1
       jmp      G_M000_IG10
 
G_M000_IG21:                ;; offset=0x051F
       lea      edx, [rbp-0x01]
       cmp      r14d, edx
       jne      SHORT G_M000_IG23
       vbroadcastss ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       jmp      G_M000_IG06
 
G_M000_IG22:                ;; offset=0x0535
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vsubps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG07
 
G_M000_IG23:                ;; offset=0x0580
       jmp      G_M000_IG06
 
G_M000_IG24:                ;; offset=0x0585
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vbroadcastss ymm1, dword ptr [rsi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD192], ymm2
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm12
       vbroadcastss ymm2, dword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG07
 
RWD00  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD32  	dd	3F800000h		;         1
RWD36  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD64  	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD96  	dd	000002C5h ; case G_M000_IG13
       	dd	00000318h ; case G_M000_IG14
       	dd	00000030h ; case G_M000_IG03
RWD108 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD128 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD160 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD192 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD224 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h
RWD256 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD288 	dq	4000000040000000h, 4000000040000000h, 4000000040000000h, 4000000040000000h

; Total bytes of code 1574

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3(Tedd.FastNoise.Procedural.CompiledStack3D,Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int,bool) (Tier1-OSR)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0x135
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2
; 9 inlinees with PGO data; 906 single block inlinees; 11 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       mov      rax, qword ptr [rbp]
       push     rax
       lea      r11, [rsp-0x1200]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       mov      qword ptr [rsp+0x1528], r15
       mov      qword ptr [rsp+0x1520], r14
       mov      qword ptr [rsp+0x1518], r13
       mov      qword ptr [rsp+0x1510], r12
       mov      qword ptr [rsp+0x1508], rdi
       mov      qword ptr [rsp+0x1500], rsi
       mov      qword ptr [rsp+0x14F8], rbx
       vmovaps  xmmword ptr [rsp+0x11B0], xmm6
       vmovaps  xmmword ptr [rsp+0x11A0], xmm7
       vmovaps  xmmword ptr [rsp+0x1190], xmm8
       vmovaps  xmmword ptr [rsp+0x1180], xmm9
       vmovaps  xmmword ptr [rsp+0x1170], xmm10
       vmovaps  xmmword ptr [rsp+0x1160], xmm11
       vmovaps  xmmword ptr [rsp+0x1150], xmm12
       vmovaps  xmmword ptr [rsp+0x1140], xmm13
       vmovaps  xmmword ptr [rsp+0x1130], xmm14
       vmovaps  xmmword ptr [rsp+0x1120], xmm15
       lea      rbp, [rsp+0x1200]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -0xE70
       vmovdqa  xmmword ptr [rbp+rax-0x110], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x100], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0xF0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x110], rax
       mov      rdi, gword ptr [rbp+0x348]
       mov      rsi, bword ptr [rbp+0x350]
       mov      rbx, bword ptr [rbp+0x358]
       mov      r14d, dword ptr [rbp+0x360]
       mov      r15d, dword ptr [rbp+0x368]
       mov      r10, gword ptr [rbp+0x2E8]
       mov      r9d, dword ptr [rbp+0x2E4]
       mov      r11d, dword ptr [rbp+0x2E0]
       mov      r8d, dword ptr [rbp+0x2DC]
       vmovss   xmm6, dword ptr [rbp+0x2D8]
       mov      r12d, dword ptr [rbp+0x2D4]
       vmovss   xmm7, dword ptr [rbp+0x2C8]
       vmovss   xmm8, dword ptr [rbp+0x2C4]
       mov      ecx, dword ptr [rbp+0x2C0]
       mov      r13d, dword ptr [rbp+0x2BC]
 
G_M000_IG02:                ;; offset=0x0150
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0152
       mov      ecx, dword ptr [rbp+0x2C0]
       mov      r8d, dword ptr [rbp+0x2DC]
       mov      r9d, dword ptr [rbp+0x2E4]
       mov      r11d, dword ptr [rbp+0x2E0]
 
G_M000_IG04:                ;; offset=0x016D
       cmp      r13d, r11d
       jl       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x0172
       inc      r12d
       lea      eax, [r14+r15]
       cmp      eax, r12d
       jle      G_M000_IG11
 
G_M000_IG06:                ;; offset=0x0182
       mov      eax, r12d
       cdq      
       idiv     edx:eax, r8d
       mov      ecx, edx
       mov      dword ptr [rbp+0x2DC], r8d
       mov      eax, r12d
       cdq      
       idiv     edx:eax, r8d
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, ecx
       vmulss   xmm0, xmm0, xmm6
       vaddss   xmm7, xmm0, dword ptr [rsi+0x04]
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, eax
       vmulss   xmm0, xmm0, xmm6
       vaddss   xmm8, xmm0, dword ptr [rsi+0x08]
       mov      ecx, r12d
       imul     ecx, r11d
       mov      dword ptr [rbp+0x2C0], ecx
       xor      edx, edx
       xor      eax, eax
       test     r10, r10
       jne      G_M000_IG15
 
G_M000_IG07:                ;; offset=0x01D5
       mov      r13d, eax
       mov      ecx, dword ptr [rbp+0x2C0]
       mov      r8d, dword ptr [rbp+0x2DC]
       jmp      SHORT G_M000_IG04
 
G_M000_IG08:                ;; offset=0x01E7
       mov      gword ptr [rbp+0x2E8], r10
       mov      dword ptr [rbp+0x2E0], r11d
       mov      dword ptr [rbp+0x2C0], ecx
       mov      dword ptr [rbp+0x2E4], r9d
       mov      dword ptr [rbp+0x2DC], r8d
       mov      rcx, rsi
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r13d
       vmulss   xmm9, xmm1, xmm6
       vaddss   xmm1, xmm0, xmm9
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       mov      rax, gword ptr [rbp+0x2F0]
       mov      rcx, gword ptr [rax+0x08]
       mov      gword ptr [rbp+0x2F0], rax
       call     [rax+0x18]System.Func`4[float,float,float,float]:Invoke(float,float,float):float:this
       vmovaps  xmm10, xmm0
       vmovaps  xmm0, xmm10
       call     [System.Single:IsNaN(float):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0255
       mov      rcx, rsi
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vaddss   xmm1, xmm0, xmm9
       mov      rcx, rdi
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovaps  xmm10, xmm0
 
G_M000_IG10:                ;; offset=0x0279
       mov      ecx, dword ptr [rbp+0x2C0]
       lea      eax, [rcx+r13]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG73
       lea      eax, [rcx+r13]
       mov      rdx, bword ptr [rbx]
       vmovss   dword ptr [rdx+4*rax], xmm10
       inc      r13d
       mov      r8d, dword ptr [rbp+0x2DC]
       mov      r9d, dword ptr [rbp+0x2E4]
       mov      r10, gword ptr [rbp+0x2E8]
       mov      r11d, dword ptr [rbp+0x2E0]
       jmp      G_M000_IG04
 
G_M000_IG11:                ;; offset=0x02BC
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x11B0]
       vmovaps  xmm7, xmmword ptr [rsp+0x11A0]
       vmovaps  xmm8, xmmword ptr [rsp+0x1190]
       vmovaps  xmm9, xmmword ptr [rsp+0x1180]
       vmovaps  xmm10, xmmword ptr [rsp+0x1170]
       vmovaps  xmm11, xmmword ptr [rsp+0x1160]
       vmovaps  xmm12, xmmword ptr [rsp+0x1150]
       vmovaps  xmm13, xmmword ptr [rsp+0x1140]
       vmovaps  xmm14, xmmword ptr [rsp+0x1130]
       vmovaps  xmm15, xmmword ptr [rsp+0x1120]
       add      rsp, 0x14F8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x032D
       vmovups  ymm0, ymmword ptr [rbp-0x128]
       vmovups  ymmword ptr [rbp+0x260], ymm0
 
G_M000_IG13:                ;; offset=0x033D
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xF80], xmm0
 
G_M000_IG14:                ;; offset=0x0349
       lea      rdx, [rbp-0xF80]
       mov      r8d, r13d
       add      r8d, dword ptr [rbp+0x2C0]
       lea      rcx, [rbp+0x260]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      r13d, dword ptr [rbp-0x104C]
       mov      eax, r13d
       mov      r9d, dword ptr [rbp+0x2E4]
       mov      r10, gword ptr [rbp+0x2E8]
       mov      r11d, dword ptr [rbp+0x2E0]
 
G_M000_IG15:                ;; offset=0x0386
       mov      dword ptr [rbp+0x2E4], r9d
       lea      ecx, [rax+r9]
       mov      dword ptr [rbp+0x2E0], r11d
       cmp      ecx, r11d
       mov      dword ptr [rbp-0x104C], ecx
       mov      r13d, eax
       jg       G_M000_IG03
 
G_M000_IG16:                ;; offset=0x03AA
       vbroadcastss ymm0, ymm6
       vcvtdq2ps ymm1, ymmword ptr [reloc @RWD00]
       vmulps   ymm0, ymm1, ymm0
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r13d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm1, dword ptr [rsi]
       vbroadcastss ymm1, ymm1
       vaddps   ymm9, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0xE08], ymm9
       vbroadcastss ymm0, ymm7
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       vbroadcastss ymm0, ymm8
       vmovups  ymmword ptr [rbp-0xE48], ymm0
       lea      r8, [rbp-0xE08]
       lea      r9, [rbp-0xE28]
       lea      rdx, [rbp-0xE48]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp+0x260]
       mov      rcx, gword ptr [r10+0x08]
       vextractf128 xmm10, ymm9
       mov      gword ptr [rbp+0x2E8], r10
       call     [r10+0x18]System.Func`4[System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]]:Invoke(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this
       vmovups  ymm1, ymmword ptr [rbp+0x260]
       vcmpeqps ymm1, ymm1, ymmword ptr [rbp+0x260]
       vmovmskps rcx, ymm1
       cmp      ecx, 255
       vinsertf128 ymm9, ymm9, xmm10
       je       G_M000_IG13
 
G_M000_IG17:                ;; offset=0x0454
       vbroadcastss ymm11, ymm7
       vmovups  ymmword ptr [rbp-0x108], ymm11
       vbroadcastss ymm12, ymm8
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x140], xmm1
       vmovdqu  xmmword ptr [rbp-0x13C], xmm1
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x160], xmm1
       vmovdqu  xmmword ptr [rbp-0x154], xmm1
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x128], ymm1
       xor      eax, eax
       jmp      G_M000_IG48
 
G_M000_IG18:                ;; offset=0x04A1
       vmovups  ymm0, ymmword ptr [rbp-0x188]
       vmovups  ymmword ptr [rbp-0x208], ymm0
       jmp      G_M000_IG47
 
G_M000_IG19:                ;; offset=0x04B6
       lea      rcx, [rbp-0x308]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Bounding():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x328]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Lacunarity():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x348]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Gain():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x368]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_WeightedStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x388]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      edx, dword ptr [rbp-0x168]
       cmp      eax, edx
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jl       G_M000_IG67
 
G_M000_IG20:                ;; offset=0x0567
       vmovups  ymm0, ymmword ptr [rbp-0x308]
       vmovups  ymmword ptr [rbp-0x228], ymm0
       jmp      G_M000_IG45
 
G_M000_IG21:                ;; offset=0x057C
       vcmpeqps ymm0, ymm13, ymm13
       vandps   ymm0, ymm0, ymm13
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vcmpgeps ymm2, ymm0, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD36]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xA68], ymm0
       vcmpeqps ymm0, ymm14, ymm14
       vandps   ymm0, ymm0, ymm14
       vcmpgeps ymm2, ymm0, ymm1
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm14, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xA88], ymm0
       vcmpeqps ymm0, ymm15, ymm15
       vandps   ymm0, ymm0, ymm15
       vcmpgeps ymm1, ymm0, ymm1
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm1
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm15, ymm1
       vpaddd   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [rbp-0xAA8], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xA68]
       vsubps   ymm0, ymm13, ymm0
       vmovups  ymmword ptr [rbp-0xAC8], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xA88]
       vsubps   ymm0, ymm14, ymm0
       vmovups  ymmword ptr [rbp-0xAE8], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xAA8]
       vsubps   ymm0, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0xB08], ymm0
       vbroadcastss ymm0, dword ptr [reloc @RWD40]
       vpmulld  ymm1, ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xA68], ymm1
       vbroadcastss ymm1, dword ptr [reloc @RWD44]
       vpmulld  ymm2, ymm1, ymmword ptr [rbp-0xA88]
       vmovups  ymmword ptr [rbp-0xA88], ymm2
       vbroadcastss ymm2, dword ptr [reloc @RWD48]
       vpmulld  ymm3, ymm2, ymmword ptr [rbp-0xAA8]
       vmovups  ymmword ptr [rbp-0xAA8], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xA68]
       vpsubd   ymm3, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xB28], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xA88]
       vpsubd   ymm3, ymm3, ymm1
       vmovups  ymmword ptr [rbp-0xB48], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xAA8]
       vpsubd   ymm3, ymm3, ymm2
       vmovups  ymmword ptr [rbp-0xB68], ymm3
       vpaddd   ymm0, ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xB88], ymm0
       vpaddd   ymm0, ymm1, ymmword ptr [rbp-0xA88]
       vmovups  ymmword ptr [rbp-0xBA8], ymm0
 
G_M000_IG22:                ;; offset=0x0701
       vpaddd   ymm0, ymm2, ymmword ptr [rbp-0xAA8]
       vmovups  ymmword ptr [rbp-0xBC8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA68]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rbp-0xBE8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA88]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rbp-0xC08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAA8]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD128]
       vmovups  ymmword ptr [rbp-0xC28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB28]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB48]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB68]
       vbroadcastss ymm1, dword ptr [reloc @RWD160]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm2, ymm0, 19
       vpxor    ymm0, ymm2, ymm0
       vcvtdq2ps ymm0, ymm0
       vbroadcastss ymm2, dword ptr [reloc @RWD164]
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2A8]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA68]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB48]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB68]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2A8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB88]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB48]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB68]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2A8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBE8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB48]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB68]
       vpmulld  ymm5, ymm5, ymm1
       vpmulld  ymm5, ymm5, ymm5
       vpslld   ymm13, ymm5, 19
       vpxor    ymm5, ymm13, ymm5
       vcvtdq2ps ymm5, ymm5
       vmulps   ymm5, ymm5, ymm2
       vsubps   ymm5, ymm5, ymm4
       vsubps   ymm14, ymm0, ymm3
       vsubps   ymm5, ymm5, ymm14
       vmovups  ymm15, ymmword ptr [rbp-0xAC8]
       vmulps   ymm13, ymm15, ymmword ptr [rbp-0xAC8]
       vmulps   ymm14, ymm13, ymmword ptr [rbp-0xAC8]
 
G_M000_IG23:                ;; offset=0x087C
       vmulps   ymm14, ymm14, ymm5
       vsubps   ymm15, ymm0, ymm3
       vsubps   ymm5, ymm15, ymm5
       vmulps   ymm5, ymm5, ymm13
       vaddps   ymm5, ymm5, ymm14
       vsubps   ymm0, ymm4, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xAC8]
       vaddps   ymm0, ymm0, ymm5
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB28]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xA88]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB68]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm3, ymm0, 19
       vpxor    ymm0, ymm3, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2A8]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA68]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA88]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB68]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2A8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB88]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA88]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB68]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2A8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBE8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xA88]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB68]
       vpmulld  ymm5, ymm5, ymm1
       vpmulld  ymm5, ymm5, ymm5
       vpslld   ymm13, ymm5, 19
       vpxor    ymm5, ymm13, ymm5
       vcvtdq2ps ymm5, ymm5
       vmulps   ymm5, ymm5, ymm2
       vsubps   ymm5, ymm5, ymm4
       vsubps   ymm13, ymm0, ymm3
       vsubps   ymm5, ymm5, ymm13
       vmovups  ymm13, ymmword ptr [rbp-0xAC8]
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0xAC8]
       vmulps   ymm14, ymm13, ymmword ptr [rbp-0xAC8]
       vmulps   ymm14, ymm14, ymm5
       vsubps   ymm15, ymm0, ymm3
       vsubps   ymm5, ymm15, ymm5
 
G_M000_IG24:                ;; offset=0x09CB
       vmulps   ymm5, ymm5, ymm13
       vaddps   ymm5, ymm5, ymm14
       vsubps   ymm0, ymm4, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xAC8]
       vaddps   ymm0, ymm0, ymm5
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB28]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xBA8]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB68]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm3, ymm0, 19
       vpxor    ymm0, ymm3, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2A8]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA68]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xBA8]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB68]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2A8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB88]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBA8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB68]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2A8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBE8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBA8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB68]
       vpmulld  ymm1, ymm5, ymm1
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm5, ymm1, 19
       vpxor    ymm1, ymm5, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm4
       vsubps   ymm2, ymm0, ymm3
       vsubps   ymm1, ymm1, ymm2
       vmovups  ymm2, ymmword ptr [rbp-0xAC8]
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0xAC8]
       vmulps   ymm5, ymm2, ymmword ptr [rbp-0xAC8]
       vmulps   ymm5, ymm5, ymm1
       vsubps   ymm13, ymm0, ymm3
       vsubps   ymm1, ymm13, ymm1
       vmulps   ymm1, ymm1, ymm2
       vaddps   ymm1, ymm1, ymm5
       vsubps   ymm0, ymm4, ymm0
 
G_M000_IG25:                ;; offset=0x0B19
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xAC8]
       vaddps   ymm0, ymm0, ymm1
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD48], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB28]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB68]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xD88]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB68]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xDA8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB88]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB68]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xDC8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
 
G_M000_IG26:                ;; offset=0x0C8F
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBE8]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       lea      rdx, [rbp-0xB68]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xDE8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xDE8]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xAC8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xD88]
       lea      r8, [rbp-0xDA8]
       lea      r9, [rbp-0xDC8]
       lea      rcx, [rbp-0xD68]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xD68]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xAE8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xD08]
       lea      r8, [rbp-0xD28]
       lea      r9, [rbp-0xD48]
       lea      rcx, [rbp-0xC48]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB28]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB88]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBE8]
       vmovups  ymmword ptr [rbp-0xEE8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB48]
       vmovups  ymmword ptr [rbp-0xF08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA88]
       vmovups  ymmword ptr [rbp-0xF28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBA8]
       vmovups  ymmword ptr [rbp-0xF48], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xF68], ymm0
 
G_M000_IG27:                ;; offset=0x0E09
       lea      rdx, [rbp-0xAA8]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xAC8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAE8]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xEE8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF08]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF28]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF48]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xF68]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE08]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE28]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xC68]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB28]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB88]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBE8]
       vmovups  ymmword ptr [rbp-0xEE8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB48]
       vmovups  ymmword ptr [rbp-0xF08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA88]
       vmovups  ymmword ptr [rbp-0xF28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBA8]
       vmovups  ymmword ptr [rbp-0xF48], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xF68], ymm0
       lea      rdx, [rbp-0xBC8]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xAC8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAE8]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
 
G_M000_IG28:                ;; offset=0x0F94
       lea      rcx, [rbp-0xEE8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF08]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF28]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF48]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xF68]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE08]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE28]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xC88]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB88]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xBE8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xB48]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xA88]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xBA8]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xC08]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xC28]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0xAC8]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xAE8]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xCA8]
       lea      rdx, [rbp-0x2A8]
       lea      r8, [rbp-0xB28]
       lea      r9, [rbp-0xA68]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xCA8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xB08]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xCC8]
       lea      rdx, [rbp-0xC48]
       lea      r8, [rbp-0xC68]
       lea      r9, [rbp-0xC88]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xCE8]
       vmovss   xmm1, dword ptr [reloc @RWD168]
 
G_M000_IG29:                ;; offset=0x10CC
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6E8]
       lea      rdx, [rbp-0xCC8]
       lea      r8, [rbp-0xCE8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG42
 
G_M000_IG30:                ;; offset=0x10FE
       vcmpeqps ymm0, ymm13, ymm13
       vandps   ymm0, ymm0, ymm13
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vcmpgeps ymm2, ymm0, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD36]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vcmpeqps ymm2, ymm14, ymm14
       vandps   ymm2, ymm2, ymm14
       vcmpgeps ymm4, ymm2, ymm1
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm3, ymm4
       vxorps   ymm4, ymm4, ymm4
       vcmpltps ymm4, ymm14, ymm4
       vpaddd   ymm2, ymm4, ymm2
       vcmpeqps ymm4, ymm15, ymm15
       vandps   ymm4, ymm4, ymm15
       vcmpgeps ymm1, ymm4, ymm1
       vcvttps2dq ymm4, ymm4
       vpblendvb ymm1, ymm4, ymm3, ymm1
       vxorps   ymm3, ymm3, ymm3
       vcmpltps ymm3, ymm15, ymm3
       vpaddd   ymm1, ymm3, ymm1
       vcvtdq2ps ymm3, ymm0
       vsubps   ymm3, ymm13, ymm3
       vcvtdq2ps ymm4, ymm2
       vsubps   ymm4, ymm14, ymm4
       vcvtdq2ps ymm5, ymm1
       vsubps   ymm5, ymm15, ymm5
       vbroadcastss ymm13, dword ptr [reloc @RWD172]
       vsubps   ymm14, ymm3, ymm13
       vmovups  ymmword ptr [rbp-0x728], ymm14
       vsubps   ymm15, ymm4, ymm13
       vmovups  ymmword ptr [rbp-0x748], ymm15
       vsubps   ymm13, ymm5, ymm13
       vmovups  ymmword ptr [rbp-0x768], ymm13
       vmulps   ymm13, ymm3, ymm3
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD176]
       vmovups  ymmword ptr [rbp-0x1108], ymm13
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x1198], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD180]
       vmovups  ymmword ptr [rbp-0x1128], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x1198]
       vsubps   ymm13, ymm13, ymmword ptr [rbp-0x1128]
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x1198], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD184]
       vmovups  ymmword ptr [rbp-0x1148], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x1198]
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1148]
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x788], ymm13
       vmulps   ymm15, ymm4, ymm4
       vmulps   ymm15, ymm15, ymm4
       vmovups  ymmword ptr [rbp-0x1178], ymm15
 
G_M000_IG31:                ;; offset=0x1268
       vmovups  ymm15, ymmword ptr [rbp-0x1108]
       vmulps   ymm15, ymm15, ymm4
       vsubps   ymm15, ymm15, ymmword ptr [rbp-0x1128]
       vmulps   ymm15, ymm15, ymm4
       vaddps   ymm15, ymm15, ymmword ptr [rbp-0x1148]
       vmulps   ymm15, ymm15, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x7A8], ymm15
       vmulps   ymm15, ymm5, ymm5
       vmulps   ymm15, ymm15, ymm5
       vmovups  ymmword ptr [rbp-0x1178], ymm15
       vmovups  ymm15, ymmword ptr [rbp-0x1108]
       vmulps   ymm15, ymm15, ymm5
       vsubps   ymm15, ymm15, ymmword ptr [rbp-0x1128]
       vmulps   ymm15, ymm15, ymm5
       vaddps   ymm15, ymm15, ymmword ptr [rbp-0x1148]
       vmulps   ymm15, ymm15, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x7C8], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD40]
       vpmulld  ymm0, ymm15, ymm0
       vbroadcastss ymm13, dword ptr [reloc @RWD44]
       vpmulld  ymm2, ymm13, ymm2
       vbroadcastss ymm14, dword ptr [reloc @RWD48]
       vpmulld  ymm1, ymm14, ymm1
       vpaddd   ymm15, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0x7E8], ymm15
       vpaddd   ymm13, ymm13, ymm2
       vmovups  ymmword ptr [rbp-0x808], ymm13
       vpaddd   ymm14, ymm14, ymm1
       vmovups  ymmword ptr [rbp-0x828], ymm14
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0x1028], ymm0
       vmovups  ymmword ptr [rbp-0x708], ymm2
       vpxor    ymm15, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xFA8], ymm15
       vpxor    ymm15, ymm1, ymm15
       vbroadcastss ymm0, dword ptr [reloc @RWD160]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm13, ymm15, 15
       vpxor    ymm15, ymm13, ymm15
       vbroadcastss ymm13, dword ptr [reloc @RWD188]
       vmovups  ymmword ptr [rbp-0x1088], ymm13
       vpand    ymm15, ymm15, ymm13
       mov      r8, 0x16A65C00F50
       mov      r8, gword ptr [r8]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm2, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x8C8], ymm2
       vbroadcastss ymm14, dword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rbp-0x10A8], ymm14
       vpand    ymm15, ymm14, ymm2
       vmovups  ymmword ptr [rbp-0x8E8], ymm15
       vxorps   ymm2, ymm2, ymm2
       vmovups  ymmword ptr [rbp-0x908], ymm2
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm2
 
G_M000_IG32:                ;; offset=0x13E5
       vmovups  ymm2, ymmword ptr [rbp-0x8C8]
       vpslld   ymm2, ymm2, 29
       vmovups  ymmword ptr [rbp-0x1198], ymm2
       vbroadcastss ymm2, dword ptr [reloc @RWD196]
       vmovups  ymm15, ymmword ptr [rbp-0x1198]
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymm3
       vmovups  ymm14, ymmword ptr [rbp-0x1178]
       vblendvps ymm14, ymm15, ymmword ptr [rbp-0x908], ymm14
       vmovups  ymmword ptr [rbp-0x1178], ymm14
       vbroadcastss ymm15, dword ptr [reloc @RWD200]
       vmovups  ymmword ptr [rbp-0x10C8], ymm15
       vpcmpeqd ymm14, ymm15, ymmword ptr [rbp-0x8E8]
       vmovups  ymmword ptr [rbp-0x1198], ymm14
       vmovups  ymm14, ymmword ptr [rbp-0x8C8]
       vpslld   ymm14, ymm14, 28
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm4
       vmovups  ymm15, ymmword ptr [rbp-0x1198]
       vblendvps ymm14, ymm14, ymmword ptr [rbp-0x908], ymm15
       vaddps   ymm14, ymm14, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x1178], ymm14
       vbroadcastss ymm15, dword ptr [reloc @RWD204]
       vmovups  ymmword ptr [rbp-0x10E8], ymm15
       vpcmpeqd ymm14, ymm15, ymmword ptr [rbp-0x8E8]
       vmovups  ymmword ptr [rbp-0x1198], ymm14
       vmovups  ymm14, ymmword ptr [rbp-0x8C8]
       vpslld   ymm14, ymm14, 27
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm5
       vmovups  ymm15, ymmword ptr [rbp-0x1198]
       vblendvps ymm14, ymm14, ymmword ptr [rbp-0x908], ymm15
       vaddps   ymm14, ymm14, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x848], ymm14
       vmovups  ymm15, ymmword ptr [rbp-0x7E8]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0x1048], ymm15
       vmovups  ymm15, ymmword ptr [rbp-0x708]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1048]
       vmovups  ymmword ptr [rbp-0xFC8], ymm15
       vpxor    ymm15, ymm1, ymm15
       vpmulld  ymm15, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0x928], ymm15
       vpsrad   ymm15, ymm15, 15
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x928]
       vpand    ymm15, ymm15, ymm13
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm13, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x948], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm14, ymm13
       vxorps   ymm14, ymm14, ymm14
       vmovups  ymmword ptr [rbp-0x968], ymm14
       vxorps   ymm14, ymm14, ymm14
 
G_M000_IG33:                ;; offset=0x1573
       vpcmpeqd ymm14, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm14
       vpslld   ymm14, ymm13, 29
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymmword ptr [rbp-0x728]
       vmovups  ymm13, ymmword ptr [rbp-0x1178]
       vblendvps ymm13, ymm14, ymmword ptr [rbp-0x968], ymm13
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm13, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1198], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x948]
       vpslld   ymm13, ymm13, 28
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm4
       vmovups  ymm14, ymmword ptr [rbp-0x1198]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x968], ymm14
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10E8]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x948]
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm5
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x968], ymm15
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymm15, ymmword ptr [rbp-0x848]
       vsubps   ymm13, ymm13, ymm15
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0x788]
       vaddps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x868], ymm13
       vmovups  ymm15, ymmword ptr [rbp-0x808]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1028]
       vmovups  ymmword ptr [rbp-0xFE8], ymm15
       vpxor    ymm15, ymm1, ymm15
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm14, ymm15, 15
       vpxor    ymm15, ymm14, ymm15
       vpand    ymm15, ymm15, ymmword ptr [rbp-0x1088]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm13, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x988], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm14, ymm13
       vxorps   ymm14, ymm14, ymm14
       vmovups  ymmword ptr [rbp-0x9A8], ymm14
       vxorps   ymm14, ymm14, ymm14
       vpcmpeqd ymm14, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm14
       vpslld   ymm14, ymm13, 29
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm3
       vmovups  ymm13, ymmword ptr [rbp-0x1178]
 
G_M000_IG34:                ;; offset=0x16E7
       vblendvps ymm13, ymm14, ymmword ptr [rbp-0x9A8], ymm13
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm13, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1198], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x988]
       vpslld   ymm13, ymm13, 28
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x748]
       vmovups  ymm14, ymmword ptr [rbp-0x1198]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x9A8], ymm14
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10E8]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x988]
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm5
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x9A8], ymm15
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymm15, ymmword ptr [rbp-0x808]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1048]
       vmovups  ymmword ptr [rbp-0x1008], ymm15
       vpxor    ymm1, ymm1, ymm15
       vpmulld  ymm1, ymm1, ymm0
       vpsrad   ymm15, ymm1, 15
       vpxor    ymm1, ymm15, ymm1
       vpand    ymm1, ymm1, ymmword ptr [rbp-0x1088]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm1, ymm1, 2
       vpcmpeqd ymm15, ymm15, ymm15
       vpgatherdd ymm14, dword ptr [r9+4*xmm1], ymm15
       vmovups  ymmword ptr [rbp-0x9C8], ymm14
       vmovups  ymm1, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm1, ymm14
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x9E8], ymm1
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vpslld   ymm1, ymm14, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x728]
       vmovups  ymm14, ymmword ptr [rbp-0x1178]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0x9E8], ymm14
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vmovups  ymm14, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm1, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1198], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x9C8]
       vpslld   ymm1, ymm1, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x748]
       vmovups  ymm14, ymmword ptr [rbp-0x1198]
 
G_M000_IG35:                ;; offset=0x185D
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0x9E8], ymm14
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vmovups  ymm14, ymmword ptr [rbp-0x10E8]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm1, ymmword ptr [rbp-0x9C8]
       vpslld   ymm1, ymm1, 27
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm5
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0x9E8], ymm15
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x1178]
       vsubps   ymm1, ymm1, ymm13
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x788]
       vaddps   ymm1, ymm1, ymm13
       vmovups  ymmword ptr [rbp-0x888], ymm1
       vmovups  ymm13, ymmword ptr [rbp-0x828]
       vpxor    ymm15, ymm13, ymmword ptr [rbp-0xFA8]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm1, ymm15, 15
       vpxor    ymm1, ymm1, ymm15
       vpand    ymm1, ymm1, ymmword ptr [rbp-0x1088]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm1, ymm1, 2
       vpcmpeqd ymm5, ymm5, ymm5
       vpgatherdd ymm13, dword ptr [r9+4*xmm1], ymm5
       vmovups  ymm1, ymmword ptr [rbp-0x10A8]
       vpand    ymm5, ymm1, ymm13
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0xA08], ymm1
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm5
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vpslld   ymm1, ymm13, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm3
       vmovups  ymm15, ymmword ptr [rbp-0x1178]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA08], ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm1, ymm15, ymm5
       vmovups  ymmword ptr [rbp-0x1198], ymm1
       vpslld   ymm1, ymm13, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm4
       vmovups  ymm15, ymmword ptr [rbp-0x1198]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA08], ymm15
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x1178]
       vpcmpeqd ymm5, ymm14, ymm5
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x768]
       vblendvps ymm5, ymm13, ymmword ptr [rbp-0xA08], ymm5
       vaddps   ymm1, ymm5, ymm1
       vmovups  ymm13, ymmword ptr [rbp-0x828]
       vpxor    ymm5, ymm13, ymmword ptr [rbp-0xFC8]
 
G_M000_IG36:                ;; offset=0x19C4
       vpmulld  ymm5, ymm5, ymm0
       vpsrad   ymm13, ymm5, 15
       vpxor    ymm5, ymm13, ymm5
       vpand    ymm5, ymm5, ymmword ptr [rbp-0x1088]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm5, ymm5, 2
       vpcmpeqd ymm15, ymm15, ymm15
       vpgatherdd ymm13, dword ptr [r9+4*xmm5], ymm15
       vmovups  ymm5, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm5, ymm13
       vxorps   ymm5, ymm5, ymm5
       vmovups  ymmword ptr [rbp-0xA28], ymm5
       vxorps   ymm5, ymm5, ymm5
       vpcmpeqd ymm5, ymm5, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm5
       vpslld   ymm5, ymm13, 29
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x728]
       vmovups  ymm14, ymmword ptr [rbp-0x1178]
       vblendvps ymm5, ymm5, ymmword ptr [rbp-0xA28], ymm14
       vmovups  ymmword ptr [rbp-0x1178], ymm5
       vmovups  ymm14, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm5, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1198], ymm5
       vpslld   ymm5, ymm13, 28
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm4, ymm5, ymm4
       vmovups  ymm14, ymmword ptr [rbp-0x1198]
       vblendvps ymm4, ymm4, ymmword ptr [rbp-0xA28], ymm14
       vaddps   ymm4, ymm4, ymmword ptr [rbp-0x1178]
       vmovups  ymm14, ymmword ptr [rbp-0x10E8]
       vpcmpeqd ymm15, ymm14, ymm15
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x768]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0xA28], ymm15
       vaddps   ymm4, ymm13, ymm4
       vsubps   ymm4, ymm4, ymm1
       vmulps   ymm4, ymm4, ymmword ptr [rbp-0x788]
       vaddps   ymm1, ymm4, ymm1
       vmovups  ymmword ptr [rbp-0x8A8], ymm1
       vmovups  ymm4, ymmword ptr [rbp-0x828]
       vpxor    ymm15, ymm4, ymmword ptr [rbp-0xFE8]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm13, ymm15, 15
       vpxor    ymm15, ymm13, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x1088]
       vpand    ymm15, ymm15, ymm13
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm4, ymm4, ymm4
       vpgatherdd ymm5, dword ptr [r9+4*xmm15], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm4, ymm5
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0xA48], ymm1
 
G_M000_IG37:                ;; offset=0x1B25
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vpslld   ymm1, ymm5, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm3
       vmovups  ymm4, ymmword ptr [rbp-0x1178]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA48], ymm4
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vmovups  ymm4, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm3, ymm4, ymm15
       vpslld   ymm1, ymm5, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x748]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA48], ymm3
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x1178]
       vpcmpeqd ymm3, ymm14, ymm15
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x768]
       vblendvps ymm3, ymm5, ymmword ptr [rbp-0xA48], ymm3
       vaddps   ymm1, ymm3, ymm1
       vmovups  ymm3, ymmword ptr [rbp-0x828]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x1008]
       vpmulld  ymm0, ymm3, ymm0
       vpsrad   ymm3, ymm0, 15
       vpxor    ymm0, ymm3, ymm0
       vpand    ymm0, ymm0, ymm13
       add      r8, 16
       vpsrld   ymm0, ymm0, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [r8+4*xmm0], ymm3
       vmovups  ymm0, ymmword ptr [rbp-0x10A8]
       vpand    ymm0, ymm0, ymm5
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm0
       vpslld   ymm15, ymm5, 29
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x728]
       vblendvps ymm13, ymm15, ymm3, ymm13
       vpcmpeqd ymm4, ymm4, ymm0
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x748]
       vblendvps ymm4, ymm15, ymm3, ymm4
       vaddps   ymm4, ymm4, ymm13
       vpcmpeqd ymm0, ymm14, ymm0
       vpslld   ymm5, ymm5, 27
       vpand    ymm2, ymm5, ymm2
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x768]
       vblendvps ymm0, ymm2, ymm3, ymm0
       vaddps   ymm0, ymm0, ymm4
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x788]
       vaddps   ymm0, ymm0, ymm1
 
G_M000_IG38:                ;; offset=0x1C66
       vmovups  ymm1, ymmword ptr [rbp-0x888]
       vmovups  ymm13, ymmword ptr [rbp-0x868]
       vsubps   ymm1, ymm1, ymm13
       vmovups  ymm15, ymmword ptr [rbp-0x7A8]
       vmulps   ymm1, ymm1, ymm15
       vaddps   ymm1, ymm1, ymm13
       vmovups  ymm2, ymmword ptr [rbp-0x8A8]
       vsubps   ymm0, ymm0, ymm2
       vmulps   ymm0, ymm0, ymm15
       vaddps   ymm0, ymm0, ymm2
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x7C8]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rbp-0x6E8], ymm0
       jmp      G_M000_IG42
 
G_M000_IG39:                ;; offset=0x1CC7
       vmovups  ymmword ptr [rbp-0xE08], ymm13
       vmovups  ymmword ptr [rbp-0xE28], ymm14
       vmovups  ymmword ptr [rbp-0xE48], ymm15
       mov      r8d, dword ptr [rbp-0x138]
       mov      dword ptr [rsp+0x28], r8d
       mov      r8d, dword ptr [rbp-0x134]
       mov      dword ptr [rsp+0x30], r8d
       vmovss   xmm0, dword ptr [rbp-0x130]
       vmovss   dword ptr [rsp+0x38], xmm0
       lea      r8, [rbp-0xE08]
       lea      r9, [rbp-0xE28]
       lea      rcx, [rbp-0xE48]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2A8]
       lea      rcx, [rbp-0x6E8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.CellularKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,int,float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG42
 
G_M000_IG40:                ;; offset=0x1D50
       vmovups  ymmword ptr [rbp-0xE08], ymm13
       vmovups  ymmword ptr [rbp-0xE28], ymm14
       vmovups  ymmword ptr [rbp-0xE48], ymm15
       lea      r8, [rbp-0xE08]
       lea      r9, [rbp-0xE28]
       lea      rcx, [rbp-0xE48]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2A8]
       lea      rcx, [rbp-0x6E8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x1DB0
       lea      rcx, [rbp-0x6E8]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG42:                ;; offset=0x1DD9
       lea      rcx, [rbp-0x160]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       test     eax, eax
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG56
 
G_M000_IG43:                ;; offset=0x1E06
       vmovups  ymm0, ymmword ptr [rbp-0x6E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      r8, [rbp-0xE08]
       lea      rdx, [rbp-0x160]
       lea      rcx, [rbp-0x2C8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:ShapeSingle[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG44:                ;; offset=0x1E49
       lea      rcx, [rbp-0x2E8]
       vmovaps  xmm1, xmm10
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x228]
       lea      rdx, [rbp-0x2C8]
       lea      r8, [rbp-0x2E8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG45:                ;; offset=0x1E8E
       vmovups  ymm0, ymmword ptr [rbp-0x228]
       vmovups  ymmword ptr [rbp-0x188], ymm0
       mov      rcx, bword ptr [rbp-0x1158]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Amplitude():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x228]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x1C8]
       lea      r8, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rcx, bword ptr [rbp-0x1158]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Offset():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1E8]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x188]
       lea      rdx, [rbp-0x1C8]
       lea      r8, [rbp-0x1E8]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x1150], 0
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG18
 
G_M000_IG46:                ;; offset=0x1F45
       mov      rcx, bword ptr [rbp-0x1158]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Blend():int:this]
       mov      dword ptr [rbp-0xF6C], eax
       mov      rcx, bword ptr [rbp-0x1158]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_BlendFactor():float:this]
       mov      edx, dword ptr [rbp-0xF6C]
       vmovss   dword ptr [rsp+0x20], xmm0
       lea      r8, [rbp-0x128]
       lea      r9, [rbp-0x188]
       lea      rcx, [rbp-0x208]
       call     [Tedd.FastNoise.Internal.StackFill:Blend[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG47:                ;; offset=0x1FA4
       vmovups  ymm0, ymmword ptr [rbp-0x208]
       vmovups  ymmword ptr [rbp-0x128], ymm0
       mov      rax, qword ptr [rbp-0x1150]
       inc      eax
       mov      rdx, rax
       vmovups  ymm11, ymmword ptr [rbp-0x108]
 
G_M000_IG48:                ;; offset=0x1FC8
       cmp      dword ptr [rdi+0x08], eax
       jle      G_M000_IG12
 
G_M000_IG49:                ;; offset=0x1FD1
       mov      qword ptr [rbp-0x1150], rax
       imul     rcx, rax, 80
       lea      rdx, bword ptr [rdi+rcx+0x10]
       mov      bword ptr [rbp-0x1158], rdx
       vmovdqu  xmm1, xmmword ptr [rdx]
       vmovdqu  xmmword ptr [rbp-0x140], xmm1
       mov      ecx, dword ptr [rdx+0x10]
       mov      dword ptr [rbp-0x130], ecx
       mov      ecx, dword ptr [rbp-0x13C]
       vbroadcastss ymm1, dword ptr [rdx+0x34]
       vmulps   ymm13, ymm9, ymm1
       vmulps   ymm14, ymm11, ymm1
       vmulps   ymm15, ymm12, ymm1
       dec      ecx
       cmp      ecx, 2
       jne      G_M000_IG70
 
G_M000_IG50:                ;; offset=0x2020
       vaddps   ymm1, ymm13, ymm14
       vaddps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD256]
       vsubps   ymm13, ymm1, ymm13
       vsubps   ymm14, ymm1, ymm14
       vsubps   ymm15, ymm1, ymm15
 
G_M000_IG51:                ;; offset=0x2041
       vmovdqu  xmm1, xmmword ptr [rdx]
       vmovdqu  xmmword ptr [rbp-0x140], xmm1
       mov      ecx, dword ptr [rdx+0x10]
       mov      dword ptr [rbp-0x130], ecx
       vmovdqu  xmm1, xmmword ptr [rdx+0x14]
       vmovdqu  xmmword ptr [rbp-0x160], xmm1
       vmovdqu  xmm1, xmmword ptr [rdx+0x20]
       vmovdqu  xmmword ptr [rbp-0x154], xmm1
       mov      r8d, dword ptr [rdx+0x30]
       mov      dword ptr [rbp-0x164], r8d
       mov      r10d, dword ptr [rdx+0x48]
       mov      dword ptr [rbp-0x168], r10d
       vmovups  ymmword ptr [rbp-0x248], ymm13
       vmovups  ymmword ptr [rbp-0x268], ymm14
       vmovups  ymmword ptr [rbp-0x288], ymm15
       vmovss   xmm10, dword ptr [rdx+0x4C]
       cmp      dword ptr [rbp-0x160], 0
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x20AC
       cmp      r10d, 1
       jg       G_M000_IG19
 
G_M000_IG53:                ;; offset=0x20B6
       vpbroadcastd ymm0, dword ptr [rbp-0x164]
       vmovups  ymmword ptr [rbp-0x2A8], ymm0
       mov      r8d, dword ptr [rbp-0x140]
       cmp      r8d, 5
       ja       G_M000_IG41
 
G_M000_IG54:                ;; offset=0x20D8
       mov      r8d, r8d
       lea      r9, [reloc @RWD288]
       mov      r9d, dword ptr [r9+4*r8]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG55:                ;; offset=0x20F3
       vmovups  ymmword ptr [rbp-0xE08], ymm13
       vmovups  ymmword ptr [rbp-0xE28], ymm14
       vmovups  ymmword ptr [rbp-0xE48], ymm15
       lea      r8, [rbp-0xE08]
       lea      r9, [rbp-0xE28]
       lea      rcx, [rbp-0xE48]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2A8]
       lea      rcx, [rbp-0x6E8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.ValueKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG42
 
G_M000_IG56:                ;; offset=0x2156
       vmovups  ymm1, ymmword ptr [rbp-0x6E8]
       vmovups  ymmword ptr [rbp-0x2C8], ymm1
       jmp      G_M000_IG44
 
G_M000_IG57:                ;; offset=0x216B
       mov      eax, dword ptr [rbp-0x38C]
 
G_M000_IG58:                ;; offset=0x2171
       mov      dword ptr [rbp-0x38C], eax
       mov      edx, eax
       add      edx, dword ptr [rbp-0x164]
       lea      rcx, [rbp-0x3C8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x248]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x268]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x288]
       vmovups  ymmword ptr [rbp-0xE48], ymm0
       lea      r9, [rbp-0xE08]
       lea      rcx, [rbp-0xE28]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xE48]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x3E8]
       lea      rdx, [rbp-0x140]
       lea      r8, [rbp-0x3C8]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Single3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       cmp      eax, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       je       G_M000_IG63
 
G_M000_IG59:                ;; offset=0x2224
       cmp      eax, 3
       je       G_M000_IG61
 
G_M000_IG60:                ;; offset=0x222D
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x648]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x308]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x308]
       lea      r8, [rbp-0x648]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x668]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x688]
       lea      rdx, [rbp-0x3E8]
       lea      r8, [rbp-0x668]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6A8]
       vmovss   xmm1, dword ptr [reloc @RWD312]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4C8]
       lea      rdx, [rbp-0x688]
       lea      r8, [rbp-0x6A8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       jmp      G_M000_IG65
 
G_M000_IG61:                ;; offset=0x230D
       lea      rcx, [rbp-0x528]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x548]
       lea      rdx, [rbp-0x3E8]
       lea      r8, [rbp-0x528]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_PingPongStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x568]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x588]
       lea      rdx, [rbp-0x548]
       lea      r8, [rbp-0x568]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x3E8]
       lea      rdx, [rbp-0x588]
       call     [Tedd.FastNoise.Internal.NoiseMath:PingPong[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5A8]
       vmovss   xmm1, dword ptr [reloc @RWD312]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x5C8]
       lea      r8, [rbp-0x5A8]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5E8]
       vmovss   xmm1, dword ptr [reloc @RWD316]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x608]
       lea      rdx, [rbp-0x5C8]
       lea      r8, [rbp-0x5E8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG62:                ;; offset=0x2403
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      r8, [rbp-0xE08]
       lea      rdx, [rbp-0x608]
       lea      rcx, [rbp-0x628]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x308]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x308]
       lea      r8, [rbp-0x628]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0x4C8], ymm0
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       jmp      G_M000_IG65
 
G_M000_IG63:                ;; offset=0x247A
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x3E8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Abs(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x408]
       vmovss   xmm1, dword ptr [reloc @RWD320]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x428]
       lea      r8, [rbp-0x408]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x448]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x468]
       lea      rdx, [rbp-0x428]
       lea      r8, [rbp-0x448]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      r8, [rbp-0xE08]
       lea      rdx, [rbp-0x468]
       lea      rcx, [rbp-0x488]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x308]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x308]
       lea      r8, [rbp-0x488]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4A8]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4C8]
       lea      rdx, [rbp-0x4A8]
       lea      r8, [rbp-0x3E8]
 
G_M000_IG64:                ;; offset=0x2594
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
 
G_M000_IG65:                ;; offset=0x25A6
       lea      rcx, [rbp-0x4E8]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x388]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      r9, [rbp-0xE08]
       lea      rdx, [rbp-0x4E8]
       lea      r8, [rbp-0x4C8]
       lea      rcx, [rbp-0x508]
       call     [Tedd.FastNoise.Internal.NoiseMath:Lerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x328]
       lea      r8, [rbp-0x508]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x248]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x348]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x248]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x268]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x348]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x268]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x288]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x348]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x288]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x368]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
 
G_M000_IG66:                ;; offset=0x26F2
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x328]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      eax, dword ptr [rbp-0x38C]
       inc      eax
       mov      r8d, dword ptr [rbp-0x168]
       cmp      eax, r8d
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       mov      edx, r8d
       jge      G_M000_IG20
 
G_M000_IG67:                ;; offset=0x2734
       vmovss   xmm13, dword ptr [reloc @RWD172]
       vucomiss xmm10, xmm13
       jp       SHORT G_M000_IG68
       je       G_M000_IG58
 
G_M000_IG68:                ;; offset=0x2749
       lea      ecx, [rdx-0x01]
       mov      dword ptr [rbp-0x38C], eax
       cmp      eax, ecx
       jne      G_M000_IG57
 
G_M000_IG69:                ;; offset=0x275A
       lea      rcx, [rbp-0x6C8]
       vmovaps  xmm1, xmm10
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x328]
       lea      r8, [rbp-0x6C8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       mov      eax, dword ptr [rbp-0x38C]
       jmp      G_M000_IG58
 
G_M000_IG70:                ;; offset=0x27BA
       cmp      ecx, 2
       ja       G_M000_IG51
       mov      ecx, ecx
       lea      r8, [reloc @RWD324]
       mov      r8d, dword ptr [r8+4*rcx]
       lea      r10, G_M000_IG02
       add      r8, r10
       jmp      r8
 
G_M000_IG71:                ;; offset=0x27DD
       vaddps   ymm1, ymm13, ymm14
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD352]
       vmulps   ymm15, ymm15, ymmword ptr [reloc @RWD384]
       vsubps   ymm2, ymm0, ymm15
       vaddps   ymm13, ymm2, ymm13
       vaddps   ymm0, ymm14, ymm0
       vsubps   ymm14, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vaddps   ymm15, ymm1, ymm15
       jmp      G_M000_IG51
 
G_M000_IG72:                ;; offset=0x2817
       vaddps   ymm1, ymm13, ymm15
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD352]
       vmulps   ymm14, ymm14, ymmword ptr [reloc @RWD384]
       vsubps   ymm2, ymm0, ymm14
       vaddps   ymm13, ymm2, ymm13
       vsubps   ymm0, ymm0, ymm14
       vaddps   ymm15, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vaddps   ymm14, ymm1, ymm14
       jmp      G_M000_IG51
 
G_M000_IG73:                ;; offset=0x2852
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dq	0000000100000000h, 0000000300000002h, 0000000500000004h, 0000000700000006h
RWD32  	dd	4F000000h		; 2.14748e+09
RWD36  	dd	7FFFFFFFh		;       nan
RWD40  	dd	1DDE90C9h		; 5.89126e-21
RWD44  	dd	43C42E4Dh		;   392.362
RWD48  	dd	668B6E2Fh		; 3.29221e+23
RWD52  	dd	00000000h, 00000000h, 00000000h
RWD64  	dq	3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h
RWD96  	dq	87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah
RWD128 	dq	CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh
RWD160 	dd	27D4EB2Dh		; 5.90968e-15
RWD164 	dd	30000000h		; 4.65661e-10
RWD168 	dd	3E97B426h		;  0.296296
RWD172 	dd	3F800000h		;         1
RWD176 	dd	40C00000h		;         6
RWD180 	dd	41700000h		;        15
RWD184 	dd	41200000h		;        10
RWD188 	dd	000000FCh		; 3.53127e-43
RWD192 	dd	00000003h		; 4.2039e-45
RWD196 	dd	80000000h		;        -0
RWD200 	dd	00000001h		; 1.4013e-45
RWD204 	dd	00000002h		; 2.8026e-45
RWD208 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD224 	dq	3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h
RWD256 	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD288 	dd	00001C00h ; case G_M000_IG40
       	dd	00001C60h ; case G_M000_IG41
       	dd	00001B77h ; case G_M000_IG39
       	dd	00000FAEh ; case G_M000_IG30
       	dd	0000042Ch ; case G_M000_IG21
       	dd	00001FA3h ; case G_M000_IG55
RWD312 	dd	3F000000h		;       0.5
RWD316 	dd	40000000h		;         2
RWD320 	dd	C0000000h		;        -2
RWD324 	dd	0000268Dh ; case G_M000_IG71
       	dd	000026C7h ; case G_M000_IG72
       	dd	00001ED0h ; case G_M000_IG50
RWD336 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD352 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD384 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah

; Total bytes of code 10328

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 464
       lea      rbp, [rsp+0x1D0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1A0], xmm4
       mov      rax, -336
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x100], 0x3E8
       call     [Tedd.FastNoise.Internal.VectorOps:get_Count():int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x40], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      eax, dword ptr [rbp+0x28]
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG14
 
G_M000_IG03:                ;; offset=0x0099
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x50], edx
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x50]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x54]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x5C], xmm0
       mov      eax, dword ptr [rbp-0x4C]
       imul     eax, dword ptr [rbp-0x40]
       mov      dword ptr [rbp-0x60], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x64], eax
       jmp      G_M000_IG07
 
G_M000_IG04:                ;; offset=0x0103
       mov      rcx, 0x7FFC657B9758
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x104], xmm0
       vmovss   xmm1, dword ptr [rbp-0x104]
       lea      rcx, [rbp-0x90]
       vmovss   xmm2, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.VectorOps:Ramp(float,float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB0]
       vmovss   xmm1, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xD0]
       vmovss   xmm1, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x170], ymm0
       lea      r8, [rbp-0x130]
       lea      r9, [rbp-0x150]
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0xF0]
       mov      rdx, gword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x190], ymm0
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x01E3
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG06:                ;; offset=0x01EF
       lea      rcx, [rbp-0x190]
       lea      rdx, [rbp-0x1A0]
       mov      eax, dword ptr [rbp-0x60]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG07:                ;; offset=0x0216
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x022D
       lea      rcx, [rbp-0x100]
       mov      edx, 183
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x023E
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp-0x40]
       jle      G_M000_IG04
       jmp      G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0252
       mov      rcx, 0x7FFC657B975C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       add      eax, dword ptr [rbp-0x64]
       mov      rcx, bword ptr [rbp+0x20]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG18
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, dword ptr [rbp-0x64]
       mov      ecx, ecx
       lea      rax, bword ptr [rax+4*rcx]
       mov      bword ptr [rbp-0xF8], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x1A4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A4]
       mov      rcx, gword ptr [rbp+0x10]
       vmovss   xmm2, dword ptr [rbp-0x58]
       vmovss   xmm3, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      rax, bword ptr [rbp-0xF8]
       vmovss   dword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x64]
       inc      eax
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG11:                ;; offset=0x02E1
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x02F8
       lea      rcx, [rbp-0x100]
       mov      edx, 233
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x0309
       mov      eax, dword ptr [rbp-0x64]
       cmp      eax, dword ptr [rbp-0x40]
       jl       G_M000_IG10
       mov      rcx, 0x7FFC657B9760
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG14:                ;; offset=0x032C
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0343
       lea      rcx, [rbp-0x100]
       mov      edx, 244
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG16:                ;; offset=0x0354
       mov      eax, dword ptr [rbp+0x28]
       add      eax, dword ptr [rbp+0x30]
       cmp      dword ptr [rbp-0x4C], eax
       jl       G_M000_IG03
       mov      rcx, 0x7FFC657B9764
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG17:                ;; offset=0x0373
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x037C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 898

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3(Tedd.FastNoise.Procedural.CompiledStack3D,Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int,bool) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 800
       lea      rbp, [rsp+0x320]
       xor      eax, eax
       mov      qword ptr [rbp-0x2E8], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -672
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0053
       mov      dword ptr [rbp-0x188], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x40], rax
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG03
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x007C
       mov      rcx, 0x7FFC6589E390
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG04:                ;; offset=0x009A
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x48], rax
       mov      dword ptr [rbp-0x4C], 8
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG19
 
G_M000_IG05:                ;; offset=0x00E0
       mov      eax, dword ptr [rbp-0x5C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x60], edx
       mov      eax, dword ptr [rbp-0x5C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x64], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x60]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x68], xmm0
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      eax, dword ptr [rbp-0x5C]
       imul     eax, dword ptr [rbp-0x50]
       mov      dword ptr [rbp-0x70], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x74], eax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG16
       jmp      G_M000_IG11
 
G_M000_IG06:                ;; offset=0x0155
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x18C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x18C]
       lea      rcx, [rbp-0xB0]
       vmovss   xmm2, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.VectorOps:Ramp(float,float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x110]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x178], rax
       mov      rcx, gword ptr [rbp-0x178]
       mov      rdx, 0x7FFC6589E398
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x1F8], rax
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1F0], ymm0
       mov      rax, gword ptr [rbp-0x1F8]
       lea      r8, [rbp-0x1B0]
       lea      r9, [rbp-0x1D0]
       lea      rcx, [rbp-0x1F0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x1F8]
       call     [rax+0x18]System.Func`4[System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]]:Invoke(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x250], ymm0
       lea      rcx, [rbp-0x230]
       lea      rdx, [rbp-0x250]
       call     [System.Numerics.Vector:EqualsAll[float](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):bool]
       test     eax, eax
       jne      G_M000_IG08
       mov      rcx, 0x7FFC6589E4A0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x150]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x170]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
 
G_M000_IG07:                ;; offset=0x02C3
       vmovups  ymmword ptr [rbp-0x270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2B0], ymm0
       lea      r8, [rbp-0x270]
       lea      r9, [rbp-0x290]
       lea      rax, [rbp-0x2B0]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0xD0]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG08:                ;; offset=0x0316
       mov      rcx, 0x7FFC6589E4A4
       call     CORINFO_HELP_COUNTPROFILE32
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x2D0], ymm0
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG09:                ;; offset=0x0339
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG10:                ;; offset=0x0345
       lea      rcx, [rbp-0x2D0]
       lea      rdx, [rbp-0x2E0]
       mov      eax, dword ptr [rbp-0x70]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x74]
       add      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG11:                ;; offset=0x036C
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0383
       lea      rcx, [rbp-0x188]
       mov      edx, 220
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x0394
       mov      eax, dword ptr [rbp-0x74]
       add      eax, dword ptr [rbp-0x4C]
       cmp      eax, dword ptr [rbp-0x50]
       jle      G_M000_IG06
       mov      rcx, 0x7FFC6589E4A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG16
 
G_M000_IG14:                ;; offset=0x03B7
       mov      rax, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, gword ptr [rbp-0x180]
       mov      rdx, 0x7FFC6589E4B0
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x2EC], xmm0
       mov      rax, gword ptr [rbp-0x2E8]
       vmovss   xmm1, dword ptr [rbp-0x2EC]
       vmovss   xmm2, dword ptr [rbp-0x68]
       vmovss   xmm3, dword ptr [rbp-0x6C]
       mov      rcx, gword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x2E8]
       call     [rax+0x18]System.Func`4[float,float,float,float]:Invoke(float,float,float):float:this
       vmovss   dword ptr [rbp-0xD4], xmm0
       vmovss   xmm0, dword ptr [rbp-0xD4]
       call     [System.Single:IsNaN(float):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rcx, 0x7FFC6589E5B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x2F0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x2F0]
       mov      rcx, gword ptr [rbp+0x18]
       vmovss   xmm2, dword ptr [rbp-0x68]
       vmovss   xmm3, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovss   dword ptr [rbp-0xD4], xmm0
 
G_M000_IG15:                ;; offset=0x04A2
       mov      rcx, 0x7FFC6589E5BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x70]
       add      eax, dword ptr [rbp-0x74]
       mov      rcx, bword ptr [rbp+0x28]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG23
       mov      rax, bword ptr [rbp+0x28]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x70]
       add      ecx, dword ptr [rbp-0x74]
       mov      ecx, ecx
       vmovss   xmm0, dword ptr [rbp-0xD4]
       vmovss   dword ptr [rax+4*rcx], xmm0
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG16:                ;; offset=0x04E8
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x04FF
       lea      rcx, [rbp-0x188]
       mov      edx, 309
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG18:                ;; offset=0x0510
       mov      eax, dword ptr [rbp-0x74]
       cmp      eax, dword ptr [rbp-0x50]
       jl       G_M000_IG14
       mov      rcx, 0x7FFC6589E5C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG19:                ;; offset=0x0533
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x054A
       lea      rcx, [rbp-0x188]
       mov      edx, 320
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG21:                ;; offset=0x055B
       mov      eax, dword ptr [rbp+0x30]
       add      eax, dword ptr [rbp+0x38]
       cmp      dword ptr [rbp-0x5C], eax
       jl       G_M000_IG05
       mov      rcx, 0x7FFC6589E5C4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG22:                ;; offset=0x057A
       add      rsp, 800
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x0583
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1417

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Tier1-OSR)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0xe9
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 3
; 12 inlinees with PGO data; 904 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       mov      rax, qword ptr [rbp]
       push     rax
       lea      r11, [rsp-0x1070]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       mov      qword ptr [rsp+0x1248], r15
       mov      qword ptr [rsp+0x1240], r14
       mov      qword ptr [rsp+0x1238], r13
       mov      qword ptr [rsp+0x1230], r12
       mov      qword ptr [rsp+0x1228], rdi
       mov      qword ptr [rsp+0x1220], rsi
       mov      qword ptr [rsp+0x1218], rbx
       vmovaps  xmmword ptr [rsp+0x1020], xmm6
       vmovaps  xmmword ptr [rsp+0x1010], xmm7
       vmovaps  xmmword ptr [rsp+0x1000], xmm8
       vmovaps  xmmword ptr [rsp+0xFF0], xmm9
       vmovaps  xmmword ptr [rsp+0xFE0], xmm10
       vmovaps  xmmword ptr [rsp+0xFD0], xmm11
       vmovaps  xmmword ptr [rsp+0xFC0], xmm12
       vmovaps  xmmword ptr [rsp+0xFB0], xmm13
       vmovaps  xmmword ptr [rsp+0xFA0], xmm14
       vmovaps  xmmword ptr [rsp+0xF90], xmm15
       lea      rbp, [rsp+0x1070]
       xor      eax, eax
       mov      qword ptr [rbp-0xFF8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xFF0], xmm4
       vmovdqa  xmmword ptr [rbp-0xFE0], xmm4
       mov      rax, -0xED0
       vmovdqa  xmmword ptr [rbp+rax-0x100], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0xF0], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0xE0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x100], rax
       mov      rbx, gword ptr [rbp+0x1F0]
       mov      rdi, bword ptr [rbp+0x1F8]
       mov      rsi, bword ptr [rbp+0x200]
       mov      r14d, dword ptr [rbp+0x208]
       mov      r15d, dword ptr [rbp+0x210]
       mov      r9d, dword ptr [rbp+0x1A4]
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r11d, dword ptr [rbp+0x19C]
       vmovss   xmm6, dword ptr [rbp+0x198]
       mov      r12d, dword ptr [rbp+0x194]
       vmovss   xmm7, dword ptr [rbp+0x188]
       vmovss   xmm8, dword ptr [rbp+0x184]
       mov      r10d, dword ptr [rbp+0x180]
       mov      r13d, dword ptr [rbp+0x17C]
 
G_M000_IG02:                ;; offset=0x0163
       vbroadcastss ymm1, ymm6
       vcvtdq2ps ymm0, ymmword ptr [reloc @RWD00]
       vmulps   ymm9, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0xFD8], ymm9
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0181
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x1A4], r9d
       mov      dword ptr [rbp+0x19C], r11d
       mov      dword ptr [rbp+0x180], r10d
       lea      ecx, [r10+r13]
       cmp      ecx, dword ptr [rsi+0x08]
       jae      G_M000_IG67
       mov      eax, ecx
       mov      qword ptr [rbp-0x1000], rax
       mov      rdx, bword ptr [rsi]
       mov      bword ptr [rbp-0xFF8], rdx
       mov      rcx, rdi
       vextractf128 xmm10, ymm9
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r13d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm0, xmm1
       mov      rcx, rbx
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      rdx, bword ptr [rbp-0xFF8]
       mov      rax, qword ptr [rbp-0x1000]
       vmovss   dword ptr [rdx+4*rax], xmm0
       inc      r13d
       vinsertf128 ymm9, ymm9, xmm10
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r9d, dword ptr [rbp+0x1A4]
       mov      r10d, dword ptr [rbp+0x180]
       mov      r11d, dword ptr [rbp+0x19C]
 
G_M000_IG04:                ;; offset=0x0227
       cmp      r13d, r8d
       jl       G_M000_IG03
 
G_M000_IG05:                ;; offset=0x0230
       inc      r12d
       mov      dword ptr [rbp+0x208], r14d
       mov      dword ptr [rbp+0x210], r15d
       lea      eax, [r14+r15]
       cmp      eax, r12d
       jle      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x024E
       mov      eax, r12d
       cdq      
       idiv     edx:eax, r11d
       mov      r10d, edx
       mov      dword ptr [rbp+0x19C], r11d
       mov      eax, r12d
       cdq      
       idiv     edx:eax, r11d
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r10d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm7, xmm1, dword ptr [rdi+0x04]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, eax
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm8, xmm1, dword ptr [rdi+0x08]
       mov      r10d, r12d
       imul     r10d, r8d
       mov      dword ptr [rbp+0x180], r10d
       xor      ecx, ecx
       xor      eax, eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x029D
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x1A4], r9d
       mov      dword ptr [rbp+0x19C], r11d
 
G_M000_IG08:                ;; offset=0x02B2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0xFA8], xmm0
 
G_M000_IG09:                ;; offset=0x02BE
       lea      rdx, [rbp-0xFA8]
       mov      dword ptr [rbp+0x180], r10d
       lea      r8d, [r10+r13]
       lea      rcx, [rbp-0x118]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      r13d, dword ptr [rbp-0xFDC]
       mov      dword ptr [rbp+0x208], r14d
       mov      dword ptr [rbp+0x210], r15d
       mov      eax, r13d
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r9d, dword ptr [rbp+0x1A4]
       vmovups  ymm9, ymmword ptr [rbp-0xFD8]
 
G_M000_IG10:                ;; offset=0x030B
       mov      dword ptr [rbp+0x1A4], r9d
       lea      edx, [rax+r9]
       mov      dword ptr [rbp+0x1A0], r8d
       cmp      edx, r8d
       mov      dword ptr [rbp-0xFDC], edx
       mov      r13d, eax
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r9d, dword ptr [rbp+0x1A4]
       mov      r10d, dword ptr [rbp+0x180]
       mov      r11d, dword ptr [rbp+0x19C]
       mov      r14d, dword ptr [rbp+0x208]
       mov      r15d, dword ptr [rbp+0x210]
       jg       G_M000_IG04
 
G_M000_IG11:                ;; offset=0x0359
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r13d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm1, dword ptr [rdi]
       vbroadcastss ymm1, ymm1
       vaddps   ymm10, ymm1, ymm9
       vbroadcastss ymm11, ymm7
       vmovss   dword ptr [rbp+0x184], xmm8
       vbroadcastss ymm12, ymm8
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x130], xmm1
       vmovdqu  xmmword ptr [rbp-0x12C], xmm1
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x150], xmm1
       vmovdqu  xmmword ptr [rbp-0x144], xmm1
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x118], ymm1
       xor      eax, eax
       vmovss   xmm8, dword ptr [rbp+0x184]
       jmp      G_M000_IG18
 
G_M000_IG12:                ;; offset=0x03C9
       vmovups  ymm0, ymmword ptr [rbp-0x178]
       vmovups  ymmword ptr [rbp-0x1F8], ymm0
       jmp      G_M000_IG17
 
G_M000_IG13:                ;; offset=0x03DE
       vmovss   dword ptr [rbp+0x184], xmm8
 
G_M000_IG14:                ;; offset=0x03E6
       vmovups  ymm0, ymmword ptr [rbp-0x318]
       vmovups  ymmword ptr [rbp-0x218], ymm0
       vmovss   xmm8, dword ptr [rbp+0x184]
 
G_M000_IG15:                ;; offset=0x03FE
       vmovups  ymm0, ymmword ptr [rbp-0x218]
       vmovups  ymmword ptr [rbp-0x178], ymm0
       mov      rcx, bword ptr [rbp-0xFF0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Amplitude():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x198]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x218]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x1B8]
       lea      r8, [rbp-0x198]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rcx, bword ptr [rbp-0xFF0]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Offset():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1D8]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x178]
       lea      rdx, [rbp-0x1B8]
       lea      r8, [rbp-0x1D8]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      r14, qword ptr [rbp-0xFE8]
       test     r14d, r14d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG12
 
G_M000_IG16:                ;; offset=0x04C4
       mov      rcx, bword ptr [rbp-0xFF0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Blend():int:this]
       mov      r15d, eax
       mov      rcx, bword ptr [rbp-0xFF0]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_BlendFactor():float:this]
       mov      edx, r15d
       vmovss   dword ptr [rsp+0x20], xmm0
       lea      r8, [rbp-0x118]
       lea      r9, [rbp-0x178]
       lea      rcx, [rbp-0x1F8]
       call     [Tedd.FastNoise.Internal.StackFill:Blend[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG17:                ;; offset=0x0529
       vmovups  ymm0, ymmword ptr [rbp-0x1F8]
       vmovups  ymmword ptr [rbp-0x118], ymm0
       inc      r14d
       mov      rax, r14
       mov      r8d, dword ptr [rbp+0x1A0]
       mov      r9d, dword ptr [rbp+0x1A4]
       mov      r10d, dword ptr [rbp+0x180]
       mov      r11d, dword ptr [rbp+0x19C]
       mov      r14d, dword ptr [rbp+0x208]
       mov      r15d, dword ptr [rbp+0x210]
 
G_M000_IG18:                ;; offset=0x0569
       mov      ecx, dword ptr [rbx+0x08]
       cmp      ecx, eax
       jle      G_M000_IG07
 
G_M000_IG19:                ;; offset=0x0574
       mov      dword ptr [rbp+0x210], r15d
       mov      qword ptr [rbp-0xFE8], rax
       imul     rcx, rax, 80
       lea      rcx, bword ptr [rbx+rcx+0x10]
       mov      bword ptr [rbp-0xFF0], rcx
       vmovdqu  xmm1, xmmword ptr [rcx]
       vmovdqu  xmmword ptr [rbp-0x130], xmm1
       mov      r15d, dword ptr [rcx+0x10]
       mov      dword ptr [rbp-0x120], r15d
       mov      r15d, dword ptr [rbp-0x12C]
       vbroadcastss ymm1, dword ptr [rcx+0x34]
       vmulps   ymm13, ymm1, ymm10
       vmulps   ymm14, ymm1, ymm11
       vmulps   ymm15, ymm1, ymm12
       dec      r15d
       cmp      r15d, 2
       jne      G_M000_IG30
 
G_M000_IG20:                ;; offset=0x05D2
       vaddps   ymm1, ymm13, ymm14
       vaddps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD32]
       vsubps   ymm13, ymm1, ymm13
       vsubps   ymm14, ymm1, ymm14
       vsubps   ymm15, ymm1, ymm15
       mov      dword ptr [rbp+0x208], r14d
 
G_M000_IG21:                ;; offset=0x05FA
       vmovdqu  xmm1, xmmword ptr [rcx]
       vmovdqu  xmmword ptr [rbp-0x130], xmm1
       mov      r15d, dword ptr [rcx+0x10]
       mov      dword ptr [rbp-0x120], r15d
       vmovdqu  xmm1, xmmword ptr [rcx+0x14]
       vmovdqu  xmmword ptr [rbp-0x150], xmm1
       vmovdqu  xmm1, xmmword ptr [rcx+0x20]
       vmovdqu  xmmword ptr [rbp-0x144], xmm1
       mov      r15d, dword ptr [rcx+0x30]
       mov      r14d, dword ptr [rcx+0x48]
       vmovups  ymmword ptr [rbp-0x238], ymm13
       vmovups  ymmword ptr [rbp-0x258], ymm14
       vmovups  ymmword ptr [rbp-0x278], ymm15
       vmovss   xmm1, dword ptr [rcx+0x4C]
       vmovss   dword ptr [rbp-0x2BC], xmm1
       cmp      dword ptr [rbp-0x150], 0
       je       G_M000_IG34
       cmp      r14d, 1
       jle      G_M000_IG34
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       mov      dword ptr [rbp+0x19C], r11d
       lea      rcx, [rbp-0x318]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Bounding():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x338]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Lacunarity():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x358]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Gain():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x378]
 
G_M000_IG22:                ;; offset=0x0702
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_WeightedStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x398]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       xor      eax, eax
       cmp      eax, r14d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jge      G_M000_IG13
 
G_M000_IG23:                ;; offset=0x0743
       vmovss   xmm9, dword ptr [reloc @RWD64]
       vmovss   xmm13, dword ptr [rbp-0x2BC]
       vucomiss xmm13, xmm9
       jp       G_M000_IG61
       jne      G_M000_IG61
       vmovss   dword ptr [rbp+0x184], xmm8
 
G_M000_IG24:                ;; offset=0x076C
       mov      dword ptr [rbp-0x39C], eax
       lea      edx, [r15+rax]
       lea      rcx, [rbp-0x3D8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x238]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x258]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x278]
       vmovups  ymmword ptr [rbp-0xE78], ymm0
       lea      r9, [rbp-0xE38]
       lea      rcx, [rbp-0xE58]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xE78]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x3F8]
       lea      rdx, [rbp-0x130]
       lea      r8, [rbp-0x3D8]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Single3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       cmp      eax, 2
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
       je       G_M000_IG62
       cmp      eax, 3
       je       G_M000_IG65
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x658]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x318]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x318]
       lea      r8, [rbp-0x658]
 
G_M000_IG25:                ;; offset=0x08A2
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x678]
       vmovaps  xmm1, xmm9
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x698]
       lea      rdx, [rbp-0x3F8]
       lea      r8, [rbp-0x678]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6B8]
       vmovss   xmm1, dword ptr [reloc @RWD68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4D8]
       lea      rdx, [rbp-0x698]
       lea      r8, [rbp-0x6B8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
 
G_M000_IG26:                ;; offset=0x0917
       lea      rcx, [rbp-0x4F8]
       vmovaps  xmm1, xmm9
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x398]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      r9, [rbp-0xE38]
       lea      rdx, [rbp-0x4F8]
       lea      r8, [rbp-0x4D8]
       lea      rcx, [rbp-0x518]
       call     [Tedd.FastNoise.Internal.NoiseMath:Lerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x338]
       lea      r8, [rbp-0x518]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x238]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x358]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x238]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x258]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x358]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x258]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x278]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x358]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x278]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x378]
 
G_M000_IG27:                ;; offset=0x0A61
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE38]
       lea      r8, [rbp-0xE58]
       lea      rcx, [rbp-0x338]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      eax, dword ptr [rbp-0x39C]
       inc      eax
       cmp      eax, r14d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
       jge      G_M000_IG14
 
G_M000_IG28:                ;; offset=0x0AA7
       vmovss   xmm8, dword ptr [rbp+0x184]
       jmp      G_M000_IG23
 
G_M000_IG29:                ;; offset=0x0AB4
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1020]
       vmovaps  xmm7, xmmword ptr [rsp+0x1010]
       vmovaps  xmm8, xmmword ptr [rsp+0x1000]
       vmovaps  xmm9, xmmword ptr [rsp+0xFF0]
       vmovaps  xmm10, xmmword ptr [rsp+0xFE0]
       vmovaps  xmm11, xmmword ptr [rsp+0xFD0]
       vmovaps  xmm12, xmmword ptr [rsp+0xFC0]
       vmovaps  xmm13, xmmword ptr [rsp+0xFB0]
       vmovaps  xmm14, xmmword ptr [rsp+0xFA0]
       vmovaps  xmm15, xmmword ptr [rsp+0xF90]
       add      rsp, 0x1218
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG30:                ;; offset=0x0B25
       cmp      r15d, 2
       mov      dword ptr [rbp+0x208], r14d
       ja       G_M000_IG21
       mov      dword ptr [rbp+0x19C], r11d
       mov      r15d, r15d
       mov      qword ptr [rbp-0x1000], r15
       lea      r15, [reloc @RWD72]
       mov      r11, qword ptr [rbp-0x1000]
       mov      r15d, dword ptr [r15+4*r11]
       lea      r14, G_M000_IG02
       add      r15, r14
       jmp      r15
 
G_M000_IG31:                ;; offset=0x0B66
       mov      r11d, dword ptr [rbp+0x19C]
       mov      r14d, dword ptr [rbp+0x208]
       jmp      G_M000_IG20
 
G_M000_IG32:                ;; offset=0x0B79
       vaddps   ymm1, ymm13, ymm14
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm15, ymm15, ymmword ptr [reloc @RWD128]
       vsubps   ymm2, ymm0, ymm15
       vaddps   ymm13, ymm2, ymm13
       vaddps   ymm0, ymm14, ymm0
       vsubps   ymm14, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vaddps   ymm15, ymm1, ymm15
       mov      r11d, dword ptr [rbp+0x19C]
       jmp      G_M000_IG21
 
G_M000_IG33:                ;; offset=0x0BBA
       vaddps   ymm1, ymm13, ymm15
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm14, ymm14, ymmword ptr [reloc @RWD128]
       vsubps   ymm2, ymm0, ymm14
       vaddps   ymm13, ymm2, ymm13
       vsubps   ymm0, ymm0, ymm14
       vaddps   ymm15, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vaddps   ymm14, ymm1, ymm14
       mov      r11d, dword ptr [rbp+0x19C]
       jmp      G_M000_IG21
 
G_M000_IG34:                ;; offset=0x0BFC
       vmovd    xmm1, r15d
       vpbroadcastd ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x298], ymm1
       mov      r14d, dword ptr [rbp-0x130]
       cmp      r14d, 5
       mov      dword ptr [rbp+0x19C], r11d
       ja       SHORT G_M000_IG36
       lea      r15, [reloc @RWD160]
       mov      r15d, dword ptr [r15+4*r14]
       lea      r11, G_M000_IG02
       add      r15, r11
       jmp      r15
 
G_M000_IG35:                ;; offset=0x0C3A
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0C51
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
 
G_M000_IG37:                ;; offset=0x0C66
       lea      rcx, [rbp-0x6F8]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG58
 
G_M000_IG38:                ;; offset=0x0CA0
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       vmovups  ymmword ptr [rbp-0xE38], ymm13
       vmovups  ymmword ptr [rbp-0xE58], ymm14
       vmovups  ymmword ptr [rbp-0xE78], ymm15
       lea      r8, [rbp-0xE38]
       lea      r9, [rbp-0xE58]
       lea      r11, [rbp-0xE78]
       mov      qword ptr [rsp+0x20], r11
       lea      rdx, [rbp-0x298]
       lea      rcx, [rbp-0x6F8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG58
 
G_M000_IG39:                ;; offset=0x0D24
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       vmovups  ymmword ptr [rbp-0xE38], ymm13
       vmovups  ymmword ptr [rbp-0xE58], ymm14
       vmovups  ymmword ptr [rbp-0xE78], ymm15
       mov      r11d, dword ptr [rbp-0x128]
       mov      dword ptr [rsp+0x28], r11d
       mov      r11d, dword ptr [rbp-0x124]
       mov      dword ptr [rsp+0x30], r11d
       vmovss   xmm1, dword ptr [rbp-0x120]
       vmovss   dword ptr [rsp+0x38], xmm1
       lea      r8, [rbp-0xE38]
       lea      r9, [rbp-0xE58]
       lea      r11, [rbp-0xE78]
       mov      qword ptr [rsp+0x20], r11
       lea      rdx, [rbp-0x298]
       lea      rcx, [rbp-0x6F8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.CellularKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,int,float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG58
 
G_M000_IG40:                ;; offset=0x0DCE
       vcmpeqps ymm1, ymm13, ymm13
       vandps   ymm1, ymm1, ymm13
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vcmpeqps ymm2, ymm14, ymm14
       vandps   ymm2, ymm2, ymm14
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vxorps   ymm3, ymm3, ymm3
       vcmpltps ymm3, ymm14, ymm3
       vpaddd   ymm2, ymm3, ymm2
       vcmpeqps ymm3, ymm15, ymm15
       vandps   ymm3, ymm3, ymm15
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vxorps   ymm4, ymm4, ymm4
       vcmpltps ymm4, ymm15, ymm4
       vpaddd   ymm3, ymm4, ymm3
       vcvtdq2ps ymm4, ymm1
       vsubps   ymm4, ymm13, ymm4
       vmovups  ymmword ptr [rbp-0x778], ymm4
       vcvtdq2ps ymm5, ymm2
       vsubps   ymm5, ymm14, ymm5
       vmovups  ymmword ptr [rbp-0x798], ymm5
       vcvtdq2ps ymm13, ymm3
       vsubps   ymm14, ymm15, ymm13
       vsubps   ymm15, ymm4, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x7B8], ymm15
       vsubps   ymm13, ymm5, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x7D8], ymm13
       vsubps   ymm13, ymm14, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x7F8], ymm13
       vmulps   ymm13, ymm4, ymm4
       vmulps   ymm13, ymm13, ymm4
       vmulps   ymm15, ymm4, ymmword ptr [reloc @RWD288]
       vsubps   ymm15, ymm15, ymmword ptr [reloc @RWD320]
       vmulps   ymm15, ymm15, ymm4
       vaddps   ymm15, ymm15, ymmword ptr [reloc @RWD352]
       vmulps   ymm13, ymm15, ymm13
       vmovups  ymmword ptr [rbp-0x818], ymm13
       vmulps   ymm15, ymm5, ymm5
       vmulps   ymm15, ymm15, ymm5
       vmulps   ymm13, ymm5, ymmword ptr [reloc @RWD288]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD320]
       vmulps   ymm13, ymm13, ymm5
       vaddps   ymm13, ymm13, ymmword ptr [reloc @RWD352]
       vmulps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x838], ymm13
       vmulps   ymm15, ymm14, ymm14
       vmulps   ymm15, ymm15, ymm14
       vmulps   ymm13, ymm14, ymmword ptr [reloc @RWD288]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD320]
       vmulps   ymm13, ymm13, ymm14
       vaddps   ymm13, ymm13, ymmword ptr [reloc @RWD352]
 
G_M000_IG41:                ;; offset=0x0F3D
       vmulps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x858], ymm13
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD416]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD448]
       vpaddd   ymm15, ymm1, ymmword ptr [reloc @RWD384]
       vmovups  ymmword ptr [rbp-0x878], ymm15
       vpaddd   ymm13, ymm2, ymmword ptr [reloc @RWD416]
       vmovups  ymmword ptr [rbp-0x898], ymm13
       vpaddd   ymm13, ymm3, ymmword ptr [reloc @RWD448]
       vmovups  ymmword ptr [rbp-0x8B8], ymm13
       vmovups  ymmword ptr [rbp-0x718], ymm1
       vpxor    ymm13, ymm1, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0x738], ymm2
       vpxor    ymm13, ymm13, ymm2
       vmovups  ymmword ptr [rbp-0x758], ymm3
       vpxor    ymm13, ymm13, ymm3
       vpmulld  ymm13, ymm13, ymmword ptr [reloc @RWD480]
       vpsrad   ymm1, ymm13, 15
       vpxor    ymm1, ymm1, ymm13
       vpand    ymm13, ymm1, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm1, ymm13, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm3, dword ptr [r11+4*xmm1], ymm13
       vpand    ymm1, ymm3, ymmword ptr [reloc @RWD544]
       vxorps   ymm13, ymm13, ymm13
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm1
       vpslld   ymm15, ymm3, 29
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymm4
       vblendvps ymm2, ymm15, ymm13, ymm2
       vpcmpeqd ymm15, ymm1, ymmword ptr [reloc @RWD608]
       vpslld   ymm4, ymm3, 28
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymm5
       vblendvps ymm4, ymm4, ymm13, ymm15
       vaddps   ymm2, ymm4, ymm2
       vpcmpeqd ymm1, ymm1, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm3, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vpxor    ymm3, ymm3, ymm14
       vblendvps ymm1, ymm3, ymm13, ymm1
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0x8D8], ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x878]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x738]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x758]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm13, ymm2, 15
       vpxor    ymm2, ymm13, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
 
G_M000_IG42:                ;; offset=0x10BD
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm3, dword ptr [r11+4*xmm2], ymm13
       vpand    ymm2, ymm3, ymmword ptr [reloc @RWD544]
       vxorps   ymm13, ymm13, ymm13
       vxorps   ymm4, ymm4, ymm4
       vpcmpeqd ymm4, ymm4, ymm2
       vpslld   ymm15, ymm3, 29
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7B8]
       vblendvps ymm4, ymm15, ymm13, ymm4
       vpcmpeqd ymm15, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm1, ymm3, 28
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD576]
       vpxor    ymm1, ymm1, ymm5
       vblendvps ymm1, ymm1, ymm13, ymm15
       vaddps   ymm1, ymm1, ymm4
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm3, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vpxor    ymm3, ymm3, ymm14
       vblendvps ymm2, ymm3, ymm13, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x8D8]
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x818]
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0x8F8], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x718]
       vpxor    ymm3, ymm2, ymmword ptr [rbp-0x298]
       vmovups  ymm4, ymmword ptr [rbp-0x898]
       vpxor    ymm3, ymm3, ymm4
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x758]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpsrad   ymm2, ymm3, 15
       vpxor    ymm3, ymm2, ymm3
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm3, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm15, dword ptr [r11+4*xmm2], ymm3
       vpand    ymm2, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm2
       vpslld   ymm5, ymm15, 29
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x778]
       vblendvps ymm1, ymm5, ymm3, ymm1
       vpcmpeqd ymm5, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm13, ymm15, 28
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x7D8]
       vblendvps ymm5, ymm13, ymm3, ymm5
 
G_M000_IG43:                ;; offset=0x121A
       vaddps   ymm1, ymm5, ymm1
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm15, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm14
       vblendvps ymm2, ymm5, ymm3, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x878]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymm4
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x758]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [r11+4*xmm2], ymm3
       vpand    ymm2, ymm5, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm2
       vpslld   ymm4, ymm5, 29
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x7B8]
       vblendvps ymm4, ymm4, ymm3, ymm13
       vpcmpeqd ymm13, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7D8]
       vblendvps ymm13, ymm15, ymm3, ymm13
       vaddps   ymm4, ymm13, ymm4
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm14
       vblendvps ymm2, ymm5, ymm3, ymm2
       vaddps   ymm2, ymm2, ymm4
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x818]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x918], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x718]
       vpxor    ymm3, ymm2, ymmword ptr [rbp-0x298]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x738]
       vmovups  ymm5, ymmword ptr [rbp-0x8B8]
       vpxor    ymm3, ymm3, ymm5
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpsrad   ymm14, ymm3, 15
       vpxor    ymm3, ymm14, ymm3
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
 
G_M000_IG44:                ;; offset=0x137B
       vpsrld   ymm3, ymm3, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm15, dword ptr [r11+4*xmm3], ymm14
       vpand    ymm3, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm14, ymm14, ymm14
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm3
       vpslld   ymm4, ymm15, 29
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x778]
       vblendvps ymm2, ymm4, ymm14, ymm2
       vpcmpeqd ymm4, ymm3, ymmword ptr [reloc @RWD608]
       vpslld   ymm1, ymm15, 28
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD576]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x798]
       vblendvps ymm1, ymm1, ymm14, ymm4
       vaddps   ymm1, ymm1, ymm2
       vpcmpeqd ymm2, ymm3, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm15, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vmovups  ymm4, ymmword ptr [rbp-0x7F8]
       vpxor    ymm3, ymm3, ymm4
       vblendvps ymm2, ymm3, ymm14, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x878]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x738]
       vpxor    ymm2, ymm2, ymm5
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm14, dword ptr [r11+4*xmm2], ymm3
       vpand    ymm2, ymm14, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm15, ymm15, ymm15
       vpcmpeqd ymm15, ymm15, ymm2
       vpslld   ymm5, ymm14, 29
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x7B8]
       vblendvps ymm5, ymm5, ymm3, ymm15
       vpcmpeqd ymm15, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm13, ymm14, 28
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x798]
       vblendvps ymm13, ymm13, ymm3, ymm15
       vaddps   ymm5, ymm13, ymm5
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm13, ymm14, 27
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymm4
       vblendvps ymm2, ymm13, ymm3, ymm2
 
G_M000_IG45:                ;; offset=0x14DF
       vaddps   ymm2, ymm2, ymm5
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x818]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x938], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x718]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x298]
       vmovups  ymm3, ymmword ptr [rbp-0x898]
       vpxor    ymm2, ymm2, ymm3
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x8B8]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm14, ymm2, 15
       vpxor    ymm2, ymm14, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm15, dword ptr [r11+4*xmm2], ymm14
       vpand    ymm2, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm14, ymm14, ymm14
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm2
       vpslld   ymm13, ymm15, 29
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x778]
       vblendvps ymm1, ymm13, ymm14, ymm1
       vpcmpeqd ymm13, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm5, ymm15, 28
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x7D8]
       vblendvps ymm5, ymm5, ymm14, ymm13
       vaddps   ymm1, ymm5, ymm1
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm15, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm4
       vblendvps ymm2, ymm5, ymm14, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x878]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymm3
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x8B8]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      r11, 0x16A65C00BE0
       mov      r11, gword ptr [r11]
       add      r11, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [r11+4*xmm2], ymm3
       vpand    ymm2, ymm5, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm2
 
G_M000_IG46:                ;; offset=0x1642
       vpslld   ymm14, ymm5, 29
       vpand    ymm14, ymm14, ymmword ptr [reloc @RWD576]
       vpxor    ymm14, ymm14, ymmword ptr [rbp-0x7B8]
       vblendvps ymm13, ymm14, ymm3, ymm13
       vpcmpeqd ymm14, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7D8]
       vblendvps ymm14, ymm15, ymm3, ymm14
       vaddps   ymm13, ymm14, ymm13
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm5, ymm4
       vblendvps ymm2, ymm4, ymm3, ymm2
       vaddps   ymm2, ymm2, ymm13
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x818]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x918]
       vmovups  ymm3, ymmword ptr [rbp-0x8F8]
       vsubps   ymm2, ymm2, ymm3
       vmovups  ymm13, ymmword ptr [rbp-0x838]
       vmulps   ymm2, ymm2, ymm13
       vaddps   ymm2, ymm2, ymm3
       vmovups  ymm3, ymmword ptr [rbp-0x938]
       vsubps   ymm1, ymm1, ymm3
       vmulps   ymm1, ymm1, ymm13
       vaddps   ymm1, ymm1, ymm3
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x858]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD672]
       vmovups  ymmword ptr [rbp-0x6F8], ymm1
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       jmp      G_M000_IG58
 
G_M000_IG47:                ;; offset=0x172D
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       vcmpeqps ymm1, ymm13, ymm13
       vandps   ymm1, ymm1, ymm13
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x958], ymm1
       vcmpeqps ymm1, ymm14, ymm14
       vandps   ymm1, ymm1, ymm14
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm14, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x978], ymm1
       vcmpeqps ymm1, ymm15, ymm15
       vandps   ymm1, ymm1, ymm15
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm15, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x998], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x958]
       vsubps   ymm1, ymm13, ymm1
       vmovups  ymmword ptr [rbp-0x9B8], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x978]
       vsubps   ymm1, ymm14, ymm1
       vmovups  ymmword ptr [rbp-0x9D8], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x998]
       vsubps   ymm1, ymm15, ymm1
       vmovups  ymmword ptr [rbp-0x9F8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x958]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vmovups  ymmword ptr [rbp-0x958], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x978]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD416]
       vmovups  ymmword ptr [rbp-0x978], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x998]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD448]
       vmovups  ymmword ptr [rbp-0x998], ymm1
       vbroadcastss ymm1, dword ptr [reloc @RWD384]
       vbroadcastss ymm2, dword ptr [reloc @RWD416]
       vbroadcastss ymm3, dword ptr [reloc @RWD448]
       vmovups  ymm4, ymmword ptr [rbp-0x958]
       vpsubd   ymm4, ymm4, ymm1
       vmovups  ymmword ptr [rbp-0xA18], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x978]
       vpsubd   ymm4, ymm4, ymm2
       vmovups  ymmword ptr [rbp-0xA38], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x998]
       vpsubd   ymm4, ymm4, ymm3
 
G_M000_IG48:                ;; offset=0x18BD
       vmovups  ymmword ptr [rbp-0xA58], ymm4
       vpaddd   ymm1, ymm1, ymmword ptr [rbp-0x958]
       vmovups  ymmword ptr [rbp-0xA78], ymm1
       vpaddd   ymm1, ymm2, ymmword ptr [rbp-0x978]
       vmovups  ymmword ptr [rbp-0xA98], ymm1
       vpaddd   ymm1, ymm3, ymmword ptr [rbp-0x998]
       vmovups  ymmword ptr [rbp-0xAB8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x958]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD704]
       vmovups  ymmword ptr [rbp-0xAD8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x978]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD736]
       vmovups  ymmword ptr [rbp-0xAF8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x998]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD768]
       vmovups  ymmword ptr [rbp-0xB18], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x298]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA18]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA38]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA58]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x958]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA38]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA58]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x298]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA78]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA38]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA58]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x298]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAD8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA38]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA58]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
 
G_M000_IG49:                ;; offset=0x1A55
       vmovups  ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm14, ymm13, ymm4
       vsubps   ymm15, ymm1, ymm2
       vsubps   ymm4, ymm15, ymm4
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm14
       vsubps   ymm1, ymm3, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9B8]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xBF8], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x298]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA18]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x978]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA58]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x958]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x978]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA58]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x298]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA78]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x978]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA58]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x298]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAD8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x978]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA58]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
       vmovups  ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9B8]
 
G_M000_IG50:                ;; offset=0x1BCE
       vmulps   ymm13, ymm13, ymm4
       vsubps   ymm14, ymm1, ymm2
       vsubps   ymm4, ymm14, ymm4
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm13
       vsubps   ymm1, ymm3, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9B8]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xC18], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x298]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA18]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA98]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA58]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x298]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x958]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA98]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA58]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x298]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA78]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA98]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA58]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x298]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAD8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA98]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA58]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
       vmovups  ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9B8]
       vmulps   ymm13, ymm13, ymm4
       vsubps   ymm14, ymm1, ymm2
       vsubps   ymm4, ymm14, ymm4
 
G_M000_IG51:                ;; offset=0x1D3B
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm13
       vsubps   ymm1, ymm3, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9B8]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xC38], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0xA18]
       vmovups  ymmword ptr [rbp-0xEB8], ymm1
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      rcx, [rbp-0xDB8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       lea      r8, [rbp-0xE98]
       lea      rdx, [rbp-0xDB8]
       lea      rcx, [rbp-0xDD8]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xA58]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       lea      r8, [rbp-0xE98]
       lea      rdx, [rbp-0xDD8]
       lea      rcx, [rbp-0xDF8]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xE18]
       mov      edx, 0x27D4EB2D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xCF8]
       lea      rdx, [rbp-0xDF8]
       lea      r8, [rbp-0xE18]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF8]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       lea      rdx, [rbp-0xE98]
       lea      rcx, [rbp-0xD18]
       lea      r8, [rbp-0xCF8]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xD18]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
 
G_M000_IG52:                ;; offset=0x1E6B
       lea      rdx, [rbp-0xE98]
       lea      rcx, [rbp-0xD38]
       mov      r8d, 19
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftLeft(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xD58]
       lea      rdx, [rbp-0xD18]
       lea      r8, [rbp-0xD38]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xD78]
       lea      rdx, [rbp-0xD58]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xD98]
       vmovss   xmm1, dword ptr [reloc @RWD800]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xC78]
       lea      rdx, [rbp-0xD78]
       lea      r8, [rbp-0xD98]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x958]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA58]
       vmovups  ymmword ptr [rbp-0xEF8], ymm0
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
       lea      rcx, [rbp-0xEF8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xC98]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA78]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA58]
       vmovups  ymmword ptr [rbp-0xEF8], ymm0
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
 
G_M000_IG53:                ;; offset=0x1FA7
       lea      rcx, [rbp-0xEF8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xCB8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD8]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       lea      rdx, [rbp-0xA58]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
       lea      rcx, [rbp-0xCD8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xCD8]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9B8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xC78]
       lea      r8, [rbp-0xC98]
       lea      r9, [rbp-0xCB8]
       lea      rcx, [rbp-0xC58]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xC58]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9D8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xBF8]
       lea      r8, [rbp-0xC18]
       lea      r9, [rbp-0xC38]
       lea      rcx, [rbp-0xB38]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA18]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x958]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA78]
       vmovups  ymmword ptr [rbp-0xEF8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD8]
       vmovups  ymmword ptr [rbp-0xF18], ymm0
 
G_M000_IG54:                ;; offset=0x2102
       vmovups  ymm0, ymmword ptr [rbp-0xA38]
       vmovups  ymmword ptr [rbp-0xF38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x978]
       vmovups  ymmword ptr [rbp-0xF58], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA98]
       vmovups  ymmword ptr [rbp-0xF78], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xF98], ymm0
       lea      rdx, [rbp-0x998]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9B8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D8]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
       lea      rcx, [rbp-0xEF8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xF18]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF38]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF58]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF78]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xF98]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE38]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE58]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB58]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x298]
       vmovups  ymmword ptr [rbp-0xE98], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA18]
       vmovups  ymmword ptr [rbp-0xEB8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x958]
       vmovups  ymmword ptr [rbp-0xED8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA78]
       vmovups  ymmword ptr [rbp-0xEF8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD8]
       vmovups  ymmword ptr [rbp-0xF18], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA38]
       vmovups  ymmword ptr [rbp-0xF38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x978]
       vmovups  ymmword ptr [rbp-0xF58], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA98]
       vmovups  ymmword ptr [rbp-0xF78], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF8]
       vmovups  ymmword ptr [rbp-0xF98], ymm0
       lea      rdx, [rbp-0xAB8]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9B8]
 
G_M000_IG55:                ;; offset=0x2294
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D8]
       vmovups  ymmword ptr [rbp-0xE58], ymm0
       lea      rdx, [rbp-0xE98]
       lea      r8, [rbp-0xEB8]
       lea      r9, [rbp-0xED8]
       lea      rcx, [rbp-0xEF8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xF18]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF38]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF58]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF78]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xF98]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE38]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE58]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB78]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xA78]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xAD8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xA38]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0x978]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xA98]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xAF8]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xB18]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x9B8]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0x9D8]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB98]
       lea      rdx, [rbp-0x298]
       lea      r8, [rbp-0xA18]
       lea      r9, [rbp-0x958]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB98]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x9F8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xBB8]
       lea      rdx, [rbp-0xB38]
       lea      r8, [rbp-0xB58]
 
G_M000_IG56:                ;; offset=0x23E9
       lea      r9, [rbp-0xB78]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xBD8]
       vmovss   xmm1, dword ptr [reloc @RWD832]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6F8]
       lea      rdx, [rbp-0xBB8]
       lea      r8, [rbp-0xBD8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG58
 
G_M000_IG57:                ;; offset=0x243D
       mov      dword ptr [rbp+0x1A0], r8d
       mov      dword ptr [rbp+0x180], r10d
       mov      dword ptr [rbp+0x1A4], r9d
       vmovups  ymmword ptr [rbp-0xE38], ymm13
       vmovups  ymmword ptr [rbp-0xE58], ymm14
       vmovups  ymmword ptr [rbp-0xE78], ymm15
       lea      r8, [rbp-0xE38]
       lea      r9, [rbp-0xE58]
       lea      r11, [rbp-0xE78]
       mov      qword ptr [rsp+0x20], r11
       lea      rdx, [rbp-0x298]
       lea      rcx, [rbp-0x6F8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.ValueKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG58:                ;; offset=0x24BC
       lea      rcx, [rbp-0x150]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       test     eax, eax
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       je       SHORT G_M000_IG59
       vmovups  ymm0, ymmword ptr [rbp-0x6F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      r8, [rbp-0xE38]
       lea      rdx, [rbp-0x150]
       lea      rcx, [rbp-0x2B8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:ShapeSingle[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x2542
       vmovups  ymm1, ymmword ptr [rbp-0x6F8]
       vmovups  ymmword ptr [rbp-0x2B8], ymm1
 
G_M000_IG60:                ;; offset=0x2552
       lea      rcx, [rbp-0x2F8]
       vmovss   xmm1, dword ptr [rbp-0x2BC]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x218]
       lea      rdx, [rbp-0x2B8]
       lea      r8, [rbp-0x2F8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG15
 
G_M000_IG61:                ;; offset=0x25AB
       lea      ecx, [r14-0x01]
       mov      dword ptr [rbp-0x39C], eax
       cmp      eax, ecx
       jne      G_M000_IG64
       lea      rcx, [rbp-0x6D8]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmmword ptr [rbp+0x120], ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x338]
       lea      r8, [rbp-0x6D8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmmword ptr [rbp+0x120]
       vmovss   dword ptr [rbp+0x184], xmm8
       mov      eax, dword ptr [rbp-0x39C]
       jmp      G_M000_IG24
 
G_M000_IG62:                ;; offset=0x2639
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x3F8]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Abs(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x418]
       vmovss   xmm1, dword ptr [reloc @RWD836]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x438]
       lea      r8, [rbp-0x418]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x458]
       vmovaps  xmm1, xmm9
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x478]
       lea      rdx, [rbp-0x438]
       lea      r8, [rbp-0x458]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      r8, [rbp-0xE38]
       lea      rdx, [rbp-0x478]
       lea      rcx, [rbp-0x498]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x318]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x318]
       lea      r8, [rbp-0x498]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4B8]
       vmovaps  xmm1, xmm9
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4D8]
       lea      rdx, [rbp-0x4B8]
       lea      r8, [rbp-0x3F8]
 
G_M000_IG63:                ;; offset=0x2759
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
       jmp      G_M000_IG26
 
G_M000_IG64:                ;; offset=0x2776
       vmovss   dword ptr [rbp+0x184], xmm8
       mov      eax, dword ptr [rbp-0x39C]
       jmp      G_M000_IG24
 
G_M000_IG65:                ;; offset=0x2789
       lea      rcx, [rbp-0x538]
       vmovaps  xmm1, xmm9
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x558]
       lea      rdx, [rbp-0x3F8]
       lea      r8, [rbp-0x538]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_PingPongStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x578]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x598]
       lea      rdx, [rbp-0x558]
       lea      r8, [rbp-0x578]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x3F8]
       lea      rdx, [rbp-0x598]
       call     [Tedd.FastNoise.Internal.NoiseMath:PingPong[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5B8]
       vmovss   xmm1, dword ptr [reloc @RWD68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x5D8]
       lea      r8, [rbp-0x5B8]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5F8]
       vmovss   xmm1, dword ptr [reloc @RWD840]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x618]
       lea      rdx, [rbp-0x5D8]
       lea      r8, [rbp-0x5F8]
 
G_M000_IG66:                ;; offset=0x287F
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x338]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      r8, [rbp-0xE38]
       lea      rdx, [rbp-0x618]
       lea      rcx, [rbp-0x638]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x318]
       vmovups  ymmword ptr [rbp-0xE38], ymm0
       lea      rdx, [rbp-0xE38]
       lea      rcx, [rbp-0x318]
       lea      r8, [rbp-0x638]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3F8]
       vmovups  ymmword ptr [rbp-0x4D8], ymm0
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm8
       jmp      G_M000_IG26
 
G_M000_IG67:                ;; offset=0x2902
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dq	0000000100000000h, 0000000300000002h, 0000000500000004h, 0000000700000006h
RWD32  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD64  	dd	3F800000h		;         1
RWD68  	dd	3F000000h		;       0.5
RWD72  	dd	00000A16h ; case G_M000_IG32
       	dd	00000A57h ; case G_M000_IG33
       	dd	00000A03h ; case G_M000_IG31
RWD84  	dd	00000000h, 00000000h, 00000000h
RWD96  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD128 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD160 	dd	00000B3Dh ; case G_M000_IG38
       	dd	00000AD7h ; case G_M000_IG35
       	dd	00000BC1h ; case G_M000_IG39
       	dd	00000C6Bh ; case G_M000_IG40
       	dd	000015CAh ; case G_M000_IG47
       	dd	000022DAh ; case G_M000_IG57
RWD184 	dd	00000000h, 00000000h
RWD192 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD224 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD256 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD288 	dq	40C0000040C00000h, 40C0000040C00000h, 40C0000040C00000h, 40C0000040C00000h
RWD320 	dq	4170000041700000h, 4170000041700000h, 4170000041700000h, 4170000041700000h
RWD352 	dq	4120000041200000h, 4120000041200000h, 4120000041200000h, 4120000041200000h
RWD384 	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD416 	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD448 	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD480 	dq	27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh
RWD512 	dq	000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh
RWD544 	dq	0000000300000003h, 0000000300000003h, 0000000300000003h, 0000000300000003h
RWD576 	dq	8000000080000000h, 8000000080000000h, 8000000080000000h, 8000000080000000h
RWD608 	dq	0000000100000001h, 0000000100000001h, 0000000100000001h, 0000000100000001h
RWD640 	dq	0000000200000002h, 0000000200000002h, 0000000200000002h, 0000000200000002h
RWD672 	dq	3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h
RWD704 	dq	3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h
RWD736 	dq	87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah
RWD768 	dq	CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh
RWD800 	dq	3000000030000000h, 3000000030000000h, 3000000030000000h, 3000000030000000h
RWD832 	dd	3E97B426h		;  0.296296
RWD836 	dd	C0000000h		;        -2
RWD840 	dd	40000000h		;         2

; Total bytes of code 10504

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3(Tedd.FastNoise.Procedural.CompiledStack3D,Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int,bool) (Tier1-OSR)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0x135
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 3
; 9 inlinees with PGO data; 906 single block inlinees; 11 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       mov      rax, qword ptr [rbp]
       push     rax
       lea      r11, [rsp-0x1200]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       mov      qword ptr [rsp+0x1528], r15
       mov      qword ptr [rsp+0x1520], r14
       mov      qword ptr [rsp+0x1518], r13
       mov      qword ptr [rsp+0x1510], r12
       mov      qword ptr [rsp+0x1508], rdi
       mov      qword ptr [rsp+0x1500], rsi
       mov      qword ptr [rsp+0x14F8], rbx
       vmovaps  xmmword ptr [rsp+0x11B0], xmm6
       vmovaps  xmmword ptr [rsp+0x11A0], xmm7
       vmovaps  xmmword ptr [rsp+0x1190], xmm8
       vmovaps  xmmword ptr [rsp+0x1180], xmm9
       vmovaps  xmmword ptr [rsp+0x1170], xmm10
       vmovaps  xmmword ptr [rsp+0x1160], xmm11
       vmovaps  xmmword ptr [rsp+0x1150], xmm12
       vmovaps  xmmword ptr [rsp+0x1140], xmm13
       vmovaps  xmmword ptr [rsp+0x1130], xmm14
       vmovaps  xmmword ptr [rsp+0x1120], xmm15
       lea      rbp, [rsp+0x1200]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -0xE70
       vmovdqa  xmmword ptr [rbp+rax-0x110], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x100], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0xF0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x110], rax
       mov      rdi, gword ptr [rbp+0x348]
       mov      rsi, bword ptr [rbp+0x350]
       mov      rbx, bword ptr [rbp+0x358]
       mov      r14d, dword ptr [rbp+0x360]
       mov      r15d, dword ptr [rbp+0x368]
       mov      r10, gword ptr [rbp+0x2E8]
       mov      r9d, dword ptr [rbp+0x2E4]
       mov      r11d, dword ptr [rbp+0x2E0]
       mov      r8d, dword ptr [rbp+0x2DC]
       vmovss   xmm6, dword ptr [rbp+0x2D8]
       mov      r12d, dword ptr [rbp+0x2D4]
       vmovss   xmm7, dword ptr [rbp+0x2C8]
       vmovss   xmm8, dword ptr [rbp+0x2C4]
       mov      ecx, dword ptr [rbp+0x2C0]
       mov      r13d, dword ptr [rbp+0x2BC]
 
G_M000_IG02:                ;; offset=0x0150
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0152
       mov      ecx, dword ptr [rbp+0x2C0]
       mov      r8d, dword ptr [rbp+0x2DC]
       mov      r9d, dword ptr [rbp+0x2E4]
       mov      r11d, dword ptr [rbp+0x2E0]
 
G_M000_IG04:                ;; offset=0x016D
       cmp      r13d, r11d
       jl       SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x0172
       inc      r12d
       lea      eax, [r14+r15]
       cmp      eax, r12d
       jle      G_M000_IG11
 
G_M000_IG06:                ;; offset=0x0182
       mov      eax, r12d
       cdq      
       idiv     edx:eax, r8d
       mov      ecx, edx
       mov      dword ptr [rbp+0x2DC], r8d
       mov      eax, r12d
       cdq      
       idiv     edx:eax, r8d
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, ecx
       vmulss   xmm0, xmm0, xmm6
       vaddss   xmm7, xmm0, dword ptr [rsi+0x04]
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, eax
       vmulss   xmm0, xmm0, xmm6
       vaddss   xmm8, xmm0, dword ptr [rsi+0x08]
       mov      ecx, r12d
       imul     ecx, r11d
       mov      dword ptr [rbp+0x2C0], ecx
       xor      edx, edx
       xor      eax, eax
       test     r10, r10
       jne      G_M000_IG15
 
G_M000_IG07:                ;; offset=0x01D5
       mov      r13d, eax
       mov      ecx, dword ptr [rbp+0x2C0]
       mov      r8d, dword ptr [rbp+0x2DC]
       jmp      SHORT G_M000_IG04
 
G_M000_IG08:                ;; offset=0x01E7
       mov      gword ptr [rbp+0x2E8], r10
       mov      dword ptr [rbp+0x2E0], r11d
       mov      dword ptr [rbp+0x2C0], ecx
       mov      dword ptr [rbp+0x2E4], r9d
       mov      dword ptr [rbp+0x2DC], r8d
       mov      rcx, rsi
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r13d
       vmulss   xmm9, xmm1, xmm6
       vaddss   xmm1, xmm0, xmm9
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       mov      rax, gword ptr [rbp+0x2F0]
       mov      rcx, gword ptr [rax+0x08]
       mov      gword ptr [rbp+0x2F0], rax
       call     [rax+0x18]System.Func`4[float,float,float,float]:Invoke(float,float,float):float:this
       vmovaps  xmm10, xmm0
       vmovaps  xmm0, xmm10
       call     [System.Single:IsNaN(float):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0255
       mov      rcx, rsi
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vaddss   xmm1, xmm0, xmm9
       mov      rcx, rdi
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovaps  xmm10, xmm0
 
G_M000_IG10:                ;; offset=0x0279
       mov      ecx, dword ptr [rbp+0x2C0]
       lea      eax, [rcx+r13]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG73
       lea      eax, [rcx+r13]
       mov      rdx, bword ptr [rbx]
       vmovss   dword ptr [rdx+4*rax], xmm10
       inc      r13d
       mov      r8d, dword ptr [rbp+0x2DC]
       mov      r9d, dword ptr [rbp+0x2E4]
       mov      r10, gword ptr [rbp+0x2E8]
       mov      r11d, dword ptr [rbp+0x2E0]
       jmp      G_M000_IG04
 
G_M000_IG11:                ;; offset=0x02BC
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x11B0]
       vmovaps  xmm7, xmmword ptr [rsp+0x11A0]
       vmovaps  xmm8, xmmword ptr [rsp+0x1190]
       vmovaps  xmm9, xmmword ptr [rsp+0x1180]
       vmovaps  xmm10, xmmword ptr [rsp+0x1170]
       vmovaps  xmm11, xmmword ptr [rsp+0x1160]
       vmovaps  xmm12, xmmword ptr [rsp+0x1150]
       vmovaps  xmm13, xmmword ptr [rsp+0x1140]
       vmovaps  xmm14, xmmword ptr [rsp+0x1130]
       vmovaps  xmm15, xmmword ptr [rsp+0x1120]
       add      rsp, 0x14F8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG12:                ;; offset=0x032D
       vmovups  ymm0, ymmword ptr [rbp-0x128]
       vmovups  ymmword ptr [rbp+0x260], ymm0
 
G_M000_IG13:                ;; offset=0x033D
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xF80], xmm0
 
G_M000_IG14:                ;; offset=0x0349
       lea      rdx, [rbp-0xF80]
       mov      r8d, r13d
       add      r8d, dword ptr [rbp+0x2C0]
       lea      rcx, [rbp+0x260]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      r13d, dword ptr [rbp-0x104C]
       mov      eax, r13d
       mov      r9d, dword ptr [rbp+0x2E4]
       mov      r10, gword ptr [rbp+0x2E8]
       mov      r11d, dword ptr [rbp+0x2E0]
 
G_M000_IG15:                ;; offset=0x0386
       mov      dword ptr [rbp+0x2E4], r9d
       lea      ecx, [rax+r9]
       mov      dword ptr [rbp+0x2E0], r11d
       cmp      ecx, r11d
       mov      dword ptr [rbp-0x104C], ecx
       mov      r13d, eax
       jg       G_M000_IG03
 
G_M000_IG16:                ;; offset=0x03AA
       vbroadcastss ymm0, ymm6
       vcvtdq2ps ymm1, ymmword ptr [reloc @RWD00]
       vmulps   ymm0, ymm1, ymm0
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r13d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm1, dword ptr [rsi]
       vbroadcastss ymm1, ymm1
       vaddps   ymm9, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0xE08], ymm9
       vbroadcastss ymm0, ymm7
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       vbroadcastss ymm0, ymm8
       vmovups  ymmword ptr [rbp-0xE48], ymm0
       lea      r8, [rbp-0xE08]
       lea      r9, [rbp-0xE28]
       lea      rdx, [rbp-0xE48]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp+0x260]
       mov      rcx, gword ptr [r10+0x08]
       vextractf128 xmm10, ymm9
       mov      gword ptr [rbp+0x2E8], r10
       call     [r10+0x18]System.Func`4[System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]]:Invoke(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this
       vmovups  ymm1, ymmword ptr [rbp+0x260]
       vcmpeqps ymm1, ymm1, ymmword ptr [rbp+0x260]
       vmovmskps rcx, ymm1
       cmp      ecx, 255
       vinsertf128 ymm9, ymm9, xmm10
       je       G_M000_IG13
 
G_M000_IG17:                ;; offset=0x0454
       vbroadcastss ymm11, ymm7
       vmovups  ymmword ptr [rbp-0x108], ymm11
       vbroadcastss ymm12, ymm8
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x140], xmm1
       vmovdqu  xmmword ptr [rbp-0x13C], xmm1
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x160], xmm1
       vmovdqu  xmmword ptr [rbp-0x154], xmm1
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x128], ymm1
       xor      eax, eax
       jmp      G_M000_IG48
 
G_M000_IG18:                ;; offset=0x04A1
       vmovups  ymm0, ymmword ptr [rbp-0x188]
       vmovups  ymmword ptr [rbp-0x208], ymm0
       jmp      G_M000_IG47
 
G_M000_IG19:                ;; offset=0x04B6
       lea      rcx, [rbp-0x308]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Bounding():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x328]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Lacunarity():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x348]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Gain():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x368]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_WeightedStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x388]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      edx, dword ptr [rbp-0x168]
       cmp      eax, edx
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jl       G_M000_IG67
 
G_M000_IG20:                ;; offset=0x0567
       vmovups  ymm0, ymmword ptr [rbp-0x308]
       vmovups  ymmword ptr [rbp-0x228], ymm0
       jmp      G_M000_IG45
 
G_M000_IG21:                ;; offset=0x057C
       vcmpeqps ymm0, ymm13, ymm13
       vandps   ymm0, ymm0, ymm13
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vcmpgeps ymm2, ymm0, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD36]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xA68], ymm0
       vcmpeqps ymm0, ymm14, ymm14
       vandps   ymm0, ymm0, ymm14
       vcmpgeps ymm2, ymm0, ymm1
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm14, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xA88], ymm0
       vcmpeqps ymm0, ymm15, ymm15
       vandps   ymm0, ymm0, ymm15
       vcmpgeps ymm1, ymm0, ymm1
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm1
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm15, ymm1
       vpaddd   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [rbp-0xAA8], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xA68]
       vsubps   ymm0, ymm13, ymm0
       vmovups  ymmword ptr [rbp-0xAC8], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xA88]
       vsubps   ymm0, ymm14, ymm0
       vmovups  ymmword ptr [rbp-0xAE8], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xAA8]
       vsubps   ymm0, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0xB08], ymm0
       vbroadcastss ymm0, dword ptr [reloc @RWD40]
       vpmulld  ymm1, ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xA68], ymm1
       vbroadcastss ymm1, dword ptr [reloc @RWD44]
       vpmulld  ymm2, ymm1, ymmword ptr [rbp-0xA88]
       vmovups  ymmword ptr [rbp-0xA88], ymm2
       vbroadcastss ymm2, dword ptr [reloc @RWD48]
       vpmulld  ymm3, ymm2, ymmword ptr [rbp-0xAA8]
       vmovups  ymmword ptr [rbp-0xAA8], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xA68]
       vpsubd   ymm3, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xB28], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xA88]
       vpsubd   ymm3, ymm3, ymm1
       vmovups  ymmword ptr [rbp-0xB48], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xAA8]
       vpsubd   ymm3, ymm3, ymm2
       vmovups  ymmword ptr [rbp-0xB68], ymm3
       vpaddd   ymm0, ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xB88], ymm0
       vpaddd   ymm0, ymm1, ymmword ptr [rbp-0xA88]
       vmovups  ymmword ptr [rbp-0xBA8], ymm0
 
G_M000_IG22:                ;; offset=0x0701
       vpaddd   ymm0, ymm2, ymmword ptr [rbp-0xAA8]
       vmovups  ymmword ptr [rbp-0xBC8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA68]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rbp-0xBE8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA88]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rbp-0xC08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAA8]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD128]
       vmovups  ymmword ptr [rbp-0xC28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB28]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB48]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB68]
       vbroadcastss ymm1, dword ptr [reloc @RWD160]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm2, ymm0, 19
       vpxor    ymm0, ymm2, ymm0
       vcvtdq2ps ymm0, ymm0
       vbroadcastss ymm2, dword ptr [reloc @RWD164]
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2A8]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA68]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB48]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB68]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2A8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB88]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB48]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB68]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2A8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBE8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB48]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB68]
       vpmulld  ymm5, ymm5, ymm1
       vpmulld  ymm5, ymm5, ymm5
       vpslld   ymm13, ymm5, 19
       vpxor    ymm5, ymm13, ymm5
       vcvtdq2ps ymm5, ymm5
       vmulps   ymm5, ymm5, ymm2
       vsubps   ymm5, ymm5, ymm4
       vsubps   ymm14, ymm0, ymm3
       vsubps   ymm5, ymm5, ymm14
       vmovups  ymm15, ymmword ptr [rbp-0xAC8]
       vmulps   ymm13, ymm15, ymmword ptr [rbp-0xAC8]
       vmulps   ymm14, ymm13, ymmword ptr [rbp-0xAC8]
 
G_M000_IG23:                ;; offset=0x087C
       vmulps   ymm14, ymm14, ymm5
       vsubps   ymm15, ymm0, ymm3
       vsubps   ymm5, ymm15, ymm5
       vmulps   ymm5, ymm5, ymm13
       vaddps   ymm5, ymm5, ymm14
       vsubps   ymm0, ymm4, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xAC8]
       vaddps   ymm0, ymm0, ymm5
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB28]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xA88]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB68]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm3, ymm0, 19
       vpxor    ymm0, ymm3, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2A8]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA68]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA88]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB68]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2A8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB88]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA88]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB68]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2A8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBE8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xA88]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB68]
       vpmulld  ymm5, ymm5, ymm1
       vpmulld  ymm5, ymm5, ymm5
       vpslld   ymm13, ymm5, 19
       vpxor    ymm5, ymm13, ymm5
       vcvtdq2ps ymm5, ymm5
       vmulps   ymm5, ymm5, ymm2
       vsubps   ymm5, ymm5, ymm4
       vsubps   ymm13, ymm0, ymm3
       vsubps   ymm5, ymm5, ymm13
       vmovups  ymm13, ymmword ptr [rbp-0xAC8]
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0xAC8]
       vmulps   ymm14, ymm13, ymmword ptr [rbp-0xAC8]
       vmulps   ymm14, ymm14, ymm5
       vsubps   ymm15, ymm0, ymm3
       vsubps   ymm5, ymm15, ymm5
 
G_M000_IG24:                ;; offset=0x09CB
       vmulps   ymm5, ymm5, ymm13
       vaddps   ymm5, ymm5, ymm14
       vsubps   ymm0, ymm4, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xAC8]
       vaddps   ymm0, ymm0, ymm5
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB28]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xBA8]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB68]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm3, ymm0, 19
       vpxor    ymm0, ymm3, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2A8]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA68]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xBA8]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB68]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2A8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB88]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBA8]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB68]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2A8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBE8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBA8]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB68]
       vpmulld  ymm1, ymm5, ymm1
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm5, ymm1, 19
       vpxor    ymm1, ymm5, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm4
       vsubps   ymm2, ymm0, ymm3
       vsubps   ymm1, ymm1, ymm2
       vmovups  ymm2, ymmword ptr [rbp-0xAC8]
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0xAC8]
       vmulps   ymm5, ymm2, ymmword ptr [rbp-0xAC8]
       vmulps   ymm5, ymm5, ymm1
       vsubps   ymm13, ymm0, ymm3
       vsubps   ymm1, ymm13, ymm1
       vmulps   ymm1, ymm1, ymm2
       vaddps   ymm1, ymm1, ymm5
       vsubps   ymm0, ymm4, ymm0
 
G_M000_IG25:                ;; offset=0x0B19
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xAC8]
       vaddps   ymm0, ymm0, ymm1
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD48], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB28]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB68]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xD88]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB68]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xDA8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB88]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB68]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xDC8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
 
G_M000_IG26:                ;; offset=0x0C8F
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBE8]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       lea      rdx, [rbp-0xB68]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xDE8]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xDE8]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xAC8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xD88]
       lea      r8, [rbp-0xDA8]
       lea      r9, [rbp-0xDC8]
       lea      rcx, [rbp-0xD68]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xD68]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xAE8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xD08]
       lea      r8, [rbp-0xD28]
       lea      r9, [rbp-0xD48]
       lea      rcx, [rbp-0xC48]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB28]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB88]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBE8]
       vmovups  ymmword ptr [rbp-0xEE8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB48]
       vmovups  ymmword ptr [rbp-0xF08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA88]
       vmovups  ymmword ptr [rbp-0xF28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBA8]
       vmovups  ymmword ptr [rbp-0xF48], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xF68], ymm0
 
G_M000_IG27:                ;; offset=0x0E09
       lea      rdx, [rbp-0xAA8]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xAC8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAE8]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xEE8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF08]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF28]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF48]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xF68]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE08]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE28]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xC68]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0xE68], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB28]
       vmovups  ymmword ptr [rbp-0xE88], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA68]
       vmovups  ymmword ptr [rbp-0xEA8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB88]
       vmovups  ymmword ptr [rbp-0xEC8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBE8]
       vmovups  ymmword ptr [rbp-0xEE8], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB48]
       vmovups  ymmword ptr [rbp-0xF08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA88]
       vmovups  ymmword ptr [rbp-0xF28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBA8]
       vmovups  ymmword ptr [rbp-0xF48], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC08]
       vmovups  ymmword ptr [rbp-0xF68], ymm0
       lea      rdx, [rbp-0xBC8]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xAC8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAE8]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE68]
       lea      r8, [rbp-0xE88]
       lea      r9, [rbp-0xEA8]
       lea      rcx, [rbp-0xEC8]
       mov      qword ptr [rsp+0x20], rcx
 
G_M000_IG28:                ;; offset=0x0F94
       lea      rcx, [rbp-0xEE8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF08]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF28]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF48]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xF68]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE08]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE28]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xC88]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB88]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xBE8]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xB48]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xA88]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xBA8]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xC08]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xC28]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0xAC8]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xAE8]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xCA8]
       lea      rdx, [rbp-0x2A8]
       lea      r8, [rbp-0xB28]
       lea      r9, [rbp-0xA68]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xCA8]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xB08]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xCC8]
       lea      rdx, [rbp-0xC48]
       lea      r8, [rbp-0xC68]
       lea      r9, [rbp-0xC88]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xCE8]
       vmovss   xmm1, dword ptr [reloc @RWD168]
 
G_M000_IG29:                ;; offset=0x10CC
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6E8]
       lea      rdx, [rbp-0xCC8]
       lea      r8, [rbp-0xCE8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG42
 
G_M000_IG30:                ;; offset=0x10FE
       vcmpeqps ymm0, ymm13, ymm13
       vandps   ymm0, ymm0, ymm13
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vcmpgeps ymm2, ymm0, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD36]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vcmpeqps ymm2, ymm14, ymm14
       vandps   ymm2, ymm2, ymm14
       vcmpgeps ymm4, ymm2, ymm1
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm3, ymm4
       vxorps   ymm4, ymm4, ymm4
       vcmpltps ymm4, ymm14, ymm4
       vpaddd   ymm2, ymm4, ymm2
       vcmpeqps ymm4, ymm15, ymm15
       vandps   ymm4, ymm4, ymm15
       vcmpgeps ymm1, ymm4, ymm1
       vcvttps2dq ymm4, ymm4
       vpblendvb ymm1, ymm4, ymm3, ymm1
       vxorps   ymm3, ymm3, ymm3
       vcmpltps ymm3, ymm15, ymm3
       vpaddd   ymm1, ymm3, ymm1
       vcvtdq2ps ymm3, ymm0
       vsubps   ymm3, ymm13, ymm3
       vcvtdq2ps ymm4, ymm2
       vsubps   ymm4, ymm14, ymm4
       vcvtdq2ps ymm5, ymm1
       vsubps   ymm5, ymm15, ymm5
       vbroadcastss ymm13, dword ptr [reloc @RWD172]
       vsubps   ymm14, ymm3, ymm13
       vmovups  ymmword ptr [rbp-0x728], ymm14
       vsubps   ymm15, ymm4, ymm13
       vmovups  ymmword ptr [rbp-0x748], ymm15
       vsubps   ymm13, ymm5, ymm13
       vmovups  ymmword ptr [rbp-0x768], ymm13
       vmulps   ymm13, ymm3, ymm3
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD176]
       vmovups  ymmword ptr [rbp-0x1108], ymm13
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x1198], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD180]
       vmovups  ymmword ptr [rbp-0x1128], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x1198]
       vsubps   ymm13, ymm13, ymmword ptr [rbp-0x1128]
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x1198], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD184]
       vmovups  ymmword ptr [rbp-0x1148], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x1198]
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1148]
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x788], ymm13
       vmulps   ymm15, ymm4, ymm4
       vmulps   ymm15, ymm15, ymm4
       vmovups  ymmword ptr [rbp-0x1178], ymm15
 
G_M000_IG31:                ;; offset=0x1268
       vmovups  ymm15, ymmword ptr [rbp-0x1108]
       vmulps   ymm15, ymm15, ymm4
       vsubps   ymm15, ymm15, ymmword ptr [rbp-0x1128]
       vmulps   ymm15, ymm15, ymm4
       vaddps   ymm15, ymm15, ymmword ptr [rbp-0x1148]
       vmulps   ymm15, ymm15, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x7A8], ymm15
       vmulps   ymm15, ymm5, ymm5
       vmulps   ymm15, ymm15, ymm5
       vmovups  ymmword ptr [rbp-0x1178], ymm15
       vmovups  ymm15, ymmword ptr [rbp-0x1108]
       vmulps   ymm15, ymm15, ymm5
       vsubps   ymm15, ymm15, ymmword ptr [rbp-0x1128]
       vmulps   ymm15, ymm15, ymm5
       vaddps   ymm15, ymm15, ymmword ptr [rbp-0x1148]
       vmulps   ymm15, ymm15, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x7C8], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD40]
       vpmulld  ymm0, ymm15, ymm0
       vbroadcastss ymm13, dword ptr [reloc @RWD44]
       vpmulld  ymm2, ymm13, ymm2
       vbroadcastss ymm14, dword ptr [reloc @RWD48]
       vpmulld  ymm1, ymm14, ymm1
       vpaddd   ymm15, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0x7E8], ymm15
       vpaddd   ymm13, ymm13, ymm2
       vmovups  ymmword ptr [rbp-0x808], ymm13
       vpaddd   ymm14, ymm14, ymm1
       vmovups  ymmword ptr [rbp-0x828], ymm14
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0x1028], ymm0
       vmovups  ymmword ptr [rbp-0x708], ymm2
       vpxor    ymm15, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xFA8], ymm15
       vpxor    ymm15, ymm1, ymm15
       vbroadcastss ymm0, dword ptr [reloc @RWD160]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm13, ymm15, 15
       vpxor    ymm15, ymm13, ymm15
       vbroadcastss ymm13, dword ptr [reloc @RWD188]
       vmovups  ymmword ptr [rbp-0x1088], ymm13
       vpand    ymm15, ymm15, ymm13
       mov      r8, 0x16A65C00F50
       mov      r8, gword ptr [r8]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm2, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x8C8], ymm2
       vbroadcastss ymm14, dword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rbp-0x10A8], ymm14
       vpand    ymm15, ymm14, ymm2
       vmovups  ymmword ptr [rbp-0x8E8], ymm15
       vxorps   ymm2, ymm2, ymm2
       vmovups  ymmword ptr [rbp-0x908], ymm2
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm2
 
G_M000_IG32:                ;; offset=0x13E5
       vmovups  ymm2, ymmword ptr [rbp-0x8C8]
       vpslld   ymm2, ymm2, 29
       vmovups  ymmword ptr [rbp-0x1198], ymm2
       vbroadcastss ymm2, dword ptr [reloc @RWD196]
       vmovups  ymm15, ymmword ptr [rbp-0x1198]
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymm3
       vmovups  ymm14, ymmword ptr [rbp-0x1178]
       vblendvps ymm14, ymm15, ymmword ptr [rbp-0x908], ymm14
       vmovups  ymmword ptr [rbp-0x1178], ymm14
       vbroadcastss ymm15, dword ptr [reloc @RWD200]
       vmovups  ymmword ptr [rbp-0x10C8], ymm15
       vpcmpeqd ymm14, ymm15, ymmword ptr [rbp-0x8E8]
       vmovups  ymmword ptr [rbp-0x1198], ymm14
       vmovups  ymm14, ymmword ptr [rbp-0x8C8]
       vpslld   ymm14, ymm14, 28
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm4
       vmovups  ymm15, ymmword ptr [rbp-0x1198]
       vblendvps ymm14, ymm14, ymmword ptr [rbp-0x908], ymm15
       vaddps   ymm14, ymm14, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x1178], ymm14
       vbroadcastss ymm15, dword ptr [reloc @RWD204]
       vmovups  ymmword ptr [rbp-0x10E8], ymm15
       vpcmpeqd ymm14, ymm15, ymmword ptr [rbp-0x8E8]
       vmovups  ymmword ptr [rbp-0x1198], ymm14
       vmovups  ymm14, ymmword ptr [rbp-0x8C8]
       vpslld   ymm14, ymm14, 27
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm5
       vmovups  ymm15, ymmword ptr [rbp-0x1198]
       vblendvps ymm14, ymm14, ymmword ptr [rbp-0x908], ymm15
       vaddps   ymm14, ymm14, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x848], ymm14
       vmovups  ymm15, ymmword ptr [rbp-0x7E8]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x2A8]
       vmovups  ymmword ptr [rbp-0x1048], ymm15
       vmovups  ymm15, ymmword ptr [rbp-0x708]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1048]
       vmovups  ymmword ptr [rbp-0xFC8], ymm15
       vpxor    ymm15, ymm1, ymm15
       vpmulld  ymm15, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0x928], ymm15
       vpsrad   ymm15, ymm15, 15
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x928]
       vpand    ymm15, ymm15, ymm13
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm13, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x948], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm14, ymm13
       vxorps   ymm14, ymm14, ymm14
       vmovups  ymmword ptr [rbp-0x968], ymm14
       vxorps   ymm14, ymm14, ymm14
 
G_M000_IG33:                ;; offset=0x1573
       vpcmpeqd ymm14, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm14
       vpslld   ymm14, ymm13, 29
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymmword ptr [rbp-0x728]
       vmovups  ymm13, ymmword ptr [rbp-0x1178]
       vblendvps ymm13, ymm14, ymmword ptr [rbp-0x968], ymm13
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm13, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1198], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x948]
       vpslld   ymm13, ymm13, 28
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm4
       vmovups  ymm14, ymmword ptr [rbp-0x1198]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x968], ymm14
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10E8]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x948]
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm5
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x968], ymm15
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymm15, ymmword ptr [rbp-0x848]
       vsubps   ymm13, ymm13, ymm15
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0x788]
       vaddps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x868], ymm13
       vmovups  ymm15, ymmword ptr [rbp-0x808]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1028]
       vmovups  ymmword ptr [rbp-0xFE8], ymm15
       vpxor    ymm15, ymm1, ymm15
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm14, ymm15, 15
       vpxor    ymm15, ymm14, ymm15
       vpand    ymm15, ymm15, ymmword ptr [rbp-0x1088]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm13, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x988], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm14, ymm13
       vxorps   ymm14, ymm14, ymm14
       vmovups  ymmword ptr [rbp-0x9A8], ymm14
       vxorps   ymm14, ymm14, ymm14
       vpcmpeqd ymm14, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm14
       vpslld   ymm14, ymm13, 29
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm3
       vmovups  ymm13, ymmword ptr [rbp-0x1178]
 
G_M000_IG34:                ;; offset=0x16E7
       vblendvps ymm13, ymm14, ymmword ptr [rbp-0x9A8], ymm13
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm13, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1198], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x988]
       vpslld   ymm13, ymm13, 28
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x748]
       vmovups  ymm14, ymmword ptr [rbp-0x1198]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x9A8], ymm14
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x1178], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10E8]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x988]
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm5
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x9A8], ymm15
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1178]
       vmovups  ymm15, ymmword ptr [rbp-0x808]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1048]
       vmovups  ymmword ptr [rbp-0x1008], ymm15
       vpxor    ymm1, ymm1, ymm15
       vpmulld  ymm1, ymm1, ymm0
       vpsrad   ymm15, ymm1, 15
       vpxor    ymm1, ymm15, ymm1
       vpand    ymm1, ymm1, ymmword ptr [rbp-0x1088]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm1, ymm1, 2
       vpcmpeqd ymm15, ymm15, ymm15
       vpgatherdd ymm14, dword ptr [r9+4*xmm1], ymm15
       vmovups  ymmword ptr [rbp-0x9C8], ymm14
       vmovups  ymm1, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm1, ymm14
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x9E8], ymm1
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vpslld   ymm1, ymm14, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x728]
       vmovups  ymm14, ymmword ptr [rbp-0x1178]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0x9E8], ymm14
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vmovups  ymm14, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm1, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1198], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x9C8]
       vpslld   ymm1, ymm1, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x748]
       vmovups  ymm14, ymmword ptr [rbp-0x1198]
 
G_M000_IG35:                ;; offset=0x185D
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0x9E8], ymm14
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x1178]
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vmovups  ymm14, ymmword ptr [rbp-0x10E8]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm1, ymmword ptr [rbp-0x9C8]
       vpslld   ymm1, ymm1, 27
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm5
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0x9E8], ymm15
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x1178]
       vsubps   ymm1, ymm1, ymm13
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x788]
       vaddps   ymm1, ymm1, ymm13
       vmovups  ymmword ptr [rbp-0x888], ymm1
       vmovups  ymm13, ymmword ptr [rbp-0x828]
       vpxor    ymm15, ymm13, ymmword ptr [rbp-0xFA8]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm1, ymm15, 15
       vpxor    ymm1, ymm1, ymm15
       vpand    ymm1, ymm1, ymmword ptr [rbp-0x1088]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm1, ymm1, 2
       vpcmpeqd ymm5, ymm5, ymm5
       vpgatherdd ymm13, dword ptr [r9+4*xmm1], ymm5
       vmovups  ymm1, ymmword ptr [rbp-0x10A8]
       vpand    ymm5, ymm1, ymm13
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0xA08], ymm1
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm5
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vpslld   ymm1, ymm13, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm3
       vmovups  ymm15, ymmword ptr [rbp-0x1178]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA08], ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm1, ymm15, ymm5
       vmovups  ymmword ptr [rbp-0x1198], ymm1
       vpslld   ymm1, ymm13, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm4
       vmovups  ymm15, ymmword ptr [rbp-0x1198]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA08], ymm15
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x1178]
       vpcmpeqd ymm5, ymm14, ymm5
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x768]
       vblendvps ymm5, ymm13, ymmword ptr [rbp-0xA08], ymm5
       vaddps   ymm1, ymm5, ymm1
       vmovups  ymm13, ymmword ptr [rbp-0x828]
       vpxor    ymm5, ymm13, ymmword ptr [rbp-0xFC8]
 
G_M000_IG36:                ;; offset=0x19C4
       vpmulld  ymm5, ymm5, ymm0
       vpsrad   ymm13, ymm5, 15
       vpxor    ymm5, ymm13, ymm5
       vpand    ymm5, ymm5, ymmword ptr [rbp-0x1088]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm5, ymm5, 2
       vpcmpeqd ymm15, ymm15, ymm15
       vpgatherdd ymm13, dword ptr [r9+4*xmm5], ymm15
       vmovups  ymm5, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm5, ymm13
       vxorps   ymm5, ymm5, ymm5
       vmovups  ymmword ptr [rbp-0xA28], ymm5
       vxorps   ymm5, ymm5, ymm5
       vpcmpeqd ymm5, ymm5, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm5
       vpslld   ymm5, ymm13, 29
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x728]
       vmovups  ymm14, ymmword ptr [rbp-0x1178]
       vblendvps ymm5, ymm5, ymmword ptr [rbp-0xA28], ymm14
       vmovups  ymmword ptr [rbp-0x1178], ymm5
       vmovups  ymm14, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm5, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x1198], ymm5
       vpslld   ymm5, ymm13, 28
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm4, ymm5, ymm4
       vmovups  ymm14, ymmword ptr [rbp-0x1198]
       vblendvps ymm4, ymm4, ymmword ptr [rbp-0xA28], ymm14
       vaddps   ymm4, ymm4, ymmword ptr [rbp-0x1178]
       vmovups  ymm14, ymmword ptr [rbp-0x10E8]
       vpcmpeqd ymm15, ymm14, ymm15
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x768]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0xA28], ymm15
       vaddps   ymm4, ymm13, ymm4
       vsubps   ymm4, ymm4, ymm1
       vmulps   ymm4, ymm4, ymmword ptr [rbp-0x788]
       vaddps   ymm1, ymm4, ymm1
       vmovups  ymmword ptr [rbp-0x8A8], ymm1
       vmovups  ymm4, ymmword ptr [rbp-0x828]
       vpxor    ymm15, ymm4, ymmword ptr [rbp-0xFE8]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm13, ymm15, 15
       vpxor    ymm15, ymm13, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x1088]
       vpand    ymm15, ymm15, ymm13
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm4, ymm4, ymm4
       vpgatherdd ymm5, dword ptr [r9+4*xmm15], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x10A8]
       vpand    ymm15, ymm4, ymm5
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0xA48], ymm1
 
G_M000_IG37:                ;; offset=0x1B25
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm15
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vpslld   ymm1, ymm5, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm3
       vmovups  ymm4, ymmword ptr [rbp-0x1178]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA48], ymm4
       vmovups  ymmword ptr [rbp-0x1178], ymm1
       vmovups  ymm4, ymmword ptr [rbp-0x10C8]
       vpcmpeqd ymm3, ymm4, ymm15
       vpslld   ymm1, ymm5, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x748]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA48], ymm3
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x1178]
       vpcmpeqd ymm3, ymm14, ymm15
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x768]
       vblendvps ymm3, ymm5, ymmword ptr [rbp-0xA48], ymm3
       vaddps   ymm1, ymm3, ymm1
       vmovups  ymm3, ymmword ptr [rbp-0x828]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x1008]
       vpmulld  ymm0, ymm3, ymm0
       vpsrad   ymm3, ymm0, 15
       vpxor    ymm0, ymm3, ymm0
       vpand    ymm0, ymm0, ymm13
       add      r8, 16
       vpsrld   ymm0, ymm0, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [r8+4*xmm0], ymm3
       vmovups  ymm0, ymmword ptr [rbp-0x10A8]
       vpand    ymm0, ymm0, ymm5
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm0
       vpslld   ymm15, ymm5, 29
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x728]
       vblendvps ymm13, ymm15, ymm3, ymm13
       vpcmpeqd ymm4, ymm4, ymm0
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x748]
       vblendvps ymm4, ymm15, ymm3, ymm4
       vaddps   ymm4, ymm4, ymm13
       vpcmpeqd ymm0, ymm14, ymm0
       vpslld   ymm5, ymm5, 27
       vpand    ymm2, ymm5, ymm2
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x768]
       vblendvps ymm0, ymm2, ymm3, ymm0
       vaddps   ymm0, ymm0, ymm4
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x788]
       vaddps   ymm0, ymm0, ymm1
 
G_M000_IG38:                ;; offset=0x1C66
       vmovups  ymm1, ymmword ptr [rbp-0x888]
       vmovups  ymm13, ymmword ptr [rbp-0x868]
       vsubps   ymm1, ymm1, ymm13
       vmovups  ymm15, ymmword ptr [rbp-0x7A8]
       vmulps   ymm1, ymm1, ymm15
       vaddps   ymm1, ymm1, ymm13
       vmovups  ymm2, ymmword ptr [rbp-0x8A8]
       vsubps   ymm0, ymm0, ymm2
       vmulps   ymm0, ymm0, ymm15
       vaddps   ymm0, ymm0, ymm2
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x7C8]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rbp-0x6E8], ymm0
       jmp      G_M000_IG42
 
G_M000_IG39:                ;; offset=0x1CC7
       vmovups  ymmword ptr [rbp-0xE08], ymm13
       vmovups  ymmword ptr [rbp-0xE28], ymm14
       vmovups  ymmword ptr [rbp-0xE48], ymm15
       mov      r8d, dword ptr [rbp-0x138]
       mov      dword ptr [rsp+0x28], r8d
       mov      r8d, dword ptr [rbp-0x134]
       mov      dword ptr [rsp+0x30], r8d
       vmovss   xmm0, dword ptr [rbp-0x130]
       vmovss   dword ptr [rsp+0x38], xmm0
       lea      r8, [rbp-0xE08]
       lea      r9, [rbp-0xE28]
       lea      rcx, [rbp-0xE48]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2A8]
       lea      rcx, [rbp-0x6E8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.CellularKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,int,float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG42
 
G_M000_IG40:                ;; offset=0x1D50
       vmovups  ymmword ptr [rbp-0xE08], ymm13
       vmovups  ymmword ptr [rbp-0xE28], ymm14
       vmovups  ymmword ptr [rbp-0xE48], ymm15
       lea      r8, [rbp-0xE08]
       lea      r9, [rbp-0xE28]
       lea      rcx, [rbp-0xE48]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2A8]
       lea      rcx, [rbp-0x6E8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x1DB0
       lea      rcx, [rbp-0x6E8]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG42:                ;; offset=0x1DD9
       lea      rcx, [rbp-0x160]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       test     eax, eax
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG56
 
G_M000_IG43:                ;; offset=0x1E06
       vmovups  ymm0, ymmword ptr [rbp-0x6E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      r8, [rbp-0xE08]
       lea      rdx, [rbp-0x160]
       lea      rcx, [rbp-0x2C8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:ShapeSingle[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG44:                ;; offset=0x1E49
       lea      rcx, [rbp-0x2E8]
       vmovaps  xmm1, xmm10
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x228]
       lea      rdx, [rbp-0x2C8]
       lea      r8, [rbp-0x2E8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG45:                ;; offset=0x1E8E
       vmovups  ymm0, ymmword ptr [rbp-0x228]
       vmovups  ymmword ptr [rbp-0x188], ymm0
       mov      rcx, bword ptr [rbp-0x1158]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Amplitude():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x228]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x1C8]
       lea      r8, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rcx, bword ptr [rbp-0x1158]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Offset():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1E8]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x188]
       lea      rdx, [rbp-0x1C8]
       lea      r8, [rbp-0x1E8]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x1150], 0
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG18
 
G_M000_IG46:                ;; offset=0x1F45
       mov      rcx, bword ptr [rbp-0x1158]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Blend():int:this]
       mov      dword ptr [rbp-0xF6C], eax
       mov      rcx, bword ptr [rbp-0x1158]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_BlendFactor():float:this]
       mov      edx, dword ptr [rbp-0xF6C]
       vmovss   dword ptr [rsp+0x20], xmm0
       lea      r8, [rbp-0x128]
       lea      r9, [rbp-0x188]
       lea      rcx, [rbp-0x208]
       call     [Tedd.FastNoise.Internal.StackFill:Blend[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG47:                ;; offset=0x1FA4
       vmovups  ymm0, ymmword ptr [rbp-0x208]
       vmovups  ymmword ptr [rbp-0x128], ymm0
       mov      rax, qword ptr [rbp-0x1150]
       inc      eax
       mov      rdx, rax
       vmovups  ymm11, ymmword ptr [rbp-0x108]
 
G_M000_IG48:                ;; offset=0x1FC8
       cmp      dword ptr [rdi+0x08], eax
       jle      G_M000_IG12
 
G_M000_IG49:                ;; offset=0x1FD1
       mov      qword ptr [rbp-0x1150], rax
       imul     rcx, rax, 80
       lea      rdx, bword ptr [rdi+rcx+0x10]
       mov      bword ptr [rbp-0x1158], rdx
       vmovdqu  xmm1, xmmword ptr [rdx]
       vmovdqu  xmmword ptr [rbp-0x140], xmm1
       mov      ecx, dword ptr [rdx+0x10]
       mov      dword ptr [rbp-0x130], ecx
       mov      ecx, dword ptr [rbp-0x13C]
       vbroadcastss ymm1, dword ptr [rdx+0x34]
       vmulps   ymm13, ymm9, ymm1
       vmulps   ymm14, ymm11, ymm1
       vmulps   ymm15, ymm12, ymm1
       dec      ecx
       cmp      ecx, 2
       jne      G_M000_IG70
 
G_M000_IG50:                ;; offset=0x2020
       vaddps   ymm1, ymm13, ymm14
       vaddps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD256]
       vsubps   ymm13, ymm1, ymm13
       vsubps   ymm14, ymm1, ymm14
       vsubps   ymm15, ymm1, ymm15
 
G_M000_IG51:                ;; offset=0x2041
       vmovdqu  xmm1, xmmword ptr [rdx]
       vmovdqu  xmmword ptr [rbp-0x140], xmm1
       mov      ecx, dword ptr [rdx+0x10]
       mov      dword ptr [rbp-0x130], ecx
       vmovdqu  xmm1, xmmword ptr [rdx+0x14]
       vmovdqu  xmmword ptr [rbp-0x160], xmm1
       vmovdqu  xmm1, xmmword ptr [rdx+0x20]
       vmovdqu  xmmword ptr [rbp-0x154], xmm1
       mov      r8d, dword ptr [rdx+0x30]
       mov      dword ptr [rbp-0x164], r8d
       mov      r10d, dword ptr [rdx+0x48]
       mov      dword ptr [rbp-0x168], r10d
       vmovups  ymmword ptr [rbp-0x248], ymm13
       vmovups  ymmword ptr [rbp-0x268], ymm14
       vmovups  ymmword ptr [rbp-0x288], ymm15
       vmovss   xmm10, dword ptr [rdx+0x4C]
       cmp      dword ptr [rbp-0x160], 0
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x20AC
       cmp      r10d, 1
       jg       G_M000_IG19
 
G_M000_IG53:                ;; offset=0x20B6
       vpbroadcastd ymm0, dword ptr [rbp-0x164]
       vmovups  ymmword ptr [rbp-0x2A8], ymm0
       mov      r8d, dword ptr [rbp-0x140]
       cmp      r8d, 5
       ja       G_M000_IG41
 
G_M000_IG54:                ;; offset=0x20D8
       mov      r8d, r8d
       lea      r9, [reloc @RWD288]
       mov      r9d, dword ptr [r9+4*r8]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG55:                ;; offset=0x20F3
       vmovups  ymmword ptr [rbp-0xE08], ymm13
       vmovups  ymmword ptr [rbp-0xE28], ymm14
       vmovups  ymmword ptr [rbp-0xE48], ymm15
       lea      r8, [rbp-0xE08]
       lea      r9, [rbp-0xE28]
       lea      rcx, [rbp-0xE48]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2A8]
       lea      rcx, [rbp-0x6E8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.ValueKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG42
 
G_M000_IG56:                ;; offset=0x2156
       vmovups  ymm1, ymmword ptr [rbp-0x6E8]
       vmovups  ymmword ptr [rbp-0x2C8], ymm1
       jmp      G_M000_IG44
 
G_M000_IG57:                ;; offset=0x216B
       mov      eax, dword ptr [rbp-0x38C]
 
G_M000_IG58:                ;; offset=0x2171
       mov      dword ptr [rbp-0x38C], eax
       mov      edx, eax
       add      edx, dword ptr [rbp-0x164]
       lea      rcx, [rbp-0x3C8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x248]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x268]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x288]
       vmovups  ymmword ptr [rbp-0xE48], ymm0
       lea      r9, [rbp-0xE08]
       lea      rcx, [rbp-0xE28]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xE48]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x3E8]
       lea      rdx, [rbp-0x140]
       lea      r8, [rbp-0x3C8]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Single3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       cmp      eax, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       je       G_M000_IG63
 
G_M000_IG59:                ;; offset=0x2224
       cmp      eax, 3
       je       G_M000_IG61
 
G_M000_IG60:                ;; offset=0x222D
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x648]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x308]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x308]
       lea      r8, [rbp-0x648]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x668]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x688]
       lea      rdx, [rbp-0x3E8]
       lea      r8, [rbp-0x668]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6A8]
       vmovss   xmm1, dword ptr [reloc @RWD312]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4C8]
       lea      rdx, [rbp-0x688]
       lea      r8, [rbp-0x6A8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       jmp      G_M000_IG65
 
G_M000_IG61:                ;; offset=0x230D
       lea      rcx, [rbp-0x528]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x548]
       lea      rdx, [rbp-0x3E8]
       lea      r8, [rbp-0x528]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x160]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_PingPongStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x568]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x588]
       lea      rdx, [rbp-0x548]
       lea      r8, [rbp-0x568]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x3E8]
       lea      rdx, [rbp-0x588]
       call     [Tedd.FastNoise.Internal.NoiseMath:PingPong[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5A8]
       vmovss   xmm1, dword ptr [reloc @RWD312]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x5C8]
       lea      r8, [rbp-0x5A8]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5E8]
       vmovss   xmm1, dword ptr [reloc @RWD316]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x608]
       lea      rdx, [rbp-0x5C8]
       lea      r8, [rbp-0x5E8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG62:                ;; offset=0x2403
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      r8, [rbp-0xE08]
       lea      rdx, [rbp-0x608]
       lea      rcx, [rbp-0x628]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x308]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x308]
       lea      r8, [rbp-0x628]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0x4C8], ymm0
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       jmp      G_M000_IG65
 
G_M000_IG63:                ;; offset=0x247A
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x3E8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Abs(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x408]
       vmovss   xmm1, dword ptr [reloc @RWD320]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3E8]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x428]
       lea      r8, [rbp-0x408]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x448]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x468]
       lea      rdx, [rbp-0x428]
       lea      r8, [rbp-0x448]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      r8, [rbp-0xE08]
       lea      rdx, [rbp-0x468]
       lea      rcx, [rbp-0x488]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x308]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x308]
       lea      r8, [rbp-0x488]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4A8]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4C8]
       lea      rdx, [rbp-0x4A8]
       lea      r8, [rbp-0x3E8]
 
G_M000_IG64:                ;; offset=0x2594
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
 
G_M000_IG65:                ;; offset=0x25A6
       lea      rcx, [rbp-0x4E8]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x388]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      r9, [rbp-0xE08]
       lea      rdx, [rbp-0x4E8]
       lea      r8, [rbp-0x4C8]
       lea      rcx, [rbp-0x508]
       call     [Tedd.FastNoise.Internal.NoiseMath:Lerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x328]
       lea      r8, [rbp-0x508]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x248]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x348]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x248]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x268]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x348]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x268]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x288]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x348]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x288]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x368]
       vmovups  ymmword ptr [rbp-0xE28], ymm0
 
G_M000_IG66:                ;; offset=0x26F2
       lea      rdx, [rbp-0xE08]
       lea      r8, [rbp-0xE28]
       lea      rcx, [rbp-0x328]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      eax, dword ptr [rbp-0x38C]
       inc      eax
       mov      r8d, dword ptr [rbp-0x168]
       cmp      eax, r8d
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       mov      edx, r8d
       jge      G_M000_IG20
 
G_M000_IG67:                ;; offset=0x2734
       vmovss   xmm13, dword ptr [reloc @RWD172]
       vucomiss xmm10, xmm13
       jp       SHORT G_M000_IG68
       je       G_M000_IG58
 
G_M000_IG68:                ;; offset=0x2749
       lea      ecx, [rdx-0x01]
       mov      dword ptr [rbp-0x38C], eax
       cmp      eax, ecx
       jne      G_M000_IG57
 
G_M000_IG69:                ;; offset=0x275A
       lea      rcx, [rbp-0x6C8]
       vmovaps  xmm1, xmm10
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x328]
       vmovups  ymmword ptr [rbp-0xE08], ymm0
       lea      rdx, [rbp-0xE08]
       lea      rcx, [rbp-0x328]
       lea      r8, [rbp-0x6C8]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       mov      eax, dword ptr [rbp-0x38C]
       jmp      G_M000_IG58
 
G_M000_IG70:                ;; offset=0x27BA
       cmp      ecx, 2
       ja       G_M000_IG51
       mov      ecx, ecx
       lea      r8, [reloc @RWD324]
       mov      r8d, dword ptr [r8+4*rcx]
       lea      r10, G_M000_IG02
       add      r8, r10
       jmp      r8
 
G_M000_IG71:                ;; offset=0x27DD
       vaddps   ymm1, ymm13, ymm14
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD352]
       vmulps   ymm15, ymm15, ymmword ptr [reloc @RWD384]
       vsubps   ymm2, ymm0, ymm15
       vaddps   ymm13, ymm2, ymm13
       vaddps   ymm0, ymm14, ymm0
       vsubps   ymm14, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vaddps   ymm15, ymm1, ymm15
       jmp      G_M000_IG51
 
G_M000_IG72:                ;; offset=0x2817
       vaddps   ymm1, ymm13, ymm15
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD352]
       vmulps   ymm14, ymm14, ymmword ptr [reloc @RWD384]
       vsubps   ymm2, ymm0, ymm14
       vaddps   ymm13, ymm2, ymm13
       vsubps   ymm0, ymm0, ymm14
       vaddps   ymm15, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vaddps   ymm14, ymm1, ymm14
       jmp      G_M000_IG51
 
G_M000_IG73:                ;; offset=0x2852
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dq	0000000100000000h, 0000000300000002h, 0000000500000004h, 0000000700000006h
RWD32  	dd	4F000000h		; 2.14748e+09
RWD36  	dd	7FFFFFFFh		;       nan
RWD40  	dd	1DDE90C9h		; 5.89126e-21
RWD44  	dd	43C42E4Dh		;   392.362
RWD48  	dd	668B6E2Fh		; 3.29221e+23
RWD52  	dd	00000000h, 00000000h, 00000000h
RWD64  	dq	3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h
RWD96  	dq	87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah
RWD128 	dq	CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh
RWD160 	dd	27D4EB2Dh		; 5.90968e-15
RWD164 	dd	30000000h		; 4.65661e-10
RWD168 	dd	3E97B426h		;  0.296296
RWD172 	dd	3F800000h		;         1
RWD176 	dd	40C00000h		;         6
RWD180 	dd	41700000h		;        15
RWD184 	dd	41200000h		;        10
RWD188 	dd	000000FCh		; 3.53127e-43
RWD192 	dd	00000003h		; 4.2039e-45
RWD196 	dd	80000000h		;        -0
RWD200 	dd	00000001h		; 1.4013e-45
RWD204 	dd	00000002h		; 2.8026e-45
RWD208 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD224 	dq	3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h
RWD256 	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD288 	dd	00001C00h ; case G_M000_IG40
       	dd	00001C60h ; case G_M000_IG41
       	dd	00001B77h ; case G_M000_IG39
       	dd	00000FAEh ; case G_M000_IG30
       	dd	0000042Ch ; case G_M000_IG21
       	dd	00001FA3h ; case G_M000_IG55
RWD312 	dd	3F000000h		;       0.5
RWD316 	dd	40000000h		;         2
RWD320 	dd	C0000000h		;        -2
RWD324 	dd	0000268Dh ; case G_M000_IG71
       	dd	000026C7h ; case G_M000_IG72
       	dd	00001ED0h ; case G_M000_IG50
RWD336 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD352 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD384 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah

; Total bytes of code 10328

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2
; 12 inlinees with PGO data; 904 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       lea      r11, [rsp-0x1048]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       vmovaps  xmmword ptr [rsp+0x1030], xmm6
       vmovaps  xmmword ptr [rsp+0x1020], xmm7
       vmovaps  xmmword ptr [rsp+0x1010], xmm8
       vmovaps  xmmword ptr [rsp+0x1000], xmm9
       vmovaps  xmmword ptr [rsp+0xFF0], xmm10
       vmovaps  xmmword ptr [rsp+0xFE0], xmm11
       vmovaps  xmmword ptr [rsp+0xFD0], xmm12
       vmovaps  xmmword ptr [rsp+0xFC0], xmm13
       vmovaps  xmmword ptr [rsp+0xFB0], xmm14
       vmovaps  xmmword ptr [rsp+0xFA0], xmm15
       lea      rbp, [rsp+0x1080]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -0xF00
       vmovdqa  xmmword ptr [rbp+rax-0x110], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x100], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0xF0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r8
       mov      r14d, r9d
       mov      r15d, dword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x00BD
       mov      r13d, dword ptr [rdi+0x0C]
       mov      r12d, dword ptr [rdi+0x10]
       vmovss   xmm6, dword ptr [rdi+0x18]
       mov      r8d, r14d
       vbroadcastss ymm1, ymm6
       vcvtdq2ps ymm0, ymmword ptr [reloc @RWD00]
       vmulps   ymm7, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0xFF0], ymm7
       mov      dword ptr [rbp+0x28], r14d
       mov      dword ptr [rbp+0x30], r15d
       lea      eax, [r14+r15]
       cmp      eax, r8d
       jg       G_M000_IG07
 
G_M000_IG03:                ;; offset=0x00FB
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1030]
       vmovaps  xmm7, xmmword ptr [rsp+0x1020]
       vmovaps  xmm8, xmmword ptr [rsp+0x1010]
       vmovaps  xmm9, xmmword ptr [rsp+0x1000]
       vmovaps  xmm10, xmmword ptr [rsp+0xFF0]
       vmovaps  xmm11, xmmword ptr [rsp+0xFE0]
       vmovaps  xmm12, xmmword ptr [rsp+0xFD0]
       vmovaps  xmm13, xmmword ptr [rsp+0xFC0]
       vmovaps  xmm14, xmmword ptr [rsp+0xFB0]
       vmovaps  xmm15, xmmword ptr [rsp+0xFA0]
       add      rsp, 0x1048
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x016C
       mov      dword ptr [rbp-0xF0], edx
       mov      ecx, edx
       add      ecx, dword ptr [rbp-0xEC]
       cmp      ecx, dword ptr [rsi+0x08]
       jae      G_M000_IG62
       mov      r10d, ecx
       mov      qword ptr [rbp-0x1018], r10
       mov      r9, bword ptr [rsi]
       mov      bword ptr [rbp-0x1010], r9
       mov      rcx, rdi
       vextractf128 xmm10, ymm7
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0xF0]
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm0, xmm1
       mov      rcx, rbx
       vmovaps  xmm2, xmm8
       vmovaps  xmm3, xmm9
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      r9, bword ptr [rbp-0x1010]
       mov      r10, qword ptr [rbp-0x1018]
       vmovss   dword ptr [r9+4*r10], xmm0
       mov      eax, dword ptr [rbp-0xF0]
       inc      eax
       cmp      eax, r13d
       vinsertf128 ymm7, ymm7, xmm10
       mov      edx, eax
       jl       G_M000_IG04
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x01FC
       cmp      edx, r13d
       jl       G_M000_IG04
 
G_M000_IG06:                ;; offset=0x0205
       mov      r8d, dword ptr [rbp-0xE4]
       inc      r8d
       mov      r14d, dword ptr [rbp+0x28]
       mov      r15d, dword ptr [rbp+0x30]
       lea      eax, [r14+r15]
       cmp      eax, r8d
       mov      dword ptr [rbp+0x28], r14d
       mov      dword ptr [rbp+0x30], r15d
       jle      G_M000_IG03
 
G_M000_IG07:                ;; offset=0x022C
       mov      eax, r8d
       cdq      
       idiv     edx:eax, r12d
       mov      ecx, edx
       mov      eax, r8d
       cdq      
       idiv     edx:eax, r12d
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, ecx
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm8, xmm1, dword ptr [rdi+0x04]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, eax
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm9, xmm1, dword ptr [rdi+0x08]
       vmovss   dword ptr [rbp-0xE8], xmm9
       mov      dword ptr [rbp-0xE4], r8d
       mov      eax, r8d
       imul     eax, r13d
       mov      dword ptr [rbp-0xEC], eax
       xor      edx, edx
       jmp      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x027E
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rbp-0xFC8], xmm0
 
G_M000_IG09:                ;; offset=0x028A
       lea      rdx, [rbp-0xFC8]
       mov      ecx, dword ptr [rbp-0xF0]
       mov      r8d, ecx
       add      r8d, dword ptr [rbp-0xEC]
       lea      rcx, [rbp-0x130]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      ecx, dword ptr [rbp-0xFF4]
       mov      eax, ecx
       mov      edx, eax
       vmovups  ymm7, ymmword ptr [rbp-0xFF0]
 
G_M000_IG10:                ;; offset=0x02C0
       lea      r10d, [rdx+0x08]
       mov      dword ptr [rbp-0xFF4], r10d
       cmp      r10d, r13d
       jg       G_M000_IG05
 
G_M000_IG11:                ;; offset=0x02D4
       mov      dword ptr [rbp-0xF0], edx
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, edx
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm1, dword ptr [rdi]
       vbroadcastss ymm1, ymm1
       vaddps   ymm10, ymm1, ymm7
       vbroadcastss ymm11, ymm8
       vbroadcastss ymm12, ymm9
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x148], xmm1
       vmovdqu  xmmword ptr [rbp-0x144], xmm1
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x168], xmm1
       vmovdqu  xmmword ptr [rbp-0x15C], xmm1
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x130], ymm1
       xor      r9d, r9d
       vmovss   xmm9, dword ptr [rbp-0xE8]
       jmp      G_M000_IG17
 
G_M000_IG12:                ;; offset=0x0341
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x210], ymm0
       jmp      G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0356
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x230], ymm0
       vmovss   xmm9, dword ptr [rbp-0xE8]
 
G_M000_IG14:                ;; offset=0x036E
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x190], ymm0
       mov      rcx, bword ptr [rbp-0x1008]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Amplitude():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x1D0]
       lea      r8, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rcx, bword ptr [rbp-0x1008]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Offset():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x190]
       lea      rdx, [rbp-0x1D0]
       lea      r8, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      r15, qword ptr [rbp-0x1000]
       test     r15d, r15d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG12
 
G_M000_IG15:                ;; offset=0x0434
       mov      rcx, bword ptr [rbp-0x1008]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Blend():int:this]
       mov      dword ptr [rbp-0xFB4], eax
       mov      rcx, bword ptr [rbp-0x1008]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_BlendFactor():float:this]
       mov      edx, dword ptr [rbp-0xFB4]
       vmovss   dword ptr [rsp+0x20], xmm0
       lea      r8, [rbp-0x130]
       lea      r9, [rbp-0x190]
       lea      rcx, [rbp-0x210]
       call     [Tedd.FastNoise.Internal.StackFill:Blend[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG16:                ;; offset=0x049F
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x130], ymm0
       inc      r15d
       mov      r9, r15
 
G_M000_IG17:                ;; offset=0x04B5
       mov      ecx, dword ptr [rbx+0x08]
       cmp      ecx, r9d
       jle      G_M000_IG08
 
G_M000_IG18:                ;; offset=0x04C1
       mov      qword ptr [rbp-0x1000], r9
       imul     rcx, r9, 80
       lea      r11, bword ptr [rbx+rcx+0x10]
       mov      bword ptr [rbp-0x1008], r11
       vmovdqu  xmm1, xmmword ptr [r11]
       vmovdqu  xmmword ptr [rbp-0x148], xmm1
       mov      ecx, dword ptr [r11+0x10]
       mov      dword ptr [rbp-0x138], ecx
       mov      ecx, dword ptr [rbp-0x144]
       vbroadcastss ymm1, dword ptr [r11+0x34]
       vmulps   ymm13, ymm1, ymm10
       vmulps   ymm14, ymm1, ymm11
       vmulps   ymm15, ymm1, ymm12
       dec      ecx
       cmp      ecx, 2
       jne      G_M000_IG28
 
G_M000_IG19:                ;; offset=0x0515
       vaddps   ymm1, ymm13, ymm14
       vaddps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD32]
       vsubps   ymm13, ymm1, ymm13
       vsubps   ymm14, ymm1, ymm14
       vsubps   ymm15, ymm1, ymm15
 
G_M000_IG20:                ;; offset=0x0536
       vmovdqu  xmm1, xmmword ptr [r11]
       vmovdqu  xmmword ptr [rbp-0x148], xmm1
       mov      ecx, dword ptr [r11+0x10]
       mov      dword ptr [rbp-0x138], ecx
       vmovdqu  xmm1, xmmword ptr [r11+0x14]
       vmovdqu  xmmword ptr [rbp-0x168], xmm1
       vmovdqu  xmm1, xmmword ptr [r11+0x20]
       vmovdqu  xmmword ptr [rbp-0x15C], xmm1
       mov      ecx, dword ptr [r11+0x30]
       mov      dword ptr [rbp-0x16C], ecx
       mov      r15d, dword ptr [r11+0x48]
       vmovups  ymmword ptr [rbp-0x250], ymm13
       vmovups  ymmword ptr [rbp-0x270], ymm14
       vmovups  ymmword ptr [rbp-0x290], ymm15
       vmovss   xmm1, dword ptr [r11+0x4C]
       vmovss   dword ptr [rbp-0x2D4], xmm1
       cmp      dword ptr [rbp-0x168], 0
       je       G_M000_IG31
       cmp      r15d, 1
       jle      G_M000_IG31
       lea      rcx, [rbp-0x330]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x168]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Bounding():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x168]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Lacunarity():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x168]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Gain():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x168]
 
G_M000_IG21:                ;; offset=0x0638
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_WeightedStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       xor      eax, eax
       cmp      eax, r15d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jge      G_M000_IG13
 
G_M000_IG22:                ;; offset=0x066C
       vmovss   xmm7, dword ptr [reloc @RWD64]
       vmovss   xmm13, dword ptr [rbp-0x2D4]
       vucomiss xmm13, xmm7
       jp       G_M000_IG56
       jne      G_M000_IG56
 
G_M000_IG23:                ;; offset=0x068C
       mov      dword ptr [rbp-0x3B4], eax
       mov      edx, eax
       add      edx, dword ptr [rbp-0x16C]
       lea      rcx, [rbp-0x3F0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm9, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0xE90], ymm0
       lea      r9, [rbp-0xE50]
       lea      rcx, [rbp-0xE70]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xE90]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x410]
       lea      rdx, [rbp-0x148]
       lea      r8, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Single3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x168]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       cmp      eax, 2
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm9
       je       G_M000_IG57
       cmp      eax, 3
       je       G_M000_IG60
       vmovups  ymm0, ymmword ptr [rbp-0x410]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x670]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm9, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x330]
       lea      r8, [rbp-0x670]
 
G_M000_IG24:                ;; offset=0x07C6
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x690]
       vmovaps  xmm1, xmm7
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6B0]
       lea      rdx, [rbp-0x410]
       lea      r8, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6D0]
       vmovss   xmm1, dword ptr [reloc @RWD68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4F0]
       lea      rdx, [rbp-0x6B0]
       lea      r8, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm9
 
G_M000_IG25:                ;; offset=0x083A
       lea      rcx, [rbp-0x510]
       vmovaps  xmm1, xmm7
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm9, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      r9, [rbp-0xE50]
       lea      rdx, [rbp-0x510]
       lea      r8, [rbp-0x4F0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.NoiseMath:Lerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x350]
       lea      r8, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x250]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
 
G_M000_IG26:                ;; offset=0x0983
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      eax, dword ptr [rbp-0x3B4]
       inc      eax
       cmp      eax, r15d
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm9
       jge      G_M000_IG13
 
G_M000_IG27:                ;; offset=0x09C9
       vmovss   xmm9, dword ptr [rbp-0xE8]
       jmp      G_M000_IG22
 
G_M000_IG28:                ;; offset=0x09D6
       cmp      ecx, 2
       ja       G_M000_IG20
       mov      ecx, ecx
       mov      qword ptr [rbp-0x1018], rcx
       lea      rcx, [reloc @RWD72]
       mov      r14, qword ptr [rbp-0x1018]
       mov      ecx, dword ptr [rcx+4*r14]
       lea      r15, G_M000_IG02
       add      rcx, r15
       jmp      rcx
 
G_M000_IG29:                ;; offset=0x0A06
       vaddps   ymm1, ymm13, ymm14
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm15, ymm15, ymmword ptr [reloc @RWD128]
       vsubps   ymm2, ymm0, ymm15
       vaddps   ymm13, ymm2, ymm13
       vaddps   ymm0, ymm14, ymm0
       vsubps   ymm14, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vaddps   ymm15, ymm1, ymm15
       jmp      G_M000_IG20
 
G_M000_IG30:                ;; offset=0x0A40
       vaddps   ymm1, ymm13, ymm15
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm14, ymm14, ymmword ptr [reloc @RWD128]
       vsubps   ymm2, ymm0, ymm14
       vaddps   ymm13, ymm2, ymm13
       vsubps   ymm0, ymm0, ymm14
       vaddps   ymm15, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vaddps   ymm14, ymm1, ymm14
       jmp      G_M000_IG20
 
G_M000_IG31:                ;; offset=0x0A7B
       vpbroadcastd ymm1, dword ptr [rbp-0x16C]
       vmovups  ymmword ptr [rbp-0x2B0], ymm1
       mov      ecx, dword ptr [rbp-0x148]
       cmp      ecx, 5
       ja       SHORT G_M000_IG32
       lea      r15, [reloc @RWD160]
       mov      r15d, dword ptr [r15+4*rcx]
       lea      r14, G_M000_IG02
       add      r15, r14
       jmp      r15
 
G_M000_IG32:                ;; offset=0x0AAF
       lea      rcx, [rbp-0x710]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG53
 
G_M000_IG33:                ;; offset=0x0AE9
       vmovups  ymmword ptr [rbp-0xE50], ymm13
       vmovups  ymmword ptr [rbp-0xE70], ymm14
       vmovups  ymmword ptr [rbp-0xE90], ymm15
       lea      r8, [rbp-0xE50]
       lea      r9, [rbp-0xE70]
       lea      rcx, [rbp-0xE90]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2B0]
       lea      rcx, [rbp-0x710]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG53
 
G_M000_IG34:                ;; offset=0x0B58
       vmovups  ymmword ptr [rbp-0xE50], ymm13
       vmovups  ymmword ptr [rbp-0xE70], ymm14
       vmovups  ymmword ptr [rbp-0xE90], ymm15
       mov      ecx, dword ptr [rbp-0x140]
       mov      dword ptr [rsp+0x28], ecx
       mov      ecx, dword ptr [rbp-0x13C]
       mov      dword ptr [rsp+0x30], ecx
       vmovss   xmm1, dword ptr [rbp-0x138]
       vmovss   dword ptr [rsp+0x38], xmm1
       lea      r8, [rbp-0xE50]
       lea      r9, [rbp-0xE70]
       lea      rcx, [rbp-0xE90]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2B0]
       lea      rcx, [rbp-0x710]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.CellularKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,int,float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG53
 
G_M000_IG35:                ;; offset=0x0BE9
       vcmpeqps ymm1, ymm13, ymm13
       vandps   ymm1, ymm1, ymm13
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vcmpeqps ymm2, ymm14, ymm14
       vandps   ymm2, ymm2, ymm14
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vxorps   ymm3, ymm3, ymm3
       vcmpltps ymm3, ymm14, ymm3
       vpaddd   ymm2, ymm3, ymm2
       vcmpeqps ymm3, ymm15, ymm15
       vandps   ymm3, ymm3, ymm15
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vxorps   ymm4, ymm4, ymm4
       vcmpltps ymm4, ymm15, ymm4
       vpaddd   ymm3, ymm4, ymm3
       vcvtdq2ps ymm4, ymm1
       vsubps   ymm4, ymm13, ymm4
       vmovups  ymmword ptr [rbp-0x790], ymm4
       vcvtdq2ps ymm5, ymm2
       vsubps   ymm5, ymm14, ymm5
       vmovups  ymmword ptr [rbp-0x7B0], ymm5
       vcvtdq2ps ymm13, ymm3
       vsubps   ymm14, ymm15, ymm13
       vsubps   ymm15, ymm4, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x7D0], ymm15
       vsubps   ymm13, ymm5, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x7F0], ymm13
       vsubps   ymm13, ymm14, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x810], ymm13
       vmulps   ymm13, ymm4, ymm4
       vmulps   ymm13, ymm13, ymm4
       vmulps   ymm15, ymm4, ymmword ptr [reloc @RWD288]
       vsubps   ymm15, ymm15, ymmword ptr [reloc @RWD320]
       vmulps   ymm15, ymm15, ymm4
       vaddps   ymm15, ymm15, ymmword ptr [reloc @RWD352]
       vmulps   ymm13, ymm15, ymm13
       vmovups  ymmword ptr [rbp-0x830], ymm13
       vmulps   ymm15, ymm5, ymm5
       vmulps   ymm15, ymm15, ymm5
       vmulps   ymm13, ymm5, ymmword ptr [reloc @RWD288]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD320]
       vmulps   ymm13, ymm13, ymm5
       vaddps   ymm13, ymm13, ymmword ptr [reloc @RWD352]
       vmulps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x850], ymm13
       vmulps   ymm15, ymm14, ymm14
       vmulps   ymm15, ymm15, ymm14
       vmulps   ymm13, ymm14, ymmword ptr [reloc @RWD288]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD320]
       vmulps   ymm13, ymm13, ymm14
       vaddps   ymm13, ymm13, ymmword ptr [reloc @RWD352]
 
G_M000_IG36:                ;; offset=0x0D58
       vmulps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x870], ymm13
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD416]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD448]
       vpaddd   ymm15, ymm1, ymmword ptr [reloc @RWD384]
       vmovups  ymmword ptr [rbp-0x890], ymm15
       vpaddd   ymm13, ymm2, ymmword ptr [reloc @RWD416]
       vmovups  ymmword ptr [rbp-0x8B0], ymm13
       vpaddd   ymm13, ymm3, ymmword ptr [reloc @RWD448]
       vmovups  ymmword ptr [rbp-0x8D0], ymm13
       vmovups  ymmword ptr [rbp-0x730], ymm1
       vpxor    ymm13, ymm1, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x750], ymm2
       vpxor    ymm13, ymm13, ymm2
       vmovups  ymmword ptr [rbp-0x770], ymm3
       vpxor    ymm13, ymm13, ymm3
       vpmulld  ymm13, ymm13, ymmword ptr [reloc @RWD480]
       vpsrad   ymm1, ymm13, 15
       vpxor    ymm1, ymm1, ymm13
       vpand    ymm13, ymm1, ymmword ptr [reloc @RWD512]
       mov      rcx, 0x16A65C00BE0
       mov      rcx, gword ptr [rcx]
       add      rcx, 16
       vpsrld   ymm1, ymm13, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm3, dword ptr [rcx+4*xmm1], ymm13
       vpand    ymm1, ymm3, ymmword ptr [reloc @RWD544]
       vxorps   ymm13, ymm13, ymm13
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm1
       vpslld   ymm15, ymm3, 29
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymm4
       vblendvps ymm2, ymm15, ymm13, ymm2
       vpcmpeqd ymm15, ymm1, ymmword ptr [reloc @RWD608]
       vpslld   ymm4, ymm3, 28
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymm5
       vblendvps ymm4, ymm4, ymm13, ymm15
       vaddps   ymm2, ymm4, ymm2
       vpcmpeqd ymm1, ymm1, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm3, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vpxor    ymm3, ymm3, ymm14
       vblendvps ymm1, ymm3, ymm13, ymm1
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0x8F0], ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x890]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x2B0]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x750]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x770]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm13, ymm2, 15
       vpxor    ymm2, ymm13, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      rcx, 0x16A65C00BE0
       mov      rcx, gword ptr [rcx]
 
G_M000_IG37:                ;; offset=0x0ED8
       add      rcx, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm3, dword ptr [rcx+4*xmm2], ymm13
       vpand    ymm2, ymm3, ymmword ptr [reloc @RWD544]
       vxorps   ymm13, ymm13, ymm13
       vxorps   ymm4, ymm4, ymm4
       vpcmpeqd ymm4, ymm4, ymm2
       vpslld   ymm15, ymm3, 29
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7D0]
       vblendvps ymm4, ymm15, ymm13, ymm4
       vpcmpeqd ymm15, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm1, ymm3, 28
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD576]
       vpxor    ymm1, ymm1, ymm5
       vblendvps ymm1, ymm1, ymm13, ymm15
       vaddps   ymm1, ymm1, ymm4
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm3, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vpxor    ymm3, ymm3, ymm14
       vblendvps ymm2, ymm3, ymm13, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x8F0]
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x830]
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0x910], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x730]
       vpxor    ymm3, ymm2, ymmword ptr [rbp-0x2B0]
       vmovups  ymm4, ymmword ptr [rbp-0x8B0]
       vpxor    ymm3, ymm3, ymm4
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x770]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpsrad   ymm2, ymm3, 15
       vpxor    ymm3, ymm2, ymm3
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD512]
       mov      rcx, 0x16A65C00BE0
       mov      rcx, gword ptr [rcx]
       add      rcx, 16
       vpsrld   ymm2, ymm3, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm15, dword ptr [rcx+4*xmm2], ymm3
       vpand    ymm2, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm2
       vpslld   ymm5, ymm15, 29
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x790]
       vblendvps ymm1, ymm5, ymm3, ymm1
       vpcmpeqd ymm5, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm13, ymm15, 28
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x7F0]
       vblendvps ymm5, ymm13, ymm3, ymm5
 
G_M000_IG38:                ;; offset=0x1035
       vaddps   ymm1, ymm5, ymm1
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm15, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm14
       vblendvps ymm2, ymm5, ymm3, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x890]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x2B0]
       vpxor    ymm2, ymm2, ymm4
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x770]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      rcx, 0x16A65C00BE0
       mov      rcx, gword ptr [rcx]
       add      rcx, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [rcx+4*xmm2], ymm3
       vpand    ymm2, ymm5, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm2
       vpslld   ymm4, ymm5, 29
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x7D0]
       vblendvps ymm4, ymm4, ymm3, ymm13
       vpcmpeqd ymm13, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7F0]
       vblendvps ymm13, ymm15, ymm3, ymm13
       vaddps   ymm4, ymm13, ymm4
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm14
       vblendvps ymm2, ymm5, ymm3, ymm2
       vaddps   ymm2, ymm2, ymm4
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x830]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x930], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x730]
       vpxor    ymm3, ymm2, ymmword ptr [rbp-0x2B0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x750]
       vmovups  ymm5, ymmword ptr [rbp-0x8D0]
       vpxor    ymm3, ymm3, ymm5
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpsrad   ymm14, ymm3, 15
       vpxor    ymm3, ymm14, ymm3
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD512]
       mov      rcx, 0x16A65C00BE0
       mov      rcx, gword ptr [rcx]
       add      rcx, 16
 
G_M000_IG39:                ;; offset=0x1196
       vpsrld   ymm3, ymm3, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm15, dword ptr [rcx+4*xmm3], ymm14
       vpand    ymm3, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm14, ymm14, ymm14
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm3
       vpslld   ymm4, ymm15, 29
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x790]
       vblendvps ymm2, ymm4, ymm14, ymm2
       vpcmpeqd ymm4, ymm3, ymmword ptr [reloc @RWD608]
       vpslld   ymm1, ymm15, 28
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD576]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x7B0]
       vblendvps ymm1, ymm1, ymm14, ymm4
       vaddps   ymm1, ymm1, ymm2
       vpcmpeqd ymm2, ymm3, ymmword ptr [reloc @RWD640]
       vpslld   ymm3, ymm15, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD576]
       vmovups  ymm4, ymmword ptr [rbp-0x810]
       vpxor    ymm3, ymm3, ymm4
       vblendvps ymm2, ymm3, ymm14, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x890]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x2B0]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x750]
       vpxor    ymm2, ymm2, ymm5
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      rcx, 0x16A65C00BE0
       mov      rcx, gword ptr [rcx]
       add      rcx, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm14, dword ptr [rcx+4*xmm2], ymm3
       vpand    ymm2, ymm14, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm15, ymm15, ymm15
       vpcmpeqd ymm15, ymm15, ymm2
       vpslld   ymm5, ymm14, 29
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x7D0]
       vblendvps ymm5, ymm5, ymm3, ymm15
       vpcmpeqd ymm15, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm13, ymm14, 28
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x7B0]
       vblendvps ymm13, ymm13, ymm3, ymm15
       vaddps   ymm5, ymm13, ymm5
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm13, ymm14, 27
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymm4
       vblendvps ymm2, ymm13, ymm3, ymm2
 
G_M000_IG40:                ;; offset=0x12FA
       vaddps   ymm2, ymm2, ymm5
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x830]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x950], ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x730]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x2B0]
       vmovups  ymm3, ymmword ptr [rbp-0x8B0]
       vpxor    ymm2, ymm2, ymm3
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x8D0]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm14, ymm2, 15
       vpxor    ymm2, ymm14, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      rcx, 0x16A65C00BE0
       mov      rcx, gword ptr [rcx]
       add      rcx, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm15, dword ptr [rcx+4*xmm2], ymm14
       vpand    ymm2, ymm15, ymmword ptr [reloc @RWD544]
       vxorps   ymm14, ymm14, ymm14
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm2
       vpslld   ymm13, ymm15, 29
       vpand    ymm13, ymm13, ymmword ptr [reloc @RWD576]
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x790]
       vblendvps ymm1, ymm13, ymm14, ymm1
       vpcmpeqd ymm13, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm5, ymm15, 28
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x7F0]
       vblendvps ymm5, ymm5, ymm14, ymm13
       vaddps   ymm1, ymm5, ymm1
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm15, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm5, ymm5, ymm4
       vblendvps ymm2, ymm5, ymm14, ymm2
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x890]
       vpxor    ymm2, ymm15, ymmword ptr [rbp-0x2B0]
       vpxor    ymm2, ymm2, ymm3
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x8D0]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD512]
       mov      rcx, 0x16A65C00BE0
       mov      rcx, gword ptr [rcx]
       add      rcx, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [rcx+4*xmm2], ymm3
       vpand    ymm2, ymm5, ymmword ptr [reloc @RWD544]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm2
 
G_M000_IG41:                ;; offset=0x145D
       vpslld   ymm14, ymm5, 29
       vpand    ymm14, ymm14, ymmword ptr [reloc @RWD576]
       vpxor    ymm14, ymm14, ymmword ptr [rbp-0x7D0]
       vblendvps ymm13, ymm14, ymm3, ymm13
       vpcmpeqd ymm14, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD576]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x7F0]
       vblendvps ymm14, ymm15, ymm3, ymm14
       vaddps   ymm13, ymm14, ymm13
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD640]
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD576]
       vpxor    ymm4, ymm5, ymm4
       vblendvps ymm2, ymm4, ymm3, ymm2
       vaddps   ymm2, ymm2, ymm13
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0x830]
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymm2, ymmword ptr [rbp-0x930]
       vmovups  ymm3, ymmword ptr [rbp-0x910]
       vsubps   ymm2, ymm2, ymm3
       vmovups  ymm13, ymmword ptr [rbp-0x850]
       vmulps   ymm2, ymm2, ymm13
       vaddps   ymm2, ymm2, ymm3
       vmovups  ymm3, ymmword ptr [rbp-0x950]
       vsubps   ymm1, ymm1, ymm3
       vmulps   ymm1, ymm1, ymm13
       vaddps   ymm1, ymm1, ymm3
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x870]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD672]
       vmovups  ymmword ptr [rbp-0x710], ymm1
       jmp      G_M000_IG53
 
G_M000_IG42:                ;; offset=0x1533
       vcmpeqps ymm1, ymm13, ymm13
       vandps   ymm1, ymm1, ymm13
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x970], ymm1
       vcmpeqps ymm1, ymm14, ymm14
       vandps   ymm1, ymm1, ymm14
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm14, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x990], ymm1
       vcmpeqps ymm1, ymm15, ymm15
       vandps   ymm1, ymm1, ymm15
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm15, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x9B0], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x970]
       vsubps   ymm1, ymm13, ymm1
       vmovups  ymmword ptr [rbp-0x9D0], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x990]
       vsubps   ymm1, ymm14, ymm1
       vmovups  ymmword ptr [rbp-0x9F0], ymm1
       vcvtdq2ps ymm1, ymmword ptr [rbp-0x9B0]
       vsubps   ymm1, ymm15, ymm1
       vmovups  ymmword ptr [rbp-0xA10], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x970]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vmovups  ymmword ptr [rbp-0x970], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x990]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD416]
       vmovups  ymmword ptr [rbp-0x990], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x9B0]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD448]
       vmovups  ymmword ptr [rbp-0x9B0], ymm1
       vbroadcastss ymm1, dword ptr [reloc @RWD384]
       vbroadcastss ymm2, dword ptr [reloc @RWD416]
       vbroadcastss ymm3, dword ptr [reloc @RWD448]
       vmovups  ymm4, ymmword ptr [rbp-0x970]
       vpsubd   ymm4, ymm4, ymm1
       vmovups  ymmword ptr [rbp-0xA30], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x990]
       vpsubd   ymm4, ymm4, ymm2
       vmovups  ymmword ptr [rbp-0xA50], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x9B0]
       vpsubd   ymm4, ymm4, ymm3
       vmovups  ymmword ptr [rbp-0xA70], ymm4
       vpaddd   ymm1, ymm1, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0xA90], ymm1
 
G_M000_IG43:                ;; offset=0x16C6
       vpaddd   ymm1, ymm2, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0xAB0], ymm1
       vpaddd   ymm1, ymm3, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0xAD0], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x970]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD704]
       vmovups  ymmword ptr [rbp-0xAF0], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x990]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD736]
       vmovups  ymmword ptr [rbp-0xB10], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x9B0]
       vpaddd   ymm1, ymm1, ymmword ptr [reloc @RWD768]
       vmovups  ymmword ptr [rbp-0xB30], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x2B0]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA30]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA50]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA70]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x2B0]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x970]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA50]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA70]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x2B0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA90]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA50]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA70]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x2B0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAF0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA50]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA70]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
       vmovups  ymm5, ymmword ptr [rbp-0x9D0]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9D0]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9D0]
 
G_M000_IG44:                ;; offset=0x185E
       vmulps   ymm14, ymm13, ymm4
       vsubps   ymm15, ymm1, ymm2
       vsubps   ymm4, ymm15, ymm4
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm14
       vsubps   ymm1, ymm3, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9D0]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xC10], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x2B0]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA30]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x990]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA70]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x2B0]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x970]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x990]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA70]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x2B0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA90]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x990]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA70]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x2B0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAF0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0x990]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA70]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
       vmovups  ymm5, ymmword ptr [rbp-0x9D0]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9D0]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9D0]
       vmulps   ymm13, ymm13, ymm4
       vsubps   ymm14, ymm1, ymm2
       vsubps   ymm4, ymm14, ymm4
 
G_M000_IG45:                ;; offset=0x19CB
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm13
       vsubps   ymm1, ymm3, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9D0]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xC30], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x2B0]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA30]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xAB0]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0xA70]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD480]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD800]
       vmovups  ymm2, ymmword ptr [rbp-0x2B0]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x970]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xAB0]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0xA70]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD480]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD800]
       vmovups  ymm3, ymmword ptr [rbp-0x2B0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA90]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xAB0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xA70]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD480]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD800]
       vmovups  ymm4, ymmword ptr [rbp-0x2B0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAF0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAB0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xA70]
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD480]
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymmword ptr [reloc @RWD800]
       vsubps   ymm4, ymm4, ymm3
       vsubps   ymm5, ymm1, ymm2
       vsubps   ymm4, ymm4, ymm5
       vmovups  ymm5, ymmword ptr [rbp-0x9D0]
       vmulps   ymm5, ymm5, ymmword ptr [rbp-0x9D0]
       vmulps   ymm13, ymm5, ymmword ptr [rbp-0x9D0]
       vmulps   ymm13, ymm13, ymm4
       vsubps   ymm14, ymm1, ymm2
       vsubps   ymm4, ymm14, ymm4
       vmulps   ymm4, ymm4, ymm5
       vaddps   ymm4, ymm4, ymm13
       vsubps   ymm1, ymm3, ymm1
 
G_M000_IG46:                ;; offset=0x1B39
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x9D0]
       vaddps   ymm1, ymm1, ymm4
       vaddps   ymm1, ymm1, ymm2
       vmovups  ymmword ptr [rbp-0xC50], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0xED0], ymm1
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      rcx, [rbp-0xDD0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       lea      r8, [rbp-0xEB0]
       lea      rdx, [rbp-0xDD0]
       lea      rcx, [rbp-0xDF0]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       lea      r8, [rbp-0xEB0]
       lea      rdx, [rbp-0xDF0]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xE30]
       mov      edx, 0x27D4EB2D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xD10]
       lea      rdx, [rbp-0xE10]
       lea      r8, [rbp-0xE30]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      rcx, [rbp-0xD30]
       lea      r8, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      rcx, [rbp-0xD50]
       mov      r8d, 19
 
G_M000_IG47:                ;; offset=0x1C70
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftLeft(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xD70]
       lea      rdx, [rbp-0xD30]
       lea      r8, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xD90]
       lea      rdx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xDB0]
       vmovss   xmm1, dword ptr [reloc @RWD800]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xC90]
       lea      rdx, [rbp-0xD90]
       lea      r8, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xCD0]
 
G_M000_IG48:                ;; offset=0x1DAB
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       lea      rdx, [rbp-0xA70]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xCF0]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xC90]
       lea      r8, [rbp-0xCB0]
       lea      r9, [rbp-0xCD0]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xC70]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xC10]
       lea      r8, [rbp-0xC30]
       lea      r9, [rbp-0xC50]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x990]
 
G_M000_IG49:                ;; offset=0x1F0B
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       lea      rdx, [rbp-0x9B0]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xF30]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF50]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF70]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF90]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xFB0]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE50]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE70]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       lea      rdx, [rbp-0xAD0]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
 
G_M000_IG50:                ;; offset=0x209D
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xF30]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF50]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF70]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF90]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xFB0]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE50]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE70]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xA90]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xAF0]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xA50]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0x990]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xAB0]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xB10]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xB30]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x9D0]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0x9F0]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xBB0]
       lea      rdx, [rbp-0x2B0]
       lea      r8, [rbp-0xA30]
       lea      r9, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xBB0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xA10]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xBD0]
       lea      rdx, [rbp-0xB50]
       lea      r8, [rbp-0xB70]
       lea      r9, [rbp-0xB90]
 
G_M000_IG51:                ;; offset=0x21E1
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xBF0]
       vmovss   xmm1, dword ptr [reloc @RWD832]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x710]
       lea      rdx, [rbp-0xBD0]
       lea      r8, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x222B
       vmovups  ymmword ptr [rbp-0xE50], ymm13
       vmovups  ymmword ptr [rbp-0xE70], ymm14
       vmovups  ymmword ptr [rbp-0xE90], ymm15
       lea      r8, [rbp-0xE50]
       lea      r9, [rbp-0xE70]
       lea      rcx, [rbp-0xE90]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0x2B0]
       lea      rcx, [rbp-0x710]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.ValueKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG53:                ;; offset=0x2295
       lea      rcx, [rbp-0x168]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       test     eax, eax
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       je       SHORT G_M000_IG54
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      r8, [rbp-0xE50]
       lea      rdx, [rbp-0x168]
       lea      rcx, [rbp-0x2D0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:ShapeSingle[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x231B
       vmovups  ymm1, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x2D0], ymm1
 
G_M000_IG55:                ;; offset=0x232B
       lea      rcx, [rbp-0x310]
       vmovss   xmm1, dword ptr [rbp-0x2D4]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x230]
       lea      rdx, [rbp-0x2D0]
       lea      r8, [rbp-0x310]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG14
 
G_M000_IG56:                ;; offset=0x2384
       lea      ecx, [r15-0x01]
       mov      dword ptr [rbp-0x3B4], eax
       cmp      eax, ecx
       jne      G_M000_IG59
       lea      rcx, [rbp-0x6F0]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmmword ptr [rbp-0x100], ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x350]
       lea      r8, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmmword ptr [rbp-0x100]
       mov      eax, dword ptr [rbp-0x3B4]
       jmp      G_M000_IG23
 
G_M000_IG57:                ;; offset=0x240A
       vmovups  ymm0, ymmword ptr [rbp-0x410]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x410]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm9, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Abs(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x430]
       vmovss   xmm1, dword ptr [reloc @RWD836]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x410]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x450]
       lea      r8, [rbp-0x430]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x470]
       vmovaps  xmm1, xmm7
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x490]
       lea      rdx, [rbp-0x450]
       lea      r8, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      r8, [rbp-0xE50]
       lea      rdx, [rbp-0x490]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x330]
       lea      r8, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4D0]
       vmovaps  xmm1, xmm7
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4F0]
       lea      rdx, [rbp-0x4D0]
       lea      r8, [rbp-0x410]
 
G_M000_IG58:                ;; offset=0x2528
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm9
       jmp      G_M000_IG25
 
G_M000_IG59:                ;; offset=0x2545
       mov      eax, dword ptr [rbp-0x3B4]
       jmp      G_M000_IG23
 
G_M000_IG60:                ;; offset=0x2550
       lea      rcx, [rbp-0x550]
       vmovaps  xmm1, xmm7
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm9, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x570]
       lea      rdx, [rbp-0x410]
       lea      r8, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x168]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_PingPongStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5B0]
       lea      rdx, [rbp-0x570]
       lea      r8, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x410]
       lea      rdx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.NoiseMath:PingPong[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5D0]
       vmovss   xmm1, dword ptr [reloc @RWD68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x410]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x5F0]
       lea      r8, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x610]
       vmovss   xmm1, dword ptr [reloc @RWD840]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x630]
       lea      rdx, [rbp-0x5F0]
       lea      r8, [rbp-0x610]
 
G_M000_IG61:                ;; offset=0x2645
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      r8, [rbp-0xE50]
       lea      rdx, [rbp-0x630]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x330]
       lea      r8, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x410]
       vmovups  ymmword ptr [rbp-0x4F0], ymm0
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm12, ymm12, xmm9
       jmp      G_M000_IG25
 
G_M000_IG62:                ;; offset=0x26C8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dq	0000000100000000h, 0000000300000002h, 0000000500000004h, 0000000700000006h
RWD32  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD64  	dd	3F800000h		;         1
RWD68  	dd	3F000000h		;       0.5
RWD72  	dd	00000949h ; case G_M000_IG29
       	dd	00000983h ; case G_M000_IG30
       	dd	00000458h ; case G_M000_IG19
RWD84  	dd	00000000h, 00000000h, 00000000h
RWD96  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD128 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD160 	dd	00000A2Ch ; case G_M000_IG33
       	dd	000009F2h ; case G_M000_IG32
       	dd	00000A9Bh ; case G_M000_IG34
       	dd	00000B2Ch ; case G_M000_IG35
       	dd	00001476h ; case G_M000_IG42
       	dd	0000216Eh ; case G_M000_IG52
RWD184 	dd	00000000h, 00000000h
RWD192 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD224 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD256 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD288 	dq	40C0000040C00000h, 40C0000040C00000h, 40C0000040C00000h, 40C0000040C00000h
RWD320 	dq	4170000041700000h, 4170000041700000h, 4170000041700000h, 4170000041700000h
RWD352 	dq	4120000041200000h, 4120000041200000h, 4120000041200000h, 4120000041200000h
RWD384 	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD416 	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD448 	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD480 	dq	27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh
RWD512 	dq	000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh
RWD544 	dq	0000000300000003h, 0000000300000003h, 0000000300000003h, 0000000300000003h
RWD576 	dq	8000000080000000h, 8000000080000000h, 8000000080000000h, 8000000080000000h
RWD608 	dq	0000000100000001h, 0000000100000001h, 0000000100000001h, 0000000100000001h
RWD640 	dq	0000000200000002h, 0000000200000002h, 0000000200000002h, 0000000200000002h
RWD672 	dq	3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h
RWD704 	dq	3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h
RWD736 	dq	87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah
RWD768 	dq	CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh
RWD800 	dq	3000000030000000h, 3000000030000000h, 3000000030000000h, 3000000030000000h
RWD832 	dd	3E97B426h		;  0.296296
RWD836 	dd	C0000000h		;        -2
RWD840 	dd	40000000h		;         2

; Total bytes of code 9934

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3(Tedd.FastNoise.Procedural.CompiledStack3D,Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int,bool) (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2
; 9 inlinees with PGO data; 906 single block inlinees; 11 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       lea      r11, [rsp-0x1218]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       vmovaps  xmmword ptr [rsp+0x1200], xmm6
       vmovaps  xmmword ptr [rsp+0x11F0], xmm7
       vmovaps  xmmword ptr [rsp+0x11E0], xmm8
       vmovaps  xmmword ptr [rsp+0x11D0], xmm9
       vmovaps  xmmword ptr [rsp+0x11C0], xmm10
       vmovaps  xmmword ptr [rsp+0x11B0], xmm11
       vmovaps  xmmword ptr [rsp+0x11A0], xmm12
       vmovaps  xmmword ptr [rsp+0x1190], xmm13
       vmovaps  xmmword ptr [rsp+0x1180], xmm14
       vmovaps  xmmword ptr [rsp+0x1170], xmm15
       lea      rbp, [rsp+0x1250]
       xor      eax, eax
       mov      qword ptr [rbp-0xFC8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xFC0], xmm4
       mov      rax, -0xEA0
       vmovdqa  xmmword ptr [rbp+rax-0x110], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x100], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0xF0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rdi, rdx
       mov      rsi, r8
       mov      rbx, r9
       mov      r14d, dword ptr [rbp+0x30]
       mov      r15d, dword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x00CF
       mov      r13, gword ptr [rcx+0x08]
       mov      gword ptr [rbp-0x1198], r13
       cmp      byte  ptr [rbp+0x40], 0
       je       G_M000_IG09
 
G_M000_IG03:                ;; offset=0x00E4
       mov      r12, gword ptr [rcx+0x10]
 
G_M000_IG04:                ;; offset=0x00E8
       mov      r10d, dword ptr [rsi+0x0C]
       mov      dword ptr [rbp-0xE4], r10d
       mov      r11d, dword ptr [rsi+0x10]
       mov      dword ptr [rbp-0xE8], r11d
       vmovss   xmm6, dword ptr [rsi+0x18]
       mov      ecx, r14d
       lea      eax, [r14+r15]
       cmp      eax, ecx
       jg       G_M000_IG70
 
G_M000_IG05:                ;; offset=0x0112
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1200]
       vmovaps  xmm7, xmmword ptr [rsp+0x11F0]
       vmovaps  xmm8, xmmword ptr [rsp+0x11E0]
       vmovaps  xmm9, xmmword ptr [rsp+0x11D0]
       vmovaps  xmm10, xmmword ptr [rsp+0x11C0]
       vmovaps  xmm11, xmmword ptr [rsp+0x11B0]
       vmovaps  xmm12, xmmword ptr [rsp+0x11A0]
       vmovaps  xmm13, xmmword ptr [rsp+0x1190]
       vmovaps  xmm14, xmmword ptr [rsp+0x1180]
       vmovaps  xmm15, xmmword ptr [rsp+0x1170]
       add      rsp, 0x1218
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x0183
       mov      rcx, rsi
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0xF4]
       vmulss   xmm9, xmm1, xmm6
       vaddss   xmm1, xmm0, xmm9
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       mov      r13, gword ptr [rbp-0x1198]
       mov      rcx, gword ptr [r13+0x08]
       call     [r13+0x18]System.Func`4[float,float,float,float]:Invoke(float,float,float):float:this
       vmovaps  xmm10, xmm0
       vmovaps  xmm0, xmm10
       call     [System.Single:IsNaN(float):bool]
       test     eax, eax
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01CC
       mov      rcx, rsi
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vaddss   xmm1, xmm0, xmm9
       mov      rcx, rdi
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovaps  xmm10, xmm0
 
G_M000_IG08:                ;; offset=0x01F0
       mov      eax, dword ptr [rbp-0xF0]
       mov      ecx, dword ptr [rbp-0xF4]
       lea      edx, [rax+rcx]
       cmp      edx, dword ptr [rbx+0x08]
       jae      G_M000_IG74
       lea      edx, [rax+rcx]
       mov      r8, bword ptr [rbx]
       vmovss   dword ptr [r8+4*rdx], xmm10
       inc      ecx
       mov      r10d, dword ptr [rbp-0xE4]
       cmp      ecx, r10d
       mov      dword ptr [rbp-0xF4], ecx
       jl       G_M000_IG06
       jmp      G_M000_IG69
 
G_M000_IG09:                ;; offset=0x0231
       xor      r12, r12
       jmp      G_M000_IG04
 
G_M000_IG10:                ;; offset=0x0239
       mov      eax, dword ptr [rbp-0x3D4]
 
G_M000_IG11:                ;; offset=0x023F
       mov      dword ptr [rbp-0x3D4], eax
       mov      edx, eax
       add      edx, dword ptr [rbp-0x1AC]
       lea      rcx, [rbp-0x410]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2D0]
       vmovups  ymmword ptr [rbp-0xE90], ymm0
       lea      r9, [rbp-0xE50]
       lea      rcx, [rbp-0xE70]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xE90]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x430]
       lea      rdx, [rbp-0x188]
       lea      r8, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Single3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       cmp      eax, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       je       G_M000_IG16
 
G_M000_IG12:                ;; offset=0x02F2
       cmp      eax, 3
       je       G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02FB
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x690]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x350]
       lea      r8, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6B0]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6D0]
       lea      rdx, [rbp-0x430]
       lea      r8, [rbp-0x6B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x6F0]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x510]
       lea      rdx, [rbp-0x6D0]
       lea      r8, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       jmp      G_M000_IG18
 
G_M000_IG14:                ;; offset=0x03DB
       lea      rcx, [rbp-0x570]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x590]
       lea      rdx, [rbp-0x430]
       lea      r8, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_PingPongStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5D0]
       lea      rdx, [rbp-0x590]
       lea      r8, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x430]
       lea      rdx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.NoiseMath:PingPong[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x5F0]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x610]
       lea      r8, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x630]
       vmovss   xmm1, dword ptr [reloc @RWD04]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x650]
       lea      rdx, [rbp-0x610]
       lea      r8, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG15:                ;; offset=0x04D1
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      r8, [rbp-0xE50]
       lea      rdx, [rbp-0x650]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x350]
       lea      r8, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x510], ymm0
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       jmp      G_M000_IG18
 
G_M000_IG16:                ;; offset=0x0548
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x430]
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:Abs(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x450]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x470]
       lea      r8, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x490]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4B0]
       lea      rdx, [rbp-0x470]
       lea      r8, [rbp-0x490]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      r8, [rbp-0xE50]
       lea      rdx, [rbp-0x4B0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x350]
       lea      r8, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4F0]
       vmovaps  xmm1, xmm13
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x510]
       lea      rdx, [rbp-0x4F0]
       lea      r8, [rbp-0x430]
 
G_M000_IG17:                ;; offset=0x0662
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
 
G_M000_IG18:                ;; offset=0x0674
       lea      rcx, [rbp-0x530]
       vmovaps  xmm1, xmm13
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      r9, [rbp-0xE50]
       lea      rdx, [rbp-0x530]
       lea      r8, [rbp-0x510]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.NoiseMath:Lerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x370]
       lea      r8, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2D0]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x2D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
 
G_M000_IG19:                ;; offset=0x07C0
       lea      rdx, [rbp-0xE50]
       lea      r8, [rbp-0xE70]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      eax, dword ptr [rbp-0x3D4]
       inc      eax
       mov      r8d, dword ptr [rbp-0x1B0]
       cmp      eax, r8d
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       mov      edx, r8d
       jge      G_M000_IG31
 
G_M000_IG20:                ;; offset=0x0802
       vmovss   xmm13, dword ptr [reloc @RWD12]
       vucomiss xmm10, xmm13
       jp       SHORT G_M000_IG21
       je       G_M000_IG11
 
G_M000_IG21:                ;; offset=0x0817
       lea      ecx, [rdx-0x01]
       mov      dword ptr [rbp-0x3D4], eax
       cmp      eax, ecx
       jne      G_M000_IG10
 
G_M000_IG22:                ;; offset=0x0828
       lea      rcx, [rbp-0x710]
       vmovaps  xmm1, xmm10
       vextractf128 xmm15, ymm9
       vextractf128 xmm11, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x370]
       lea      r8, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm11
       mov      eax, dword ptr [rbp-0x3D4]
       jmp      G_M000_IG11
 
G_M000_IG23:                ;; offset=0x0888
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x130], ymm0
 
G_M000_IG24:                ;; offset=0x0898
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xFC8], xmm0
 
G_M000_IG25:                ;; offset=0x08A4
       lea      rdx, [rbp-0xFC8]
       mov      r8d, dword ptr [rbp-0xF4]
       add      r8d, dword ptr [rbp-0xF0]
       lea      rcx, [rbp-0x130]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      r8d, dword ptr [rbp-0x1094]
       mov      eax, r8d
       mov      r8d, eax
       mov      r10d, dword ptr [rbp-0xE4]
 
G_M000_IG26:                ;; offset=0x08DA
       lea      edx, [r8+0x08]
       mov      dword ptr [rbp-0x1094], edx
       cmp      edx, r10d
       jg       G_M000_IG68
 
G_M000_IG27:                ;; offset=0x08ED
       vbroadcastss ymm0, ymm6
       vcvtdq2ps ymm1, ymmword ptr [reloc @RWD32]
       vmulps   ymm0, ymm1, ymm0
       mov      dword ptr [rbp-0xF4], r8d
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r8d
       vmulss   xmm1, xmm1, xmm6
       vaddss   xmm1, xmm1, dword ptr [rsi]
       vbroadcastss ymm1, ymm1
       vaddps   ymm9, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0xE50], ymm9
       vbroadcastss ymm0, ymm7
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       vbroadcastss ymm0, ymm8
       vmovups  ymmword ptr [rbp-0xE90], ymm0
       lea      r8, [rbp-0xE50]
       lea      r9, [rbp-0xE70]
       lea      r13, [rbp-0xE90]
       mov      qword ptr [rsp+0x20], r13
       lea      rdx, [rbp-0x130]
       mov      rcx, gword ptr [r12+0x08]
       vextractf128 xmm10, ymm9
       call     [r12+0x18]System.Func`4[System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]]:Invoke(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this
       vmovups  ymm1, ymmword ptr [rbp-0x130]
       vcmpeqps ymm1, ymm1, ymmword ptr [rbp-0x130]
       vmovmskps rcx, ymm1
       cmp      ecx, 255
       vinsertf128 ymm9, ymm9, xmm10
       je       G_M000_IG24
 
G_M000_IG28:                ;; offset=0x0999
       vbroadcastss ymm11, ymm7
       vmovups  ymmword ptr [rbp-0x150], ymm11
       vbroadcastss ymm12, ymm8
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x188], xmm1
       vmovdqu  xmmword ptr [rbp-0x184], xmm1
       vxorps   xmm1, xmm1, xmm1
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm1
       vmovdqu  xmmword ptr [rbp-0x19C], xmm1
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0x170], ymm1
       xor      r13d, r13d
       jmp      G_M000_IG59
 
G_M000_IG29:                ;; offset=0x09E7
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x250], ymm0
       jmp      G_M000_IG58
 
G_M000_IG30:                ;; offset=0x09FC
       lea      rcx, [rbp-0x350]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Bounding():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Lacunarity():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Gain():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x1A8]
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_WeightedStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      edx, dword ptr [rbp-0x1B0]
       cmp      eax, edx
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jl       G_M000_IG20
 
G_M000_IG31:                ;; offset=0x0AAD
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x270], ymm0
       jmp      G_M000_IG56
 
G_M000_IG32:                ;; offset=0x0AC2
       vcmpeqps ymm0, ymm13, ymm13
       vandps   ymm0, ymm0, ymm13
       vbroadcastss ymm1, dword ptr [reloc @RWD64]
       vcmpgeps ymm2, ymm0, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD68]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xAB0], ymm0
       vcmpeqps ymm0, ymm14, ymm14
       vandps   ymm0, ymm0, ymm14
       vcmpgeps ymm2, ymm0, ymm1
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm14, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xAD0], ymm0
       vcmpeqps ymm0, ymm15, ymm15
       vandps   ymm0, ymm0, ymm15
       vcmpgeps ymm1, ymm0, ymm1
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm1
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm15, ymm1
       vpaddd   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [rbp-0xAF0], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xAB0]
       vsubps   ymm0, ymm13, ymm0
       vmovups  ymmword ptr [rbp-0xB10], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xAD0]
       vsubps   ymm0, ymm14, ymm0
       vmovups  ymmword ptr [rbp-0xB30], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0xAF0]
       vsubps   ymm0, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vbroadcastss ymm0, dword ptr [reloc @RWD72]
       vpmulld  ymm1, ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0xAB0], ymm1
       vbroadcastss ymm1, dword ptr [reloc @RWD76]
       vpmulld  ymm2, ymm1, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0xAD0], ymm2
       vbroadcastss ymm2, dword ptr [reloc @RWD80]
       vpmulld  ymm3, ymm2, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0xAF0], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xAB0]
       vpsubd   ymm3, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xB70], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xAD0]
       vpsubd   ymm3, ymm3, ymm1
       vmovups  ymmword ptr [rbp-0xB90], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0xAF0]
       vpsubd   ymm3, ymm3, ymm2
       vmovups  ymmword ptr [rbp-0xBB0], ymm3
       vpaddd   ymm0, ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0xBD0], ymm0
       vpaddd   ymm0, ymm1, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0xBF0], ymm0
 
G_M000_IG33:                ;; offset=0x0C47
       vpaddd   ymm0, ymm2, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0xC10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rbp-0xC30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD128]
       vmovups  ymmword ptr [rbp-0xC50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vmovups  ymmword ptr [rbp-0xC70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB70]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB90]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xBB0]
       vbroadcastss ymm1, dword ptr [reloc @RWD192]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm2, ymm0, 19
       vpxor    ymm0, ymm2, ymm0
       vcvtdq2ps ymm0, ymm0
       vbroadcastss ymm2, dword ptr [reloc @RWD196]
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2F0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xAB0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xB90]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2F0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBD0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xB90]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2F0]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xC30]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xB90]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm5, ymm5, ymm1
       vpmulld  ymm5, ymm5, ymm5
       vpslld   ymm13, ymm5, 19
       vpxor    ymm5, ymm13, ymm5
       vcvtdq2ps ymm5, ymm5
       vmulps   ymm5, ymm5, ymm2
       vsubps   ymm5, ymm5, ymm4
       vsubps   ymm14, ymm0, ymm3
       vsubps   ymm5, ymm5, ymm14
       vmovups  ymm15, ymmword ptr [rbp-0xB10]
       vmulps   ymm13, ymm15, ymmword ptr [rbp-0xB10]
       vmulps   ymm14, ymm13, ymmword ptr [rbp-0xB10]
 
G_M000_IG34:                ;; offset=0x0DC2
       vmulps   ymm14, ymm14, ymm5
       vsubps   ymm15, ymm0, ymm3
       vsubps   ymm5, ymm15, ymm5
       vmulps   ymm5, ymm5, ymm13
       vaddps   ymm5, ymm5, ymm14
       vsubps   ymm0, ymm4, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xB10]
       vaddps   ymm0, ymm0, ymm5
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB70]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xAD0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm3, ymm0, 19
       vpxor    ymm0, ymm3, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2F0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xAB0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xAD0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2F0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBD0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xAD0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2F0]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xC30]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xAD0]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm5, ymm5, ymm1
       vpmulld  ymm5, ymm5, ymm5
       vpslld   ymm13, ymm5, 19
       vpxor    ymm5, ymm13, ymm5
       vcvtdq2ps ymm5, ymm5
       vmulps   ymm5, ymm5, ymm2
       vsubps   ymm5, ymm5, ymm4
       vsubps   ymm13, ymm0, ymm3
       vsubps   ymm5, ymm5, ymm13
       vmovups  ymm13, ymmword ptr [rbp-0xB10]
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0xB10]
       vmulps   ymm14, ymm13, ymmword ptr [rbp-0xB10]
       vmulps   ymm14, ymm14, ymm5
       vsubps   ymm15, ymm0, ymm3
       vsubps   ymm5, ymm15, ymm5
 
G_M000_IG35:                ;; offset=0x0F11
       vmulps   ymm5, ymm5, ymm13
       vaddps   ymm5, ymm5, ymm14
       vsubps   ymm0, ymm4, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xB10]
       vaddps   ymm0, ymm0, ymm5
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xB70]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xBF0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm0, ymm0, ymm1
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm3, ymm0, 19
       vpxor    ymm0, ymm3, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymm2
       vmovups  ymm3, ymmword ptr [rbp-0x2F0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xAB0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xBF0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm3, ymm3, ymm1
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymm2
       vmovups  ymm4, ymmword ptr [rbp-0x2F0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBD0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBF0]
       vpxor    ymm4, ymm4, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm4, ymm4, ymm1
       vpmulld  ymm4, ymm4, ymm4
       vpslld   ymm5, ymm4, 19
       vpxor    ymm4, ymm5, ymm4
       vcvtdq2ps ymm4, ymm4
       vmulps   ymm4, ymm4, ymm2
       vmovups  ymm5, ymmword ptr [rbp-0x2F0]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xC30]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBF0]
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0xBB0]
       vpmulld  ymm1, ymm5, ymm1
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm5, ymm1, 19
       vpxor    ymm1, ymm5, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm4
       vsubps   ymm2, ymm0, ymm3
       vsubps   ymm1, ymm1, ymm2
       vmovups  ymm2, ymmword ptr [rbp-0xB10]
       vmulps   ymm2, ymm2, ymmword ptr [rbp-0xB10]
       vmulps   ymm5, ymm2, ymmword ptr [rbp-0xB10]
       vmulps   ymm5, ymm5, ymm1
       vsubps   ymm13, ymm0, ymm3
       vsubps   ymm1, ymm13, ymm1
       vmulps   ymm1, ymm1, ymm2
       vaddps   ymm1, ymm1, ymm5
       vsubps   ymm0, ymm4, ymm0
 
G_M000_IG36:                ;; offset=0x105F
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0xB10]
       vaddps   ymm0, ymm0, ymm1
       vaddps   ymm0, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0xD90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xDD0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xDF0]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
 
G_M000_IG37:                ;; offset=0x11D5
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       lea      rdx, [rbp-0xBB0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xE30]
       call     [Tedd.FastNoise.Internal.Hashing:ValCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xE30]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xDD0]
       lea      r8, [rbp-0xDF0]
       lea      r9, [rbp-0xE10]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xDB0]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xD50]
       lea      r8, [rbp-0xD70]
       lea      r9, [rbp-0xD90]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
 
G_M000_IG38:                ;; offset=0x134F
       lea      rdx, [rbp-0xAF0]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xF30]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF50]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF70]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF90]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xFB0]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE50]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE70]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0xEB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0xED0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0xEF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0xF10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       lea      rdx, [rbp-0xC10]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0xE70], ymm0
       lea      rdx, [rbp-0xEB0]
       lea      r8, [rbp-0xED0]
       lea      r9, [rbp-0xEF0]
       lea      rcx, [rbp-0xF10]
       mov      qword ptr [rsp+0x20], rcx
 
G_M000_IG39:                ;; offset=0x14DA
       lea      rcx, [rbp-0xF30]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xF50]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xF70]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xF90]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xFB0]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xE50]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xE70]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xBD0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xC30]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xB90]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xAD0]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xBF0]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xC50]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xC70]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0xB10]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xB30]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xCF0]
       lea      rdx, [rbp-0x2F0]
       lea      r8, [rbp-0xB70]
       lea      r9, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xCF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xB50]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xD10]
       lea      rdx, [rbp-0xC90]
       lea      r8, [rbp-0xCB0]
       lea      r9, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xD30]
       vmovss   xmm1, dword ptr [reloc @RWD200]
 
G_M000_IG40:                ;; offset=0x1612
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x730]
       lea      rdx, [rbp-0xD10]
       lea      r8, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG53
 
G_M000_IG41:                ;; offset=0x1644
       vcmpeqps ymm0, ymm13, ymm13
       vandps   ymm0, ymm0, ymm13
       vbroadcastss ymm1, dword ptr [reloc @RWD64]
       vcmpgeps ymm2, ymm0, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD68]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymm3, ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm13, ymm2
       vpaddd   ymm0, ymm2, ymm0
       vcmpeqps ymm2, ymm14, ymm14
       vandps   ymm2, ymm2, ymm14
       vcmpgeps ymm4, ymm2, ymm1
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm3, ymm4
       vxorps   ymm4, ymm4, ymm4
       vcmpltps ymm4, ymm14, ymm4
       vpaddd   ymm2, ymm4, ymm2
       vcmpeqps ymm4, ymm15, ymm15
       vandps   ymm4, ymm4, ymm15
       vcmpgeps ymm1, ymm4, ymm1
       vcvttps2dq ymm4, ymm4
       vpblendvb ymm1, ymm4, ymm3, ymm1
       vxorps   ymm3, ymm3, ymm3
       vcmpltps ymm3, ymm15, ymm3
       vpaddd   ymm1, ymm3, ymm1
       vcvtdq2ps ymm3, ymm0
       vsubps   ymm3, ymm13, ymm3
       vcvtdq2ps ymm4, ymm2
       vsubps   ymm4, ymm14, ymm4
       vcvtdq2ps ymm5, ymm1
       vsubps   ymm5, ymm15, ymm5
       vbroadcastss ymm13, dword ptr [reloc @RWD12]
       vsubps   ymm14, ymm3, ymm13
       vmovups  ymmword ptr [rbp-0x770], ymm14
       vsubps   ymm15, ymm4, ymm13
       vmovups  ymmword ptr [rbp-0x790], ymm15
       vsubps   ymm13, ymm5, ymm13
       vmovups  ymmword ptr [rbp-0x7B0], ymm13
       vmulps   ymm13, ymm3, ymm3
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x11C0], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD204]
       vmovups  ymmword ptr [rbp-0x1150], ymm13
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x11E0], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD208]
       vmovups  ymmword ptr [rbp-0x1170], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x11E0]
       vsubps   ymm13, ymm13, ymmword ptr [rbp-0x1170]
       vmulps   ymm13, ymm13, ymm3
       vmovups  ymmword ptr [rbp-0x11E0], ymm13
       vbroadcastss ymm13, dword ptr [reloc @RWD212]
       vmovups  ymmword ptr [rbp-0x1190], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x11E0]
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x1190]
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0x11C0]
       vmovups  ymmword ptr [rbp-0x7D0], ymm13
       vmulps   ymm15, ymm4, ymm4
       vmulps   ymm15, ymm15, ymm4
       vmovups  ymmword ptr [rbp-0x11C0], ymm15
 
G_M000_IG42:                ;; offset=0x17AE
       vmovups  ymm15, ymmword ptr [rbp-0x1150]
       vmulps   ymm15, ymm15, ymm4
       vsubps   ymm15, ymm15, ymmword ptr [rbp-0x1170]
       vmulps   ymm15, ymm15, ymm4
       vaddps   ymm15, ymm15, ymmword ptr [rbp-0x1190]
       vmulps   ymm15, ymm15, ymmword ptr [rbp-0x11C0]
       vmovups  ymmword ptr [rbp-0x7F0], ymm15
       vmulps   ymm15, ymm5, ymm5
       vmulps   ymm15, ymm15, ymm5
       vmovups  ymmword ptr [rbp-0x11C0], ymm15
       vmovups  ymm15, ymmword ptr [rbp-0x1150]
       vmulps   ymm15, ymm15, ymm5
       vsubps   ymm15, ymm15, ymmword ptr [rbp-0x1170]
       vmulps   ymm15, ymm15, ymm5
       vaddps   ymm15, ymm15, ymmword ptr [rbp-0x1190]
       vmulps   ymm15, ymm15, ymmword ptr [rbp-0x11C0]
       vmovups  ymmword ptr [rbp-0x810], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD72]
       vpmulld  ymm0, ymm15, ymm0
       vbroadcastss ymm13, dword ptr [reloc @RWD76]
       vpmulld  ymm2, ymm13, ymm2
       vbroadcastss ymm14, dword ptr [reloc @RWD80]
       vpmulld  ymm1, ymm14, ymm1
       vpaddd   ymm15, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0x830], ymm15
       vpaddd   ymm13, ymm13, ymm2
       vmovups  ymmword ptr [rbp-0x850], ymm13
       vpaddd   ymm14, ymm14, ymm1
       vmovups  ymmword ptr [rbp-0x870], ymm14
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymmword ptr [rbp-0x750], ymm2
       vpxor    ymm15, ymm2, ymm0
       vmovups  ymmword ptr [rbp-0xFF0], ymm15
       vpxor    ymm15, ymm1, ymm15
       vbroadcastss ymm0, dword ptr [reloc @RWD192]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm13, ymm15, 15
       vpxor    ymm15, ymm13, ymm15
       vbroadcastss ymm13, dword ptr [reloc @RWD216]
       vmovups  ymmword ptr [rbp-0x10D0], ymm13
       vpand    ymm15, ymm15, ymm13
       mov      r8, 0x16A65C00F50
       mov      r8, gword ptr [r8]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm2, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x910], ymm2
       vbroadcastss ymm14, dword ptr [reloc @RWD220]
       vmovups  ymmword ptr [rbp-0x10F0], ymm14
       vpand    ymm15, ymm14, ymm2
       vmovups  ymmword ptr [rbp-0x930], ymm15
       vxorps   ymm2, ymm2, ymm2
       vmovups  ymmword ptr [rbp-0x950], ymm2
       vxorps   ymm2, ymm2, ymm2
       vpcmpeqd ymm2, ymm2, ymm15
       vmovups  ymmword ptr [rbp-0x11C0], ymm2
 
G_M000_IG43:                ;; offset=0x192B
       vmovups  ymm2, ymmword ptr [rbp-0x910]
       vpslld   ymm2, ymm2, 29
       vmovups  ymmword ptr [rbp-0x11E0], ymm2
       vbroadcastss ymm2, dword ptr [reloc @RWD224]
       vmovups  ymm15, ymmword ptr [rbp-0x11E0]
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymm3
       vmovups  ymm14, ymmword ptr [rbp-0x11C0]
       vblendvps ymm14, ymm15, ymmword ptr [rbp-0x950], ymm14
       vmovups  ymmword ptr [rbp-0x11C0], ymm14
       vbroadcastss ymm15, dword ptr [reloc @RWD228]
       vmovups  ymmword ptr [rbp-0x1110], ymm15
       vpcmpeqd ymm14, ymm15, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x11E0], ymm14
       vmovups  ymm14, ymmword ptr [rbp-0x910]
       vpslld   ymm14, ymm14, 28
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm4
       vmovups  ymm15, ymmword ptr [rbp-0x11E0]
       vblendvps ymm14, ymm14, ymmword ptr [rbp-0x950], ymm15
       vaddps   ymm14, ymm14, ymmword ptr [rbp-0x11C0]
       vmovups  ymmword ptr [rbp-0x11C0], ymm14
       vbroadcastss ymm15, dword ptr [reloc @RWD232]
       vmovups  ymmword ptr [rbp-0x1130], ymm15
       vpcmpeqd ymm14, ymm15, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x11E0], ymm14
       vmovups  ymm14, ymmword ptr [rbp-0x910]
       vpslld   ymm14, ymm14, 27
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm5
       vmovups  ymm15, ymmword ptr [rbp-0x11E0]
       vblendvps ymm14, ymm14, ymmword ptr [rbp-0x950], ymm15
       vaddps   ymm14, ymm14, ymmword ptr [rbp-0x11C0]
       vmovups  ymmword ptr [rbp-0x890], ymm14
       vmovups  ymm15, ymmword ptr [rbp-0x830]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm15
       vmovups  ymm15, ymmword ptr [rbp-0x750]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1090]
       vmovups  ymmword ptr [rbp-0x1010], ymm15
       vpxor    ymm15, ymm1, ymm15
       vpmulld  ymm15, ymm15, ymm0
       vmovups  ymmword ptr [rbp-0x970], ymm15
       vpsrad   ymm15, ymm15, 15
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x970]
       vpand    ymm15, ymm15, ymm13
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm13, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x990], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10F0]
       vpand    ymm15, ymm14, ymm13
       vxorps   ymm14, ymm14, ymm14
       vmovups  ymmword ptr [rbp-0x9B0], ymm14
       vxorps   ymm14, ymm14, ymm14
 
G_M000_IG44:                ;; offset=0x1AB9
       vpcmpeqd ymm14, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x11C0], ymm14
       vpslld   ymm14, ymm13, 29
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymmword ptr [rbp-0x770]
       vmovups  ymm13, ymmword ptr [rbp-0x11C0]
       vblendvps ymm13, ymm14, ymmword ptr [rbp-0x9B0], ymm13
       vmovups  ymmword ptr [rbp-0x11C0], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x1110]
       vpcmpeqd ymm13, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x11E0], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x990]
       vpslld   ymm13, ymm13, 28
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm4
       vmovups  ymm14, ymmword ptr [rbp-0x11E0]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x9B0], ymm14
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x11C0]
       vmovups  ymmword ptr [rbp-0x11C0], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x1130]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x990]
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm5
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x9B0], ymm15
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x11C0]
       vmovups  ymm15, ymmword ptr [rbp-0x890]
       vsubps   ymm13, ymm13, ymm15
       vmulps   ymm13, ymm13, ymmword ptr [rbp-0x7D0]
       vaddps   ymm13, ymm13, ymm15
       vmovups  ymmword ptr [rbp-0x8B0], ymm13
       vmovups  ymm15, ymmword ptr [rbp-0x850]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1070]
       vmovups  ymmword ptr [rbp-0x1030], ymm15
       vpxor    ymm15, ymm1, ymm15
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm14, ymm15, 15
       vpxor    ymm15, ymm14, ymm15
       vpand    ymm15, ymm15, ymmword ptr [rbp-0x10D0]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm14, ymm14, ymm14
       vpgatherdd ymm13, dword ptr [r9+4*xmm15], ymm14
       vmovups  ymmword ptr [rbp-0x9D0], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x10F0]
       vpand    ymm15, ymm14, ymm13
       vxorps   ymm14, ymm14, ymm14
       vmovups  ymmword ptr [rbp-0x9F0], ymm14
       vxorps   ymm14, ymm14, ymm14
       vpcmpeqd ymm14, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x11C0], ymm14
       vpslld   ymm14, ymm13, 29
       vpand    ymm14, ymm14, ymm2
       vpxor    ymm14, ymm14, ymm3
       vmovups  ymm13, ymmword ptr [rbp-0x11C0]
 
G_M000_IG45:                ;; offset=0x1C2D
       vblendvps ymm13, ymm14, ymmword ptr [rbp-0x9F0], ymm13
       vmovups  ymmword ptr [rbp-0x11C0], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x1110]
       vpcmpeqd ymm13, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x11E0], ymm13
       vmovups  ymm13, ymmword ptr [rbp-0x9D0]
       vpslld   ymm13, ymm13, 28
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x790]
       vmovups  ymm14, ymmword ptr [rbp-0x11E0]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x9F0], ymm14
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x11C0]
       vmovups  ymmword ptr [rbp-0x11C0], ymm13
       vmovups  ymm14, ymmword ptr [rbp-0x1130]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x9D0]
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymm5
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0x9F0], ymm15
       vaddps   ymm13, ymm13, ymmword ptr [rbp-0x11C0]
       vmovups  ymm15, ymmword ptr [rbp-0x850]
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x1090]
       vmovups  ymmword ptr [rbp-0x1050], ymm15
       vpxor    ymm1, ymm1, ymm15
       vpmulld  ymm1, ymm1, ymm0
       vpsrad   ymm15, ymm1, 15
       vpxor    ymm1, ymm15, ymm1
       vpand    ymm1, ymm1, ymmword ptr [rbp-0x10D0]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm1, ymm1, 2
       vpcmpeqd ymm15, ymm15, ymm15
       vpgatherdd ymm14, dword ptr [r9+4*xmm1], ymm15
       vmovups  ymmword ptr [rbp-0xA10], ymm14
       vmovups  ymm1, ymmword ptr [rbp-0x10F0]
       vpand    ymm15, ymm1, ymm14
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0xA30], ymm1
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm15
       vmovups  ymmword ptr [rbp-0x11C0], ymm1
       vpslld   ymm1, ymm14, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x770]
       vmovups  ymm14, ymmword ptr [rbp-0x11C0]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA30], ymm14
       vmovups  ymmword ptr [rbp-0x11C0], ymm1
       vmovups  ymm14, ymmword ptr [rbp-0x1110]
       vpcmpeqd ymm1, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x11E0], ymm1
       vmovups  ymm1, ymmword ptr [rbp-0xA10]
       vpslld   ymm1, ymm1, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x790]
       vmovups  ymm14, ymmword ptr [rbp-0x11E0]
 
G_M000_IG46:                ;; offset=0x1DA3
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA30], ymm14
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x11C0]
       vmovups  ymmword ptr [rbp-0x11C0], ymm1
       vmovups  ymm14, ymmword ptr [rbp-0x1130]
       vpcmpeqd ymm15, ymm14, ymm15
       vmovups  ymm1, ymmword ptr [rbp-0xA10]
       vpslld   ymm1, ymm1, 27
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm5
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA30], ymm15
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x11C0]
       vsubps   ymm1, ymm1, ymm13
       vmulps   ymm1, ymm1, ymmword ptr [rbp-0x7D0]
       vaddps   ymm1, ymm1, ymm13
       vmovups  ymmword ptr [rbp-0x8D0], ymm1
       vmovups  ymm13, ymmword ptr [rbp-0x870]
       vpxor    ymm15, ymm13, ymmword ptr [rbp-0xFF0]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm1, ymm15, 15
       vpxor    ymm1, ymm1, ymm15
       vpand    ymm1, ymm1, ymmword ptr [rbp-0x10D0]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm1, ymm1, 2
       vpcmpeqd ymm5, ymm5, ymm5
       vpgatherdd ymm13, dword ptr [r9+4*xmm1], ymm5
       vmovups  ymm1, ymmword ptr [rbp-0x10F0]
       vpand    ymm5, ymm1, ymm13
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0xA50], ymm1
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm5
       vmovups  ymmword ptr [rbp-0x11C0], ymm1
       vpslld   ymm1, ymm13, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm3
       vmovups  ymm15, ymmword ptr [rbp-0x11C0]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA50], ymm15
       vmovups  ymmword ptr [rbp-0x11C0], ymm1
       vmovups  ymm15, ymmword ptr [rbp-0x1110]
       vpcmpeqd ymm1, ymm15, ymm5
       vmovups  ymmword ptr [rbp-0x11E0], ymm1
       vpslld   ymm1, ymm13, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm4
       vmovups  ymm15, ymmword ptr [rbp-0x11E0]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA50], ymm15
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x11C0]
       vpcmpeqd ymm5, ymm14, ymm5
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x7B0]
       vblendvps ymm5, ymm13, ymmword ptr [rbp-0xA50], ymm5
       vaddps   ymm1, ymm5, ymm1
       vmovups  ymm13, ymmword ptr [rbp-0x870]
       vpxor    ymm5, ymm13, ymmword ptr [rbp-0x1010]
 
G_M000_IG47:                ;; offset=0x1F0A
       vpmulld  ymm5, ymm5, ymm0
       vpsrad   ymm13, ymm5, 15
       vpxor    ymm5, ymm13, ymm5
       vpand    ymm5, ymm5, ymmword ptr [rbp-0x10D0]
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm5, ymm5, 2
       vpcmpeqd ymm15, ymm15, ymm15
       vpgatherdd ymm13, dword ptr [r9+4*xmm5], ymm15
       vmovups  ymm5, ymmword ptr [rbp-0x10F0]
       vpand    ymm15, ymm5, ymm13
       vxorps   ymm5, ymm5, ymm5
       vmovups  ymmword ptr [rbp-0xA70], ymm5
       vxorps   ymm5, ymm5, ymm5
       vpcmpeqd ymm5, ymm5, ymm15
       vmovups  ymmword ptr [rbp-0x11C0], ymm5
       vpslld   ymm5, ymm13, 29
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x770]
       vmovups  ymm14, ymmword ptr [rbp-0x11C0]
       vblendvps ymm5, ymm5, ymmword ptr [rbp-0xA70], ymm14
       vmovups  ymmword ptr [rbp-0x11C0], ymm5
       vmovups  ymm14, ymmword ptr [rbp-0x1110]
       vpcmpeqd ymm5, ymm14, ymm15
       vmovups  ymmword ptr [rbp-0x11E0], ymm5
       vpslld   ymm5, ymm13, 28
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm4, ymm5, ymm4
       vmovups  ymm14, ymmword ptr [rbp-0x11E0]
       vblendvps ymm4, ymm4, ymmword ptr [rbp-0xA70], ymm14
       vaddps   ymm4, ymm4, ymmword ptr [rbp-0x11C0]
       vmovups  ymm14, ymmword ptr [rbp-0x1130]
       vpcmpeqd ymm15, ymm14, ymm15
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm2
       vpxor    ymm13, ymm13, ymmword ptr [rbp-0x7B0]
       vblendvps ymm13, ymm13, ymmword ptr [rbp-0xA70], ymm15
       vaddps   ymm4, ymm13, ymm4
       vsubps   ymm4, ymm4, ymm1
       vmulps   ymm4, ymm4, ymmword ptr [rbp-0x7D0]
       vaddps   ymm1, ymm4, ymm1
       vmovups  ymmword ptr [rbp-0x8F0], ymm1
       vmovups  ymm4, ymmword ptr [rbp-0x870]
       vpxor    ymm15, ymm4, ymmword ptr [rbp-0x1030]
       vpmulld  ymm15, ymm15, ymm0
       vpsrad   ymm13, ymm15, 15
       vpxor    ymm15, ymm13, ymm15
       vmovups  ymm13, ymmword ptr [rbp-0x10D0]
       vpand    ymm15, ymm15, ymm13
       mov      r9, r8
       add      r9, 16
       vpsrld   ymm15, ymm15, 2
       vpcmpeqd ymm4, ymm4, ymm4
       vpgatherdd ymm5, dword ptr [r9+4*xmm15], ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x10F0]
       vpand    ymm15, ymm4, ymm5
       vxorps   ymm1, ymm1, ymm1
       vmovups  ymmword ptr [rbp-0xA90], ymm1
 
G_M000_IG48:                ;; offset=0x206B
       vxorps   ymm1, ymm1, ymm1
       vpcmpeqd ymm1, ymm1, ymm15
       vmovups  ymmword ptr [rbp-0x11C0], ymm1
       vpslld   ymm1, ymm5, 29
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymm3
       vmovups  ymm4, ymmword ptr [rbp-0x11C0]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA90], ymm4
       vmovups  ymmword ptr [rbp-0x11C0], ymm1
       vmovups  ymm4, ymmword ptr [rbp-0x1110]
       vpcmpeqd ymm3, ymm4, ymm15
       vpslld   ymm1, ymm5, 28
       vpand    ymm1, ymm1, ymm2
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x790]
       vblendvps ymm1, ymm1, ymmword ptr [rbp-0xA90], ymm3
       vaddps   ymm1, ymm1, ymmword ptr [rbp-0x11C0]
       vpcmpeqd ymm3, ymm14, ymm15
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymm2
       vpxor    ymm5, ymm5, ymmword ptr [rbp-0x7B0]
       vblendvps ymm3, ymm5, ymmword ptr [rbp-0xA90], ymm3
       vaddps   ymm1, ymm3, ymm1
       vmovups  ymm3, ymmword ptr [rbp-0x870]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x1050]
       vpmulld  ymm0, ymm3, ymm0
       vpsrad   ymm3, ymm0, 15
       vpxor    ymm0, ymm3, ymm0
       vpand    ymm0, ymm0, ymm13
       add      r8, 16
       vpsrld   ymm0, ymm0, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm5, dword ptr [r8+4*xmm0], ymm3
       vmovups  ymm0, ymmword ptr [rbp-0x10F0]
       vpand    ymm0, ymm0, ymm5
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm0
       vpslld   ymm15, ymm5, 29
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x770]
       vblendvps ymm13, ymm15, ymm3, ymm13
       vpcmpeqd ymm4, ymm4, ymm0
       vpslld   ymm15, ymm5, 28
       vpand    ymm15, ymm15, ymm2
       vpxor    ymm15, ymm15, ymmword ptr [rbp-0x790]
       vblendvps ymm4, ymm15, ymm3, ymm4
       vaddps   ymm4, ymm4, ymm13
       vpcmpeqd ymm0, ymm14, ymm0
       vpslld   ymm5, ymm5, 27
       vpand    ymm2, ymm5, ymm2
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x7B0]
       vblendvps ymm0, ymm2, ymm3, ymm0
       vaddps   ymm0, ymm0, ymm4
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x7D0]
       vaddps   ymm0, ymm0, ymm1
 
G_M000_IG49:                ;; offset=0x21AC
       vmovups  ymm1, ymmword ptr [rbp-0x8D0]
       vmovups  ymm13, ymmword ptr [rbp-0x8B0]
       vsubps   ymm1, ymm1, ymm13
       vmovups  ymm15, ymmword ptr [rbp-0x7F0]
       vmulps   ymm1, ymm1, ymm15
       vaddps   ymm1, ymm1, ymm13
       vmovups  ymm2, ymmword ptr [rbp-0x8F0]
       vsubps   ymm0, ymm0, ymm2
       vmulps   ymm0, ymm0, ymm15
       vaddps   ymm0, ymm0, ymm2
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x810]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rbp-0x730], ymm0
       jmp      G_M000_IG53
 
G_M000_IG50:                ;; offset=0x220D
       vmovups  ymmword ptr [rbp-0xE50], ymm13
       vmovups  ymmword ptr [rbp-0xE70], ymm14
       vmovups  ymmword ptr [rbp-0xE90], ymm15
       mov      r8d, dword ptr [rbp-0x180]
       mov      dword ptr [rsp+0x28], r8d
       mov      r8d, dword ptr [rbp-0x17C]
       mov      dword ptr [rsp+0x30], r8d
       vmovss   xmm0, dword ptr [rbp-0x178]
       vmovss   dword ptr [rsp+0x38], xmm0
       lea      r8, [rbp-0xE50]
       lea      r9, [rbp-0xE70]
       lea      rdx, [rbp-0xE90]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2F0]
       lea      rcx, [rbp-0x730]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.CellularKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,int,float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG53
 
G_M000_IG51:                ;; offset=0x2296
       vmovups  ymmword ptr [rbp-0xE50], ymm13
       vmovups  ymmword ptr [rbp-0xE70], ymm14
       vmovups  ymmword ptr [rbp-0xE90], ymm15
       lea      r8, [rbp-0xE50]
       lea      r9, [rbp-0xE70]
       lea      rdx, [rbp-0xE90]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2F0]
       lea      rcx, [rbp-0x730]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x22F6
       lea      rcx, [rbp-0x730]
       vxorps   xmm1, xmm1, xmm1
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG53:                ;; offset=0x231F
       lea      rcx, [rbp-0x1A8]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       test     eax, eax
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG67
 
G_M000_IG54:                ;; offset=0x234C
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      r8, [rbp-0xE50]
       lea      rdx, [rbp-0x1A8]
       lea      rcx, [rbp-0x310]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:ShapeSingle[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG55:                ;; offset=0x238F
       lea      rcx, [rbp-0x330]
       vmovaps  xmm1, xmm10
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x270]
       lea      rdx, [rbp-0x310]
       lea      r8, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG56:                ;; offset=0x23D4
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1D0], ymm0
       mov      rcx, bword ptr [rbp-0x11A0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Amplitude():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0xE50], ymm0
       lea      rdx, [rbp-0xE50]
       lea      rcx, [rbp-0x210]
       lea      r8, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rcx, bword ptr [rbp-0x11A0]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Offset():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x230]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x1D0]
       lea      rdx, [rbp-0x210]
       lea      r8, [rbp-0x230]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       test     r13d, r13d
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       je       G_M000_IG29
 
G_M000_IG57:                ;; offset=0x2487
       mov      rcx, bword ptr [rbp-0x11A0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_Blend():int:this]
       mov      dword ptr [rbp-0xFB4], eax
       mov      rcx, bword ptr [rbp-0x11A0]
       call     [Tedd.FastNoise.Internal.ResolvedLayer:get_BlendFactor():float:this]
       mov      edx, dword ptr [rbp-0xFB4]
       vmovss   dword ptr [rsp+0x20], xmm0
       lea      r8, [rbp-0x170]
       lea      r9, [rbp-0x1D0]
       lea      rcx, [rbp-0x250]
       call     [Tedd.FastNoise.Internal.StackFill:Blend[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],float):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG58:                ;; offset=0x24E6
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x170], ymm0
       inc      r13d
       vmovups  ymm11, ymmword ptr [rbp-0x150]
 
G_M000_IG59:                ;; offset=0x2501
       cmp      dword ptr [rdi+0x08], r13d
       jle      G_M000_IG23
 
G_M000_IG60:                ;; offset=0x250B
       imul     rcx, r13, 80
       lea      rax, bword ptr [rdi+rcx+0x10]
       mov      bword ptr [rbp-0x11A0], rax
       vmovdqu  xmm1, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x188], xmm1
       mov      ecx, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x178], ecx
       mov      ecx, dword ptr [rbp-0x184]
       vbroadcastss ymm1, dword ptr [rax+0x34]
       vmulps   ymm13, ymm9, ymm1
       vmulps   ymm14, ymm11, ymm1
       vmulps   ymm15, ymm12, ymm1
       dec      ecx
       cmp      ecx, 2
       jne      G_M000_IG71
 
G_M000_IG61:                ;; offset=0x2553
       vaddps   ymm1, ymm13, ymm14
       vaddps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vsubps   ymm13, ymm1, ymm13
       vsubps   ymm14, ymm1, ymm14
       vsubps   ymm15, ymm1, ymm15
 
G_M000_IG62:                ;; offset=0x2574
       vmovdqu  xmm1, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x188], xmm1
       mov      ecx, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x178], ecx
       vmovdqu  xmm1, xmmword ptr [rax+0x14]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm1
       vmovdqu  xmm1, xmmword ptr [rax+0x20]
       vmovdqu  xmmword ptr [rbp-0x19C], xmm1
       mov      edx, dword ptr [rax+0x30]
       mov      dword ptr [rbp-0x1AC], edx
       mov      r8d, dword ptr [rax+0x48]
       mov      dword ptr [rbp-0x1B0], r8d
       vmovups  ymmword ptr [rbp-0x290], ymm13
       vmovups  ymmword ptr [rbp-0x2B0], ymm14
       vmovups  ymmword ptr [rbp-0x2D0], ymm15
       vmovss   xmm10, dword ptr [rax+0x4C]
       cmp      dword ptr [rbp-0x1A8], 0
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x25DD
       cmp      r8d, 1
       jg       G_M000_IG30
 
G_M000_IG64:                ;; offset=0x25E7
       vpbroadcastd ymm0, dword ptr [rbp-0x1AC]
       vmovups  ymmword ptr [rbp-0x2F0], ymm0
       mov      r8d, dword ptr [rbp-0x188]
       cmp      r8d, 5
       ja       G_M000_IG52
 
G_M000_IG65:                ;; offset=0x2609
       mov      r8d, r8d
       lea      r9, [reloc @RWD320]
       mov      r9d, dword ptr [r9+4*r8]
       lea      rdx, G_M000_IG02
       add      r9, rdx
       jmp      r9
 
G_M000_IG66:                ;; offset=0x2624
       vmovups  ymmword ptr [rbp-0xE50], ymm13
       vmovups  ymmword ptr [rbp-0xE70], ymm14
       vmovups  ymmword ptr [rbp-0xE90], ymm15
       lea      r8, [rbp-0xE50]
       lea      r9, [rbp-0xE70]
       lea      rdx, [rbp-0xE90]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2F0]
       lea      rcx, [rbp-0x730]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Internal.Kernels.ValueKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm12, ymm12, xmm13
       jmp      G_M000_IG53
 
G_M000_IG67:                ;; offset=0x2687
       vmovups  ymm1, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x310], ymm1
       jmp      G_M000_IG55
 
G_M000_IG68:                ;; offset=0x269C
       mov      dword ptr [rbp-0xF4], r8d
       cmp      r8d, dword ptr [rbp-0xE4]
       jl       G_M000_IG06
 
G_M000_IG69:                ;; offset=0x26B0
       mov      ecx, dword ptr [rbp-0xEC]
       inc      ecx
       lea      eax, [r14+r15]
       cmp      eax, ecx
       mov      r10d, dword ptr [rbp-0xE4]
       mov      r11d, dword ptr [rbp-0xE8]
       jle      G_M000_IG05
 
G_M000_IG70:                ;; offset=0x26D2
       mov      eax, ecx
       cdq      
       idiv     edx:eax, r11d
       mov      r8d, edx
       mov      eax, ecx
       cdq      
       idiv     edx:eax, r11d
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, r8d
       vmulss   xmm0, xmm0, xmm6
       vaddss   xmm7, xmm0, dword ptr [rsi+0x04]
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, eax
       vmulss   xmm0, xmm0, xmm6
       vaddss   xmm8, xmm0, dword ptr [rsi+0x08]
       mov      dword ptr [rbp-0xEC], ecx
       mov      eax, ecx
       imul     eax, r10d
       mov      dword ptr [rbp-0xF0], eax
       xor      edx, edx
       xor      r8d, r8d
       test     r12, r12
       je       G_M000_IG68
       jmp      G_M000_IG26
 
G_M000_IG71:                ;; offset=0x2729
       cmp      ecx, 2
       ja       G_M000_IG62
       mov      ecx, ecx
       lea      rdx, [reloc @RWD344]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG72:                ;; offset=0x274A
       vaddps   ymm1, ymm13, ymm14
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD384]
       vmulps   ymm15, ymm15, ymmword ptr [reloc @RWD416]
       vsubps   ymm2, ymm0, ymm15
       vaddps   ymm13, ymm2, ymm13
       vaddps   ymm0, ymm14, ymm0
       vsubps   ymm14, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD416]
       vaddps   ymm15, ymm1, ymm15
       jmp      G_M000_IG62
 
G_M000_IG73:                ;; offset=0x2784
       vaddps   ymm1, ymm13, ymm15
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD384]
       vmulps   ymm14, ymm14, ymmword ptr [reloc @RWD416]
       vsubps   ymm2, ymm0, ymm14
       vaddps   ymm13, ymm2, ymm13
       vsubps   ymm0, ymm0, ymm14
       vaddps   ymm15, ymm0, ymm15
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD416]
       vaddps   ymm14, ymm1, ymm14
       jmp      G_M000_IG62
 
G_M000_IG74:                ;; offset=0x27BF
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	3F000000h		;       0.5
RWD04  	dd	40000000h		;         2
RWD08  	dd	C0000000h		;        -2
RWD12  	dd	3F800000h		;         1
RWD16  	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD32  	dq	0000000100000000h, 0000000300000002h, 0000000500000004h, 0000000700000006h
RWD64  	dd	4F000000h		; 2.14748e+09
RWD68  	dd	7FFFFFFFh		;       nan
RWD72  	dd	1DDE90C9h		; 5.89126e-21
RWD76  	dd	43C42E4Dh		;   392.362
RWD80  	dd	668B6E2Fh		; 3.29221e+23
RWD84  	dd	00000000h, 00000000h, 00000000h
RWD96  	dq	3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h
RWD128 	dq	87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah
RWD160 	dq	CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh
RWD192 	dd	27D4EB2Dh		; 5.90968e-15
RWD196 	dd	30000000h		; 4.65661e-10
RWD200 	dd	3E97B426h		;  0.296296
RWD204 	dd	40C00000h		;         6
RWD208 	dd	41700000h		;        15
RWD212 	dd	41200000h		;        10
RWD216 	dd	000000FCh		; 3.53127e-43
RWD220 	dd	00000003h		; 4.2039e-45
RWD224 	dd	80000000h		;        -0
RWD228 	dd	00000001h		; 1.4013e-45
RWD232 	dd	00000002h		; 2.8026e-45
RWD236 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD256 	dq	3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h
RWD288 	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD320 	dd	000021C7h ; case G_M000_IG51
       	dd	00002227h ; case G_M000_IG52
       	dd	0000213Eh ; case G_M000_IG50
       	dd	00001575h ; case G_M000_IG41
       	dd	000009F3h ; case G_M000_IG32
       	dd	00002555h ; case G_M000_IG66
RWD344 	dd	0000267Bh ; case G_M000_IG72
       	dd	000026B5h ; case G_M000_IG73
       	dd	00002484h ; case G_M000_IG61
RWD356 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD384 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD416 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah

; Total bytes of code 10181


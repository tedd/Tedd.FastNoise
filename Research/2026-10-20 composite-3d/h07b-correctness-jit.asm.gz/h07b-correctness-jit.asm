; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0x98], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0043
       mov      dword ptr [rbp-0x80], 0x3E8
       call     [Tedd.FastNoise.Internal.ScalarOps:get_Count():int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x40], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      eax, dword ptr [rbp+0x28]
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG14
 
G_M000_IG03:                ;; offset=0x0087
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x50], edx
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x50]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x54]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x5C], xmm0
       mov      eax, dword ptr [rbp-0x4C]
       imul     eax, dword ptr [rbp-0x40]
       mov      dword ptr [rbp-0x60], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x64], eax
       jmp      G_M000_IG07
 
G_M000_IG04:                ;; offset=0x00F1
       mov      rcx, 0x7FFC66218CA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x84], xmm0
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Ramp(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       vmovss   xmm0, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x70], xmm0
       mov      rcx, gword ptr [rbp+0x10]
       vmovss   xmm1, dword ptr [rbp-0x68]
       vmovss   xmm2, dword ptr [rbp-0x6C]
       vmovss   xmm3, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovss   dword ptr [rbp-0x9C], xmm0
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x0181
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG06:                ;; offset=0x018D
       vmovss   xmm0, dword ptr [rbp-0x9C]
       lea      rdx, [rbp-0x98]
       mov      eax, dword ptr [rbp-0x60]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Store(float,System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG07:                ;; offset=0x01B5
       mov      eax, dword ptr [rbp-0x80]
       dec      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      dword ptr [rbp-0x80], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01C3
       lea      rcx, [rbp-0x80]
       mov      edx, 183
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x01D1
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp-0x40]
       jle      G_M000_IG04
       jmp      G_M000_IG11
 
G_M000_IG10:                ;; offset=0x01E5
       mov      rcx, 0x7FFC66218CAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       add      eax, dword ptr [rbp-0x64]
       mov      rcx, bword ptr [rbp+0x20]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG18
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, dword ptr [rbp-0x64]
       mov      ecx, ecx
       lea      rax, bword ptr [rax+4*rcx]
       mov      bword ptr [rbp-0x78], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0xA0], xmm0
       vmovss   xmm1, dword ptr [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0x10]
       vmovss   xmm2, dword ptr [rbp-0x58]
       vmovss   xmm3, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      rax, bword ptr [rbp-0x78]
       vmovss   dword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x64]
       inc      eax
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG11:                ;; offset=0x026E
       mov      eax, dword ptr [rbp-0x80]
       dec      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      dword ptr [rbp-0x80], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x027C
       lea      rcx, [rbp-0x80]
       mov      edx, 233
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x028A
       mov      eax, dword ptr [rbp-0x64]
       cmp      eax, dword ptr [rbp-0x40]
       jl       G_M000_IG10
       mov      rcx, 0x7FFC66218CB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG14:                ;; offset=0x02AD
       mov      eax, dword ptr [rbp-0x80]
       dec      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      dword ptr [rbp-0x80], 0
       jg       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02BB
       lea      rcx, [rbp-0x80]
       mov      edx, 244
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG16:                ;; offset=0x02C9
       mov      eax, dword ptr [rbp+0x28]
       add      eax, dword ptr [rbp+0x30]
       cmp      dword ptr [rbp-0x4C], eax
       jl       G_M000_IG03
       mov      rcx, 0x7FFC66218CB4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG17:                ;; offset=0x02E8
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x02F1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 759

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3(Tedd.FastNoise.Procedural.CompiledStack3D,Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int,bool) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 800
       lea      rbp, [rsp+0x320]
       xor      eax, eax
       mov      qword ptr [rbp-0x2E8], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -672
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0053
       mov      dword ptr [rbp-0x188], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x40], rax
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG03
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x007C
       mov      rcx, 0x7FFC6636B9C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG04:                ;; offset=0x009A
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x48], rax
       mov      dword ptr [rbp-0x4C], 8
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG19
 
G_M000_IG05:                ;; offset=0x00E0
       mov      eax, dword ptr [rbp-0x5C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x60], edx
       mov      eax, dword ptr [rbp-0x5C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x64], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x60]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x68], xmm0
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      eax, dword ptr [rbp-0x5C]
       imul     eax, dword ptr [rbp-0x50]
       mov      dword ptr [rbp-0x70], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x74], eax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG16
       jmp      G_M000_IG11
 
G_M000_IG06:                ;; offset=0x0155
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x18C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x18C]
       lea      rcx, [rbp-0xB0]
       vmovss   xmm2, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.VectorOps:Ramp(float,float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x110]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x178], rax
       mov      rcx, gword ptr [rbp-0x178]
       mov      rdx, 0x7FFC6636B9C8
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x1F8], rax
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1F0], ymm0
       mov      rax, gword ptr [rbp-0x1F8]
       lea      r8, [rbp-0x1B0]
       lea      r9, [rbp-0x1D0]
       lea      rcx, [rbp-0x1F0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x1F8]
       call     [rax+0x18]System.Func`4[System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]]:Invoke(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x250], ymm0
       lea      rcx, [rbp-0x230]
       lea      rdx, [rbp-0x250]
       call     [System.Numerics.Vector:EqualsAll[float](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):bool]
       test     eax, eax
       jne      G_M000_IG08
       mov      rcx, 0x7FFC6636BAD0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x150]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x170]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
 
G_M000_IG07:                ;; offset=0x02C3
       vmovups  ymmword ptr [rbp-0x270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2B0], ymm0
       lea      r8, [rbp-0x270]
       lea      r9, [rbp-0x290]
       lea      rax, [rbp-0x2B0]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0xD0]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3WideNaN(Tedd.FastNoise.Internal.ResolvedLayer[],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG08:                ;; offset=0x0316
       mov      rcx, 0x7FFC6636BAD4
       call     CORINFO_HELP_COUNTPROFILE32
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x2D0], ymm0
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG09:                ;; offset=0x0339
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG10:                ;; offset=0x0345
       lea      rcx, [rbp-0x2D0]
       lea      rdx, [rbp-0x2E0]
       mov      eax, dword ptr [rbp-0x70]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x74]
       add      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG11:                ;; offset=0x036C
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0383
       lea      rcx, [rbp-0x188]
       mov      edx, 220
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x0394
       mov      eax, dword ptr [rbp-0x74]
       add      eax, dword ptr [rbp-0x4C]
       cmp      eax, dword ptr [rbp-0x50]
       jle      G_M000_IG06
       mov      rcx, 0x7FFC6636BAD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG16
 
G_M000_IG14:                ;; offset=0x03B7
       mov      rax, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, gword ptr [rbp-0x180]
       mov      rdx, 0x7FFC6636BAE0
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x2EC], xmm0
       mov      rax, gword ptr [rbp-0x2E8]
       vmovss   xmm1, dword ptr [rbp-0x2EC]
       vmovss   xmm2, dword ptr [rbp-0x68]
       vmovss   xmm3, dword ptr [rbp-0x6C]
       mov      rcx, gword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x2E8]
       call     [rax+0x18]System.Func`4[float,float,float,float]:Invoke(float,float,float):float:this
       vmovss   dword ptr [rbp-0xD4], xmm0
       vmovss   xmm0, dword ptr [rbp-0xD4]
       call     [System.Single:IsNaN(float):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rcx, 0x7FFC6636BBE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x2F0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x2F0]
       mov      rcx, gword ptr [rbp+0x18]
       vmovss   xmm2, dword ptr [rbp-0x68]
       vmovss   xmm3, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3ScalarNaN(Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovss   dword ptr [rbp-0xD4], xmm0
 
G_M000_IG15:                ;; offset=0x04A2
       mov      rcx, 0x7FFC6636BBEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x70]
       add      eax, dword ptr [rbp-0x74]
       mov      rcx, bword ptr [rbp+0x28]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG23
       mov      rax, bword ptr [rbp+0x28]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x70]
       add      ecx, dword ptr [rbp-0x74]
       mov      ecx, ecx
       vmovss   xmm0, dword ptr [rbp-0xD4]
       vmovss   dword ptr [rax+4*rcx], xmm0
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG16:                ;; offset=0x04E8
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x04FF
       lea      rcx, [rbp-0x188]
       mov      edx, 309
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG18:                ;; offset=0x0510
       mov      eax, dword ptr [rbp-0x74]
       cmp      eax, dword ptr [rbp-0x50]
       jl       G_M000_IG14
       mov      rcx, 0x7FFC6636BBF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG19:                ;; offset=0x0533
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x054A
       lea      rcx, [rbp-0x188]
       mov      edx, 320
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG21:                ;; offset=0x055B
       mov      eax, dword ptr [rbp+0x30]
       add      eax, dword ptr [rbp+0x38]
       cmp      dword ptr [rbp-0x5C], eax
       jl       G_M000_IG05
       mov      rcx, 0x7FFC6636BBF4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG22:                ;; offset=0x057A
       add      rsp, 800
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x0583
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1417

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 464
       lea      rbp, [rsp+0x1D0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1A0], xmm4
       mov      rax, -336
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x100], 0x3E8
       call     [Tedd.FastNoise.Internal.VectorOps:get_Count():int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x40], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      eax, dword ptr [rbp+0x28]
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG14
 
G_M000_IG03:                ;; offset=0x0099
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x50], edx
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x50]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x54]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x5C], xmm0
       mov      eax, dword ptr [rbp-0x4C]
       imul     eax, dword ptr [rbp-0x40]
       mov      dword ptr [rbp-0x60], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x64], eax
       jmp      G_M000_IG07
 
G_M000_IG04:                ;; offset=0x0103
       mov      rcx, 0x7FFC6636C998
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x104], xmm0
       vmovss   xmm1, dword ptr [rbp-0x104]
       lea      rcx, [rbp-0x90]
       vmovss   xmm2, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.VectorOps:Ramp(float,float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB0]
       vmovss   xmm1, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xD0]
       vmovss   xmm1, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x170], ymm0
       lea      r8, [rbp-0x130]
       lea      r9, [rbp-0x150]
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0xF0]
       mov      rdx, gword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x190], ymm0
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x01E3
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG06:                ;; offset=0x01EF
       lea      rcx, [rbp-0x190]
       lea      rdx, [rbp-0x1A0]
       mov      eax, dword ptr [rbp-0x60]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG07:                ;; offset=0x0216
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x022D
       lea      rcx, [rbp-0x100]
       mov      edx, 183
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x023E
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp-0x40]
       jle      G_M000_IG04
       jmp      G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0252
       mov      rcx, 0x7FFC6636C99C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       add      eax, dword ptr [rbp-0x64]
       mov      rcx, bword ptr [rbp+0x20]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG18
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, dword ptr [rbp-0x64]
       mov      ecx, ecx
       lea      rax, bword ptr [rax+4*rcx]
       mov      bword ptr [rbp-0xF8], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x1A4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A4]
       mov      rcx, gword ptr [rbp+0x10]
       vmovss   xmm2, dword ptr [rbp-0x58]
       vmovss   xmm3, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      rax, bword ptr [rbp-0xF8]
       vmovss   dword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x64]
       inc      eax
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG11:                ;; offset=0x02E1
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x02F8
       lea      rcx, [rbp-0x100]
       mov      edx, 233
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x0309
       mov      eax, dword ptr [rbp-0x64]
       cmp      eax, dword ptr [rbp-0x40]
       jl       G_M000_IG10
       mov      rcx, 0x7FFC6636C9A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG14:                ;; offset=0x032C
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0343
       lea      rcx, [rbp-0x100]
       mov      edx, 244
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG16:                ;; offset=0x0354
       mov      eax, dword ptr [rbp+0x28]
       add      eax, dword ptr [rbp+0x30]
       cmp      dword ptr [rbp-0x4C], eax
       jl       G_M000_IG03
       mov      rcx, 0x7FFC6636C9A4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG17:                ;; offset=0x0373
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x037C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 898

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3(Tedd.FastNoise.Procedural.CompiledStack3D,Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int,bool) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 800
       lea      rbp, [rsp+0x320]
       xor      eax, eax
       mov      qword ptr [rbp-0x2E8], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -672
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0053
       mov      dword ptr [rbp-0x188], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x40], rax
       movzx    rax, byte  ptr [rbp+0x40]
       test     eax, eax
       jne      SHORT G_M000_IG03
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
       jmp      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x007C
       mov      rcx, 0x7FFC6636B9C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG04:                ;; offset=0x009A
       mov      rax, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0x48], rax
       mov      dword ptr [rbp-0x4C], 8
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rbp-0x5C], eax
       jmp      G_M000_IG19
 
G_M000_IG05:                ;; offset=0x00E0
       mov      eax, dword ptr [rbp-0x5C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x60], edx
       mov      eax, dword ptr [rbp-0x5C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x54]
       mov      dword ptr [rbp-0x64], eax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x60]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x68], xmm0
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      eax, dword ptr [rbp-0x5C]
       imul     eax, dword ptr [rbp-0x50]
       mov      dword ptr [rbp-0x70], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x74], eax
       cmp      gword ptr [rbp-0x48], 0
       je       G_M000_IG16
       jmp      G_M000_IG11
 
G_M000_IG06:                ;; offset=0x0155
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x18C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x18C]
       lea      rcx, [rbp-0xB0]
       vmovss   xmm2, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.VectorOps:Ramp(float,float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x110]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       mov      rax, gword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x178], rax
       mov      rcx, gword ptr [rbp-0x178]
       mov      rdx, 0x7FFC6636B9C8
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x1F8], rax
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1F0], ymm0
       mov      rax, gword ptr [rbp-0x1F8]
       lea      r8, [rbp-0x1B0]
       lea      r9, [rbp-0x1D0]
       lea      rcx, [rbp-0x1F0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x1F8]
       call     [rax+0x18]System.Func`4[System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]]:Invoke(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x250], ymm0
       lea      rcx, [rbp-0x230]
       lea      rdx, [rbp-0x250]
       call     [System.Numerics.Vector:EqualsAll[float](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):bool]
       test     eax, eax
       jne      G_M000_IG08
       mov      rcx, 0x7FFC6636BAD0
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x150]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x170]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
 
G_M000_IG07:                ;; offset=0x02C3
       vmovups  ymmword ptr [rbp-0x270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2B0], ymm0
       lea      r8, [rbp-0x270]
       lea      r9, [rbp-0x290]
       lea      rax, [rbp-0x2B0]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0xD0]
       mov      rdx, gword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3WideNaN(Tedd.FastNoise.Internal.ResolvedLayer[],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG08:                ;; offset=0x0316
       mov      rcx, 0x7FFC6636BAD4
       call     CORINFO_HELP_COUNTPROFILE32
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x2D0], ymm0
       mov      rax, bword ptr [rbp+0x28]
 
G_M000_IG09:                ;; offset=0x0339
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG10:                ;; offset=0x0345
       lea      rcx, [rbp-0x2D0]
       lea      rdx, [rbp-0x2E0]
       mov      eax, dword ptr [rbp-0x70]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x74]
       add      eax, dword ptr [rbp-0x4C]
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG11:                ;; offset=0x036C
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0383
       lea      rcx, [rbp-0x188]
       mov      edx, 220
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x0394
       mov      eax, dword ptr [rbp-0x74]
       add      eax, dword ptr [rbp-0x4C]
       cmp      eax, dword ptr [rbp-0x50]
       jle      G_M000_IG06
       mov      rcx, 0x7FFC6636BAD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG16
 
G_M000_IG14:                ;; offset=0x03B7
       mov      rax, gword ptr [rbp-0x40]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, gword ptr [rbp-0x180]
       mov      rdx, 0x7FFC6636BAE0
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x2EC], xmm0
       mov      rax, gword ptr [rbp-0x2E8]
       vmovss   xmm1, dword ptr [rbp-0x2EC]
       vmovss   xmm2, dword ptr [rbp-0x68]
       vmovss   xmm3, dword ptr [rbp-0x6C]
       mov      rcx, gword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x2E8]
       call     [rax+0x18]System.Func`4[float,float,float,float]:Invoke(float,float,float):float:this
       vmovss   dword ptr [rbp-0xD4], xmm0
       vmovss   xmm0, dword ptr [rbp-0xD4]
       call     [System.Single:IsNaN(float):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rcx, 0x7FFC6636BBE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x20]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x74]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x58]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x2F0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x2F0]
       mov      rcx, gword ptr [rbp+0x18]
       vmovss   xmm2, dword ptr [rbp-0x68]
       vmovss   xmm3, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3ScalarNaN(Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovss   dword ptr [rbp-0xD4], xmm0
 
G_M000_IG15:                ;; offset=0x04A2
       mov      rcx, 0x7FFC6636BBEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x70]
       add      eax, dword ptr [rbp-0x74]
       mov      rcx, bword ptr [rbp+0x28]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG23
       mov      rax, bword ptr [rbp+0x28]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x70]
       add      ecx, dword ptr [rbp-0x74]
       mov      ecx, ecx
       vmovss   xmm0, dword ptr [rbp-0xD4]
       vmovss   dword ptr [rax+4*rcx], xmm0
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG16:                ;; offset=0x04E8
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x04FF
       lea      rcx, [rbp-0x188]
       mov      edx, 309
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG18:                ;; offset=0x0510
       mov      eax, dword ptr [rbp-0x74]
       cmp      eax, dword ptr [rbp-0x50]
       jl       G_M000_IG14
       mov      rcx, 0x7FFC6636BBF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x5C]
       inc      eax
       mov      dword ptr [rbp-0x5C], eax
 
G_M000_IG19:                ;; offset=0x0533
       mov      eax, dword ptr [rbp-0x188]
       dec      eax
       mov      dword ptr [rbp-0x188], eax
       cmp      dword ptr [rbp-0x188], 0
       jg       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x054A
       lea      rcx, [rbp-0x188]
       mov      edx, 320
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG21:                ;; offset=0x055B
       mov      eax, dword ptr [rbp+0x30]
       add      eax, dword ptr [rbp+0x38]
       cmp      dword ptr [rbp-0x5C], eax
       jl       G_M000_IG05
       mov      rcx, 0x7FFC6636BBF4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG22:                ;; offset=0x057A
       add      rsp, 800
       pop      rbp
       ret      
 
G_M000_IG23:                ;; offset=0x0583
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1417

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 464
       lea      rbp, [rsp+0x1D0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1A0], xmm4
       mov      rax, -336
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x100], 0x3E8
       call     [Tedd.FastNoise.Internal.VectorOps:get_Count():int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x40], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      eax, dword ptr [rbp+0x28]
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG14
 
G_M000_IG03:                ;; offset=0x0099
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x50], edx
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x50]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x54]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x5C], xmm0
       mov      eax, dword ptr [rbp-0x4C]
       imul     eax, dword ptr [rbp-0x40]
       mov      dword ptr [rbp-0x60], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x64], eax
       jmp      G_M000_IG07
 
G_M000_IG04:                ;; offset=0x0103
       mov      rcx, 0x7FFC6636C998
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x104], xmm0
       vmovss   xmm1, dword ptr [rbp-0x104]
       lea      rcx, [rbp-0x90]
       vmovss   xmm2, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.VectorOps:Ramp(float,float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB0]
       vmovss   xmm1, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xD0]
       vmovss   xmm1, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x170], ymm0
       lea      r8, [rbp-0x130]
       lea      r9, [rbp-0x150]
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x20], rax
       lea      rcx, [rbp-0xF0]
       mov      rdx, gword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](Tedd.FastNoise.Internal.ResolvedLayer[],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x190], ymm0
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x01E3
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG06:                ;; offset=0x01EF
       lea      rcx, [rbp-0x190]
       lea      rdx, [rbp-0x1A0]
       mov      eax, dword ptr [rbp-0x60]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.VectorOps:Store(System.Numerics.Vector`1[float],System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG07:                ;; offset=0x0216
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x022D
       lea      rcx, [rbp-0x100]
       mov      edx, 183
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x023E
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp-0x40]
       jle      G_M000_IG04
       jmp      G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0252
       mov      rcx, 0x7FFC6636C99C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       add      eax, dword ptr [rbp-0x64]
       mov      rcx, bword ptr [rbp+0x20]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG18
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, dword ptr [rbp-0x64]
       mov      ecx, ecx
       lea      rax, bword ptr [rax+4*rcx]
       mov      bword ptr [rbp-0xF8], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x1A4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A4]
       mov      rcx, gword ptr [rbp+0x10]
       vmovss   xmm2, dword ptr [rbp-0x58]
       vmovss   xmm3, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      rax, bword ptr [rbp-0xF8]
       vmovss   dword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x64]
       inc      eax
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG11:                ;; offset=0x02E1
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x02F8
       lea      rcx, [rbp-0x100]
       mov      edx, 233
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x0309
       mov      eax, dword ptr [rbp-0x64]
       cmp      eax, dword ptr [rbp-0x40]
       jl       G_M000_IG10
       mov      rcx, 0x7FFC6636C9A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG14:                ;; offset=0x032C
       mov      eax, dword ptr [rbp-0x100]
       dec      eax
       mov      dword ptr [rbp-0x100], eax
       cmp      dword ptr [rbp-0x100], 0
       jg       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0343
       lea      rcx, [rbp-0x100]
       mov      edx, 244
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG16:                ;; offset=0x0354
       mov      eax, dword ptr [rbp+0x28]
       add      eax, dword ptr [rbp+0x30]
       cmp      dword ptr [rbp-0x4C], eax
       jl       G_M000_IG03
       mov      rcx, 0x7FFC6636C9A4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG17:                ;; offset=0x0373
       add      rsp, 464
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x037C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 898

; Assembly listing for method Tedd.FastNoise.Internal.StackFill:Rows3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],byref,System.Span`1[float],int,int) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0x98], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0043
       mov      dword ptr [rbp-0x80], 0x3E8
       call     [Tedd.FastNoise.Internal.ScalarOps:get_Count():int]
       mov      dword ptr [rbp-0x3C], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Width():int:this]
       mov      dword ptr [rbp-0x40], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Height():int:this]
       mov      dword ptr [rbp-0x44], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_Step():float:this]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      eax, dword ptr [rbp+0x28]
       mov      dword ptr [rbp-0x4C], eax
       jmp      G_M000_IG14
 
G_M000_IG03:                ;; offset=0x0087
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x50], edx
       mov      eax, dword ptr [rbp-0x4C]
       cdq      
       idiv     edx:eax, dword ptr [rbp-0x44]
       mov      dword ptr [rbp-0x54], eax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginY():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x50]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x58], xmm0
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginZ():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x54]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x5C], xmm0
       mov      eax, dword ptr [rbp-0x4C]
       imul     eax, dword ptr [rbp-0x40]
       mov      dword ptr [rbp-0x60], eax
       xor      eax, eax
       mov      dword ptr [rbp-0x64], eax
       jmp      G_M000_IG07
 
G_M000_IG04:                ;; offset=0x00F1
       mov      rcx, 0x7FFC66218CA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0x84], xmm0
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Ramp(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       vmovss   xmm0, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x70], xmm0
       mov      rcx, gword ptr [rbp+0x10]
       vmovss   xmm1, dword ptr [rbp-0x68]
       vmovss   xmm2, dword ptr [rbp-0x6C]
       vmovss   xmm3, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       vmovss   dword ptr [rbp-0x9C], xmm0
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG05:                ;; offset=0x0181
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
 
G_M000_IG06:                ;; offset=0x018D
       vmovss   xmm0, dword ptr [rbp-0x9C]
       lea      rdx, [rbp-0x98]
       mov      eax, dword ptr [rbp-0x60]
       mov      r8d, eax
       add      r8d, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Store(float,System.Span`1[float],int)]
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG07:                ;; offset=0x01B5
       mov      eax, dword ptr [rbp-0x80]
       dec      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      dword ptr [rbp-0x80], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01C3
       lea      rcx, [rbp-0x80]
       mov      edx, 183
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x01D1
       mov      eax, dword ptr [rbp-0x64]
       add      eax, dword ptr [rbp-0x3C]
       cmp      eax, dword ptr [rbp-0x40]
       jle      G_M000_IG04
       jmp      G_M000_IG11
 
G_M000_IG10:                ;; offset=0x01E5
       mov      rcx, 0x7FFC66218CAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x60]
       add      eax, dword ptr [rbp-0x64]
       mov      rcx, bword ptr [rbp+0x20]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG18
       mov      rax, bword ptr [rbp+0x20]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x60]
       add      ecx, dword ptr [rbp-0x64]
       mov      ecx, ecx
       lea      rax, bword ptr [rax+4*rcx]
       mov      bword ptr [rbp-0x78], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.GridRegion3D:get_OriginX():float:this]
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, dword ptr [rbp-0x64]
       vmulss   xmm1, xmm1, dword ptr [rbp-0x48]
       vaddss   xmm0, xmm0, xmm1
       vmovss   dword ptr [rbp-0xA0], xmm0
       vmovss   xmm1, dword ptr [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0x10]
       vmovss   xmm2, dword ptr [rbp-0x58]
       vmovss   xmm3, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.StackFill:Evaluate3[Tedd.FastNoise.Internal.ScalarOps,float,int](Tedd.FastNoise.Internal.ResolvedLayer[],float,float,float):float]
       mov      rax, bword ptr [rbp-0x78]
       vmovss   dword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x64]
       inc      eax
       mov      dword ptr [rbp-0x64], eax
 
G_M000_IG11:                ;; offset=0x026E
       mov      eax, dword ptr [rbp-0x80]
       dec      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      dword ptr [rbp-0x80], 0
       jg       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x027C
       lea      rcx, [rbp-0x80]
       mov      edx, 233
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG13:                ;; offset=0x028A
       mov      eax, dword ptr [rbp-0x64]
       cmp      eax, dword ptr [rbp-0x40]
       jl       G_M000_IG10
       mov      rcx, 0x7FFC66218CB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       inc      eax
       mov      dword ptr [rbp-0x4C], eax
 
G_M000_IG14:                ;; offset=0x02AD
       mov      eax, dword ptr [rbp-0x80]
       dec      eax
       mov      dword ptr [rbp-0x80], eax
       cmp      dword ptr [rbp-0x80], 0
       jg       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02BB
       lea      rcx, [rbp-0x80]
       mov      edx, 244
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG16:                ;; offset=0x02C9
       mov      eax, dword ptr [rbp+0x28]
       add      eax, dword ptr [rbp+0x30]
       cmp      dword ptr [rbp-0x4C], eax
       jl       G_M000_IG03
       mov      rcx, 0x7FFC66218CB4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG17:                ;; offset=0x02E8
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG18:                ;; offset=0x02F1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 759


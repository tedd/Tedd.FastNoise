; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC658F2438
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC658F243C
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:Sample3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:Fractal3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC658FA3B8
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC658FA3BC
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      dword ptr [rbp+0x10], ecx
       vmovss   dword ptr [rbp+0x18], xmm1
       vmovss   dword ptr [rbp+0x20], xmm2
       vmovss   dword ptr [rbp+0x28], xmm3
 
G_M000_IG02:                ;; offset=0x0046
       mov      dword ptr [rbp-0x120], 0x3E8
       vmovss   xmm0, dword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x3C], eax
       vmovss   xmm0, dword ptr [rbp+0x20]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x40], eax
       vmovss   xmm0, dword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x124], xmm0
       vmovss   xmm1, dword ptr [rbp-0x124]
       vmovss   xmm0, dword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x128], xmm0
       vmovss   xmm1, dword ptr [rbp-0x128]
       vmovss   xmm0, dword ptr [rbp+0x20]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x4C], xmm0
       mov      ecx, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x12C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x12C]
       vmovss   xmm0, dword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x50], xmm0
       mov      ecx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x54], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x130], xmm0
       vmovss   xmm0, dword ptr [rbp-0x130]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x134], xmm0
       vmovss   xmm0, dword ptr [rbp-0x134]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x138], eax
       mov      ecx, dword ptr [rbp-0x138]
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x58], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x13C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x13C]
       vmovss   xmm1, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x140], xmm0
       vmovss   xmm0, dword ptr [rbp-0x140]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x144], eax
       mov      ecx, dword ptr [rbp-0x144]
 
G_M000_IG03:                ;; offset=0x01A5
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x5C], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x148], xmm0
       vmovss   xmm0, dword ptr [rbp-0x148]
       vmovss   xmm1, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x14C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x14C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x150], eax
       mov      ecx, dword ptr [rbp-0x150]
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x60], eax
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xC4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x154], xmm0
       vmovss   xmm1, dword ptr [rbp-0x154]
       vmovss   xmm0, dword ptr [rbp-0xC4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x64], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xC8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x158], xmm0
       vmovss   xmm1, dword ptr [rbp-0x158]
       vmovss   xmm0, dword ptr [rbp-0xC8]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       mov      ecx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xCC], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x15C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x15C]
       vmovss   xmm0, dword ptr [rbp-0xCC]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      ecx, dword ptr [rbp-0x3C]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      ecx, dword ptr [rbp-0x40]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
       mov      dword ptr [rbp-0x40], eax
       mov      ecx, dword ptr [rbp-0x44]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
 
G_M000_IG04:                ;; offset=0x02F5
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x70], eax
       mov      ecx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x74], eax
       mov      ecx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x78], eax
       vxorps   xmm0, xmm0, xmm0
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x7C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x7C]
       vmovss   dword ptr [rbp-0x80], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD04]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0xD0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x160], xmm0
       vmovss   xmm1, dword ptr [rbp-0x160]
       vmovss   xmm0, dword ptr [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0xD4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       vmovss   xmm1, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xD8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       vmovss   xmm1, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x164], xmm0
       vmovss   xmm1, dword ptr [rbp-0x164]
       vmovss   xmm0, dword ptr [rbp-0xD8]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x168], xmm0
       vmovss   xmm1, dword ptr [rbp-0x168]
       vmovss   xmm0, dword ptr [rbp-0xD4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x84], xmm0
       xor      eax, eax
       mov      dword ptr [rbp-0x88], eax
 
G_M000_IG05:                ;; offset=0x03FB
       mov      eax, dword ptr [rbp-0x120]
       dec      eax
       mov      dword ptr [rbp-0x120], eax
       cmp      dword ptr [rbp-0x120], 0
       jg       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0412
       lea      rcx, [rbp-0x120]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG07:                ;; offset=0x0423
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
       mov      dword ptr [rbp-0x8C], eax
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x84]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xDC], xmm0
       vmovss   xmm0, dword ptr [rbp-0xDC]
       vmovss   xmm1, dword ptr [rbp-0xDC]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xE0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       vmovss   dword ptr [rsp+0x20], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       vmovss   dword ptr [rsp+0x28], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       vmovss   dword ptr [rsp+0x30], xmm0
       mov      ecx, dword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x3C]
       mov      r8d, dword ptr [rbp-0x40]
       mov      r9d, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int,int,int,float,float,float):float]
       vmovss   dword ptr [rbp-0x16C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x16C]
       vmovss   xmm0, dword ptr [rbp-0xE0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x90], xmm0
       mov      ecx, dword ptr [rbp-0x8C]
       vmovss   xmm1, dword ptr [rbp-0x90]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x170], xmm0
       vmovss   xmm1, dword ptr [rbp-0x170]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x80], xmm0
       vmovss   xmm0, dword ptr [rbp-0x64]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0xE4], eax
       vmovss   xmm0, dword ptr [rbp-0x64]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x174], eax
       mov      edx, dword ptr [rbp-0x174]
       mov      ecx, dword ptr [rbp-0xE4]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x94], eax
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0xE8], eax
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
 
G_M000_IG08:                ;; offset=0x0582
       mov      dword ptr [rbp-0xEC], eax
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x178], eax
       mov      edx, dword ptr [rbp-0x178]
       mov      ecx, dword ptr [rbp-0xEC]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       mov      ecx, dword ptr [rbp-0xE8]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x98], eax
       mov      ecx, dword ptr [rbp-0x94]
       mov      edx, dword ptr [rbp-0x98]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x9C], eax
       mov      ecx, dword ptr [rbp-0x98]
       vmovss   xmm1, dword ptr [rbp-0x68]
       vmovss   xmm2, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x180], xmm0
       vmovss   xmm2, dword ptr [rbp-0x180]
       vmovss   xmm1, dword ptr [rbp-0x64]
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0xA0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0xA0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x184], xmm0
       vmovss   xmm0, dword ptr [rbp-0x184]
       vmovss   xmm1, dword ptr [rbp-0xA0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xF0], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD08]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x188], xmm0
       vmovss   xmm1, dword ptr [rbp-0x188]
       vmovss   xmm0, dword ptr [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0xF4], xmm0
       mov      ecx, dword ptr [rbp-0x58]
       mov      edx, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0xF8], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x18C], eax
       mov      r8d, dword ptr [rbp-0x18C]
       mov      edx, dword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x190], eax
       mov      edx, dword ptr [rbp-0x190]
       mov      ecx, dword ptr [rbp-0x3C]
 
G_M000_IG09:                ;; offset=0x06ED
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xA4], eax
       mov      ecx, dword ptr [rbp-0x5C]
       mov      edx, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0xFC], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x194], eax
       mov      r8d, dword ptr [rbp-0x194]
       mov      edx, dword ptr [rbp-0xFC]
       mov      ecx, dword ptr [rbp-0x98]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x198], eax
       mov      edx, dword ptr [rbp-0x198]
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xA8], eax
       mov      ecx, dword ptr [rbp-0x60]
       mov      edx, dword ptr [rbp-0x78]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0x100], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x19C], eax
       mov      r8d, dword ptr [rbp-0x19C]
       mov      edx, dword ptr [rbp-0x100]
       mov      ecx, dword ptr [rbp-0x9C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x104], eax
       mov      ecx, dword ptr [rbp-0x44]
       mov      edx, dword ptr [rbp-0x104]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xAC], eax
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1A0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A0]
       mov      ecx, dword ptr [rbp-0x94]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1A4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A4]
       vmovss   xmm0, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB0], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1A8], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A8]
       mov      ecx, dword ptr [rbp-0x98]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1AC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1AC]
       vmovss   xmm0, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB4], xmm0
       mov      ecx, dword ptr [rbp-0x60]
 
G_M000_IG10:                ;; offset=0x083E
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1B0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B0]
       mov      ecx, dword ptr [rbp-0x9C]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1B4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B4]
       vmovss   xmm0, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB8], xmm0
       vmovss   xmm0, dword ptr [rbp-0xF4]
       vmovss   xmm1, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
       mov      dword ptr [rbp-0xBC], eax
       vmovss   xmm0, dword ptr [rbp-0xF4]
       vmovss   xmm1, dword ptr [rbp-0xF4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x108], xmm0
       vmovss   xmm0, dword ptr [rbp-0x108]
       vmovss   xmm1, dword ptr [rbp-0x108]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x10C], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB0]
       vmovss   dword ptr [rsp+0x20], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB4]
       vmovss   dword ptr [rsp+0x28], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB8]
       vmovss   dword ptr [rsp+0x30], xmm0
       mov      ecx, dword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0xA4]
       mov      r8d, dword ptr [rbp-0xA8]
       mov      r9d, dword ptr [rbp-0xAC]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int,int,int,float,float,float):float]
       vmovss   dword ptr [rbp-0x1B8], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B8]
       vmovss   xmm0, dword ptr [rbp-0x10C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x110], xmm0
       vmovss   xmm0, dword ptr [rbp-0x110]
       vmovss   dword ptr [rbp-0xC0], xmm0
       mov      ecx, dword ptr [rbp-0xBC]
       vmovss   xmm1, dword ptr [rbp-0xC0]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1BC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1BC]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x80], xmm0
       cmp      dword ptr [rbp-0x88], 1
       je       G_M000_IG14
       mov      rcx, 0x7FFC658FC5D8
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C0], xmm0
 
G_M000_IG11:                ;; offset=0x09C5
       vmovss   xmm0, dword ptr [rbp-0x1C0]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x64], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1C4]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1C8]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1CC], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1CC]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1D0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D0]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x4C], xmm0
       mov      ecx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1D4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D4]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x50], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD16]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1D8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D8]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x1DC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1DC]
       vmovss   xmm0, dword ptr [rbp-0x114]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x1E0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1E0]
       vmovss   xmm0, dword ptr [rbp-0x84]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x84], xmm0
       mov      ecx, dword ptr [rbp-0x58]
 
G_M000_IG12:                ;; offset=0x0B3C
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1E4], eax
       mov      ecx, dword ptr [rbp-0x1E4]
       mov      edx, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1E8], eax
       mov      edx, dword ptr [rbp-0x1E8]
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      ecx, dword ptr [rbp-0x5C]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1EC], eax
       mov      ecx, dword ptr [rbp-0x1EC]
       mov      edx, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1F0], eax
       mov      edx, dword ptr [rbp-0x1F0]
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x40], eax
       mov      ecx, dword ptr [rbp-0x60]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1F4], eax
       mov      ecx, dword ptr [rbp-0x1F4]
       mov      edx, dword ptr [rbp-0x78]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1F8], eax
       mov      edx, dword ptr [rbp-0x1F8]
       mov      ecx, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x44], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x1FC], eax
       mov      ecx, dword ptr [rbp-0x1FC]
       mov      edx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x58], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x200], eax
       mov      ecx, dword ptr [rbp-0x200]
       mov      edx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x5C], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x204], eax
       mov      ecx, dword ptr [rbp-0x204]
       mov      edx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x60], eax
       mov      ecx, dword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp+0x10], eax
       mov      eax, dword ptr [rbp-0x88]
       inc      eax
 
G_M000_IG13:                ;; offset=0x0C5E
       mov      dword ptr [rbp-0x88], eax
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0C69
       mov      rcx, 0x7FFC658FC5DC
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm0, dword ptr [reloc @RWD20]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x208], xmm0
       vmovss   xmm1, dword ptr [rbp-0x208]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       nop      
 
G_M000_IG15:                ;; offset=0x0CA2
       add      rsp, 576
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 3243

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      dword ptr [rbp+0x10], ecx
       vmovss   dword ptr [rbp+0x18], xmm1
       vmovss   dword ptr [rbp+0x20], xmm2
       vmovss   dword ptr [rbp+0x28], xmm3
 
G_M000_IG02:                ;; offset=0x0046
       mov      dword ptr [rbp-0x120], 0x3E8
       vmovss   xmm0, dword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x3C], eax
       vmovss   xmm0, dword ptr [rbp+0x20]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x40], eax
       vmovss   xmm0, dword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x124], xmm0
       vmovss   xmm1, dword ptr [rbp-0x124]
       vmovss   xmm0, dword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x128], xmm0
       vmovss   xmm1, dword ptr [rbp-0x128]
       vmovss   xmm0, dword ptr [rbp+0x20]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x4C], xmm0
       mov      ecx, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x12C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x12C]
       vmovss   xmm0, dword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x50], xmm0
       mov      ecx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x54], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x130], xmm0
       vmovss   xmm0, dword ptr [rbp-0x130]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x134], xmm0
       vmovss   xmm0, dword ptr [rbp-0x134]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x138], eax
       mov      ecx, dword ptr [rbp-0x138]
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x58], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x13C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x13C]
       vmovss   xmm1, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x140], xmm0
       vmovss   xmm0, dword ptr [rbp-0x140]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x144], eax
       mov      ecx, dword ptr [rbp-0x144]
 
G_M000_IG03:                ;; offset=0x01A5
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x5C], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x148], xmm0
       vmovss   xmm0, dword ptr [rbp-0x148]
       vmovss   xmm1, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x14C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x14C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x150], eax
       mov      ecx, dword ptr [rbp-0x150]
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x60], eax
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xC4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x154], xmm0
       vmovss   xmm1, dword ptr [rbp-0x154]
       vmovss   xmm0, dword ptr [rbp-0xC4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x64], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xC8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x158], xmm0
       vmovss   xmm1, dword ptr [rbp-0x158]
       vmovss   xmm0, dword ptr [rbp-0xC8]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       mov      ecx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xCC], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x15C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x15C]
       vmovss   xmm0, dword ptr [rbp-0xCC]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      ecx, dword ptr [rbp-0x3C]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      ecx, dword ptr [rbp-0x40]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
       mov      dword ptr [rbp-0x40], eax
       mov      ecx, dword ptr [rbp-0x44]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
 
G_M000_IG04:                ;; offset=0x02F5
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x70], eax
       mov      ecx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x74], eax
       mov      ecx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x78], eax
       vxorps   xmm0, xmm0, xmm0
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x7C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x7C]
       vmovss   dword ptr [rbp-0x80], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD04]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0xD0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x160], xmm0
       vmovss   xmm1, dword ptr [rbp-0x160]
       vmovss   xmm0, dword ptr [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0xD4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       vmovss   xmm1, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xD8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       vmovss   xmm1, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x164], xmm0
       vmovss   xmm1, dword ptr [rbp-0x164]
       vmovss   xmm0, dword ptr [rbp-0xD8]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x168], xmm0
       vmovss   xmm1, dword ptr [rbp-0x168]
       vmovss   xmm0, dword ptr [rbp-0xD4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x84], xmm0
       xor      eax, eax
       mov      dword ptr [rbp-0x88], eax
 
G_M000_IG05:                ;; offset=0x03FB
       mov      eax, dword ptr [rbp-0x120]
       dec      eax
       mov      dword ptr [rbp-0x120], eax
       cmp      dword ptr [rbp-0x120], 0
       jg       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0412
       lea      rcx, [rbp-0x120]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG07:                ;; offset=0x0423
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
       mov      dword ptr [rbp-0x8C], eax
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x84]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xDC], xmm0
       vmovss   xmm0, dword ptr [rbp-0xDC]
       vmovss   xmm1, dword ptr [rbp-0xDC]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xE0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       vmovss   dword ptr [rsp+0x20], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       vmovss   dword ptr [rsp+0x28], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       vmovss   dword ptr [rsp+0x30], xmm0
       mov      ecx, dword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x3C]
       mov      r8d, dword ptr [rbp-0x40]
       mov      r9d, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int,int,int,float,float,float):float]
       vmovss   dword ptr [rbp-0x16C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x16C]
       vmovss   xmm0, dword ptr [rbp-0xE0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x90], xmm0
       mov      ecx, dword ptr [rbp-0x8C]
       vmovss   xmm1, dword ptr [rbp-0x90]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x170], xmm0
       vmovss   xmm1, dword ptr [rbp-0x170]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x80], xmm0
       vmovss   xmm0, dword ptr [rbp-0x64]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0xE4], eax
       vmovss   xmm0, dword ptr [rbp-0x64]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x174], eax
       mov      edx, dword ptr [rbp-0x174]
       mov      ecx, dword ptr [rbp-0xE4]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x94], eax
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0xE8], eax
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
 
G_M000_IG08:                ;; offset=0x0582
       mov      dword ptr [rbp-0xEC], eax
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x178], eax
       mov      edx, dword ptr [rbp-0x178]
       mov      ecx, dword ptr [rbp-0xEC]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       mov      ecx, dword ptr [rbp-0xE8]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x98], eax
       mov      ecx, dword ptr [rbp-0x94]
       mov      edx, dword ptr [rbp-0x98]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x9C], eax
       mov      ecx, dword ptr [rbp-0x98]
       vmovss   xmm1, dword ptr [rbp-0x68]
       vmovss   xmm2, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x180], xmm0
       vmovss   xmm2, dword ptr [rbp-0x180]
       vmovss   xmm1, dword ptr [rbp-0x64]
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0xA0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0xA0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x184], xmm0
       vmovss   xmm0, dword ptr [rbp-0x184]
       vmovss   xmm1, dword ptr [rbp-0xA0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xF0], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD08]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x188], xmm0
       vmovss   xmm1, dword ptr [rbp-0x188]
       vmovss   xmm0, dword ptr [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0xF4], xmm0
       mov      ecx, dword ptr [rbp-0x58]
       mov      edx, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0xF8], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x18C], eax
       mov      r8d, dword ptr [rbp-0x18C]
       mov      edx, dword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x190], eax
       mov      edx, dword ptr [rbp-0x190]
       mov      ecx, dword ptr [rbp-0x3C]
 
G_M000_IG09:                ;; offset=0x06ED
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xA4], eax
       mov      ecx, dword ptr [rbp-0x5C]
       mov      edx, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0xFC], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x194], eax
       mov      r8d, dword ptr [rbp-0x194]
       mov      edx, dword ptr [rbp-0xFC]
       mov      ecx, dword ptr [rbp-0x98]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x198], eax
       mov      edx, dword ptr [rbp-0x198]
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xA8], eax
       mov      ecx, dword ptr [rbp-0x60]
       mov      edx, dword ptr [rbp-0x78]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0x100], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x19C], eax
       mov      r8d, dword ptr [rbp-0x19C]
       mov      edx, dword ptr [rbp-0x100]
       mov      ecx, dword ptr [rbp-0x9C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x104], eax
       mov      ecx, dword ptr [rbp-0x44]
       mov      edx, dword ptr [rbp-0x104]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xAC], eax
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1A0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A0]
       mov      ecx, dword ptr [rbp-0x94]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1A4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A4]
       vmovss   xmm0, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB0], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1A8], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A8]
       mov      ecx, dword ptr [rbp-0x98]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1AC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1AC]
       vmovss   xmm0, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB4], xmm0
       mov      ecx, dword ptr [rbp-0x60]
 
G_M000_IG10:                ;; offset=0x083E
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1B0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B0]
       mov      ecx, dword ptr [rbp-0x9C]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1B4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B4]
       vmovss   xmm0, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB8], xmm0
       vmovss   xmm0, dword ptr [rbp-0xF4]
       vmovss   xmm1, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
       mov      dword ptr [rbp-0xBC], eax
       vmovss   xmm0, dword ptr [rbp-0xF4]
       vmovss   xmm1, dword ptr [rbp-0xF4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x108], xmm0
       vmovss   xmm0, dword ptr [rbp-0x108]
       vmovss   xmm1, dword ptr [rbp-0x108]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x10C], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB0]
       vmovss   dword ptr [rsp+0x20], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB4]
       vmovss   dword ptr [rsp+0x28], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB8]
       vmovss   dword ptr [rsp+0x30], xmm0
       mov      ecx, dword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0xA4]
       mov      r8d, dword ptr [rbp-0xA8]
       mov      r9d, dword ptr [rbp-0xAC]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int,int,int,float,float,float):float]
       vmovss   dword ptr [rbp-0x1B8], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B8]
       vmovss   xmm0, dword ptr [rbp-0x10C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x110], xmm0
       vmovss   xmm0, dword ptr [rbp-0x110]
       vmovss   dword ptr [rbp-0xC0], xmm0
       mov      ecx, dword ptr [rbp-0xBC]
       vmovss   xmm1, dword ptr [rbp-0xC0]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1BC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1BC]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x80], xmm0
       cmp      dword ptr [rbp-0x88], 1
       je       G_M000_IG14
       mov      rcx, 0x7FFC658FC5D8
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C0], xmm0
 
G_M000_IG11:                ;; offset=0x09C5
       vmovss   xmm0, dword ptr [rbp-0x1C0]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x64], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1C4]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1C8]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1CC], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1CC]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1D0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D0]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x4C], xmm0
       mov      ecx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1D4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D4]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x50], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD16]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1D8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D8]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x1DC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1DC]
       vmovss   xmm0, dword ptr [rbp-0x114]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x1E0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1E0]
       vmovss   xmm0, dword ptr [rbp-0x84]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x84], xmm0
       mov      ecx, dword ptr [rbp-0x58]
 
G_M000_IG12:                ;; offset=0x0B3C
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1E4], eax
       mov      ecx, dword ptr [rbp-0x1E4]
       mov      edx, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1E8], eax
       mov      edx, dword ptr [rbp-0x1E8]
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      ecx, dword ptr [rbp-0x5C]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1EC], eax
       mov      ecx, dword ptr [rbp-0x1EC]
       mov      edx, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1F0], eax
       mov      edx, dword ptr [rbp-0x1F0]
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x40], eax
       mov      ecx, dword ptr [rbp-0x60]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1F4], eax
       mov      ecx, dword ptr [rbp-0x1F4]
       mov      edx, dword ptr [rbp-0x78]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1F8], eax
       mov      edx, dword ptr [rbp-0x1F8]
       mov      ecx, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x44], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x1FC], eax
       mov      ecx, dword ptr [rbp-0x1FC]
       mov      edx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x58], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x200], eax
       mov      ecx, dword ptr [rbp-0x200]
       mov      edx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x5C], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x204], eax
       mov      ecx, dword ptr [rbp-0x204]
       mov      edx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x60], eax
       mov      ecx, dword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp+0x10], eax
       mov      eax, dword ptr [rbp-0x88]
       inc      eax
 
G_M000_IG13:                ;; offset=0x0C5E
       mov      dword ptr [rbp-0x88], eax
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0C69
       mov      rcx, 0x7FFC658FC5DC
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm0, dword ptr [reloc @RWD20]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x208], xmm0
       vmovss   xmm1, dword ptr [rbp-0x208]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       nop      
 
G_M000_IG15:                ;; offset=0x0CA2
       add      rsp, 576
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 3243

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 142304
; 36 inlinees with PGO data; 197 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 120
       vmovaps  xmmword ptr [rsp+0x60], xmm6
       vmovaps  xmmword ptr [rsp+0x50], xmm7
       vmovaps  xmmword ptr [rsp+0x40], xmm8
       vmovaps  xmmword ptr [rsp+0x30], xmm9
       vmovaps  xmmword ptr [rsp+0x20], xmm10
       vmovaps  xmmword ptr [rsp+0x10], xmm11
 
G_M000_IG02:                ;; offset=0x0034
       vxorps   xmm0, xmm0, xmm0
       vucomiss xmm0, xmm1
       ja       G_M000_IG55
 
G_M000_IG03:                ;; offset=0x0042
       vmovss   xmm0, dword ptr [reloc @RWD00]
 
G_M000_IG04:                ;; offset=0x004A
       vaddss   xmm0, xmm1, xmm0
       vcmpordss xmm4, xmm0, xmm0
       vandps   xmm4, xmm4, xmm0
       mov      eax, 0x7FFFFFFF
       vcvttss2si edx, xmm4
       vucomiss xmm0, dword ptr [reloc @RWD04]
       cmovb    eax, edx
       vxorps   xmm0, xmm0, xmm0
       vucomiss xmm0, xmm2
       ja       G_M000_IG56
 
G_M000_IG05:                ;; offset=0x0079
       vmovss   xmm0, dword ptr [reloc @RWD00]
 
G_M000_IG06:                ;; offset=0x0081
       vaddss   xmm0, xmm2, xmm0
       vcmpordss xmm4, xmm0, xmm0
       vandps   xmm4, xmm4, xmm0
       mov      edx, 0x7FFFFFFF
       vcvttss2si r8d, xmm4
       vucomiss xmm0, dword ptr [reloc @RWD04]
       cmovb    edx, r8d
       vxorps   xmm0, xmm0, xmm0
       vucomiss xmm0, xmm3
       ja       G_M000_IG57
 
G_M000_IG07:                ;; offset=0x00B1
       vmovss   xmm0, dword ptr [reloc @RWD00]
 
G_M000_IG08:                ;; offset=0x00B9
       vaddss   xmm0, xmm3, xmm0
       vcmpordss xmm4, xmm0, xmm0
       vandps   xmm4, xmm4, xmm0
       mov      r8d, 0x7FFFFFFF
       vcvttss2si r10d, xmm4
       vucomiss xmm0, dword ptr [reloc @RWD04]
       cmovb    r8d, r10d
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, eax
       vsubss   xmm0, xmm1, xmm0
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, edx
       vsubss   xmm1, xmm2, xmm1
       vxorps   xmm2, xmm2, xmm2
       vcvtsi2ss xmm2, xmm2, r8d
       vsubss   xmm2, xmm3, xmm2
       vmovss   xmm3, dword ptr [reloc @RWD08]
       vsubss   xmm4, xmm3, xmm0
       vcmpordss xmm5, xmm4, xmm4
       vandps   xmm5, xmm5, xmm4
       mov      r10d, 0x7FFFFFFF
       vcvttss2si r9d, xmm5
       vucomiss xmm4, dword ptr [reloc @RWD04]
       cmovb    r10d, r9d
       or       r10d, 1
       vsubss   xmm4, xmm3, xmm1
       vcmpordss xmm5, xmm4, xmm4
       vandps   xmm5, xmm5, xmm4
       mov      r9d, 0x7FFFFFFF
       vcvttss2si r11d, xmm5
       vucomiss xmm4, dword ptr [reloc @RWD04]
       cmovb    r9d, r11d
       or       r9d, 1
       vsubss   xmm3, xmm3, xmm2
       vcmpordss xmm4, xmm3, xmm3
       vandps   xmm4, xmm4, xmm3
       mov      r11d, 0x7FFFFFFF
       vcvttss2si ebx, xmm4
       vucomiss xmm3, dword ptr [reloc @RWD04]
       cmovb    r11d, ebx
       or       r11d, 1
       vxorps   xmm3, xmm0, xmmword ptr [reloc @RWD16]
       vxorps   xmm4, xmm4, xmm4
       vcvtsi2ss xmm4, xmm4, r10d
       vmulss   xmm3, xmm3, xmm4
       vxorps   xmm4, xmm1, xmmword ptr [reloc @RWD16]
       vxorps   xmm5, xmm5, xmm5
       vcvtsi2ss xmm5, xmm5, r9d
       vmulss   xmm4, xmm4, xmm5
       vxorps   xmm5, xmm2, xmmword ptr [reloc @RWD16]
       vxorps   xmm6, xmm6, xmm6
       vcvtsi2ss xmm6, xmm6, r11d
       vmulss   xmm5, xmm5, xmm6
       imul     eax, eax, 0x1DDE90C9
       imul     edx, edx, 0x43C42E4D
       imul     r8d, r8d, 0x668B6E2F
       vxorps   xmm6, xmm6, xmm6
       vmulss   xmm7, xmm1, xmm1
       vmulss   xmm8, xmm2, xmm2
       vaddss   xmm7, xmm7, xmm8
 
G_M000_IG09:                ;; offset=0x01E1
       vmulss   xmm8, xmm0, xmm0
       vmovss   xmm9, dword ptr [reloc @RWD32]
       vsubss   xmm8, xmm9, xmm8
       vsubss   xmm7, xmm8, xmm7
       xor      ebx, ebx
 
G_M000_IG10:                ;; offset=0x01F8
       vxorps   xmm8, xmm8, xmm8
       vucomiss xmm7, xmm8
       jbe      G_M000_IG58
 
G_M000_IG11:                ;; offset=0x0208
       mov      esi, -1
 
G_M000_IG12:                ;; offset=0x020D
       vmulss   xmm8, xmm7, xmm7
       vmulss   xmm8, xmm8, xmm8
       mov      edi, ecx
       xor      edi, eax
       xor      edi, edx
       xor      edi, r8d
       imul     edi, edi, 0x27D4EB2D
       mov      ebp, edi
       sar      ebp, 15
       xor      ebp, edi
       mov      edi, ebp
       and      edi, 252
       mov      rbp, 0x1A484C01008
       mov      rbp, gword ptr [rbp]
       mov      r14, rbp
       add      r14, 16
       shr      edi, 2
       mov      edi, dword ptr [r14+4*rdi]
       mov      r14d, edi
       and      r14d, 3
       je       G_M000_IG59
 
G_M000_IG13:                ;; offset=0x025D
       vmovd    r15d, xmm0
       mov      r13d, edi
       shl      r13d, 29
       and      r13d, 0xFFFFFFFF80000000
       xor      r15d, r13d
       vmovd    xmm9, r15d
 
G_M000_IG14:                ;; offset=0x0278
       cmp      r14d, 1
       je       G_M000_IG60
 
G_M000_IG15:                ;; offset=0x0282
       vmovd    r15d, xmm1
       mov      r13d, edi
       shl      r13d, 28
       and      r13d, 0xFFFFFFFF80000000
       xor      r15d, r13d
       vmovd    xmm10, r15d
 
G_M000_IG16:                ;; offset=0x029D
       cmp      r14d, 2
       je       G_M000_IG61
 
G_M000_IG17:                ;; offset=0x02A7
       vmovd    r14d, xmm2
       shl      edi, 27
       and      edi, 0xFFFFFFFF80000000
       xor      edi, r14d
       vmovd    xmm11, edi
 
G_M000_IG18:                ;; offset=0x02BC
       vaddss   xmm9, xmm9, xmm10
       vaddss   xmm9, xmm9, xmm11
       vmulss   xmm8, xmm9, xmm8
       test     esi, esi
       jne      G_M000_IG62
 
G_M000_IG19:                ;; offset=0x02D3
       vxorps   xmm9, xmm9, xmm9
 
G_M000_IG20:                ;; offset=0x02D8
       vaddss   xmm6, xmm6, xmm9
       vucomiss xmm4, xmm3
       ja       G_M000_IG63
 
G_M000_IG21:                ;; offset=0x02E7
       xor      esi, esi
 
G_M000_IG22:                ;; offset=0x02E9
       not      esi
       vucomiss xmm5, xmm3
       ja       G_M000_IG64
 
G_M000_IG23:                ;; offset=0x02F5
       xor      edi, edi
 
G_M000_IG24:                ;; offset=0x02F7
       andn     esi, edi, esi
       mov      edi, esi
       not      edi
       vucomiss xmm4, xmm3
       jbe      G_M000_IG65
 
G_M000_IG25:                ;; offset=0x030A
       mov      r14d, -1
 
G_M000_IG26:                ;; offset=0x0310
       vucomiss xmm5, xmm4
       ja       G_M000_IG66
 
G_M000_IG27:                ;; offset=0x031A
       xor      r15d, r15d
 
G_M000_IG28:                ;; offset=0x031D
       and      edi, r14d
       andn     edi, r15d, edi
       mov      r14d, esi
       or       r14d, edi
       not      r14d
       test     edi, edi
       jne      G_M000_IG67
 
G_M000_IG29:                ;; offset=0x0336
       vmovaps  xmm8, xmm5
 
G_M000_IG30:                ;; offset=0x033A
       test     esi, esi
       jne      G_M000_IG68
 
G_M000_IG31:                ;; offset=0x0342
       vaddss   xmm9, xmm7, xmm8
       vaddss   xmm8, xmm9, xmm8
       vsubss   xmm8, xmm8, dword ptr [reloc @RWD36]
       imul     r15d, r10d, 0x1DDE90C9
       test     esi, esi
       jne      G_M000_IG69
 
G_M000_IG32:                ;; offset=0x0363
       xor      r13d, r13d
 
G_M000_IG33:                ;; offset=0x0366
       mov      r15d, eax
       sub      r15d, r13d
       imul     r13d, r9d, 0x43C42E4D
       test     edi, edi
       jne      G_M000_IG70
 
G_M000_IG34:                ;; offset=0x037B
       xor      r12d, r12d
 
G_M000_IG35:                ;; offset=0x037E
       mov      r13d, edx
       sub      r13d, r12d
       mov      dword ptr [rsp+0x0C], r13d
       imul     r12d, r11d, 0x668B6E2F
       test     r14d, r14d
       jne      G_M000_IG71
 
G_M000_IG36:                ;; offset=0x0399
       xor      r12d, r12d
 
G_M000_IG37:                ;; offset=0x039C
       mov      r13d, r8d
       sub      r13d, r12d
       test     esi, esi
       jne      G_M000_IG72
 
G_M000_IG38:                ;; offset=0x03AA
       vxorps   xmm9, xmm9, xmm9
 
G_M000_IG39:                ;; offset=0x03AF
       vaddss   xmm0, xmm0, xmm9
       test     edi, edi
       jne      G_M000_IG73
 
G_M000_IG40:                ;; offset=0x03BC
       vxorps   xmm9, xmm9, xmm9
 
G_M000_IG41:                ;; offset=0x03C1
       vaddss   xmm1, xmm1, xmm9
       test     r14d, r14d
       jne      G_M000_IG74
 
G_M000_IG42:                ;; offset=0x03CF
       vxorps   xmm9, xmm9, xmm9
 
G_M000_IG43:                ;; offset=0x03D4
       vaddss   xmm2, xmm2, xmm9
       vxorps   xmm9, xmm9, xmm9
       vucomiss xmm8, xmm9
       jbe      G_M000_IG75
 
G_M000_IG44:                ;; offset=0x03E9
       mov      esi, -1
 
G_M000_IG45:                ;; offset=0x03EE
       vmulss   xmm8, xmm8, xmm8
       vmulss   xmm8, xmm8, xmm8
       xor      r15d, ecx
       xor      r15d, dword ptr [rsp+0x0C]
       xor      r15d, r13d
       imul     edi, r15d, 0x27D4EB2D
       mov      r14d, edi
       sar      r14d, 15
       xor      r14d, edi
       mov      edi, r14d
       and      edi, 252
       add      rbp, 16
       shr      edi, 2
       mov      edi, dword ptr [rbp+4*rdi]
       mov      ebp, edi
       and      ebp, 3
       je       G_M000_IG76
 
G_M000_IG46:                ;; offset=0x0433
       vmovd    r14d, xmm0
       mov      r15d, edi
       shl      r15d, 29
       and      r15d, 0xFFFFFFFF80000000
       xor      r14d, r15d
       vmovd    xmm0, r14d
 
G_M000_IG47:                ;; offset=0x044E
       cmp      ebp, 1
       je       G_M000_IG77
 
G_M000_IG48:                ;; offset=0x0457
       vmovd    r14d, xmm1
       mov      r15d, edi
       shl      r15d, 28
       and      r15d, 0xFFFFFFFF80000000
       xor      r14d, r15d
       vmovd    xmm1, r14d
 
G_M000_IG49:                ;; offset=0x0472
       cmp      ebp, 2
       je       G_M000_IG78
 
G_M000_IG50:                ;; offset=0x047B
       vmovd    ebp, xmm2
       shl      edi, 27
       and      edi, 0xFFFFFFFF80000000
       xor      edi, ebp
       vmovd    xmm2, edi
 
G_M000_IG51:                ;; offset=0x048E
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm2
       vmulss   xmm0, xmm0, xmm8
       test     esi, esi
       jne      G_M000_IG79
 
G_M000_IG52:                ;; offset=0x04A3
       vxorps   xmm1, xmm1, xmm1
 
G_M000_IG53:                ;; offset=0x04A7
       vaddss   xmm6, xmm6, xmm1
       cmp      ebx, 1
       je       G_M000_IG80
 
G_M000_IG54:                ;; offset=0x04B4
       vmovss   xmm0, dword ptr [reloc @RWD00]
       vsubss   xmm3, xmm0, xmm3
       vsubss   xmm4, xmm0, xmm4
       vsubss   xmm5, xmm0, xmm5
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, r10d
       vmulss   xmm0, xmm0, xmm3
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r9d
       vmulss   xmm1, xmm1, xmm4
       vxorps   xmm2, xmm2, xmm2
       vcvtsi2ss xmm2, xmm2, r11d
       vmulss   xmm2, xmm2, xmm5
       vaddss   xmm8, xmm4, xmm5
       vmovss   xmm9, dword ptr [reloc @RWD40]
       vsubss   xmm9, xmm9, xmm3
       vsubss   xmm8, xmm9, xmm8
       vaddss   xmm7, xmm8, xmm7
       mov      esi, r10d
       sar      esi, 1
       and      esi, 0x1DDE90C9
       add      eax, esi
       mov      esi, r9d
       sar      esi, 1
       and      esi, 0x43C42E4D
       add      edx, esi
       mov      esi, r11d
       sar      esi, 1
       and      esi, 0x668B6E2F
       add      r8d, esi
       neg      r10d
       neg      r9d
       neg      r11d
       not      ecx
       inc      ebx
       jmp      G_M000_IG10
 
G_M000_IG55:                ;; offset=0x0542
       vmovss   xmm0, dword ptr [reloc @RWD44]
       jmp      G_M000_IG04
 
G_M000_IG56:                ;; offset=0x054F
       vmovss   xmm0, dword ptr [reloc @RWD44]
       jmp      G_M000_IG06
 
G_M000_IG57:                ;; offset=0x055C
       vmovss   xmm0, dword ptr [reloc @RWD44]
       jmp      G_M000_IG08
 
G_M000_IG58:                ;; offset=0x0569
       xor      esi, esi
       jmp      G_M000_IG12
 
G_M000_IG59:                ;; offset=0x0570
       vxorps   xmm9, xmm9, xmm9
       jmp      G_M000_IG14
 
G_M000_IG60:                ;; offset=0x057A
       vxorps   xmm10, xmm10, xmm10
       jmp      G_M000_IG16
 
G_M000_IG61:                ;; offset=0x0584
       vxorps   xmm11, xmm11, xmm11
       jmp      G_M000_IG18
 
G_M000_IG62:                ;; offset=0x058E
       vmovaps  xmm9, xmm8
       jmp      G_M000_IG20
 
G_M000_IG63:                ;; offset=0x0598
       mov      esi, -1
       jmp      G_M000_IG22
 
G_M000_IG64:                ;; offset=0x05A2
       mov      edi, -1
       jmp      G_M000_IG24
 
G_M000_IG65:                ;; offset=0x05AC
       xor      r14d, r14d
       jmp      G_M000_IG26
 
G_M000_IG66:                ;; offset=0x05B4
       mov      r15d, -1
       jmp      G_M000_IG28
 
G_M000_IG67:                ;; offset=0x05BF
       vmovaps  xmm8, xmm4
       jmp      G_M000_IG30
 
G_M000_IG68:                ;; offset=0x05C8
       vmovaps  xmm8, xmm3
       jmp      G_M000_IG31
 
G_M000_IG69:                ;; offset=0x05D1
       mov      r13d, r15d
       jmp      G_M000_IG33
 
G_M000_IG70:                ;; offset=0x05D9
       mov      r12d, r13d
       jmp      G_M000_IG35
 
G_M000_IG71:                ;; offset=0x05E1
       jmp      G_M000_IG37
 
G_M000_IG72:                ;; offset=0x05E6
       vxorps   xmm9, xmm9, xmm9
       vcvtsi2ss xmm9, xmm9, r10d
       jmp      G_M000_IG39
 
G_M000_IG73:                ;; offset=0x05F5
       vxorps   xmm9, xmm9, xmm9
       vcvtsi2ss xmm9, xmm9, r9d
       jmp      G_M000_IG41
 
G_M000_IG74:                ;; offset=0x0604
       vxorps   xmm9, xmm9, xmm9
       vcvtsi2ss xmm9, xmm9, r11d
       jmp      G_M000_IG43
 
G_M000_IG75:                ;; offset=0x0613
       xor      esi, esi
       jmp      G_M000_IG45
 
G_M000_IG76:                ;; offset=0x061A
       vxorps   xmm0, xmm0, xmm0
       jmp      G_M000_IG47
 
G_M000_IG77:                ;; offset=0x0623
       vxorps   xmm1, xmm1, xmm1
       jmp      G_M000_IG49
 
G_M000_IG78:                ;; offset=0x062C
       vxorps   xmm2, xmm2, xmm2
       jmp      G_M000_IG51
 
G_M000_IG79:                ;; offset=0x0635
       vmovaps  xmm1, xmm0
       jmp      G_M000_IG53
 
G_M000_IG80:                ;; offset=0x063E
       vmulss   xmm0, xmm6, dword ptr [reloc @RWD48]
 
G_M000_IG81:                ;; offset=0x0646
       vmovaps  xmm6, xmmword ptr [rsp+0x60]
       vmovaps  xmm7, xmmword ptr [rsp+0x50]
       vmovaps  xmm8, xmmword ptr [rsp+0x40]
       vmovaps  xmm9, xmmword ptr [rsp+0x30]
       vmovaps  xmm10, xmmword ptr [rsp+0x20]
       vmovaps  xmm11, xmmword ptr [rsp+0x10]
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
RWD00  	dd	3F000000h		;       0.5
RWD04  	dd	4F000000h		; 2.14748e+09
RWD08  	dd	BF800000h		;        -1
RWD12  	dd	00000000h
RWD16  	dq	8000000080000000h, 8000000080000000h
RWD32  	dd	3F19999Ah		;       0.6
RWD36  	dd	3F800000h		;         1
RWD40  	dd	3F400000h		;      0.75
RWD44  	dd	BF000000h		;      -0.5
RWD48  	dd	4202C6F2h		;   32.6943

; Total bytes of code 1659

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC658FA3B8
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC658FA3BC
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC658F2438
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC658F243C
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:Sample3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:Fractal3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 23236
; 2 inlinees with PGO data; 295 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       sub      rsp, 0x438
       vmovaps  xmmword ptr [rsp+0x420], xmm6
       vmovaps  xmmword ptr [rsp+0x410], xmm7
       vmovaps  xmmword ptr [rsp+0x400], xmm8
       vmovaps  xmmword ptr [rsp+0x3F0], xmm9
       vmovaps  xmmword ptr [rsp+0x3E0], xmm10
       vmovaps  xmmword ptr [rsp+0x3D0], xmm11
       vmovaps  xmmword ptr [rsp+0x3C0], xmm12
       vmovaps  xmmword ptr [rsp+0x3B0], xmm13
       vmovaps  xmmword ptr [rsp+0x3A0], xmm14
       vmovaps  xmmword ptr [rsp+0x390], xmm15
       mov      rax, bword ptr [rsp+0x460]
 
G_M000_IG02:                ;; offset=0x0069
       vmovups  ymm0, ymmword ptr [r8]
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm0, ymm1
       vbroadcastss ymm2, dword ptr [reloc @RWD00]
       vbroadcastss ymm3, dword ptr [reloc @RWD04]
       vmovups  ymmword ptr [rsp+0xC0], ymm3
       vblendvps ymm1, ymm3, ymm2, ymm1
       vaddps   ymm1, ymm1, ymm0
       vcmpeqps ymm4, ymm1, ymm1
       vandps   ymm1, ymm4, ymm1
       vbroadcastss ymm4, dword ptr [reloc @RWD08]
       vcmpgeps ymm5, ymm1, ymm4
       vbroadcastss ymm6, dword ptr [reloc @RWD12]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymm6, ymm5
       vmovups  ymm5, ymmword ptr [r9]
       vxorps   ymm7, ymm7, ymm7
       vcmpltps ymm7, ymm5, ymm7
       vblendvps ymm7, ymm3, ymm2, ymm7
       vaddps   ymm7, ymm7, ymm5
       vcmpeqps ymm8, ymm7, ymm7
       vandps   ymm7, ymm8, ymm7
       vcmpgeps ymm8, ymm7, ymm4
       vcvttps2dq ymm7, ymm7
       vpblendvb ymm7, ymm7, ymm6, ymm8
       vmovups  ymm8, ymmword ptr [rax]
       vxorps   ymm9, ymm9, ymm9
       vcmpltps ymm9, ymm8, ymm9
       vblendvps ymm2, ymm3, ymm2, ymm9
       vaddps   ymm2, ymm2, ymm8
       vcmpeqps ymm9, ymm2, ymm2
       vandps   ymm2, ymm9, ymm2
       vcmpgeps ymm9, ymm2, ymm4
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm6, ymm9
       vcvtdq2ps ymm9, ymm1
       vsubps   ymm0, ymm0, ymm9
       vcvtdq2ps ymm9, ymm7
       vsubps   ymm5, ymm5, ymm9
       vcvtdq2ps ymm9, ymm2
       vsubps   ymm8, ymm8, ymm9
       vbroadcastss ymm9, dword ptr [reloc @RWD16]
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       vmovaps  ymm10, ymm9
       vbroadcastss ymm11, dword ptr [reloc @RWD20]
       vsubps   ymm12, ymm11, ymm0
       vcmpeqps ymm13, ymm12, ymm12
       vandps   ymm12, ymm13, ymm12
       vcmpgeps ymm13, ymm12, ymm4
       vcvttps2dq ymm12, ymm12
       vpblendvb ymm12, ymm12, ymm6, ymm13
       vpor     ymm12, ymm12, ymm10
       vsubps   ymm13, ymm11, ymm5
       vcmpeqps ymm14, ymm13, ymm13
       vandps   ymm13, ymm14, ymm13
       vcmpgeps ymm14, ymm13, ymm4
       vcvttps2dq ymm13, ymm13
       vpblendvb ymm13, ymm13, ymm6, ymm14
       vpor     ymm13, ymm13, ymm10
       vsubps   ymm11, ymm11, ymm8
       vcmpeqps ymm14, ymm11, ymm11
       vandps   ymm11, ymm14, ymm11
 
G_M000_IG03:                ;; offset=0x01BB
       vcmpgeps ymm4, ymm11, ymm4
       vcvttps2dq ymm11, ymm11
       vpblendvb ymm4, ymm11, ymm6, ymm4
       vpor     ymm4, ymm4, ymm10
       vbroadcastss ymm6, dword ptr [reloc @RWD24]
       vxorps   ymm10, ymm6, ymm0
       vcvtdq2ps ymm11, ymm12
       vmulps   ymm10, ymm10, ymm11
       vxorps   ymm11, ymm6, ymm5
       vcvtdq2ps ymm14, ymm13
       vmulps   ymm11, ymm11, ymm14
       vxorps   ymm14, ymm6, ymm8
       vcvtdq2ps ymm15, ymm4
       vmulps   ymm14, ymm14, ymm15
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD32]
       vpmulld  ymm7, ymm7, ymmword ptr [reloc @RWD64]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD96]
       vbroadcastss ymm15, dword ptr [reloc @RWD32]
       vmovups  ymmword ptr [rsp+0x2A0], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rsp+0x280], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0x260], ymm15
       vxorps   ymm15, ymm15, ymm15
       vxorps   ymm9, ymm9, ymm9
       vmovups  ymmword ptr [rsp+0x2E0], ymm5
       vmulps   ymm3, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0x370], ymm3
       vmovups  ymmword ptr [rsp+0x2C0], ymm8
       vmulps   ymm3, ymm8, ymm8
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x370], ymm3
       vmovups  ymmword ptr [rsp+0x300], ymm0
       vmulps   ymm3, ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x350], ymm3
       vbroadcastss ymm3, dword ptr [reloc @RWD128]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x350]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x370]
       xor      eax, eax
       mov      r8, 0x1A484C01008
       mov      r8, gword ptr [r8]
       jmp      G_M000_IG05
 
G_M000_IG04:                ;; offset=0x02D9
       vmovups  ymm0, ymmword ptr [rsp+0xC0]
       vsubps   ymm10, ymm0, ymm10
       vsubps   ymm11, ymm0, ymm11
       vsubps   ymm14, ymm0, ymm14
       vcvtdq2ps ymm2, ymm12
       vmulps   ymm2, ymm2, ymm10
       vmovups  ymmword ptr [rsp+0x300], ymm2
       vcvtdq2ps ymm5, ymm13
       vmulps   ymm5, ymm5, ymm11
       vcvtdq2ps ymm8, ymm4
       vmulps   ymm8, ymm8, ymm14
       vaddps   ymm0, ymm11, ymm14
       vmovups  ymmword ptr [rsp+0x370], ymm0
       vbroadcastss ymm0, dword ptr [reloc @RWD132]
       vsubps   ymm0, ymm0, ymm10
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x370]
       vaddps   ymm3, ymm0, ymm3
       vpsrad   ymm0, ymm12, 1
       vpand    ymm0, ymm0, ymmword ptr [rsp+0x2A0]
       vpaddd   ymm1, ymm0, ymm1
       vpsrad   ymm0, ymm13, 1
       vpand    ymm0, ymm0, ymmword ptr [rsp+0x280]
       vpaddd   ymm7, ymm0, ymm7
       vpsrad   ymm0, ymm4, 1
       vpand    ymm0, ymm0, ymmword ptr [rsp+0x260]
       vpaddd   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm12, ymm2, ymm12
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm13, ymm2, ymm13
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm4, ymm2, ymm4
       vpcmpeqd ymm2, ymm2, ymm2
       vpxor    ymm2, ymm2, ymmword ptr [rsp+0x80]
       vmovups  ymmword ptr [rdx], ymm2
       inc      eax
       vmovups  ymmword ptr [rsp+0x2E0], ymm5
       vmovups  ymmword ptr [rsp+0x2C0], ymm8
       vmovaps  ymm2, ymm0
 
G_M000_IG05:                ;; offset=0x03C0
       vcmpgtps ymm8, ymm3, ymm15
       vmovups  ymmword ptr [rsp+0x220], ymm8
       vmulps   ymm8, ymm3, ymm3
       vmulps   ymm8, ymm8, ymm8
       vmovups  ymmword ptr [rsp+0x100], ymm8
       vmovups  ymm8, ymmword ptr [rdx]
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vpxor    ymm8, ymm1, ymm8
       vpxor    ymm8, ymm8, ymm7
       vmovups  ymmword ptr [rsp+0x320], ymm2
       vpxor    ymm8, ymm8, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm8
       vbroadcastss ymm8, dword ptr [reloc @RWD136]
       vmovups  ymmword ptr [rsp+0x60], ymm8
       vmovups  ymm8, ymmword ptr [rsp+0x370]
       vpmulld  ymm8, ymm8, ymmword ptr [rsp+0x60]
       vpsrad   ymm5, ymm8, 15
       vpxor    ymm5, ymm5, ymm8
       vbroadcastss ymm8, dword ptr [reloc @RWD140]
       vmovups  ymmword ptr [rsp+0x40], ymm8
       vpand    ymm5, ymm5, ymm8
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm5, ymm5, 2
       vpcmpeqd ymm8, ymm8, ymm8
       vpgatherdd ymm0, dword ptr [r10+4*xmm5], ymm8
       vbroadcastss ymm5, dword ptr [reloc @RWD144]
       vmovups  ymmword ptr [rsp+0x20], ymm5
       vpand    ymm8, ymm5, ymm0
       vxorps   ymm5, ymm5, ymm5
       vpcmpeqd ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0x370], ymm5
       vpslld   ymm5, ymm0, 29
       vpand    ymm5, ymm5, ymm6
       vpxor    ymm5, ymm5, ymmword ptr [rsp+0x300]
       vmovups  ymm2, ymmword ptr [rsp+0x370]
       vblendvps ymm2, ymm5, ymm15, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm2
       vmovups  ymm5, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0x350], ymm5
       vpslld   ymm2, ymm0, 28
       vpand    ymm2, ymm2, ymm6
       vpxor    ymm2, ymm2, ymmword ptr [rsp+0x2E0]
       vmovups  ymm5, ymmword ptr [rsp+0x350]
       vblendvps ymm2, ymm2, ymm15, ymm5
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x370]
       vbroadcastss ymm5, dword ptr [reloc @RWD148]
       vmovups  ymmword ptr [rsp], ymm5
       vpcmpeqd ymm8, ymm5, ymm8
       vpslld   ymm0, ymm0, 27
       vpand    ymm0, ymm0, ymm6
       vpxor    ymm0, ymm0, ymmword ptr [rsp+0x2C0]
       vblendvps ymm0, ymm0, ymm15, ymm8
       vaddps   ymm0, ymm0, ymm2
       vmovups  ymm8, ymmword ptr [rsp+0x100]
       vmulps   ymm0, ymm8, ymm0
       vmovups  ymm8, ymmword ptr [rsp+0x220]
 
G_M000_IG06:                ;; offset=0x0537
       vandps   ymm0, ymm0, ymm8
       vandnps  ymm2, ymm8, ymm15
       vorps    ymm0, ymm2, ymm0
       vaddps   ymm9, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0x240], ymm9
       vcmpnltps ymm0, ymm10, ymm11
       vcmpnltps ymm2, ymm10, ymm14
       vpand    ymm0, ymm2, ymm0
       vcmpgtps ymm2, ymm11, ymm10
       vcmpnltps ymm8, ymm11, ymm14
       vpand    ymm2, ymm8, ymm2
       vpandn   ymm2, ymm0, ymm2
       vpor     ymm8, ymm0, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm8
       vpcmpeqd ymm8, ymm8, ymm8
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x370]
       vandps   ymm5, ymm10, ymm0
       vmovups  ymmword ptr [rsp+0x370], ymm5
       vandps   ymm5, ymm11, ymm2
       vmovups  ymmword ptr [rsp+0x350], ymm5
       vandnps  ymm5, ymm2, ymm14
       vorps    ymm5, ymm5, ymmword ptr [rsp+0x350]
       vandnps  ymm5, ymm0, ymm5
       vorps    ymm5, ymm5, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x200], ymm5
       vaddps   ymm5, ymm3, ymm5
       vaddps   ymm5, ymm5, ymmword ptr [rsp+0x200]
       vsubps   ymm5, ymm5, ymmword ptr [reloc @RWD160]
       vpmulld  ymm9, ymm12, ymmword ptr [rsp+0x2A0]
       vpand    ymm9, ymm9, ymm0
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm0, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x370]
       vpsubd   ymm9, ymm1, ymm9
       vmovups  ymmword ptr [rsp+0x1E0], ymm9
       vpmulld  ymm9, ymm13, ymmword ptr [rsp+0x280]
       vpand    ymm9, ymm9, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm2, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x370]
       vpsubd   ymm9, ymm7, ymm9
       vmovups  ymmword ptr [rsp+0x1C0], ymm9
       vpmulld  ymm9, ymm4, ymmword ptr [rsp+0x260]
       vpand    ymm9, ymm9, ymm8
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm8, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x320]
       vpsubd   ymm9, ymm9, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x1A0], ymm9
       vcvtdq2ps ymm9, ymm12
       vandps   ymm9, ymm9, ymm0
       vandnps  ymm0, ymm0, ymm15
       vorps    ymm0, ymm0, ymm9
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x300]
 
G_M000_IG07:                ;; offset=0x06C0
       vmovups  ymmword ptr [rsp+0x180], ymm0
       vcvtdq2ps ymm9, ymm13
       vandps   ymm9, ymm9, ymm2
       vandnps  ymm2, ymm2, ymm15
       vorps    ymm2, ymm2, ymm9
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x160], ymm2
       vcvtdq2ps ymm9, ymm4
       vandps   ymm9, ymm9, ymm8
       vandnps  ymm8, ymm8, ymm15
       vorps    ymm8, ymm8, ymm9
       vaddps   ymm8, ymm8, ymmword ptr [rsp+0x2C0]
       vmovups  ymmword ptr [rsp+0x140], ymm8
       vcmpgtps ymm9, ymm5, ymm15
       vmovups  ymmword ptr [rsp+0x120], ymm9
       vmulps   ymm5, ymm5, ymm5
       vmulps   ymm5, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0xE0], ymm5
       vmovups  ymm8, ymmword ptr [rsp+0x1E0]
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x80]
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x1C0]
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x1A0]
       vpmulld  ymm8, ymm8, ymmword ptr [rsp+0x60]
       vpsrad   ymm2, ymm8, 15
       vpxor    ymm2, ymm2, ymm8
       vpand    ymm8, ymm2, ymmword ptr [rsp+0x40]
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm2, ymm8, 2
       vpcmpeqd ymm8, ymm8, ymm8
       vpgatherdd ymm0, dword ptr [r10+4*xmm2], ymm8
       vmovups  ymm2, ymmword ptr [rsp+0x20]
       vpand    ymm2, ymm2, ymm0
       vxorps   ymm8, ymm8, ymm8
       vpcmpeqd ymm8, ymm8, ymm2
       vpslld   ymm9, ymm0, 29
       vpand    ymm9, ymm9, ymm6
       vpxor    ymm9, ymm9, ymmword ptr [rsp+0x180]
       vblendvps ymm8, ymm9, ymm15, ymm8
       vmovups  ymm9, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm9, ymm9, ymm2
       vpslld   ymm5, ymm0, 28
       vpand    ymm5, ymm5, ymm6
       vpxor    ymm5, ymm5, ymmword ptr [rsp+0x160]
       vblendvps ymm5, ymm5, ymm15, ymm9
       vaddps   ymm5, ymm5, ymm8
       vmovups  ymm8, ymmword ptr [rsp]
       vpcmpeqd ymm2, ymm8, ymm2
       vpslld   ymm0, ymm0, 27
       vpand    ymm0, ymm0, ymm6
       vpxor    ymm0, ymm0, ymmword ptr [rsp+0x140]
       vblendvps ymm0, ymm0, ymm15, ymm2
       vaddps   ymm0, ymm0, ymm5
       vmovups  ymm5, ymmword ptr [rsp+0xE0]
       vmulps   ymm0, ymm5, ymm0
       vmovups  ymm9, ymmword ptr [rsp+0x120]
       vandps   ymm0, ymm0, ymm9
       vandnps  ymm2, ymm9, ymm15
       vorps    ymm0, ymm2, ymm0
 
G_M000_IG08:                ;; offset=0x0825
       vaddps   ymm9, ymm0, ymmword ptr [rsp+0x240]
       cmp      eax, 1
       jne      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x0837
       vmulps   ymm0, ymm9, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rcx], ymm0
       mov      rax, rcx
 
G_M000_IG10:                ;; offset=0x0846
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x420]
       vmovaps  xmm7, xmmword ptr [rsp+0x410]
       vmovaps  xmm8, xmmword ptr [rsp+0x400]
       vmovaps  xmm9, xmmword ptr [rsp+0x3F0]
       vmovaps  xmm10, xmmword ptr [rsp+0x3E0]
       vmovaps  xmm11, xmmword ptr [rsp+0x3D0]
       vmovaps  xmm12, xmmword ptr [rsp+0x3C0]
       vmovaps  xmm13, xmmword ptr [rsp+0x3B0]
       vmovaps  xmm14, xmmword ptr [rsp+0x3A0]
       vmovaps  xmm15, xmmword ptr [rsp+0x390]
       add      rsp, 0x438
       ret      
 
RWD00  	dd	BF000000h		;      -0.5
RWD04  	dd	3F000000h		;       0.5
RWD08  	dd	4F000000h		; 2.14748e+09
RWD12  	dd	7FFFFFFFh		;       nan
RWD16  	dd	00000001h		; 1.4013e-45
RWD20  	dd	BF800000h		;        -1
RWD24  	dd	80000000h		;        -0
RWD28  	dd	00000000h
RWD32  	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD64  	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD96  	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD128 	dd	3F19999Ah		;       0.6
RWD132 	dd	3F400000h		;      0.75
RWD136 	dd	27D4EB2Dh		; 5.90968e-15
RWD140 	dd	000000FCh		; 3.53127e-43
RWD144 	dd	00000003h		; 4.2039e-45
RWD148 	dd	00000002h		; 2.8026e-45
RWD152 	dd	00000000h, 00000000h
RWD160 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD192 	dq	4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h

; Total bytes of code 2219

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 3 inlinees with PGO data; 182 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 544
       vmovaps  xmmword ptr [rsp+0x210], xmm6
       vmovaps  xmmword ptr [rsp+0x200], xmm7
       vmovaps  xmmword ptr [rsp+0x1F0], xmm8
       vmovaps  xmmword ptr [rsp+0x1E0], xmm9
       vmovaps  xmmword ptr [rsp+0x1D0], xmm10
       vmovaps  xmmword ptr [rsp+0x1C0], xmm11
       vmovaps  xmmword ptr [rsp+0x1B0], xmm12
       vmovaps  xmmword ptr [rsp+0x1A0], xmm13
       vmovaps  xmmword ptr [rsp+0x190], xmm14
       vmovaps  xmmword ptr [rsp+0x180], xmm15
       mov      rbx, rdx
       mov      rax, bword ptr [rsp+0x270]
 
G_M000_IG02:                ;; offset=0x0072
       mov      edx, dword ptr [rcx+0x64]
       vbroadcastss ymm0, dword ptr [rcx+0x0C]
       vmulps   ymm1, ymm0, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       dec      edx
       cmp      edx, 2
       jne      G_M000_IG17
 
G_M000_IG03:                ;; offset=0x00A2
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm1, ymm0, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD00]
       vsubps   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [r8], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x00D3
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       vmovups  ymm6, ymmword ptr [r8]
       vmovups  ymm7, ymmword ptr [r9]
       vmovups  ymm8, ymmword ptr [rax]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  ymm9, ymm6
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovss   xmm12, dword ptr [rcx+0x38]
       vmovss   dword ptr [rsp+0x14C], xmm12
       cmp      dword ptr [rsi], 0
       je       G_M000_IG15
       cmp      ebp, 1
       jle      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x011C
       vxorps   ymm6, ymm6, ymm6
       vmovups  ymmword ptr [rsp+0x110], ymm6
       vbroadcastss ymm7, dword ptr [rsi+0x18]
       vbroadcastss ymm8, dword ptr [rsi+0x08]
       vbroadcastss ymm13, dword ptr [rsi+0x0C]
       vmovups  ymmword ptr [rsp+0xF0], ymm13
       vbroadcastss ymm14, dword ptr [rsi+0x10]
       vmovups  ymmword ptr [rsp+0xD0], ymm14
       xor      r14d, r14d
       cmp      r14d, ebp
       jge      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x015F
       vucomiss xmm12, dword ptr [reloc @RWD32]
       jp       G_M000_IG24
       jne      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x0173
       lea      edx, [rdi+r14]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm9
       vmovups  ymmword ptr [rsp+0x50], ymm10
       vmovups  ymmword ptr [rsp+0x30], ymm11
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xB0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm6, ymm7
       vextractf128 xmm12, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rsi]
       cmp      edx, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm10, ymm10, xmm13
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm8, ymm8, xmm12
       je       G_M000_IG11
 
G_M000_IG08:                ;; offset=0x020C
       cmp      edx, 3
       je       G_M000_IG25
       vmulps   ymm0, ymm7, ymmword ptr [rsp+0xB0]
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
 
G_M000_IG09:                ;; offset=0x0241
       vsubps   ymm0, ymm0, ymm12
       vmovups  ymm14, ymmword ptr [rsp+0xD0]
       vmulps   ymm0, ymm0, ymm14
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       vmulps   ymm9, ymm9, ymm8
       vmulps   ymm10, ymm10, ymm8
       vmulps   ymm11, ymm11, ymm8
       vmovups  ymm13, ymmword ptr [rsp+0xF0]
       vmulps   ymm7, ymm7, ymm13
       inc      r14d
       cmp      r14d, ebp
       vmovss   xmm12, dword ptr [rsp+0x14C]
       jge      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x028B
       vmovups  ymmword ptr [rsp+0x110], ymm6
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x0299
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vsubps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
G_M000_IG12:                ;; offset=0x02E4
       vmovups  ymm6, ymmword ptr [rsp+0x110]
 
G_M000_IG13:                ;; offset=0x02ED
       vmovups  ymmword ptr [rbx], ymm6
       mov      rax, rbx
 
G_M000_IG14:                ;; offset=0x02F4
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x210]
       vmovaps  xmm7, xmmword ptr [rsp+0x200]
       vmovaps  xmm8, xmmword ptr [rsp+0x1F0]
       vmovaps  xmm9, xmmword ptr [rsp+0x1E0]
       vmovaps  xmm10, xmmword ptr [rsp+0x1D0]
       vmovaps  xmm11, xmmword ptr [rsp+0x1C0]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B0]
       vmovaps  xmm13, xmmword ptr [rsp+0x1A0]
       vmovaps  xmm14, xmmword ptr [rsp+0x190]
       vmovaps  xmm15, xmmword ptr [rsp+0x180]
       add      rsp, 544
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG15:                ;; offset=0x035F
       vmovd    xmm0, edi
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm6
       vmovups  ymmword ptr [rsp+0x50], ymm7
       vmovups  ymmword ptr [rsp+0x30], ymm8
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x150]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG23
       vbroadcastss ymm0, dword ptr [rsi+0x18]
       mov      eax, dword ptr [rsi]
       cmp      eax, 2
       je       G_M000_IG20
       cmp      eax, 3
       je       G_M000_IG22
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x150]
 
G_M000_IG16:                ;; offset=0x03D9
       vbroadcastss ymm0, ymm12
       vmulps   ymm6, ymm0, ymm1
       jmp      G_M000_IG13
 
G_M000_IG17:                ;; offset=0x03E7
       cmp      edx, 2
       ja       G_M000_IG04
       mov      edx, edx
       lea      r10, [reloc @RWD160]
       mov      r10d, dword ptr [r10+4*rdx]
       lea      r11, G_M000_IG02
       add      r10, r11
       jmp      r10
 
G_M000_IG18:                ;; offset=0x040A
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymm2, ymmword ptr [rax]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rax], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [rax]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vaddps   ymm1, ymm1, ymmword ptr [r9]
       vsubps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       jmp      G_M000_IG04
 
G_M000_IG19:                ;; offset=0x045D
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymm2, ymmword ptr [r9]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [r9], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [r9]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vsubps   ymm1, ymm1, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       jmp      G_M000_IG04
 
G_M000_IG20:                ;; offset=0x04B3
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm2, dword ptr [reloc @RWD32]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG16
 
G_M000_IG21:                ;; offset=0x04E2
       jmp      G_M000_IG07
 
G_M000_IG22:                ;; offset=0x04E7
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x150]
       vbroadcastss ymm3, dword ptr [rsi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD96], ymm4
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD288]
       vsubps   ymm3, ymm3, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD64]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG16
 
G_M000_IG23:                ;; offset=0x056C
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       jmp      G_M000_IG16
 
G_M000_IG24:                ;; offset=0x057A
       lea      edx, [rbp-0x01]
       cmp      r14d, edx
       jne      G_M000_IG21
       vbroadcastss ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       jmp      G_M000_IG07
 
G_M000_IG25:                ;; offset=0x0594
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vbroadcastss ymm1, dword ptr [rsi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD96], ymm2
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm12
       vbroadcastss ymm2, dword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
RWD00  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD32  	dd	3F800000h		;         1
RWD36  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD64  	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD96  	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD128 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h
RWD160 	dd	00000398h ; case G_M000_IG18
       	dd	000003EBh ; case G_M000_IG19
       	dd	00000030h ; case G_M000_IG03
RWD172 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD192 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD224 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD256 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD288 	dq	4000000040000000h, 4000000040000000h, 4000000040000000h, 4000000040000000h

; Total bytes of code 1589

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 29208
; 2 inlinees with PGO data; 295 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       sub      rsp, 0x438
       vmovaps  xmmword ptr [rsp+0x420], xmm6
       vmovaps  xmmword ptr [rsp+0x410], xmm7
       vmovaps  xmmword ptr [rsp+0x400], xmm8
       vmovaps  xmmword ptr [rsp+0x3F0], xmm9
       vmovaps  xmmword ptr [rsp+0x3E0], xmm10
       vmovaps  xmmword ptr [rsp+0x3D0], xmm11
       vmovaps  xmmword ptr [rsp+0x3C0], xmm12
       vmovaps  xmmword ptr [rsp+0x3B0], xmm13
       vmovaps  xmmword ptr [rsp+0x3A0], xmm14
       vmovaps  xmmword ptr [rsp+0x390], xmm15
       mov      rax, bword ptr [rsp+0x460]
 
G_M000_IG02:                ;; offset=0x0069
       vmovups  ymm0, ymmword ptr [r8]
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm0, ymm1
       vbroadcastss ymm2, dword ptr [reloc @RWD00]
       vbroadcastss ymm3, dword ptr [reloc @RWD04]
       vmovups  ymmword ptr [rsp+0xC0], ymm3
       vblendvps ymm1, ymm3, ymm2, ymm1
       vaddps   ymm1, ymm1, ymm0
       vcmpeqps ymm4, ymm1, ymm1
       vandps   ymm1, ymm4, ymm1
       vbroadcastss ymm4, dword ptr [reloc @RWD08]
       vcmpgeps ymm5, ymm1, ymm4
       vbroadcastss ymm6, dword ptr [reloc @RWD12]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymm6, ymm5
       vmovups  ymm5, ymmword ptr [r9]
       vxorps   ymm7, ymm7, ymm7
       vcmpltps ymm7, ymm5, ymm7
       vblendvps ymm7, ymm3, ymm2, ymm7
       vaddps   ymm7, ymm7, ymm5
       vcmpeqps ymm8, ymm7, ymm7
       vandps   ymm7, ymm8, ymm7
       vcmpgeps ymm8, ymm7, ymm4
       vcvttps2dq ymm7, ymm7
       vpblendvb ymm7, ymm7, ymm6, ymm8
       vmovups  ymm8, ymmword ptr [rax]
       vxorps   ymm9, ymm9, ymm9
       vcmpltps ymm9, ymm8, ymm9
       vblendvps ymm2, ymm3, ymm2, ymm9
       vaddps   ymm2, ymm2, ymm8
       vcmpeqps ymm9, ymm2, ymm2
       vandps   ymm2, ymm9, ymm2
       vcmpgeps ymm9, ymm2, ymm4
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm6, ymm9
       vcvtdq2ps ymm9, ymm1
       vsubps   ymm0, ymm0, ymm9
       vcvtdq2ps ymm9, ymm7
       vsubps   ymm5, ymm5, ymm9
       vcvtdq2ps ymm9, ymm2
       vsubps   ymm8, ymm8, ymm9
       vbroadcastss ymm9, dword ptr [reloc @RWD16]
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       vmovaps  ymm10, ymm9
       vbroadcastss ymm11, dword ptr [reloc @RWD20]
       vsubps   ymm12, ymm11, ymm0
       vcmpeqps ymm13, ymm12, ymm12
       vandps   ymm12, ymm13, ymm12
       vcmpgeps ymm13, ymm12, ymm4
       vcvttps2dq ymm12, ymm12
       vpblendvb ymm12, ymm12, ymm6, ymm13
       vpor     ymm12, ymm12, ymm10
       vsubps   ymm13, ymm11, ymm5
       vcmpeqps ymm14, ymm13, ymm13
       vandps   ymm13, ymm14, ymm13
       vcmpgeps ymm14, ymm13, ymm4
       vcvttps2dq ymm13, ymm13
       vpblendvb ymm13, ymm13, ymm6, ymm14
       vpor     ymm13, ymm13, ymm10
       vsubps   ymm11, ymm11, ymm8
       vcmpeqps ymm14, ymm11, ymm11
       vandps   ymm11, ymm14, ymm11
 
G_M000_IG03:                ;; offset=0x01BB
       vcmpgeps ymm4, ymm11, ymm4
       vcvttps2dq ymm11, ymm11
       vpblendvb ymm4, ymm11, ymm6, ymm4
       vpor     ymm4, ymm4, ymm10
       vbroadcastss ymm6, dword ptr [reloc @RWD24]
       vxorps   ymm10, ymm6, ymm0
       vcvtdq2ps ymm11, ymm12
       vmulps   ymm10, ymm10, ymm11
       vxorps   ymm11, ymm6, ymm5
       vcvtdq2ps ymm14, ymm13
       vmulps   ymm11, ymm11, ymm14
       vxorps   ymm14, ymm6, ymm8
       vcvtdq2ps ymm15, ymm4
       vmulps   ymm14, ymm14, ymm15
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD32]
       vpmulld  ymm7, ymm7, ymmword ptr [reloc @RWD64]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD96]
       vbroadcastss ymm15, dword ptr [reloc @RWD32]
       vmovups  ymmword ptr [rsp+0x2A0], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rsp+0x280], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0x260], ymm15
       vxorps   ymm15, ymm15, ymm15
       vxorps   ymm9, ymm9, ymm9
       vmovups  ymmword ptr [rsp+0x2E0], ymm5
       vmulps   ymm3, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0x370], ymm3
       vmovups  ymmword ptr [rsp+0x2C0], ymm8
       vmulps   ymm3, ymm8, ymm8
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x370], ymm3
       vmovups  ymmword ptr [rsp+0x300], ymm0
       vmulps   ymm3, ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x350], ymm3
       vbroadcastss ymm3, dword ptr [reloc @RWD128]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x350]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x370]
       xor      eax, eax
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
       jmp      G_M000_IG05
 
G_M000_IG04:                ;; offset=0x02D9
       vmovups  ymm0, ymmword ptr [rsp+0xC0]
       vsubps   ymm10, ymm0, ymm10
       vsubps   ymm11, ymm0, ymm11
       vsubps   ymm14, ymm0, ymm14
       vcvtdq2ps ymm2, ymm12
       vmulps   ymm2, ymm2, ymm10
       vmovups  ymmword ptr [rsp+0x300], ymm2
       vcvtdq2ps ymm5, ymm13
       vmulps   ymm5, ymm5, ymm11
       vcvtdq2ps ymm8, ymm4
       vmulps   ymm8, ymm8, ymm14
       vaddps   ymm0, ymm11, ymm14
       vmovups  ymmword ptr [rsp+0x370], ymm0
       vbroadcastss ymm0, dword ptr [reloc @RWD132]
       vsubps   ymm0, ymm0, ymm10
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x370]
       vaddps   ymm3, ymm0, ymm3
       vpsrad   ymm0, ymm12, 1
       vpand    ymm0, ymm0, ymmword ptr [rsp+0x2A0]
       vpaddd   ymm1, ymm0, ymm1
       vpsrad   ymm0, ymm13, 1
       vpand    ymm0, ymm0, ymmword ptr [rsp+0x280]
       vpaddd   ymm7, ymm0, ymm7
       vpsrad   ymm0, ymm4, 1
       vpand    ymm0, ymm0, ymmword ptr [rsp+0x260]
       vpaddd   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm12, ymm2, ymm12
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm13, ymm2, ymm13
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm4, ymm2, ymm4
       vpcmpeqd ymm2, ymm2, ymm2
       vpxor    ymm2, ymm2, ymmword ptr [rsp+0x80]
       vmovups  ymmword ptr [rdx], ymm2
       inc      eax
       vmovups  ymmword ptr [rsp+0x2E0], ymm5
       vmovups  ymmword ptr [rsp+0x2C0], ymm8
       vmovaps  ymm2, ymm0
 
G_M000_IG05:                ;; offset=0x03C0
       vcmpgtps ymm8, ymm3, ymm15
       vmovups  ymmword ptr [rsp+0x220], ymm8
       vmulps   ymm8, ymm3, ymm3
       vmulps   ymm8, ymm8, ymm8
       vmovups  ymmword ptr [rsp+0x100], ymm8
       vmovups  ymm8, ymmword ptr [rdx]
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vpxor    ymm8, ymm1, ymm8
       vpxor    ymm8, ymm8, ymm7
       vmovups  ymmword ptr [rsp+0x320], ymm2
       vpxor    ymm8, ymm8, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm8
       vbroadcastss ymm8, dword ptr [reloc @RWD136]
       vmovups  ymmword ptr [rsp+0x60], ymm8
       vmovups  ymm8, ymmword ptr [rsp+0x370]
       vpmulld  ymm8, ymm8, ymmword ptr [rsp+0x60]
       vpsrad   ymm5, ymm8, 15
       vpxor    ymm5, ymm5, ymm8
       vbroadcastss ymm8, dword ptr [reloc @RWD140]
       vmovups  ymmword ptr [rsp+0x40], ymm8
       vpand    ymm5, ymm5, ymm8
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm5, ymm5, 2
       vpcmpeqd ymm8, ymm8, ymm8
       vpgatherdd ymm0, dword ptr [r10+4*xmm5], ymm8
       vbroadcastss ymm5, dword ptr [reloc @RWD144]
       vmovups  ymmword ptr [rsp+0x20], ymm5
       vpand    ymm8, ymm5, ymm0
       vxorps   ymm5, ymm5, ymm5
       vpcmpeqd ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0x370], ymm5
       vpslld   ymm5, ymm0, 29
       vpand    ymm5, ymm5, ymm6
       vpxor    ymm5, ymm5, ymmword ptr [rsp+0x300]
       vmovups  ymm2, ymmword ptr [rsp+0x370]
       vblendvps ymm2, ymm5, ymm15, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm2
       vmovups  ymm5, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0x350], ymm5
       vpslld   ymm2, ymm0, 28
       vpand    ymm2, ymm2, ymm6
       vpxor    ymm2, ymm2, ymmword ptr [rsp+0x2E0]
       vmovups  ymm5, ymmword ptr [rsp+0x350]
       vblendvps ymm2, ymm2, ymm15, ymm5
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x370]
       vbroadcastss ymm5, dword ptr [reloc @RWD148]
       vmovups  ymmword ptr [rsp], ymm5
       vpcmpeqd ymm8, ymm5, ymm8
       vpslld   ymm0, ymm0, 27
       vpand    ymm0, ymm0, ymm6
       vpxor    ymm0, ymm0, ymmword ptr [rsp+0x2C0]
       vblendvps ymm0, ymm0, ymm15, ymm8
       vaddps   ymm0, ymm0, ymm2
       vmovups  ymm8, ymmword ptr [rsp+0x100]
       vmulps   ymm0, ymm8, ymm0
       vmovups  ymm8, ymmword ptr [rsp+0x220]
 
G_M000_IG06:                ;; offset=0x0537
       vandps   ymm0, ymm0, ymm8
       vandnps  ymm2, ymm8, ymm15
       vorps    ymm0, ymm2, ymm0
       vaddps   ymm9, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0x240], ymm9
       vcmpnltps ymm0, ymm10, ymm11
       vcmpnltps ymm2, ymm10, ymm14
       vpand    ymm0, ymm2, ymm0
       vcmpgtps ymm2, ymm11, ymm10
       vcmpnltps ymm8, ymm11, ymm14
       vpand    ymm2, ymm8, ymm2
       vpandn   ymm2, ymm0, ymm2
       vpor     ymm8, ymm0, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm8
       vpcmpeqd ymm8, ymm8, ymm8
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x370]
       vandps   ymm5, ymm10, ymm0
       vmovups  ymmword ptr [rsp+0x370], ymm5
       vandps   ymm5, ymm11, ymm2
       vmovups  ymmword ptr [rsp+0x350], ymm5
       vandnps  ymm5, ymm2, ymm14
       vorps    ymm5, ymm5, ymmword ptr [rsp+0x350]
       vandnps  ymm5, ymm0, ymm5
       vorps    ymm5, ymm5, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x200], ymm5
       vaddps   ymm5, ymm3, ymm5
       vaddps   ymm5, ymm5, ymmword ptr [rsp+0x200]
       vsubps   ymm5, ymm5, ymmword ptr [reloc @RWD160]
       vpmulld  ymm9, ymm12, ymmword ptr [rsp+0x2A0]
       vpand    ymm9, ymm9, ymm0
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm0, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x370]
       vpsubd   ymm9, ymm1, ymm9
       vmovups  ymmword ptr [rsp+0x1E0], ymm9
       vpmulld  ymm9, ymm13, ymmword ptr [rsp+0x280]
       vpand    ymm9, ymm9, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm2, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x370]
       vpsubd   ymm9, ymm7, ymm9
       vmovups  ymmword ptr [rsp+0x1C0], ymm9
       vpmulld  ymm9, ymm4, ymmword ptr [rsp+0x260]
       vpand    ymm9, ymm9, ymm8
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm8, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x320]
       vpsubd   ymm9, ymm9, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x1A0], ymm9
       vcvtdq2ps ymm9, ymm12
       vandps   ymm9, ymm9, ymm0
       vandnps  ymm0, ymm0, ymm15
       vorps    ymm0, ymm0, ymm9
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x300]
 
G_M000_IG07:                ;; offset=0x06C0
       vmovups  ymmword ptr [rsp+0x180], ymm0
       vcvtdq2ps ymm9, ymm13
       vandps   ymm9, ymm9, ymm2
       vandnps  ymm2, ymm2, ymm15
       vorps    ymm2, ymm2, ymm9
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x160], ymm2
       vcvtdq2ps ymm9, ymm4
       vandps   ymm9, ymm9, ymm8
       vandnps  ymm8, ymm8, ymm15
       vorps    ymm8, ymm8, ymm9
       vaddps   ymm8, ymm8, ymmword ptr [rsp+0x2C0]
       vmovups  ymmword ptr [rsp+0x140], ymm8
       vcmpgtps ymm9, ymm5, ymm15
       vmovups  ymmword ptr [rsp+0x120], ymm9
       vmulps   ymm5, ymm5, ymm5
       vmulps   ymm5, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0xE0], ymm5
       vmovups  ymm8, ymmword ptr [rsp+0x1E0]
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x80]
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x1C0]
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x1A0]
       vpmulld  ymm8, ymm8, ymmword ptr [rsp+0x60]
       vpsrad   ymm2, ymm8, 15
       vpxor    ymm2, ymm2, ymm8
       vpand    ymm8, ymm2, ymmword ptr [rsp+0x40]
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm2, ymm8, 2
       vpcmpeqd ymm8, ymm8, ymm8
       vpgatherdd ymm0, dword ptr [r10+4*xmm2], ymm8
       vmovups  ymm2, ymmword ptr [rsp+0x20]
       vpand    ymm2, ymm2, ymm0
       vxorps   ymm8, ymm8, ymm8
       vpcmpeqd ymm8, ymm8, ymm2
       vpslld   ymm9, ymm0, 29
       vpand    ymm9, ymm9, ymm6
       vpxor    ymm9, ymm9, ymmword ptr [rsp+0x180]
       vblendvps ymm8, ymm9, ymm15, ymm8
       vmovups  ymm9, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm9, ymm9, ymm2
       vpslld   ymm5, ymm0, 28
       vpand    ymm5, ymm5, ymm6
       vpxor    ymm5, ymm5, ymmword ptr [rsp+0x160]
       vblendvps ymm5, ymm5, ymm15, ymm9
       vaddps   ymm5, ymm5, ymm8
       vmovups  ymm8, ymmword ptr [rsp]
       vpcmpeqd ymm2, ymm8, ymm2
       vpslld   ymm0, ymm0, 27
       vpand    ymm0, ymm0, ymm6
       vpxor    ymm0, ymm0, ymmword ptr [rsp+0x140]
       vblendvps ymm0, ymm0, ymm15, ymm2
       vaddps   ymm0, ymm0, ymm5
       vmovups  ymm5, ymmword ptr [rsp+0xE0]
       vmulps   ymm0, ymm5, ymm0
       vmovups  ymm9, ymmword ptr [rsp+0x120]
       vandps   ymm0, ymm0, ymm9
       vandnps  ymm2, ymm9, ymm15
       vorps    ymm0, ymm2, ymm0
 
G_M000_IG08:                ;; offset=0x0825
       vaddps   ymm9, ymm0, ymmword ptr [rsp+0x240]
       cmp      eax, 1
       jne      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x0837
       vmulps   ymm0, ymm9, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rcx], ymm0
       mov      rax, rcx
 
G_M000_IG10:                ;; offset=0x0846
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x420]
       vmovaps  xmm7, xmmword ptr [rsp+0x410]
       vmovaps  xmm8, xmmword ptr [rsp+0x400]
       vmovaps  xmm9, xmmword ptr [rsp+0x3F0]
       vmovaps  xmm10, xmmword ptr [rsp+0x3E0]
       vmovaps  xmm11, xmmword ptr [rsp+0x3D0]
       vmovaps  xmm12, xmmword ptr [rsp+0x3C0]
       vmovaps  xmm13, xmmword ptr [rsp+0x3B0]
       vmovaps  xmm14, xmmword ptr [rsp+0x3A0]
       vmovaps  xmm15, xmmword ptr [rsp+0x390]
       add      rsp, 0x438
       ret      
 
RWD00  	dd	BF000000h		;      -0.5
RWD04  	dd	3F000000h		;       0.5
RWD08  	dd	4F000000h		; 2.14748e+09
RWD12  	dd	7FFFFFFFh		;       nan
RWD16  	dd	00000001h		; 1.4013e-45
RWD20  	dd	BF800000h		;        -1
RWD24  	dd	80000000h		;        -0
RWD28  	dd	00000000h
RWD32  	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD64  	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD96  	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD128 	dd	3F19999Ah		;       0.6
RWD132 	dd	3F400000h		;      0.75
RWD136 	dd	27D4EB2Dh		; 5.90968e-15
RWD140 	dd	000000FCh		; 3.53127e-43
RWD144 	dd	00000003h		; 4.2039e-45
RWD148 	dd	00000002h		; 2.8026e-45
RWD152 	dd	00000000h, 00000000h
RWD160 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD192 	dq	4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h

; Total bytes of code 2219

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:Sample3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 11 inlinees with PGO data; 932 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 0xCF0
       vmovaps  xmmword ptr [rsp+0xCE0], xmm6
       vmovaps  xmmword ptr [rsp+0xCD0], xmm7
       vmovaps  xmmword ptr [rsp+0xCC0], xmm8
       vmovaps  xmmword ptr [rsp+0xCB0], xmm9
       vmovaps  xmmword ptr [rsp+0xCA0], xmm10
       vmovaps  xmmword ptr [rsp+0xC90], xmm11
       vmovaps  xmmword ptr [rsp+0xC80], xmm12
       vmovaps  xmmword ptr [rsp+0xC70], xmm13
       vmovaps  xmmword ptr [rsp+0xC60], xmm14
       vmovaps  xmmword ptr [rsp+0xC50], xmm15
       lea      rbp, [rsp+0xD20]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x8B0], xmm4
       vmovdqa  xmmword ptr [rbp-0x8A0], xmm4
       mov      rax, -0x720
       vmovdqa  xmmword ptr [rbp+rax-0x170], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x160], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x150], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rbx, rdx
       mov      rax, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x00B9
       mov      edx, dword ptr [rcx+0x64]
       vbroadcastss ymm1, dword ptr [rcx+0x0C]
       vmulps   ymm0, ymm1, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
       dec      edx
       cmp      edx, 2
       jne      G_M000_IG20
 
G_M000_IG03:                ;; offset=0x00E9
       vmovups  ymm1, ymmword ptr [r8]
       vaddps   ymm0, ymm1, ymmword ptr [r9]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vsubps   ymm1, ymm0, ymm1
       vmovups  ymmword ptr [r8], ymm1
       vsubps   ymm1, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm1
       vsubps   ymm1, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
 
G_M000_IG04:                ;; offset=0x011A
       lea      rsi, bword ptr [rcx+0x60]
       lea      rdi, bword ptr [rcx+0x74]
       mov      r14d, dword ptr [rcx+0x08]
       vmovups  ymm6, ymmword ptr [r8]
       vmovups  ymm7, ymmword ptr [r9]
       vmovups  ymm8, ymmword ptr [rax]
       mov      r15d, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovups  ymmword ptr [rbp-0x110], ymm6
       vmovups  ymmword ptr [rbp-0x130], ymm7
       vmovups  ymmword ptr [rbp-0x150], ymm8
       vmovss   xmm9, dword ptr [rcx+0x38]
       cmp      dword ptr [rdi], 0
       je       G_M000_IG16
       cmp      r15d, 1
       jle      G_M000_IG16
 
G_M000_IG05:                ;; offset=0x016C
       lea      rcx, [rbp-0x1D0]
       vxorps   xmm1, xmm1, xmm1
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       mov      rcx, rdi
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Bounding():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       mov      rcx, rdi
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Lacunarity():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x210]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       mov      rcx, rdi
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Gain():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x230]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       mov      rcx, rdi
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_WeightedStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x250]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       xor      r13d, r13d
       cmp      r13d, r15d
       jge      G_M000_IG11
 
G_M000_IG06:                ;; offset=0x01F1
       vmovss   xmm6, dword ptr [reloc @RWD32]
       vucomiss xmm9, xmm6
       jp       G_M000_IG45
       jne      G_M000_IG45
 
G_M000_IG07:                ;; offset=0x0209
       lea      edx, [r14+r13]
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0xB70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0xB90], ymm0
       lea      r9, [rbp-0xB50]
       lea      rcx, [rbp-0xB70]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xB90]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x290]
       lea      r8, [rbp-0x270]
       mov      rdx, rsi
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Single3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rcx, rdi
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       cmp      eax, 2
       je       G_M000_IG14
 
G_M000_IG08:                ;; offset=0x0292
       cmp      eax, 3
       je       G_M000_IG46
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0xB70], ymm0
       lea      rdx, [rbp-0xB50]
       lea      r8, [rbp-0xB70]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       lea      rcx, [rbp-0x1D0]
       lea      r8, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x510]
       vmovaps  xmm1, xmm6
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x530]
       lea      rdx, [rbp-0x290]
       lea      r8, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x550]
       vmovss   xmm1, dword ptr [reloc @RWD36]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x370]
       lea      rdx, [rbp-0x530]
       lea      r8, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG09:                ;; offset=0x035D
       lea      rcx, [rbp-0x390]
       vmovaps  xmm1, xmm6
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      r9, [rbp-0xB50]
       lea      rdx, [rbp-0x390]
       lea      r8, [rbp-0x370]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.NoiseMath:Lerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       lea      rcx, [rbp-0x1F0]
       lea      r8, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0xB70], ymm0
       lea      rdx, [rbp-0xB50]
       lea      r8, [rbp-0xB70]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0xB70], ymm0
       lea      rdx, [rbp-0xB50]
       lea      r8, [rbp-0xB70]
       lea      rcx, [rbp-0x130]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0xB70], ymm0
       lea      rdx, [rbp-0xB50]
       lea      r8, [rbp-0xB70]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0xB70], ymm0
       lea      rdx, [rbp-0xB50]
 
G_M000_IG10:                ;; offset=0x04A3
       lea      r8, [rbp-0xB70]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       inc      r13d
       cmp      r13d, r15d
       jl       G_M000_IG06
 
G_M000_IG11:                ;; offset=0x04C3
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
 
G_M000_IG12:                ;; offset=0x04D3
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbx], ymm0
       mov      rax, rbx
 
G_M000_IG13:                ;; offset=0x04E2
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0xCE0]
       vmovaps  xmm7, xmmword ptr [rsp+0xCD0]
       vmovaps  xmm8, xmmword ptr [rsp+0xCC0]
       vmovaps  xmm9, xmmword ptr [rsp+0xCB0]
       vmovaps  xmm10, xmmword ptr [rsp+0xCA0]
       vmovaps  xmm11, xmmword ptr [rsp+0xC90]
       vmovaps  xmm12, xmmword ptr [rsp+0xC80]
       vmovaps  xmm13, xmmword ptr [rsp+0xC70]
       vmovaps  xmm14, xmmword ptr [rsp+0xC60]
       vmovaps  xmm15, xmmword ptr [rsp+0xC50]
       add      rsp, 0xCF0
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x0551
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Abs(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x2B0]
       vmovss   xmm1, dword ptr [reloc @RWD40]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       lea      rcx, [rbp-0x2D0]
       lea      r8, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x2F0]
       vmovaps  xmm1, xmm6
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x310]
       lea      rdx, [rbp-0x2D0]
       lea      r8, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      r8, [rbp-0xB50]
       lea      rdx, [rbp-0x310]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       lea      rcx, [rbp-0x1D0]
       lea      r8, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x350]
       vmovaps  xmm1, xmm6
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x370]
       lea      rdx, [rbp-0x350]
       lea      r8, [rbp-0x290]
 
G_M000_IG15:                ;; offset=0x065D
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       jmp      G_M000_IG09
 
G_M000_IG16:                ;; offset=0x0668
       vmovd    xmm0, r14d
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rbp-0x170], ymm0
       mov      r8d, dword ptr [rsi]
       test     r8d, r8d
       jne      G_M000_IG23
 
G_M000_IG17:                ;; offset=0x0686
       vmovups  ymmword ptr [rbp-0xB50], ymm6
       vmovups  ymmword ptr [rbp-0xB70], ymm7
       vmovups  ymmword ptr [rbp-0xB90], ymm8
       lea      r8, [rbp-0xB50]
       lea      r9, [rbp-0xB70]
       lea      rdx, [rbp-0xB90]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG18:                ;; offset=0x06CC
       mov      rcx, rdi
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_Type():int:this]
       test     eax, eax
       je       G_M000_IG44
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      r8, [rbp-0xB50]
       lea      rcx, [rbp-0x190]
       mov      rdx, rdi
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:ShapeSingle[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG19:                ;; offset=0x0704
       lea      rcx, [rbp-0x1B0]
       vmovaps  xmm1, xmm9
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xF0]
       lea      rdx, [rbp-0x190]
       lea      r8, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       jmp      G_M000_IG12
 
G_M000_IG20:                ;; offset=0x0736
       cmp      edx, 2
       ja       G_M000_IG04
       mov      edx, edx
       lea      r10, [reloc @RWD44]
       mov      r10d, dword ptr [r10+4*rdx]
       lea      r11, G_M000_IG02
       add      r10, r11
       jmp      r10
 
G_M000_IG21:                ;; offset=0x0759
       vmovups  ymm1, ymmword ptr [r8]
       vaddps   ymm1, ymm1, ymmword ptr [r9]
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD64]
       vmovups  ymm2, ymmword ptr [rax]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rax], ymm2
       vsubps   ymm2, ymm0, ymmword ptr [rax]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vsubps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [r9], ymm0
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD96]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
       jmp      G_M000_IG04
 
G_M000_IG22:                ;; offset=0x07AC
       vmovups  ymm1, ymmword ptr [r8]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmulps   ymm0, ymm1, ymmword ptr [reloc @RWD64]
       vmovups  ymm2, ymmword ptr [r9]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [r9], ymm2
       vsubps   ymm2, ymm0, ymmword ptr [r9]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vsubps   ymm0, ymm0, ymmword ptr [r9]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD96]
       vaddps   ymm1, ymm1, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm1
       jmp      G_M000_IG04
 
G_M000_IG23:                ;; offset=0x0802
       cmp      r8d, 5
       ja       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0808
       mov      r8d, r8d
       lea      r9, [reloc @RWD128]
       mov      r9d, dword ptr [r9+4*r8]
       lea      rdx, G_M000_IG02
       add      r9, rdx
       jmp      r9
 
G_M000_IG25:                ;; offset=0x0823
       lea      rcx, [rbp-0x590]
       vxorps   xmm1, xmm1, xmm1
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       jmp      G_M000_IG18
 
G_M000_IG26:                ;; offset=0x0839
       vmovups  ymmword ptr [rbp-0xB50], ymm6
       vmovups  ymmword ptr [rbp-0xB70], ymm7
       vmovups  ymmword ptr [rbp-0xB90], ymm8
       mov      r8d, dword ptr [rsi+0x08]
       mov      dword ptr [rsp+0x28], r8d
       mov      r8d, dword ptr [rsi+0x0C]
       mov      dword ptr [rsp+0x30], r8d
       vmovss   xmm0, dword ptr [rsi+0x10]
       vmovss   dword ptr [rsp+0x38], xmm0
       lea      r8, [rbp-0xB50]
       lea      r9, [rbp-0xB70]
       lea      rcx, [rbp-0xB90]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x590]
       lea      rdx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.Kernels.CellularKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,int,float):System.Numerics.Vector`1[float]]
       jmp      G_M000_IG18
 
G_M000_IG27:                ;; offset=0x08A1
       vcmpeqps ymm0, ymm6, ymm6
       vandps   ymm0, ymm0, ymm6
       vcmpgeps ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymmword ptr [reloc @RWD192], ymm1
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm6, ymm1
       vpaddd   ymm0, ymm1, ymm0
       vcmpeqps ymm1, ymm7, ymm7
       vandps   ymm1, ymm1, ymm7
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD192], ymm2
       vxorps   ymm2, ymm2, ymm2
       vcmpltps ymm2, ymm7, ymm2
       vpaddd   ymm1, ymm2, ymm1
       vcmpeqps ymm2, ymm8, ymm8
       vandps   ymm2, ymm2, ymm8
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD160]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD192], ymm3
       vxorps   ymm3, ymm3, ymm3
       vcmpltps ymm3, ymm8, ymm3
       vpaddd   ymm2, ymm3, ymm2
       vcvtdq2ps ymm3, ymm0
       vsubps   ymm3, ymm6, ymm3
       vmovups  ymmword ptr [rbp-0x5D0], ymm3
       vcvtdq2ps ymm4, ymm1
       vsubps   ymm4, ymm7, ymm4
       vcvtdq2ps ymm5, ymm2
       vsubps   ymm5, ymm8, ymm5
       vsubps   ymm6, ymm3, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rbp-0x5F0], ymm6
       vsubps   ymm7, ymm4, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rbp-0x610], ymm7
       vsubps   ymm8, ymm5, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rbp-0x630], ymm8
       vmulps   ymm10, ymm3, ymm3
       vmulps   ymm10, ymm10, ymm3
       vmulps   ymm11, ymm3, ymmword ptr [reloc @RWD256]
       vsubps   ymm11, ymm11, ymmword ptr [reloc @RWD288]
       vmulps   ymm11, ymm11, ymm3
       vaddps   ymm11, ymm11, ymmword ptr [reloc @RWD320]
       vmulps   ymm10, ymm11, ymm10
       vmulps   ymm11, ymm4, ymm4
       vmulps   ymm11, ymm11, ymm4
       vmulps   ymm12, ymm4, ymmword ptr [reloc @RWD256]
       vsubps   ymm12, ymm12, ymmword ptr [reloc @RWD288]
       vmulps   ymm12, ymm12, ymm4
       vaddps   ymm12, ymm12, ymmword ptr [reloc @RWD320]
       vmulps   ymm11, ymm12, ymm11
       vmovups  ymmword ptr [rbp-0x650], ymm11
       vmulps   ymm12, ymm5, ymm5
       vmulps   ymm12, ymm12, ymm5
       vmulps   ymm13, ymm5, ymmword ptr [reloc @RWD256]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD288]
       vmulps   ymm13, ymm13, ymm5
       vaddps   ymm13, ymm13, ymmword ptr [reloc @RWD320]
       vmulps   ymm12, ymm13, ymm12
       vmovups  ymmword ptr [rbp-0x670], ymm12
 
G_M000_IG28:                ;; offset=0x0A05
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD352]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD384]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD416]
       vpaddd   ymm13, ymm0, ymmword ptr [reloc @RWD352]
       vpaddd   ymm14, ymm1, ymmword ptr [reloc @RWD384]
       vpaddd   ymm15, ymm2, ymmword ptr [reloc @RWD416]
       vmovups  ymmword ptr [rbp-0x690], ymm15
       vpxor    ymm12, ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm12, ymm12, ymm1
       vpxor    ymm12, ymm12, ymm2
       vpmulld  ymm12, ymm12, ymmword ptr [reloc @RWD448]
       vpsrad   ymm11, ymm12, 15
       vpxor    ymm12, ymm11, ymm12
       vpand    ymm12, ymm12, ymmword ptr [reloc @RWD480]
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
       add      r8, 16
       vpsrld   ymm11, ymm12, 2
       vpcmpeqd ymm12, ymm12, ymm12
       vpgatherdd ymm8, dword ptr [r8+4*xmm11], ymm12
       vpand    ymm11, ymm8, ymmword ptr [reloc @RWD512]
       vxorps   ymm12, ymm12, ymm12
       vxorps   ymm15, ymm15, ymm15
       vpcmpeqd ymm15, ymm15, ymm11
       vpslld   ymm7, ymm8, 29
       vpand    ymm7, ymm7, ymmword ptr [reloc @RWD544]
       vpxor    ymm7, ymm7, ymm3
       vblendvps ymm7, ymm7, ymm12, ymm15
       vpcmpeqd ymm15, ymm11, ymmword ptr [reloc @RWD576]
       vpslld   ymm3, ymm8, 28
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD544]
       vpxor    ymm3, ymm3, ymm4
       vblendvps ymm3, ymm3, ymm12, ymm15
       vaddps   ymm3, ymm3, ymm7
       vpcmpeqd ymm7, ymm11, ymmword ptr [reloc @RWD608]
       vpslld   ymm8, ymm8, 27
       vpand    ymm8, ymm8, ymmword ptr [reloc @RWD544]
       vpxor    ymm8, ymm8, ymm5
       vblendvps ymm7, ymm8, ymm12, ymm7
       vaddps   ymm3, ymm7, ymm3
       vpxor    ymm7, ymm13, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x5B0], ymm1
       vpxor    ymm7, ymm7, ymm1
       vpxor    ymm7, ymm7, ymm2
       vpmulld  ymm7, ymm7, ymmword ptr [reloc @RWD448]
       vpsrad   ymm8, ymm7, 15
       vpxor    ymm7, ymm8, ymm7
       vpand    ymm7, ymm7, ymmword ptr [reloc @RWD480]
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
       add      r8, 16
       vpsrld   ymm7, ymm7, 2
       vpcmpeqd ymm8, ymm8, ymm8
       vpgatherdd ymm11, dword ptr [r8+4*xmm7], ymm8
       vpand    ymm7, ymm11, ymmword ptr [reloc @RWD512]
       vxorps   ymm8, ymm8, ymm8
       vxorps   ymm12, ymm12, ymm12
       vpcmpeqd ymm12, ymm12, ymm7
 
G_M000_IG29:                ;; offset=0x0B6E
       vpslld   ymm15, ymm11, 29
       vpand    ymm15, ymm15, ymmword ptr [reloc @RWD544]
       vpxor    ymm15, ymm15, ymm6
       vblendvps ymm12, ymm15, ymm8, ymm12
       vpcmpeqd ymm15, ymm7, ymmword ptr [reloc @RWD576]
       vpslld   ymm1, ymm11, 28
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD544]
       vpxor    ymm1, ymm1, ymm4
       vblendvps ymm1, ymm1, ymm8, ymm15
       vaddps   ymm1, ymm1, ymm12
       vpcmpeqd ymm7, ymm7, ymmword ptr [reloc @RWD608]
       vpslld   ymm11, ymm11, 27
       vpand    ymm11, ymm11, ymmword ptr [reloc @RWD544]
       vpxor    ymm11, ymm11, ymm5
       vblendvps ymm7, ymm11, ymm8, ymm7
       vaddps   ymm1, ymm7, ymm1
       vsubps   ymm1, ymm1, ymm3
       vmulps   ymm1, ymm1, ymm10
       vaddps   ymm1, ymm1, ymm3
       vmovups  ymmword ptr [rbp-0x6B0], ymm1
       vpxor    ymm3, ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm3, ymm3, ymm14
       vpxor    ymm3, ymm3, ymm2
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD448]
       vpsrad   ymm7, ymm3, 15
       vpxor    ymm3, ymm7, ymm3
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD480]
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
       add      r8, 16
       vpsrld   ymm3, ymm3, 2
       vpcmpeqd ymm7, ymm7, ymm7
       vpgatherdd ymm8, dword ptr [r8+4*xmm3], ymm7
       vpand    ymm3, ymm8, ymmword ptr [reloc @RWD512]
       vxorps   ymm7, ymm7, ymm7
       vxorps   ymm11, ymm11, ymm11
       vpcmpeqd ymm11, ymm11, ymm3
       vpslld   ymm12, ymm8, 29
       vpand    ymm12, ymm12, ymmword ptr [reloc @RWD544]
       vmovups  ymm15, ymmword ptr [rbp-0x5D0]
       vpxor    ymm12, ymm12, ymm15
       vblendvps ymm11, ymm12, ymm7, ymm11
       vpcmpeqd ymm12, ymm3, ymmword ptr [reloc @RWD576]
       vpslld   ymm1, ymm8, 28
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD544]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x610]
       vblendvps ymm1, ymm1, ymm7, ymm12
       vaddps   ymm1, ymm1, ymm11
       vpcmpeqd ymm3, ymm3, ymmword ptr [reloc @RWD608]
       vpslld   ymm8, ymm8, 27
       vpand    ymm8, ymm8, ymmword ptr [reloc @RWD544]
       vpxor    ymm8, ymm8, ymm5
       vblendvps ymm3, ymm8, ymm7, ymm3
       vaddps   ymm1, ymm3, ymm1
       vpxor    ymm3, ymm13, ymmword ptr [rbp-0x170]
       vpxor    ymm3, ymm3, ymm14
       vpxor    ymm2, ymm3, ymm2
 
G_M000_IG30:                ;; offset=0x0CC3
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD448]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD480]
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
       add      r8, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm7, dword ptr [r8+4*xmm2], ymm3
       vpand    ymm2, ymm7, ymmword ptr [reloc @RWD512]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm8, ymm8, ymm8
       vpcmpeqd ymm8, ymm8, ymm2
       vpslld   ymm11, ymm7, 29
       vpand    ymm11, ymm11, ymmword ptr [reloc @RWD544]
       vpxor    ymm11, ymm11, ymm6
       vblendvps ymm8, ymm11, ymm3, ymm8
       vpcmpeqd ymm11, ymm2, ymmword ptr [reloc @RWD576]
       vpslld   ymm12, ymm7, 28
       vpand    ymm12, ymm12, ymmword ptr [reloc @RWD544]
       vpxor    ymm12, ymm12, ymmword ptr [rbp-0x610]
       vblendvps ymm11, ymm12, ymm3, ymm11
       vaddps   ymm8, ymm11, ymm8
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm7, ymm7, 27
       vpand    ymm7, ymm7, ymmword ptr [reloc @RWD544]
       vpxor    ymm5, ymm7, ymm5
       vblendvps ymm2, ymm5, ymm3, ymm2
       vaddps   ymm2, ymm2, ymm8
       vsubps   ymm2, ymm2, ymm1
       vmulps   ymm2, ymm2, ymm10
       vaddps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rbp-0x6D0], ymm1
       vpxor    ymm2, ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x5B0]
       vmovups  ymm5, ymmword ptr [rbp-0x690]
       vpxor    ymm2, ymm2, ymm5
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD448]
       vpsrad   ymm7, ymm2, 15
       vpxor    ymm2, ymm7, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD480]
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
       add      r8, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm7, ymm7, ymm7
       vpgatherdd ymm8, dword ptr [r8+4*xmm2], ymm7
       vpand    ymm2, ymm8, ymmword ptr [reloc @RWD512]
       vxorps   ymm7, ymm7, ymm7
       vxorps   ymm11, ymm11, ymm11
       vpcmpeqd ymm11, ymm11, ymm2
       vpslld   ymm12, ymm8, 29
       vpand    ymm12, ymm12, ymmword ptr [reloc @RWD544]
       vpxor    ymm12, ymm12, ymm15
       vblendvps ymm11, ymm12, ymm7, ymm11
       vpcmpeqd ymm12, ymm2, ymmword ptr [reloc @RWD576]
 
G_M000_IG31:                ;; offset=0x0E16
       vpslld   ymm3, ymm8, 28
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD544]
       vpxor    ymm3, ymm3, ymm4
       vblendvps ymm3, ymm3, ymm7, ymm12
       vaddps   ymm3, ymm3, ymm11
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm8, ymm8, 27
       vpand    ymm8, ymm8, ymmword ptr [reloc @RWD544]
       vmovups  ymm11, ymmword ptr [rbp-0x630]
       vpxor    ymm8, ymm8, ymm11
       vblendvps ymm2, ymm8, ymm7, ymm2
       vaddps   ymm2, ymm2, ymm3
       vpxor    ymm3, ymm13, ymmword ptr [rbp-0x170]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x5B0]
       vpxor    ymm3, ymm3, ymm5
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD448]
       vpsrad   ymm7, ymm3, 15
       vpxor    ymm3, ymm7, ymm3
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD480]
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
       add      r8, 16
       vpsrld   ymm3, ymm3, 2
       vpcmpeqd ymm7, ymm7, ymm7
       vpgatherdd ymm8, dword ptr [r8+4*xmm3], ymm7
       vpand    ymm3, ymm8, ymmword ptr [reloc @RWD512]
       vxorps   ymm7, ymm7, ymm7
       vxorps   ymm12, ymm12, ymm12
       vpcmpeqd ymm12, ymm12, ymm3
       vpslld   ymm1, ymm8, 29
       vpand    ymm1, ymm1, ymmword ptr [reloc @RWD544]
       vpxor    ymm1, ymm1, ymm6
       vblendvps ymm1, ymm1, ymm7, ymm12
       vpcmpeqd ymm12, ymm3, ymmword ptr [reloc @RWD576]
       vpslld   ymm6, ymm8, 28
       vpand    ymm6, ymm6, ymmword ptr [reloc @RWD544]
       vpxor    ymm4, ymm6, ymm4
       vblendvps ymm4, ymm4, ymm7, ymm12
       vaddps   ymm1, ymm4, ymm1
       vpcmpeqd ymm3, ymm3, ymmword ptr [reloc @RWD608]
       vpslld   ymm4, ymm8, 27
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD544]
       vpxor    ymm4, ymm4, ymm11
       vblendvps ymm3, ymm4, ymm7, ymm3
       vaddps   ymm1, ymm3, ymm1
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm10
       vaddps   ymm1, ymm1, ymm2
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm0, ymm0, ymm14
       vpxor    ymm0, ymm0, ymm5
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD448]
       vpsrad   ymm2, ymm0, 15
       vpxor    ymm0, ymm2, ymm0
       vpand    ymm0, ymm0, ymmword ptr [reloc @RWD480]
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
 
G_M000_IG32:                ;; offset=0x0F69
       add      r8, 16
       vpsrld   ymm0, ymm0, 2
       vpcmpeqd ymm2, ymm2, ymm2
       vpgatherdd ymm3, dword ptr [r8+4*xmm0], ymm2
       vpand    ymm0, ymm3, ymmword ptr [reloc @RWD512]
       vxorps   ymm2, ymm2, ymm2
       vxorps   ymm4, ymm4, ymm4
       vpcmpeqd ymm4, ymm4, ymm0
       vpslld   ymm6, ymm3, 29
       vpand    ymm6, ymm6, ymmword ptr [reloc @RWD544]
       vpxor    ymm6, ymm6, ymm15
       vblendvps ymm4, ymm6, ymm2, ymm4
       vpcmpeqd ymm6, ymm0, ymmword ptr [reloc @RWD576]
       vpslld   ymm7, ymm3, 28
       vpand    ymm7, ymm7, ymmword ptr [reloc @RWD544]
       vmovups  ymm8, ymmword ptr [rbp-0x610]
       vpxor    ymm7, ymm7, ymm8
       vblendvps ymm6, ymm7, ymm2, ymm6
       vaddps   ymm4, ymm6, ymm4
       vpcmpeqd ymm0, ymm0, ymmword ptr [reloc @RWD608]
       vpslld   ymm3, ymm3, 27
       vpand    ymm3, ymm3, ymmword ptr [reloc @RWD544]
       vpxor    ymm3, ymm3, ymm11
       vblendvps ymm0, ymm3, ymm2, ymm0
       vaddps   ymm0, ymm0, ymm4
       vpxor    ymm2, ymm13, ymmword ptr [rbp-0x170]
       vpxor    ymm2, ymm2, ymm14
       vpxor    ymm2, ymm2, ymm5
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD448]
       vpsrad   ymm3, ymm2, 15
       vpxor    ymm2, ymm3, ymm2
       vpand    ymm2, ymm2, ymmword ptr [reloc @RWD480]
       mov      r8, 0x1A484C00FE0
       mov      r8, gword ptr [r8]
       add      r8, 16
       vpsrld   ymm2, ymm2, 2
       vpcmpeqd ymm3, ymm3, ymm3
       vpgatherdd ymm4, dword ptr [r8+4*xmm2], ymm3
       vpand    ymm2, ymm4, ymmword ptr [reloc @RWD512]
       vxorps   ymm3, ymm3, ymm3
       vxorps   ymm5, ymm5, ymm5
       vpcmpeqd ymm5, ymm5, ymm2
       vpslld   ymm6, ymm4, 29
       vpand    ymm6, ymm6, ymmword ptr [reloc @RWD544]
       vpxor    ymm6, ymm6, ymmword ptr [rbp-0x5F0]
       vblendvps ymm5, ymm6, ymm3, ymm5
       vpcmpeqd ymm6, ymm2, ymmword ptr [reloc @RWD576]
       vpslld   ymm7, ymm4, 28
       vpand    ymm7, ymm7, ymmword ptr [reloc @RWD544]
       vpxor    ymm7, ymm7, ymm8
       vblendvps ymm6, ymm7, ymm3, ymm6
       vaddps   ymm5, ymm6, ymm5
       vpcmpeqd ymm2, ymm2, ymmword ptr [reloc @RWD608]
       vpslld   ymm4, ymm4, 27
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD544]
       vpxor    ymm4, ymm4, ymm11
       vblendvps ymm2, ymm4, ymm3, ymm2
 
G_M000_IG33:                ;; offset=0x10B6
       vaddps   ymm2, ymm2, ymm5
       vsubps   ymm2, ymm2, ymm0
       vmulps   ymm2, ymm2, ymm10
       vaddps   ymm0, ymm2, ymm0
       vmovups  ymm2, ymmword ptr [rbp-0x6D0]
       vmovups  ymm3, ymmword ptr [rbp-0x6B0]
       vsubps   ymm2, ymm2, ymm3
       vmovups  ymm11, ymmword ptr [rbp-0x650]
       vmulps   ymm2, ymm2, ymm11
       vaddps   ymm2, ymm2, ymm3
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymm11
       vaddps   ymm0, ymm0, ymm1
       vsubps   ymm0, ymm0, ymm2
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x670]
       vaddps   ymm0, ymm0, ymm2
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD640]
       vmovups  ymmword ptr [rbp-0x590], ymm0
       jmp      G_M000_IG18
 
G_M000_IG34:                ;; offset=0x111E
       vcmpeqps ymm0, ymm6, ymm6
       vandps   ymm0, ymm0, ymm6
       vcmpgeps ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymmword ptr [reloc @RWD192], ymm1
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm6, ymm1
       vpaddd   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [rbp-0x6F0], ymm0
       vcmpeqps ymm0, ymm7, ymm7
       vandps   ymm0, ymm0, ymm7
       vcmpgeps ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymmword ptr [reloc @RWD192], ymm1
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm7, ymm1
       vpaddd   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [rbp-0x710], ymm0
       vcmpeqps ymm0, ymm8, ymm8
       vandps   ymm0, ymm0, ymm8
       vcmpgeps ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcvttps2dq ymm0, ymm0
       vpblendvb ymm0, ymm0, ymmword ptr [reloc @RWD192], ymm1
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm8, ymm1
       vpaddd   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [rbp-0x730], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0x6F0]
       vsubps   ymm0, ymm6, ymm0
       vmovups  ymmword ptr [rbp-0x750], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0x710]
       vsubps   ymm0, ymm7, ymm0
       vmovups  ymmword ptr [rbp-0x770], ymm0
       vcvtdq2ps ymm0, ymmword ptr [rbp-0x730]
       vsubps   ymm0, ymm8, ymm0
       vmovups  ymmword ptr [rbp-0x790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD352]
       vmovups  ymmword ptr [rbp-0x6F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD384]
       vmovups  ymmword ptr [rbp-0x710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD416]
       vmovups  ymmword ptr [rbp-0x730], ymm0
       vbroadcastss ymm0, dword ptr [reloc @RWD352]
       vbroadcastss ymm1, dword ptr [reloc @RWD384]
       vbroadcastss ymm2, dword ptr [reloc @RWD416]
       vmovups  ymm3, ymmword ptr [rbp-0x6F0]
       vpsubd   ymm3, ymm3, ymm0
       vmovups  ymmword ptr [rbp-0x7B0], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0x710]
       vpsubd   ymm3, ymm3, ymm1
       vmovups  ymmword ptr [rbp-0x7D0], ymm3
       vmovups  ymm3, ymmword ptr [rbp-0x730]
       vpsubd   ymm3, ymm3, ymm2
       vmovups  ymmword ptr [rbp-0x7F0], ymm3
       vpaddd   ymm0, ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x810], ymm0
 
G_M000_IG35:                ;; offset=0x12AD
       vpaddd   ymm0, ymm1, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x830], ymm0
       vpaddd   ymm0, ymm2, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x850], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD672]
       vmovups  ymmword ptr [rbp-0x870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD704]
       vmovups  ymmword ptr [rbp-0x890], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vpaddd   ymm0, ymm0, ymmword ptr [reloc @RWD736]
       vmovups  ymmword ptr [rbp-0x8B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7B0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7D0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD448]
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm1, ymm0, 19
       vpxor    ymm0, ymm1, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD768]
       vmovups  ymm1, ymmword ptr [rbp-0x170]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x6F0]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x7D0]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD448]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD768]
       vmovups  ymm2, ymmword ptr [rbp-0x170]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x810]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x7D0]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD448]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD768]
       vmovups  ymm3, ymmword ptr [rbp-0x170]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x870]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x7D0]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD448]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD768]
       vsubps   ymm3, ymm3, ymm2
       vsubps   ymm4, ymm0, ymm1
       vsubps   ymm3, ymm3, ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x750]
       vmulps   ymm4, ymm4, ymmword ptr [rbp-0x750]
       vmulps   ymm5, ymm4, ymmword ptr [rbp-0x750]
 
G_M000_IG36:                ;; offset=0x1445
       vmulps   ymm5, ymm5, ymm3
       vsubps   ymm6, ymm0, ymm1
       vsubps   ymm3, ymm6, ymm3
       vmulps   ymm3, ymm3, ymm4
       vaddps   ymm3, ymm3, ymm5
       vsubps   ymm0, ymm2, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x750]
       vaddps   ymm0, ymm0, ymm3
       vaddps   ymm0, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0x990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7B0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x710]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD448]
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm1, ymm0, 19
       vpxor    ymm0, ymm1, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD768]
       vmovups  ymm1, ymmword ptr [rbp-0x170]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x6F0]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x710]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD448]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD768]
       vmovups  ymm2, ymmword ptr [rbp-0x170]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x810]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x710]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD448]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD768]
       vmovups  ymm3, ymmword ptr [rbp-0x170]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x870]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x710]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD448]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD768]
       vsubps   ymm3, ymm3, ymm2
       vsubps   ymm4, ymm0, ymm1
       vsubps   ymm3, ymm3, ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x750]
       vmulps   ymm4, ymm4, ymmword ptr [rbp-0x750]
       vmulps   ymm5, ymm4, ymmword ptr [rbp-0x750]
       vmulps   ymm5, ymm5, ymm3
       vsubps   ymm7, ymm0, ymm1
       vsubps   ymm3, ymm7, ymm3
 
G_M000_IG37:                ;; offset=0x15B1
       vmulps   ymm3, ymm3, ymm4
       vaddps   ymm3, ymm3, ymm5
       vsubps   ymm0, ymm2, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x750]
       vaddps   ymm0, ymm0, ymm3
       vaddps   ymm0, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0x9B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7B0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x830]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD448]
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm1, ymm0, 19
       vpxor    ymm0, ymm1, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD768]
       vmovups  ymm1, ymmword ptr [rbp-0x170]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x6F0]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x830]
       vpxor    ymm1, ymm1, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD448]
       vpmulld  ymm1, ymm1, ymm1
       vpslld   ymm2, ymm1, 19
       vpxor    ymm1, ymm2, ymm1
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD768]
       vmovups  ymm2, ymmword ptr [rbp-0x170]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x810]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x830]
       vpxor    ymm2, ymm2, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD448]
       vpmulld  ymm2, ymm2, ymm2
       vpslld   ymm3, ymm2, 19
       vpxor    ymm2, ymm3, ymm2
       vcvtdq2ps ymm2, ymm2
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD768]
       vmovups  ymm3, ymmword ptr [rbp-0x170]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x870]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x830]
       vpxor    ymm3, ymm3, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm3, ymm3, ymmword ptr [reloc @RWD448]
       vpmulld  ymm3, ymm3, ymm3
       vpslld   ymm4, ymm3, 19
       vpxor    ymm3, ymm4, ymm3
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD768]
       vsubps   ymm3, ymm3, ymm2
       vsubps   ymm4, ymm0, ymm1
       vsubps   ymm3, ymm3, ymm4
       vmovups  ymm4, ymmword ptr [rbp-0x750]
       vmulps   ymm4, ymm4, ymmword ptr [rbp-0x750]
       vmulps   ymm5, ymm4, ymmword ptr [rbp-0x750]
       vmulps   ymm5, ymm5, ymm3
       vsubps   ymm8, ymm0, ymm1
       vsubps   ymm3, ymm8, ymm3
       vmulps   ymm3, ymm3, ymm4
       vaddps   ymm3, ymm3, ymm5
       vsubps   ymm0, ymm2, ymm0
 
G_M000_IG38:                ;; offset=0x171D
       vmulps   ymm0, ymm0, ymmword ptr [rbp-0x750]
       vaddps   ymm0, ymm0, ymm3
       vaddps   ymm0, ymm0, ymm1
       vmovups  ymmword ptr [rbp-0x9D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7B0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x890]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD448]
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm1, ymm0, 19
       vpxor    ymm0, ymm1, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD768]
       vmovups  ymmword ptr [rbp-0xA10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x6F0]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x890]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD448]
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm1, ymm0, 19
       vpxor    ymm0, ymm1, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD768]
       vmovups  ymmword ptr [rbp-0xA30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x810]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x890]
       vpxor    ymm0, ymm0, ymmword ptr [rbp-0x7F0]
       vpmulld  ymm0, ymm0, ymmword ptr [reloc @RWD448]
       vpmulld  ymm0, ymm0, ymm0
       vpslld   ymm1, ymm0, 19
       vpxor    ymm0, ymm1, ymm0
       vcvtdq2ps ymm0, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD768]
       vmovups  ymmword ptr [rbp-0xA50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0xBB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0xBD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0xBF0], ymm0
       lea      rdx, [rbp-0x7F0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xBB0]
       lea      r8, [rbp-0xBD0]
       lea      r9, [rbp-0xBF0]
       lea      rcx, [rbp-0xA90]
       call     [Tedd.FastNoise.Internal.Hashing:Hash3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0xBB0], ymm0
       lea      rdx, [rbp-0xBB0]
       lea      rcx, [rbp-0xAB0]
       lea      r8, [rbp-0xA90]
 
G_M000_IG39:                ;; offset=0x1899
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0xBB0], ymm0
       lea      rdx, [rbp-0xBB0]
       lea      rcx, [rbp-0xAD0]
       mov      r8d, 19
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftLeft(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       lea      rdx, [rbp-0xAB0]
       lea      r8, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:XorI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xB10]
       lea      rdx, [rbp-0xAF0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xB30]
       vmovss   xmm1, dword ptr [reloc @RWD768]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0xA70]
       lea      rdx, [rbp-0xB10]
       lea      r8, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0xA70]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xA10]
       lea      r8, [rbp-0xA30]
       lea      r9, [rbp-0xA50]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rdx, [rbp-0x9F0]
       mov      qword ptr [rsp+0x20], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0x990]
       lea      r8, [rbp-0x9B0]
       lea      r9, [rbp-0x9D0]
       lea      rcx, [rbp-0x8D0]
 
G_M000_IG40:                ;; offset=0x19B6
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0xBB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0xBD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0xBF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0xC10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0xC30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0xC50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0xC70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0xC90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0xCB0], ymm0
       lea      rdx, [rbp-0x730]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0xB70], ymm0
       lea      rdx, [rbp-0xBB0]
       lea      r8, [rbp-0xBD0]
       lea      r9, [rbp-0xBF0]
       lea      rcx, [rbp-0xC10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xC30]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xC50]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xC70]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xC90]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xCB0]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xB50]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xB70]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0xBB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0xBD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0xBF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0xC10], ymm0
 
G_M000_IG41:                ;; offset=0x1B3A
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0xC30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0xC50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0xC70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0xC90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0xCB0], ymm0
       lea      rdx, [rbp-0x850]
       mov      qword ptr [rsp+0x50], rdx
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0xB70], ymm0
       lea      rdx, [rbp-0xBB0]
       lea      r8, [rbp-0xBD0]
       lea      r9, [rbp-0xBF0]
       lea      rcx, [rbp-0xC10]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0xC30]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0xC50]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xC70]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0xC90]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0xCB0]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0xB50]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0xB70]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x810]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x870]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x7D0]
       mov      qword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0x710]
       mov      qword ptr [rsp+0x38], rcx
       lea      rcx, [rbp-0x830]
       mov      qword ptr [rsp+0x40], rcx
       lea      rcx, [rbp-0x890]
       mov      qword ptr [rsp+0x48], rcx
       lea      rcx, [rbp-0x8B0]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x750]
       mov      qword ptr [rsp+0x58], rcx
       lea      rcx, [rbp-0x770]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0x930]
 
G_M000_IG42:                ;; offset=0x1CAB
       lea      rdx, [rbp-0x170]
       lea      r8, [rbp-0x7B0]
       lea      r9, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.Kernels.ValueCubicKernel:Plane3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x930]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x790]
       mov      qword ptr [rsp+0x28], rcx
       lea      rcx, [rbp-0x950]
       lea      rdx, [rbp-0x8D0]
       lea      r8, [rbp-0x8F0]
       lea      r9, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.NoiseMath:CubicLerp[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x970]
       vmovss   xmm1, dword ptr [reloc @RWD800]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x590]
       lea      rdx, [rbp-0x950]
       lea      r8, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       jmp      G_M000_IG18
 
G_M000_IG43:                ;; offset=0x1D35
       vmovups  ymmword ptr [rbp-0xB50], ymm6
       vmovups  ymmword ptr [rbp-0xB70], ymm7
       vmovups  ymmword ptr [rbp-0xB90], ymm8
       lea      r8, [rbp-0xB50]
       lea      r9, [rbp-0xB70]
       lea      rdx, [rbp-0xB90]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.Kernels.ValueKernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       jmp      G_M000_IG18
 
G_M000_IG44:                ;; offset=0x1D80
       vmovups  ymm1, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x190], ymm1
       jmp      G_M000_IG19
 
G_M000_IG45:                ;; offset=0x1D95
       lea      ecx, [r15-0x01]
       cmp      r13d, ecx
       jne      G_M000_IG07
       lea      rcx, [rbp-0x570]
       vmovaps  xmm1, xmm9
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       lea      rcx, [rbp-0x1F0]
       lea      r8, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       jmp      G_M000_IG07
 
G_M000_IG46:                ;; offset=0x1DE4
       lea      rcx, [rbp-0x3D0]
       vmovaps  xmm1, xmm6
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x3F0]
       lea      rdx, [rbp-0x290]
       lea      r8, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rcx, rdi
       call     [Tedd.FastNoise.Internal.Kernels.FractalConfig:get_PingPongStrength():float:this]
       vmovaps  xmm1, xmm0
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x430]
       lea      rdx, [rbp-0x3F0]
       lea      r8, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x290]
       lea      rdx, [rbp-0x430]
       call     [Tedd.FastNoise.Internal.NoiseMath:PingPong[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x450]
       vmovss   xmm1, dword ptr [reloc @RWD36]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       lea      rcx, [rbp-0x470]
       lea      r8, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x490]
       vmovss   xmm1, dword ptr [reloc @RWD804]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x4B0]
       lea      rdx, [rbp-0x470]
       lea      r8, [rbp-0x490]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
 
G_M000_IG47:                ;; offset=0x1ED1
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      r8, [rbp-0xB50]
       lea      rdx, [rbp-0x4B0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0xB50], ymm0
       lea      rdx, [rbp-0xB50]
       lea      rcx, [rbp-0x1D0]
       lea      r8, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x370], ymm0
       jmp      G_M000_IG09
 
RWD00  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD32  	dd	3F800000h		;         1
RWD36  	dd	3F000000h		;       0.5
RWD40  	dd	C0000000h		;        -2
RWD44  	dd	000006A0h ; case G_M000_IG21
       	dd	000006F3h ; case G_M000_IG22
       	dd	00000030h ; case G_M000_IG03
RWD56  	dd	00000000h, 00000000h
RWD64  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD96  	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD128 	dd	000005CDh ; case G_M000_IG17
       	dd	0000076Ah ; case G_M000_IG25
       	dd	00000780h ; case G_M000_IG26
       	dd	000007E8h ; case G_M000_IG27
       	dd	00001065h ; case G_M000_IG34
       	dd	00001C7Ch ; case G_M000_IG43
RWD152 	dd	00000000h, 00000000h
RWD160 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD192 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD224 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD256 	dq	40C0000040C00000h, 40C0000040C00000h, 40C0000040C00000h, 40C0000040C00000h
RWD288 	dq	4170000041700000h, 4170000041700000h, 4170000041700000h, 4170000041700000h
RWD320 	dq	4120000041200000h, 4120000041200000h, 4120000041200000h, 4120000041200000h
RWD352 	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD384 	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD416 	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD448 	dq	27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh
RWD480 	dq	000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh
RWD512 	dq	0000000300000003h, 0000000300000003h, 0000000300000003h, 0000000300000003h
RWD544 	dq	8000000080000000h, 8000000080000000h, 8000000080000000h, 8000000080000000h
RWD576 	dq	0000000100000001h, 0000000100000001h, 0000000100000001h, 0000000100000001h
RWD608 	dq	0000000200000002h, 0000000200000002h, 0000000200000002h, 0000000200000002h
RWD640 	dq	3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h, 3F7705173F770517h
RWD672 	dq	3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h, 3BBD21923BBD2192h
RWD704 	dq	87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah, 87885C9A87885C9Ah
RWD736 	dq	CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh, CD16DC5ECD16DC5Eh
RWD768 	dq	3000000030000000h, 3000000030000000h, 3000000030000000h, 3000000030000000h
RWD800 	dd	3E97B426h		;  0.296296
RWD804 	dd	40000000h		;         2

; Total bytes of code 7988


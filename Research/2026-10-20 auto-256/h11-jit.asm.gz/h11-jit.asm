; Assembly listing for method (dynamicClass):lambda_method1(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 14 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 256
       vmovaps  xmmword ptr [rsp+0xF0], xmm6
       vmovaps  xmmword ptr [rsp+0xE0], xmm7
       vmovaps  xmmword ptr [rsp+0xD0], xmm8
       vmovaps  xmmword ptr [rsp+0xC0], xmm9
       vmovaps  xmmword ptr [rsp+0xB0], xmm10
       vmovaps  xmmword ptr [rsp+0xA0], xmm11
       vmovaps  xmmword ptr [rsp+0x90], xmm12
       vmovaps  xmmword ptr [rsp+0x80], xmm13
       vmovaps  xmmword ptr [rsp+0x70], xmm14
       vmovaps  xmmword ptr [rsp+0x60], xmm15
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0061
       mov      rsi, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       test     eax, eax
       je       G_M000_IG48
       vmovsd   xmm1, qword ptr [rcx]
       cmp      eax, 1
       jbe      G_M000_IG48
       vmovsd   xmm2, qword ptr [rcx+0x08]
       cmp      eax, 2
       jbe      G_M000_IG48
       vmovsd   xmm3, qword ptr [rcx+0x10]
       vcvtsd2ss xmm6, xmm6, xmm1
       vcvtsd2ss xmm7, xmm7, xmm2
       vcvtsd2ss xmm8, xmm8, xmm3
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 0
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x00CF
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD00]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm9, xmm1, xmm2
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 1
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x18]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x010E
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG35
 
G_M000_IG06:                ;; offset=0x0121
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD04]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm9
       vmovss   xmm9, dword ptr [reloc @RWD08]
       vaddss   xmm1, xmm1, xmm9
       vxorps   xmm10, xmm10, xmm10
       vmovaps  xmm2, xmm10
       vmovss   xmm11, dword ptr [reloc @RWD12]
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vcmpneqps xmm12, xmm2, xmm2
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vbroadcastss xmm13, dword ptr [reloc @RWD08]
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm14, xmm14, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 2
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x20]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01DE
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG36
 
G_M000_IG08:                ;; offset=0x01F1
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm15, xmm15, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 3
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x027E
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG37
 
G_M000_IG10:                ;; offset=0x0291
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD16]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vmovss   dword ptr [rsp+0x2C], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 4
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x30]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x02D6
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG38
 
G_M000_IG12:                ;; offset=0x02E9
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD20]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x2C]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x58], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 5
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x38]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x038A
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG39
 
G_M000_IG14:                ;; offset=0x039D
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vmovss   dword ptr [rsp+0x28], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 6
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x03DA
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG40
 
G_M000_IG16:                ;; offset=0x03ED
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, xmm11
       vaddss   xmm1, xmm1, xmm11
       vmulss   xmm1, xmm1, dword ptr [rsp+0x28]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x50], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0488
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG41
 
G_M000_IG18:                ;; offset=0x049B
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x48], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x052E
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG42
 
G_M000_IG20:                ;; offset=0x0541
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x40], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 9
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x58]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x05D4
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG43
 
G_M000_IG22:                ;; offset=0x05E7
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD24]
       vaddss   xmm1, xmm1, dword ptr [reloc @RWD28]
       vmovss   dword ptr [rsp+0x24], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 10
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x062C
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG44
 
G_M000_IG24:                ;; offset=0x063F
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD32]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x24]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x38], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 11
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x68]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x06E0
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG45
 
G_M000_IG26:                ;; offset=0x06F3
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x30], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0786
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG46
 
G_M000_IG28:                ;; offset=0x0799
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm9
       vmulss   xmm0, xmm0, xmm11
       vcmpeqps xmm1, xmm10, xmm0
       vxorps   xmm2, xmm2, xmm2
       vpcmpgtd xmm2, xmm2, xmm0
       vandps   xmm1, xmm2, xmm1
       vorps    xmm1, xmm1, xmm12
       vcmpltps xmm2, xmm0, xmm10
       vorps    xmm1, xmm2, xmm1
       vandps   xmm2, xmm10, xmm1
       vandnps  xmm0, xmm1, xmm0
       vorps    xmm0, xmm0, xmm2
       vxorps   xmm1, xmm1, xmm1
       vcmpltps xmm2, xmm13, xmm0
       vorps    xmm1, xmm2, xmm1
       vblendvps xmm0, xmm0, xmm13, xmm1
       vcvtss2sd xmm0, xmm0, xmm0
       vmovsd   xmm1, qword ptr [reloc @RWD40]
       vsubsd   xmm2, xmm1, xmm15
       vxorps   xmm3, xmm3, xmm3
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vsubsd   xmm5, xmm4, qword ptr [reloc @RWD48]
       vcmpeqpd xmm6, xmm3, xmm5
       vxorps   xmm7, xmm7, xmm7
       vpcmpgtq xmm7, xmm7, xmm5
       vandpd   xmm6, xmm7, xmm6
       vcmpneqpd xmm7, xmm3, xmm3
       vorpd    xmm6, xmm6, xmm7
       vcmpltpd xmm8, xmm5, xmm3
       vorpd    xmm6, xmm8, xmm6
       vandpd   xmm3, xmm3, xmm6
       vandnpd  xmm5, xmm6, xmm5
       vorpd    xmm3, xmm5, xmm3
       vmovsd   xmm6, qword ptr [rsp+0x30]
       vsubsd   xmm5, xmm6, qword ptr [reloc @RWD56]
       vaddsd   xmm5, xmm5, xmm5
       vxorps   xmm8, xmm8, xmm8
       vsubsd   xmm9, xmm6, qword ptr [reloc @RWD48]
       vdivsd   xmm9, xmm9, qword ptr [reloc @RWD64]
       vcmpeqpd xmm10, xmm8, xmm9
       vxorps   xmm11, xmm11, xmm11
       vpcmpgtq xmm11, xmm11, xmm9
       vandpd   xmm10, xmm11, xmm10
       vorpd    xmm10, xmm10, xmm7
       vcmpltpd xmm11, xmm9, xmm8
       vorpd    xmm10, xmm11, xmm10
       vandpd   xmm8, xmm8, xmm10
       vandnpd  xmm9, xmm10, xmm9
       vorpd    xmm8, xmm9, xmm8
       vmovddup xmm9, qword ptr [reloc @RWD40]
       vmovaps  xmm10, xmm9
 
G_M000_IG29:                ;; offset=0x08B9
       vxorps   xmm11, xmm11, xmm11
       vcmpltpd xmm12, xmm10, xmm8
       vorpd    xmm11, xmm12, xmm11
       vblendvpd xmm8, xmm8, xmm10, xmm11
       vmulsd   xmm10, xmm8, xmm8
       vaddsd   xmm8, xmm8, xmm8
       vmovsd   xmm11, qword ptr [reloc @RWD72]
       vsubsd   xmm8, xmm11, xmm8
       vmulsd   xmm8, xmm8, xmm10
       vsubsd   xmm10, xmm14, qword ptr [reloc @RWD80]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD88]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD96]
       vmovsd   xmm12, qword ptr [rsp+0x58]
       vsubsd   xmm13, xmm12, qword ptr [reloc @RWD56]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD104]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD112]
       vaddsd   xmm10, xmm10, xmm13
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD120]
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD128]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD136]
       vmulsd   xmm2, xmm3, xmm2
       vaddsd   xmm2, xmm10, xmm2
       vmulsd   xmm3, xmm5, qword ptr [reloc @RWD144]
       vaddsd   xmm2, xmm2, xmm3
       vmulsd   xmm3, xmm8, xmm0
       vmulsd   xmm3, xmm3, xmm0
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD152]
       vaddsd   xmm2, xmm2, xmm3
       vsubsd   xmm2, xmm2, qword ptr [reloc @RWD160]
       vmovaps  xmm3, xmm2
       vxorps   xmm5, xmm5, xmm5
       vmovsd   xmm8, qword ptr [rsp+0x38]
       vaddsd   xmm10, xmm8, xmm8
       vsubsd   xmm10, xmm10, xmm1
       vandps   xmm10, xmm10, xmmword ptr [reloc @RWD176]
       vsubsd   xmm10, xmm10, qword ptr [reloc @RWD192]
       vdivsd   xmm10, xmm10, qword ptr [reloc @RWD200]
       vcmpeqpd xmm13, xmm5, xmm10
       vxorps   xmm4, xmm4, xmm4
       vpcmpgtq xmm4, xmm4, xmm10
       vandpd   xmm4, xmm4, xmm13
       vorpd    xmm4, xmm4, xmm7
       vcmpltpd xmm13, xmm10, xmm5
       vorpd    xmm4, xmm13, xmm4
       vandpd   xmm5, xmm5, xmm4
       vandnpd  xmm4, xmm4, xmm10
       vorpd    xmm4, xmm4, xmm5
       vmovaps  xmm5, xmm9
       vxorps   xmm10, xmm10, xmm10
       vcmpltpd xmm13, xmm5, xmm4
       vorpd    xmm10, xmm13, xmm10
       vblendvpd xmm4, xmm4, xmm5, xmm10
       vmulsd   xmm5, xmm4, xmm4
       vaddsd   xmm4, xmm4, xmm4
       vsubsd   xmm4, xmm11, xmm4
       vmulsd   xmm4, xmm5, xmm4
       vsubsd   xmm4, xmm1, xmm4
       vxorps   xmm5, xmm5, xmm5
       vdivsd   xmm2, xmm2, qword ptr [reloc @RWD208]
 
G_M000_IG30:                ;; offset=0x0A05
       vcmpeqpd xmm10, xmm5, xmm2
       vxorps   xmm13, xmm13, xmm13
       vpcmpgtq xmm13, xmm13, xmm2
       vandpd   xmm10, xmm13, xmm10
       vorpd    xmm7, xmm10, xmm7
       vcmpltpd xmm10, xmm2, xmm5
       vorpd    xmm7, xmm10, xmm7
       vandpd   xmm5, xmm5, xmm7
       vandnpd  xmm2, xmm7, xmm2
       vorpd    xmm2, xmm2, xmm5
       vxorps   xmm5, xmm5, xmm5
       vcmpltpd xmm7, xmm9, xmm2
       vorpd    xmm5, xmm7, xmm5
       vblendvpd xmm2, xmm2, xmm9, xmm5
       vmulsd   xmm5, xmm2, xmm2
       vaddsd   xmm2, xmm2, xmm2
       vsubsd   xmm2, xmm11, xmm2
       vmulsd   xmm2, xmm5, xmm2
       vsubsd   xmm1, xmm1, xmm2
       vmulsd   xmm1, xmm1, xmm4
       vmulsd   xmm2, xmm12, qword ptr [reloc @RWD216]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD224]
       vucomisd xmm3, xmm2
       seta     dl
       movzx    rdx, dl
       vsubsd   xmm2, xmm2, xmm3
       vmulsd   xmm2, xmm2, xmm1
       vaddsd   xmm2, xmm2, xmm3
       test     edx, edx
       je       G_M000_IG33
 
G_M000_IG31:                ;; offset=0x0A8B
       cmp      edi, 10
       jle      G_M000_IG47
       vmovsd   qword ptr [rsi], xmm14
       vmovsd   qword ptr [rsi+0x08], xmm15
       vmovsd   qword ptr [rsi+0x10], xmm12
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       vmovsd   qword ptr [rsi+0x30], xmm8
       vmovsd   qword ptr [rsi+0x38], xmm6
       vmovsd   qword ptr [rsi+0x40], xmm0
       vmovsd   qword ptr [rsi+0x48], xmm2
       vmovsd   qword ptr [rsi+0x50], xmm1
 
G_M000_IG32:                ;; offset=0x0ADC
       vmovaps  xmm6, xmmword ptr [rsp+0xF0]
       vmovaps  xmm7, xmmword ptr [rsp+0xE0]
       vmovaps  xmm8, xmmword ptr [rsp+0xD0]
       vmovaps  xmm9, xmmword ptr [rsp+0xC0]
       vmovaps  xmm10, xmmword ptr [rsp+0xB0]
       vmovaps  xmm11, xmmword ptr [rsp+0xA0]
       vmovaps  xmm12, xmmword ptr [rsp+0x90]
       vmovaps  xmm13, xmmword ptr [rsp+0x80]
       vmovaps  xmm14, xmmword ptr [rsp+0x70]
       vmovaps  xmm15, xmmword ptr [rsp+0x60]
       add      rsp, 256
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG33:                ;; offset=0x0B3B
       vmovaps  xmm2, xmm3
       jmp      G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0B44
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG35:                ;; offset=0x0B4E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG36:                ;; offset=0x0B58
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG37:                ;; offset=0x0B62
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG38:                ;; offset=0x0B6C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG39:                ;; offset=0x0B76
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG40:                ;; offset=0x0B80
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG41:                ;; offset=0x0B8A
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG42:                ;; offset=0x0B94
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG43:                ;; offset=0x0B9E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG44:                ;; offset=0x0BA8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG45:                ;; offset=0x0BB2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG46:                ;; offset=0x0BBC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG47:                ;; offset=0x0BC6
       test     edi, edi
       je       G_M000_IG48
       vmovsd   qword ptr [rsi], xmm14
       cmp      edi, 1
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x08], xmm15
       cmp      edi, 2
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x10], xmm12
       cmp      edi, 3
       jbe      SHORT G_M000_IG48
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       cmp      edi, 4
       jbe      SHORT G_M000_IG48
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       cmp      edi, 5
       jbe      SHORT G_M000_IG48
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       cmp      edi, 6
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x30], xmm8
       cmp      edi, 7
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x38], xmm6
       cmp      edi, 8
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x40], xmm0
       cmp      edi, 9
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x48], xmm2
       cmp      edi, 10
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x50], xmm1
       jmp      G_M000_IG32
 
G_M000_IG48:                ;; offset=0x0C4D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	3F47AE14h		;      0.78
RWD04  	dd	3E6147AEh		;      0.22
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F51EB85h		;      0.82
RWD20  	dd	3E3851ECh		;      0.18
RWD24  	dd	3F666666h		;       0.9
RWD28  	dd	3E570A3Dh		;      0.21
RWD32  	dd	3DCCCCCDh		;       0.1
RWD36  	dd	00000000h
RWD40  	dq	3FF0000000000000h	;            1
RWD48  	dq	3FDEB851EB851EB8h	;         0.48
RWD56  	dq	3FE0000000000000h	;          0.5
RWD64  	dq	3FCEB851EB851EB8h	;         0.24
RWD72  	dq	4008000000000000h	;            3
RWD80  	dq	3FD6666666666666h	;         0.35
RWD88  	dq	4038000000000000h	;           24
RWD96  	dq	4000000000000000h	;            2
RWD104 	dq	4044000000000000h	;           40
RWD112 	dq	3FE1EB851EB851ECh	;         0.56
RWD120 	dq	4067C00000000000h	;          190
RWD128 	dq	3FF6666666666666h	;          1.4
RWD136 	dq	3FD3333333333333h	;          0.3
RWD144 	dq	4074000000000000h	;          320
RWD152 	dq	408F400000000000h	;         1000
RWD160 	dq	4010000000000000h	;            4
RWD168 	dd	00000000h, 00000000h
RWD176 	dq	7FFFFFFFFFFFFFFFh, 7FFFFFFFFFFFFFFFh
RWD192 	dq	3F9999999999999Ah	;        0.025
RWD200 	dq	3FB5C28F5C28F5C2h	;        0.085
RWD208 	dq	4042000000000000h	;           36
RWD216 	dq	3FF3333333333333h	;          1.2
RWD224 	dq	C014000000000000h	;           -5

; Total bytes of code 3155

; Assembly listing for method (dynamicClass):lambda_method2(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 384 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       lea      r11, [rsp-0x1BA0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       vmovaps  xmmword ptr [rsp+0x1B90], xmm6
       vmovaps  xmmword ptr [rsp+0x1B80], xmm7
       vmovaps  xmmword ptr [rsp+0x1B70], xmm8
       vmovaps  xmmword ptr [rsp+0x1B60], xmm9
       vmovaps  xmmword ptr [rsp+0x1B50], xmm10
       vmovaps  xmmword ptr [rsp+0x1B40], xmm11
       vmovaps  xmmword ptr [rsp+0x1B30], xmm12
       vmovaps  xmmword ptr [rsp+0x1B20], xmm13
       vmovaps  xmmword ptr [rsp+0x1B10], xmm14
       vmovaps  xmmword ptr [rsp+0x1B00], xmm15
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x30], xmm4
       mov      rax, -0x1980
       vmovdqa  xmmword ptr [rsp+rax+0x19C0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x19D0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x19E0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r8
 
G_M000_IG02:                ;; offset=0x00B2
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG03:                ;; offset=0x00BF
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1AC0]
       xor      r8d, r8d
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG04:                ;; offset=0x00DE
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG05:                ;; offset=0x00EB
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1A80]
       mov      r8d, 1
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1A40]
       mov      rdx, rdi
       mov      r8d, 2
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x1AC0]
       vmovups  ymm1, ymmword ptr [rsp+0x1AE0]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1A20], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A80]
       vmovups  ymm1, ymmword ptr [rsp+0x1AA0]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1A00], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A40]
       vmovups  ymm1, ymmword ptr [rsp+0x1A60]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x19E0], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 0
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x10]
       mov      r14, 0x7FFC65893210
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x01CA
       mov      rdx, rbp
       mov      rcx, r14
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG07:                ;; offset=0x01D6
       vmovups  ymm6, ymmword ptr [rbp+0x08]
       cmp      dword ptr [rdi+0x08], 1
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x18]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01F1
       mov      rcx, 0x7FFC657BBC68
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG180
 
G_M000_IG09:                ;; offset=0x0204
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm7, ymm0, ymmword ptr [rsp+0x1A20]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x1A00]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x19E0]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0234
       mov      edx, edx
       lea      r9, [reloc @RWD00]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG11:                ;; offset=0x024E
       vaddps   ymm0, ymm8, ymm7
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm7, ymm0, ymm7
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x026F
       vaddps   ymm0, ymm9, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm8, ymm8, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm8
       vaddps   ymm7, ymm1, ymm7
       vaddps   ymm9, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm8, ymm0, ymm8
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02A0
       vaddps   ymm0, ymm8, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm9
       vaddps   ymm7, ymm2, ymm7
       vaddps   ymm1, ymm8, ymm1
       vsubps   ymm8, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
 
G_M000_IG14:                ;; offset=0x02D3
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovss   xmm13, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02FC
       cmp      r15d, 1
       jg       G_M000_IG154
 
G_M000_IG16:                ;; offset=0x0306
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm7
       vmovups  ymmword ptr [rsp+0xE0], ymm8
       vmovups  ymmword ptr [rsp+0xC0], ymm9
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x480]
       vextractf128 xmm14, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       vinsertf128 ymm6, ymm6, xmm14
       je       G_M000_IG159
 
G_M000_IG17:                ;; offset=0x037B
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG158
 
G_M000_IG18:                ;; offset=0x038C
       cmp      edx, 3
       je       G_M000_IG157
 
G_M000_IG19:                ;; offset=0x0395
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x480]
 
G_M000_IG20:                ;; offset=0x039E
       vbroadcastss ymm0, ymm13
       vmulps   ymm7, ymm0, ymm1
 
G_M000_IG21:                ;; offset=0x03A7
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 2
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x20]
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x03C2
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm14, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG23:                ;; offset=0x03E6
       vmulps   ymm0, ymm7, ymmword ptr [rbp+0x08]
       vaddps   ymm7, ymm0, ymm6
       vmovups  ymmword ptr [rsp+0x19C0], ymm7
       cmp      dword ptr [rdi+0x08], 3
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x28]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x040E
       mov      rcx, 0x7FFC657BBC68
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG181
 
G_M000_IG25:                ;; offset=0x0421
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x1A20]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x1A00]
       vmulps   ymm10, ymm0, ymmword ptr [rsp+0x19E0]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG30
 
G_M000_IG26:                ;; offset=0x0451
       mov      edx, edx
       lea      r9, [reloc @RWD128]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG27:                ;; offset=0x046B
       vaddps   ymm0, ymm9, ymm8
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       vsubps   ymm10, ymm0, ymm10
       jmp      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x048E
       vaddps   ymm0, ymm10, ymm8
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm9
       vaddps   ymm8, ymm1, ymm8
       vaddps   ymm10, ymm1, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x04C1
       vaddps   ymm0, ymm9, ymm8
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm10, ymm10, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm10
       vaddps   ymm8, ymm2, ymm8
       vaddps   ymm1, ymm9, ymm1
       vsubps   ymm9, ymm1, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm10, ymm0, ymm10
 
G_M000_IG30:                ;; offset=0x04F6
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovaps  ymm13, ymm10
       vmovss   xmm14, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0520
       cmp      r15d, 1
       jg       G_M000_IG148
 
G_M000_IG32:                ;; offset=0x052A
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm9
       vmovups  ymmword ptr [rsp+0xC0], ymm10
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x3A0]
       vextractf128 xmm15, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       vinsertf128 ymm6, ymm6, xmm15
       je       G_M000_IG153
 
G_M000_IG33:                ;; offset=0x059F
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG152
 
G_M000_IG34:                ;; offset=0x05B0
       cmp      edx, 3
       je       G_M000_IG151
 
G_M000_IG35:                ;; offset=0x05B9
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x3A0]
 
G_M000_IG36:                ;; offset=0x05C2
       vbroadcastss ymm0, ymm14
       vmulps   ymm8, ymm0, ymm1
 
G_M000_IG37:                ;; offset=0x05CB
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 4
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x30]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x05E7
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG39:                ;; offset=0x060B
       vmulps   ymm0, ymm8, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x19C0]
       mov      rdx, rdi
       cmp      ebp, 5
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x38]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0633
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm8, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm7, ymm7, xmm8
 
G_M000_IG41:                ;; offset=0x0657
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x19A0], ymm0
       vaddps   ymm7, ymm7, ymmword ptr [rsp+0x19A0]
       cmp      ebp, 6
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdi+0x40]
       cmp      qword ptr [rdi], r14
       je       SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0681
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm8, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm7, ymm7, xmm8
 
G_M000_IG43:                ;; offset=0x06A5
       vmovups  ymm9, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmulps   ymm0, ymm9, ymm7
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1980]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1960]
       lea      r8, [rsp+0x1980]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1920]
       lea      rdx, [rsp+0x1960]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0756
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG182
 
G_M000_IG45:                ;; offset=0x0769
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1900]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1900]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x18E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x18C0]
       lea      r8, [rsp+0x18E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1880]
       lea      rdx, [rsp+0x18C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x08B0
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG183
 
G_M000_IG47:                ;; offset=0x08C3
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1860]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 9
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x58]
       cmp      qword ptr [rbp], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x0959
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG49:                ;; offset=0x097D
       vmovups  ymm0, ymmword ptr [rsp+0x1860]
       vmulps   ymm0, ymm0, ymmword ptr [rbp+0x08]
       vaddps   ymm8, ymm0, ymm6
       cmp      dword ptr [rdi+0x08], 10
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x09A5
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG184
 
G_M000_IG51:                ;; offset=0x09B8
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1840]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 11
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x68]
       cmp      qword ptr [rdi], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0A56
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG53:                ;; offset=0x0A86
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1840]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1820]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1800]
       lea      r8, [rsp+0x1820]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x17C0]
       lea      rdx, [rsp+0x1800]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0B53
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG185
 
G_M000_IG55:                ;; offset=0x0B66
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x17A0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vmovups  ymm0, ymmword ptr [rsp+0x17A0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm6, ymm6, xmm15
       vaddps   ymm8, ymm0, ymm6
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 13
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x78]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0C11
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG186
 
G_M000_IG57:                ;; offset=0x0C24
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1780]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm9, ymmword ptr [rsp+0x1780]
       vaddps   ymm0, ymm0, ymm9
       vinsertf128 ymm8, ymm8, xmm10
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1760]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1740]
       lea      r8, [rsp+0x1760]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1700]
       lea      rdx, [rsp+0x1740]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 14
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x80]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG58:                ;; offset=0x0D75
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0D77
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG187
 
G_M000_IG60:                ;; offset=0x0D8A
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x16E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x16E0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x16C0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x16A0]
       lea      r8, [rsp+0x16C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1660]
       lea      rdx, [rsp+0x16A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 15
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x88]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0ED4
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG188
 
G_M000_IG62:                ;; offset=0x0EE7
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1640]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1640]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1620]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1600]
       lea      r8, [rsp+0x1620]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x15C0]
       lea      rdx, [rsp+0x1600]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 16
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x90]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x1031
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG189
 
G_M000_IG64:                ;; offset=0x1044
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x15A0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 17
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x98]
       cmp      qword ptr [r15], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x10DE
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG66:                ;; offset=0x1102
       vmovups  ymm0, ymmword ptr [rsp+0x15A0]
       vmulps   ymm8, ymm0, ymmword ptr [r15+0x08]
       mov      rdx, rdi
       cmp      ebp, 18
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0xA0]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x1129
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG68:                ;; offset=0x1159
       vaddps   ymm8, ymm8, ymmword ptr [r15+0x08]
       cmp      ebp, 19
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0xA8]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x1177
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG190
 
G_M000_IG70:                ;; offset=0x118A
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1580]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 20
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xB0]
       cmp      qword ptr [rdi], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
       je       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x122B
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG72:                ;; offset=0x125B
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1580]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1560]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1540]
       lea      r8, [rsp+0x1560]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1500]
       lea      rdx, [rsp+0x1540]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 21
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0xB8]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x132B
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG191
 
G_M000_IG74:                ;; offset=0x133E
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x14E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x14E0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x14C0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x14A0]
       lea      r8, [rsp+0x14C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1460]
       lea      rdx, [rsp+0x14A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 22
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0xC0]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x1488
       mov      rax, 0x7FFC657BBC68
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG192
 
G_M000_IG76:                ;; offset=0x149B
       lea      rdx, [rsp+0x19E0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1440]
       lea      r8, [rsp+0x1A20]
       lea      r9, [rsp+0x1A00]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1440]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1420]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1400]
       lea      rdx, [rsp+0x19A0]
       lea      r8, [rsp+0x1420]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x13C0]
       lea      rdx, [rsp+0x1400]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 23
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xC8]
       mov      rbp, 0x7FFC65890890
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x158C
       mov      rdx, rdi
       mov      rcx, rbp
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG78:                ;; offset=0x1598
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       vmovdqu  ymm0, ymmword ptr [rsp+0x1880]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x18A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1380]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 24
       jbe      G_M000_IG193
       mov      r14, gword ptr [rdx+0xD0]
       cmp      qword ptr [r14], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x1622
       mov      rdx, r14
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG80:                ;; offset=0x1646
       vmovups  ymm10, ymmword ptr [r14+0x08]
       vmovups  ymm11, ymmword ptr [r14+0x28]
       cmp      dword ptr [rdi+0x08], 25
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdi+0xD8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x1668
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG82:                ;; offset=0x16A4
       vmovups  ymm14, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x240], ymm14
       vmovups  ymm15, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x220], ymm15
       vmovdqu  ymm0, ymmword ptr [rsp+0x1700]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1720]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymmword ptr [rsp+0x40], ymm14
       vmovups  ymmword ptr [rsp+0x60], ymm15
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1340]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1300]
       lea      r8, [rsp+0x1340]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 26
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xE0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x179D
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG84:                ;; offset=0x17D9
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x200], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x1E0], ymm1
       vmovdqu  ymm2, ymmword ptr [rsp+0x1460]
       vmovdqu  ymmword ptr [rsp+0x80], ymm2
       vmovdqu  ymm2, ymmword ptr [rsp+0x1480]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm2
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x12C0]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 27
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xE8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x188A
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG86:                ;; offset=0x18C6
       vmovups  ymm8, ymmword ptr [rdi+0x08]
       vmovups  ymm9, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x12C0]
       lea      rcx, [rsp+0x1280]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1460]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1480]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x240]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x220]
       vmovups  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1240]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 28
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xF0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x19D3
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG88:                ;; offset=0x1A3B
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1240]
       lea      rcx, [rsp+0x1200]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmmword ptr [rsp+0x1D0], ymm8
       vextractf128 xmmword ptr [rsp+0x1B0], ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x11C0]
       lea      r8, [rsp+0x1200]
       vextractf128 xmm14, ymm10
       vextractf128 xmm15, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1180]
       lea      r8, [rsp+0x11C0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1180]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x11A0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1180]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x11A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1140]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 29
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xF8]
 
G_M000_IG89:                ;; offset=0x1BB9
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1D0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1B0]
       vinsertf128 ymm10, ymm10, xmm14
       vinsertf128 ymm11, ymm11, xmm15
       je       SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x1BEC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG91:                ;; offset=0x1C54
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x180], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x160], ymm1
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1100]
       lea      r8, [rsp+0x1180]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x10C0]
       lea      r8, [rsp+0x1100]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1080]
       lea      rdx, [rsp+0x1140]
       lea      r8, [rsp+0x10C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 30
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x100]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x1D76
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG93:                ;; offset=0x1DDE
       vmovdqu  ymm0, ymmword ptr [rsp+0x1920]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1940]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1040]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 31
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x108]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x1EA9
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG95:                ;; offset=0x1F11
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1040]
       lea      rcx, [rsp+0x1000]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1000]
       lea      rcx, [rsp+0xFC0]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x17C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x200]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1E0]
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xF80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 32
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x110]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x2066
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG97:                ;; offset=0x20CE
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF80]
       lea      rcx, [rsp+0xF40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 33
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x118]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x217E
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG99:                ;; offset=0x21E6
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF40]
       lea      rcx, [rsp+0xF00]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xEC0]
       lea      rdx, [rsp+0xFC0]
       lea      r8, [rsp+0xF00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 34
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x120]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x22B4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG101:                ;; offset=0x231C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1300]
       lea      rcx, [rsp+0xE80]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 35
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x128]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x23CC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG103:                ;; offset=0x2434
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xE80]
       lea      rcx, [rsp+0xE40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 36
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x130]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x24E4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG105:                ;; offset=0x254C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xE00]
       lea      r8, [rsp+0x1380]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xDC0]
       lea      rdx, [rsp+0xE40]
       lea      r8, [rsp+0xE00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD80]
       lea      rdx, [rsp+0xEC0]
       lea      r8, [rsp+0xDC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 37
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x138]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x2638
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG107:                ;; offset=0x26A0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1280]
       lea      rcx, [rsp+0xD40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD00]
       lea      rdx, [rsp+0xD80]
       lea      r8, [rsp+0xD40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x13C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1080]
       lea      rcx, [rsp+0xCC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x13C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xCC0]
       lea      rcx, [rsp+0xC80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 38
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x140]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x27F2
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG109:                ;; offset=0x285A
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC80]
       lea      rcx, [rsp+0xC40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xC00]
       lea      rdx, [rsp+0xD00]
       lea      r8, [rsp+0xC40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 39
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x148]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x2928
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG111:                ;; offset=0x2990
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC00]
       lea      rcx, [rsp+0xBC0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1500]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1520]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x40], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0x60], ymm9
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xB80]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB80]
       lea      rcx, [rsp+0xB40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xB00]
       lea      rdx, [rsp+0xB40]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Abs(Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 40
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x150]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
 
G_M000_IG112:                ;; offset=0x2AE9
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x2B01
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG114:                ;; offset=0x2B69
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB00]
       lea      rcx, [rsp+0xAC0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 41
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x158]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x2C19
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG116:                ;; offset=0x2C81
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xAC0]
       lea      rcx, [rsp+0xA80]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xA40]
       lea      r8, [rsp+0xA80]
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xA00]
       lea      r8, [rsp+0xA40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xA00]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA20]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA00]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA20]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x9C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
 
G_M000_IG117:                ;; offset=0x2E10
       lea      rcx, [rsp+0x980]
       lea      r8, [rsp+0xA00]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x940]
       lea      r8, [rsp+0x980]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x900]
       lea      rdx, [rsp+0x9C0]
       lea      r8, [rsp+0x940]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x8C0]
       lea      r8, [rsp+0x900]
       vextractf128 xmmword ptr [rsp+0x2D0], ymm6
       vextractf128 xmmword ptr [rsp+0x2B0], ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x40], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0x60], ymm11
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x880]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 42
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x160]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2D0]
 
G_M000_IG118:                ;; offset=0x2F74
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x2B0]
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x2F99
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG120:                ;; offset=0x3001
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x880]
       lea      rcx, [rsp+0x840]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x800]
       lea      r8, [rsp+0x840]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x7C0]
       lea      r8, [rsp+0x800]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x7C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7C0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7E0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x780]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x740]
       lea      r8, [rsp+0x7C0]
 
G_M000_IG121:                ;; offset=0x318A
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x700]
       lea      r8, [rsp+0x740]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x6C0]
       lea      rdx, [rsp+0x780]
       lea      r8, [rsp+0x700]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x680]
       lea      r8, [rsp+0x6C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x640]
       lea      rdx, [rsp+0x8C0]
       lea      r8, [rsp+0x680]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rbx, gword ptr [rbx+0x08]
       mov      rdx, rbx
       cmp      dword ptr [rdx+0x08], 43
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x168]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x3267
       mov      rdx, rdi
       mov      rcx, rbp
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG123:                ;; offset=0x3273
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       cmp      dword ptr [rbx+0x08], 44
       jbe      G_M000_IG193
       mov      rbx, gword ptr [rbx+0x170]
       cmp      qword ptr [rbx], rbp
       je       SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x3293
       mov      rdx, rbx
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG125:                ;; offset=0x32B7
       vmovdqu  ymm0, ymmword ptr [rsp+0x17C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x600]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm8
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm9
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x5C0]
       lea      r8, [rsp+0x600]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x5C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x5E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x5A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:LessThan(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):System.Numerics.Vector`1[int]]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x5C0]
       lea      rcx, [rsp+0x560]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x640]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x660]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x560]
       lea      rcx, [rsp+0x520]
 
G_M000_IG126:                ;; offset=0x342F
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x4E0]
       lea      r8, [rsp+0x520]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x4A0]
       lea      rdx, [rsp+0x5A0]
       lea      r8, [rsp+0x4E0]
       lea      r9, [rsp+0xBC0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Select(System.Numerics.Vector`1[int],Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG127:                ;; offset=0x349D
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG128:                ;; offset=0x34A7
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1920]
       xor      edx, edx
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG129:                ;; offset=0x34C2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG130:                ;; offset=0x34CC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1880]
       mov      edx, 1
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG131:                ;; offset=0x34EA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG132:                ;; offset=0x34F4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x17C0]
       mov      edx, 2
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG133:                ;; offset=0x3512
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG134:                ;; offset=0x351C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1700]
       mov      edx, 3
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG135:                ;; offset=0x353A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG136:                ;; offset=0x3544
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1660]
       mov      edx, 4
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG137:                ;; offset=0x3562
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG138:                ;; offset=0x356C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x15C0]
       mov      edx, 5
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG139:                ;; offset=0x358A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG140:                ;; offset=0x3594
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1500]
       mov      edx, 6
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG141:                ;; offset=0x35B2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG142:                ;; offset=0x35BC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1460]
       mov      edx, 7
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG143:                ;; offset=0x35DA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG144:                ;; offset=0x35E4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x13C0]
       mov      edx, 8
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG145:                ;; offset=0x3602
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG146:                ;; offset=0x360C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x4A0]
       mov      edx, 9
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       lea      r9, [rsp+0x640]
       mov      rcx, rsi
       mov      edx, 10
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       nop      
 
G_M000_IG147:                ;; offset=0x3647
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1B90]
       vmovaps  xmm7, xmmword ptr [rsp+0x1B80]
       vmovaps  xmm8, xmmword ptr [rsp+0x1B70]
       vmovaps  xmm9, xmmword ptr [rsp+0x1B60]
       vmovaps  xmm10, xmmword ptr [rsp+0x1B50]
       vmovaps  xmm11, xmmword ptr [rsp+0x1B40]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B30]
       vmovaps  xmm13, xmmword ptr [rsp+0x1B20]
       vmovaps  xmm14, xmmword ptr [rsp+0x1B10]
       vmovaps  xmm15, xmmword ptr [rsp+0x1B00]
       add      rsp, 0x1BA0
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG148:                ;; offset=0x36B6
       vxorps   ymm8, ymm8, ymm8
       vmovups  ymmword ptr [rsp+0x380], ymm8
       vbroadcastss ymm9, dword ptr [rdi+0x18]
       vbroadcastss ymm10, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm10
       vbroadcastss ymm0, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       vbroadcastss ymm1, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x300], ymm1
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG174
 
G_M000_IG149:                ;; offset=0x3703
       vmovups  ymm8, ymmword ptr [rsp+0x380]
 
G_M000_IG150:                ;; offset=0x370C
       jmp      G_M000_IG37
 
G_M000_IG151:                ;; offset=0x3711
       vbroadcastss ymm1, dword ptr [reloc @RWD140]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x3A0]
       vbroadcastss ymm3, dword ptr [rdi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vcvtdq2ps ymm3, ymm3
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm3, ymm3, ymm15
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vsubps   ymm3, ymm15, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG36
 
G_M000_IG152:                ;; offset=0x3790
       vmovups  ymm1, ymmword ptr [rsp+0x3A0]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG36
 
G_M000_IG153:                ;; offset=0x37BF
       vmovups  ymm1, ymmword ptr [rsp+0x3A0]
       jmp      G_M000_IG36
 
G_M000_IG154:                ;; offset=0x37CD
       vxorps   ymm7, ymm7, ymm7
       vmovups  ymmword ptr [rsp+0x460], ymm7
       vbroadcastss ymm8, dword ptr [rdi+0x18]
       vbroadcastss ymm9, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x420], ymm9
       vbroadcastss ymm14, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x400], ymm14
       vbroadcastss ymm15, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x3E0], ymm15
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG164
 
G_M000_IG155:                ;; offset=0x3819
       vmovups  ymm7, ymmword ptr [rsp+0x460]
 
G_M000_IG156:                ;; offset=0x3822
       jmp      G_M000_IG21
 
G_M000_IG157:                ;; offset=0x3827
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm9, ymmword ptr [rsp+0x480]
       vbroadcastss ymm2, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm2, ymm1
       vmulps   ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm2, ymm2
       vandps   ymm2, ymm3, ymm2
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm2, ymm2
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm2, ymm2, ymm15
       vsubps   ymm1, ymm1, ymm2
       vcmpltps ymm2, ymm1, ymm9
       vsubps   ymm3, ymm15, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG20
 
G_M000_IG158:                ;; offset=0x38A7
       vmovups  ymm1, ymmword ptr [rsp+0x480]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm1, ymm9
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG20
 
G_M000_IG159:                ;; offset=0x38D7
       vmovups  ymm1, ymmword ptr [rsp+0x480]
       jmp      G_M000_IG20
 
G_M000_IG160:                ;; offset=0x38E5
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
       vbroadcastss ymm1, dword ptr [rdi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vcvtdq2ps ymm1, ymm1
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm1, ymm1, ymm15
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm9
       vsubps   ymm2, ymm15, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vmulps   ymm0, ymm0, ymm15
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       jmp      SHORT G_M000_IG162
 
G_M000_IG161:                ;; offset=0x397E
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vsubps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
 
G_M000_IG162:                ;; offset=0x39C5
       vsubps   ymm0, ymm0, ymm9
       vmovups  ymm15, ymmword ptr [rsp+0x3E0]
       vmulps   ymm0, ymm0, ymm15
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm8, ymm0, ymm8
       vmovups  ymm9, ymmword ptr [rsp+0x420]
       vmulps   ymm10, ymm10, ymm9
       vmulps   ymm11, ymm11, ymm9
       vmulps   ymm12, ymm12, ymm9
       vmovups  ymm14, ymmword ptr [rsp+0x400]
       vmulps   ymm8, ymm8, ymm14
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG156
 
G_M000_IG163:                ;; offset=0x3A14
       vmovups  ymmword ptr [rsp+0x460], ymm7
 
G_M000_IG164:                ;; offset=0x3A1D
       vucomiss xmm13, dword ptr [reloc @RWD140]
       jp       SHORT G_M000_IG165
       je       SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x3A29
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x3A32
       vbroadcastss ymm0, ymm13
       vmulps   ymm8, ymm0, ymm8
 
G_M000_IG167:                ;; offset=0x3A3C
       lea      edx, [rbp+r13]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm10
       vmovups  ymmword ptr [rsp+0xE0], ymm11
       vmovups  ymmword ptr [rsp+0xC0], ymm12
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x3C0]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm10
       vextractf128 xmm7, ymm11
       vextractf128 xmm9, ymm12
       vextractf128 xmmword ptr [rsp+0x450], ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm7
       vinsertf128 ymm12, ymm12, xmm9
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x450]
       je       G_M000_IG161
 
G_M000_IG168:                ;; offset=0x3AF2
       cmp      edx, 3
       je       G_M000_IG160
 
G_M000_IG169:                ;; offset=0x3AFB
       vmulps   ymm0, ymm8, ymmword ptr [rsp+0x3C0]
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       jmp      G_M000_IG162
 
G_M000_IG170:                ;; offset=0x3B2C
       vbroadcastss ymm0, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x2E0]
       vbroadcastss ymm2, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm2, ymm1
       vmulps   ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm2, ymm2
       vandps   ymm2, ymm3, ymm2
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm2, ymm2
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm2, ymm2, ymm15
       vsubps   ymm1, ymm1, ymm2
       vcmpltps ymm2, ymm1, ymm0
       vsubps   ymm3, ymm15, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vmovups  ymmword ptr [rsp+0x2E0], ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm9
       vaddps   ymm8, ymm1, ymmword ptr [rsp+0x380]
       vmovups  ymm1, ymmword ptr [rsp+0x2E0]
       vmovaps  ymm2, ymm0
       vmovaps  ymm0, ymm1
       vmovaps  ymm1, ymm2
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x3BD0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vandps   ymm1, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x2E0], ymm1
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm1, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymm9
       vaddps   ymm8, ymm0, ymmword ptr [rsp+0x380]
       vsubps   ymm0, ymm1, ymmword ptr [rsp+0x2E0]
 
G_M000_IG172:                ;; offset=0x3C1F
       vsubps   ymm0, ymm0, ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymm2
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm9, ymm0, ymm9
       vmovups  ymm10, ymmword ptr [rsp+0x340]
       vmulps   ymm11, ymm11, ymm10
       vmulps   ymm12, ymm12, ymm10
       vmulps   ymm13, ymm13, ymm10
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm9, ymm9, ymm0
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG150
 
G_M000_IG173:                ;; offset=0x3C6A
       vmovups  ymmword ptr [rsp+0x380], ymm8
 
G_M000_IG174:                ;; offset=0x3C73
       vucomiss xmm14, dword ptr [reloc @RWD140]
       jp       SHORT G_M000_IG175
       je       SHORT G_M000_IG177
 
G_M000_IG175:                ;; offset=0x3C7F
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x3C88
       vbroadcastss ymm2, ymm14
       vmulps   ymm9, ymm2, ymm9
 
G_M000_IG177:                ;; offset=0x3C92
       lea      edx, [rbp+r13]
       vmovd    xmm2, edx
       vpbroadcastd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x120], ymm2
       vmovups  ymmword ptr [rsp+0x100], ymm11
       vmovups  ymmword ptr [rsp+0xE0], ymm12
       vmovups  ymmword ptr [rsp+0xC0], ymm13
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x2E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm11
       vextractf128 xmm8, ymm12
       vextractf128 xmm10, ymm13
       vextractf128 xmmword ptr [rsp+0x370], ymm9
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm11, ymm11, xmm7
       vinsertf128 ymm12, ymm12, xmm8
       vinsertf128 ymm13, ymm13, xmm10
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x370]
       je       G_M000_IG171
 
G_M000_IG178:                ;; offset=0x3D48
       cmp      edx, 3
       je       G_M000_IG170
 
G_M000_IG179:                ;; offset=0x3D51
       vmulps   ymm0, ymm9, ymmword ptr [rsp+0x2E0]
       vaddps   ymm8, ymm0, ymmword ptr [rsp+0x380]
       vbroadcastss ymm0, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmovaps  ymm2, ymm0
       vmovaps  ymm0, ymm1
       vmovaps  ymm1, ymm2
       jmp      G_M000_IG172
 
G_M000_IG180:                ;; offset=0x3D8E
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG181:                ;; offset=0x3D95
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG182:                ;; offset=0x3D9C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG183:                ;; offset=0x3DA6
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG184:                ;; offset=0x3DB0
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG185:                ;; offset=0x3DBA
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG186:                ;; offset=0x3DC4
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG187:                ;; offset=0x3DCE
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG188:                ;; offset=0x3DD8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG189:                ;; offset=0x3DE2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG190:                ;; offset=0x3DEC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG191:                ;; offset=0x3DF6
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG192:                ;; offset=0x3E00
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG193:                ;; offset=0x3E0A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000001EEh ; case G_M000_IG13
       	dd	000001BDh ; case G_M000_IG12
       	dd	0000019Ch ; case G_M000_IG11
RWD12  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD32  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD64  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD96  	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD128 	dd	0000040Fh ; case G_M000_IG29
       	dd	000003DCh ; case G_M000_IG28
       	dd	000003B9h ; case G_M000_IG27
RWD140 	dd	3F800000h		;         1
RWD144 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD160 	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD192 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD224 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD256 	dd	40000000h		;         2
RWD260 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD288 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h

; Total bytes of code 15888

; Assembly listing for method (dynamicClass):lambda_method3(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 14 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 256
       vmovaps  xmmword ptr [rsp+0xF0], xmm6
       vmovaps  xmmword ptr [rsp+0xE0], xmm7
       vmovaps  xmmword ptr [rsp+0xD0], xmm8
       vmovaps  xmmword ptr [rsp+0xC0], xmm9
       vmovaps  xmmword ptr [rsp+0xB0], xmm10
       vmovaps  xmmword ptr [rsp+0xA0], xmm11
       vmovaps  xmmword ptr [rsp+0x90], xmm12
       vmovaps  xmmword ptr [rsp+0x80], xmm13
       vmovaps  xmmword ptr [rsp+0x70], xmm14
       vmovaps  xmmword ptr [rsp+0x60], xmm15
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0061
       mov      rsi, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       test     eax, eax
       je       G_M000_IG48
       vmovsd   xmm1, qword ptr [rcx]
       cmp      eax, 1
       jbe      G_M000_IG48
       vmovsd   xmm2, qword ptr [rcx+0x08]
       cmp      eax, 2
       jbe      G_M000_IG48
       vmovsd   xmm3, qword ptr [rcx+0x10]
       vcvtsd2ss xmm6, xmm6, xmm1
       vcvtsd2ss xmm7, xmm7, xmm2
       vcvtsd2ss xmm8, xmm8, xmm3
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 0
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x00CF
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD00]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm9, xmm1, xmm2
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 1
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x18]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x010E
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG35
 
G_M000_IG06:                ;; offset=0x0121
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD04]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm9
       vmovss   xmm9, dword ptr [reloc @RWD08]
       vaddss   xmm1, xmm1, xmm9
       vxorps   xmm10, xmm10, xmm10
       vmovaps  xmm2, xmm10
       vmovss   xmm11, dword ptr [reloc @RWD12]
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vcmpneqps xmm12, xmm2, xmm2
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vbroadcastss xmm13, dword ptr [reloc @RWD08]
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm14, xmm14, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 2
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x20]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01DE
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG36
 
G_M000_IG08:                ;; offset=0x01F1
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm15, xmm15, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 3
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x027E
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG37
 
G_M000_IG10:                ;; offset=0x0291
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD16]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vmovss   dword ptr [rsp+0x2C], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 4
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x30]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x02D6
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG38
 
G_M000_IG12:                ;; offset=0x02E9
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD20]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x2C]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x58], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 5
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x38]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x038A
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG39
 
G_M000_IG14:                ;; offset=0x039D
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vmovss   dword ptr [rsp+0x28], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 6
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x03DA
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG40
 
G_M000_IG16:                ;; offset=0x03ED
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, xmm11
       vaddss   xmm1, xmm1, xmm11
       vmulss   xmm1, xmm1, dword ptr [rsp+0x28]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x50], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0488
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG41
 
G_M000_IG18:                ;; offset=0x049B
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x48], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x052E
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG42
 
G_M000_IG20:                ;; offset=0x0541
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x40], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 9
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x58]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x05D4
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG43
 
G_M000_IG22:                ;; offset=0x05E7
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD24]
       vaddss   xmm1, xmm1, dword ptr [reloc @RWD28]
       vmovss   dword ptr [rsp+0x24], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 10
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x062C
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG44
 
G_M000_IG24:                ;; offset=0x063F
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD32]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x24]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x38], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 11
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x68]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x06E0
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG45
 
G_M000_IG26:                ;; offset=0x06F3
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x30], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0786
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG46
 
G_M000_IG28:                ;; offset=0x0799
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm9
       vmulss   xmm0, xmm0, xmm11
       vcmpeqps xmm1, xmm10, xmm0
       vxorps   xmm2, xmm2, xmm2
       vpcmpgtd xmm2, xmm2, xmm0
       vandps   xmm1, xmm2, xmm1
       vorps    xmm1, xmm1, xmm12
       vcmpltps xmm2, xmm0, xmm10
       vorps    xmm1, xmm2, xmm1
       vandps   xmm2, xmm10, xmm1
       vandnps  xmm0, xmm1, xmm0
       vorps    xmm0, xmm0, xmm2
       vxorps   xmm1, xmm1, xmm1
       vcmpltps xmm2, xmm13, xmm0
       vorps    xmm1, xmm2, xmm1
       vblendvps xmm0, xmm0, xmm13, xmm1
       vcvtss2sd xmm0, xmm0, xmm0
       vmovsd   xmm1, qword ptr [reloc @RWD40]
       vsubsd   xmm2, xmm1, xmm15
       vxorps   xmm3, xmm3, xmm3
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vsubsd   xmm5, xmm4, qword ptr [reloc @RWD48]
       vcmpeqpd xmm6, xmm3, xmm5
       vxorps   xmm7, xmm7, xmm7
       vpcmpgtq xmm7, xmm7, xmm5
       vandpd   xmm6, xmm7, xmm6
       vcmpneqpd xmm7, xmm3, xmm3
       vorpd    xmm6, xmm6, xmm7
       vcmpltpd xmm8, xmm5, xmm3
       vorpd    xmm6, xmm8, xmm6
       vandpd   xmm3, xmm3, xmm6
       vandnpd  xmm5, xmm6, xmm5
       vorpd    xmm3, xmm5, xmm3
       vmovsd   xmm6, qword ptr [rsp+0x30]
       vsubsd   xmm5, xmm6, qword ptr [reloc @RWD56]
       vaddsd   xmm5, xmm5, xmm5
       vxorps   xmm8, xmm8, xmm8
       vsubsd   xmm9, xmm6, qword ptr [reloc @RWD48]
       vdivsd   xmm9, xmm9, qword ptr [reloc @RWD64]
       vcmpeqpd xmm10, xmm8, xmm9
       vxorps   xmm11, xmm11, xmm11
       vpcmpgtq xmm11, xmm11, xmm9
       vandpd   xmm10, xmm11, xmm10
       vorpd    xmm10, xmm10, xmm7
       vcmpltpd xmm11, xmm9, xmm8
       vorpd    xmm10, xmm11, xmm10
       vandpd   xmm8, xmm8, xmm10
       vandnpd  xmm9, xmm10, xmm9
       vorpd    xmm8, xmm9, xmm8
       vmovddup xmm9, qword ptr [reloc @RWD40]
       vmovaps  xmm10, xmm9
 
G_M000_IG29:                ;; offset=0x08B9
       vxorps   xmm11, xmm11, xmm11
       vcmpltpd xmm12, xmm10, xmm8
       vorpd    xmm11, xmm12, xmm11
       vblendvpd xmm8, xmm8, xmm10, xmm11
       vmulsd   xmm10, xmm8, xmm8
       vaddsd   xmm8, xmm8, xmm8
       vmovsd   xmm11, qword ptr [reloc @RWD72]
       vsubsd   xmm8, xmm11, xmm8
       vmulsd   xmm8, xmm8, xmm10
       vsubsd   xmm10, xmm14, qword ptr [reloc @RWD80]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD88]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD96]
       vmovsd   xmm12, qword ptr [rsp+0x58]
       vsubsd   xmm13, xmm12, qword ptr [reloc @RWD56]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD104]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD112]
       vaddsd   xmm10, xmm10, xmm13
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD120]
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD128]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD136]
       vmulsd   xmm2, xmm3, xmm2
       vaddsd   xmm2, xmm10, xmm2
       vmulsd   xmm3, xmm5, qword ptr [reloc @RWD144]
       vaddsd   xmm2, xmm2, xmm3
       vmulsd   xmm3, xmm8, xmm0
       vmulsd   xmm3, xmm3, xmm0
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD152]
       vaddsd   xmm2, xmm2, xmm3
       vsubsd   xmm2, xmm2, qword ptr [reloc @RWD160]
       vmovaps  xmm3, xmm2
       vxorps   xmm5, xmm5, xmm5
       vmovsd   xmm8, qword ptr [rsp+0x38]
       vaddsd   xmm10, xmm8, xmm8
       vsubsd   xmm10, xmm10, xmm1
       vandps   xmm10, xmm10, xmmword ptr [reloc @RWD176]
       vsubsd   xmm10, xmm10, qword ptr [reloc @RWD192]
       vdivsd   xmm10, xmm10, qword ptr [reloc @RWD200]
       vcmpeqpd xmm13, xmm5, xmm10
       vxorps   xmm4, xmm4, xmm4
       vpcmpgtq xmm4, xmm4, xmm10
       vandpd   xmm4, xmm4, xmm13
       vorpd    xmm4, xmm4, xmm7
       vcmpltpd xmm13, xmm10, xmm5
       vorpd    xmm4, xmm13, xmm4
       vandpd   xmm5, xmm5, xmm4
       vandnpd  xmm4, xmm4, xmm10
       vorpd    xmm4, xmm4, xmm5
       vmovaps  xmm5, xmm9
       vxorps   xmm10, xmm10, xmm10
       vcmpltpd xmm13, xmm5, xmm4
       vorpd    xmm10, xmm13, xmm10
       vblendvpd xmm4, xmm4, xmm5, xmm10
       vmulsd   xmm5, xmm4, xmm4
       vaddsd   xmm4, xmm4, xmm4
       vsubsd   xmm4, xmm11, xmm4
       vmulsd   xmm4, xmm5, xmm4
       vsubsd   xmm4, xmm1, xmm4
       vxorps   xmm5, xmm5, xmm5
       vdivsd   xmm2, xmm2, qword ptr [reloc @RWD208]
 
G_M000_IG30:                ;; offset=0x0A05
       vcmpeqpd xmm10, xmm5, xmm2
       vxorps   xmm13, xmm13, xmm13
       vpcmpgtq xmm13, xmm13, xmm2
       vandpd   xmm10, xmm13, xmm10
       vorpd    xmm7, xmm10, xmm7
       vcmpltpd xmm10, xmm2, xmm5
       vorpd    xmm7, xmm10, xmm7
       vandpd   xmm5, xmm5, xmm7
       vandnpd  xmm2, xmm7, xmm2
       vorpd    xmm2, xmm2, xmm5
       vxorps   xmm5, xmm5, xmm5
       vcmpltpd xmm7, xmm9, xmm2
       vorpd    xmm5, xmm7, xmm5
       vblendvpd xmm2, xmm2, xmm9, xmm5
       vmulsd   xmm5, xmm2, xmm2
       vaddsd   xmm2, xmm2, xmm2
       vsubsd   xmm2, xmm11, xmm2
       vmulsd   xmm2, xmm5, xmm2
       vsubsd   xmm1, xmm1, xmm2
       vmulsd   xmm1, xmm1, xmm4
       vmulsd   xmm2, xmm12, qword ptr [reloc @RWD216]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD224]
       vucomisd xmm3, xmm2
       seta     dl
       movzx    rdx, dl
       vsubsd   xmm2, xmm2, xmm3
       vmulsd   xmm2, xmm2, xmm1
       vaddsd   xmm2, xmm2, xmm3
       test     edx, edx
       je       G_M000_IG33
 
G_M000_IG31:                ;; offset=0x0A8B
       cmp      edi, 10
       jle      G_M000_IG47
       vmovsd   qword ptr [rsi], xmm14
       vmovsd   qword ptr [rsi+0x08], xmm15
       vmovsd   qword ptr [rsi+0x10], xmm12
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       vmovsd   qword ptr [rsi+0x30], xmm8
       vmovsd   qword ptr [rsi+0x38], xmm6
       vmovsd   qword ptr [rsi+0x40], xmm0
       vmovsd   qword ptr [rsi+0x48], xmm2
       vmovsd   qword ptr [rsi+0x50], xmm1
 
G_M000_IG32:                ;; offset=0x0ADC
       vmovaps  xmm6, xmmword ptr [rsp+0xF0]
       vmovaps  xmm7, xmmword ptr [rsp+0xE0]
       vmovaps  xmm8, xmmword ptr [rsp+0xD0]
       vmovaps  xmm9, xmmword ptr [rsp+0xC0]
       vmovaps  xmm10, xmmword ptr [rsp+0xB0]
       vmovaps  xmm11, xmmword ptr [rsp+0xA0]
       vmovaps  xmm12, xmmword ptr [rsp+0x90]
       vmovaps  xmm13, xmmword ptr [rsp+0x80]
       vmovaps  xmm14, xmmword ptr [rsp+0x70]
       vmovaps  xmm15, xmmword ptr [rsp+0x60]
       add      rsp, 256
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG33:                ;; offset=0x0B3B
       vmovaps  xmm2, xmm3
       jmp      G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0B44
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG35:                ;; offset=0x0B4E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG36:                ;; offset=0x0B58
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG37:                ;; offset=0x0B62
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG38:                ;; offset=0x0B6C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG39:                ;; offset=0x0B76
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG40:                ;; offset=0x0B80
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG41:                ;; offset=0x0B8A
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG42:                ;; offset=0x0B94
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG43:                ;; offset=0x0B9E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG44:                ;; offset=0x0BA8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG45:                ;; offset=0x0BB2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG46:                ;; offset=0x0BBC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG47:                ;; offset=0x0BC6
       test     edi, edi
       je       G_M000_IG48
       vmovsd   qword ptr [rsi], xmm14
       cmp      edi, 1
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x08], xmm15
       cmp      edi, 2
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x10], xmm12
       cmp      edi, 3
       jbe      SHORT G_M000_IG48
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       cmp      edi, 4
       jbe      SHORT G_M000_IG48
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       cmp      edi, 5
       jbe      SHORT G_M000_IG48
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       cmp      edi, 6
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x30], xmm8
       cmp      edi, 7
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x38], xmm6
       cmp      edi, 8
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x40], xmm0
       cmp      edi, 9
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x48], xmm2
       cmp      edi, 10
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x50], xmm1
       jmp      G_M000_IG32
 
G_M000_IG48:                ;; offset=0x0C4D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	3F47AE14h		;      0.78
RWD04  	dd	3E6147AEh		;      0.22
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F51EB85h		;      0.82
RWD20  	dd	3E3851ECh		;      0.18
RWD24  	dd	3F666666h		;       0.9
RWD28  	dd	3E570A3Dh		;      0.21
RWD32  	dd	3DCCCCCDh		;       0.1
RWD36  	dd	00000000h
RWD40  	dq	3FF0000000000000h	;            1
RWD48  	dq	3FDEB851EB851EB8h	;         0.48
RWD56  	dq	3FE0000000000000h	;          0.5
RWD64  	dq	3FCEB851EB851EB8h	;         0.24
RWD72  	dq	4008000000000000h	;            3
RWD80  	dq	3FD6666666666666h	;         0.35
RWD88  	dq	4038000000000000h	;           24
RWD96  	dq	4000000000000000h	;            2
RWD104 	dq	4044000000000000h	;           40
RWD112 	dq	3FE1EB851EB851ECh	;         0.56
RWD120 	dq	4067C00000000000h	;          190
RWD128 	dq	3FF6666666666666h	;          1.4
RWD136 	dq	3FD3333333333333h	;          0.3
RWD144 	dq	4074000000000000h	;          320
RWD152 	dq	408F400000000000h	;         1000
RWD160 	dq	4010000000000000h	;            4
RWD168 	dd	00000000h, 00000000h
RWD176 	dq	7FFFFFFFFFFFFFFFh, 7FFFFFFFFFFFFFFFh
RWD192 	dq	3F9999999999999Ah	;        0.025
RWD200 	dq	3FB5C28F5C28F5C2h	;        0.085
RWD208 	dq	4042000000000000h	;           36
RWD216 	dq	3FF3333333333333h	;          1.2
RWD224 	dq	C014000000000000h	;           -5

; Total bytes of code 3155

; Assembly listing for method (dynamicClass):lambda_method4(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 384 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       lea      r11, [rsp-0x1BA0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       vmovaps  xmmword ptr [rsp+0x1B90], xmm6
       vmovaps  xmmword ptr [rsp+0x1B80], xmm7
       vmovaps  xmmword ptr [rsp+0x1B70], xmm8
       vmovaps  xmmword ptr [rsp+0x1B60], xmm9
       vmovaps  xmmword ptr [rsp+0x1B50], xmm10
       vmovaps  xmmword ptr [rsp+0x1B40], xmm11
       vmovaps  xmmword ptr [rsp+0x1B30], xmm12
       vmovaps  xmmword ptr [rsp+0x1B20], xmm13
       vmovaps  xmmword ptr [rsp+0x1B10], xmm14
       vmovaps  xmmword ptr [rsp+0x1B00], xmm15
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x30], xmm4
       mov      rax, -0x1980
       vmovdqa  xmmword ptr [rsp+rax+0x19C0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x19D0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x19E0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r8
 
G_M000_IG02:                ;; offset=0x00B2
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG03:                ;; offset=0x00BF
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1AC0]
       xor      r8d, r8d
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG04:                ;; offset=0x00DE
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG05:                ;; offset=0x00EB
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1A80]
       mov      r8d, 1
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1A40]
       mov      rdx, rdi
       mov      r8d, 2
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x1AC0]
       vmovups  ymm1, ymmword ptr [rsp+0x1AE0]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1A20], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A80]
       vmovups  ymm1, ymmword ptr [rsp+0x1AA0]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1A00], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A40]
       vmovups  ymm1, ymmword ptr [rsp+0x1A60]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x19E0], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 0
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x10]
       mov      r14, 0x7FFC65893210
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x01CA
       mov      rdx, rbp
       mov      rcx, r14
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG07:                ;; offset=0x01D6
       vmovups  ymm6, ymmword ptr [rbp+0x08]
       cmp      dword ptr [rdi+0x08], 1
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x18]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01F1
       mov      rcx, 0x7FFC658D3A98
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG180
 
G_M000_IG09:                ;; offset=0x0204
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm7, ymm0, ymmword ptr [rsp+0x1A20]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x1A00]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x19E0]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0234
       mov      edx, edx
       lea      r9, [reloc @RWD00]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG11:                ;; offset=0x024E
       vaddps   ymm0, ymm8, ymm7
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm7, ymm0, ymm7
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x026F
       vaddps   ymm0, ymm9, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm8, ymm8, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm8
       vaddps   ymm7, ymm1, ymm7
       vaddps   ymm9, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm8, ymm0, ymm8
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02A0
       vaddps   ymm0, ymm8, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm9
       vaddps   ymm7, ymm2, ymm7
       vaddps   ymm1, ymm8, ymm1
       vsubps   ymm8, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
 
G_M000_IG14:                ;; offset=0x02D3
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovss   xmm13, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02FC
       cmp      r15d, 1
       jg       G_M000_IG154
 
G_M000_IG16:                ;; offset=0x0306
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm7
       vmovups  ymmword ptr [rsp+0xE0], ymm8
       vmovups  ymmword ptr [rsp+0xC0], ymm9
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x480]
       vextractf128 xmm14, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       vinsertf128 ymm6, ymm6, xmm14
       je       G_M000_IG159
 
G_M000_IG17:                ;; offset=0x037B
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG158
 
G_M000_IG18:                ;; offset=0x038C
       cmp      edx, 3
       je       G_M000_IG157
 
G_M000_IG19:                ;; offset=0x0395
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x480]
 
G_M000_IG20:                ;; offset=0x039E
       vbroadcastss ymm0, ymm13
       vmulps   ymm7, ymm0, ymm1
 
G_M000_IG21:                ;; offset=0x03A7
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 2
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x20]
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x03C2
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm14, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG23:                ;; offset=0x03E6
       vmulps   ymm0, ymm7, ymmword ptr [rbp+0x08]
       vaddps   ymm7, ymm0, ymm6
       vmovups  ymmword ptr [rsp+0x19C0], ymm7
       cmp      dword ptr [rdi+0x08], 3
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x28]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x040E
       mov      rcx, 0x7FFC658D3A98
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG181
 
G_M000_IG25:                ;; offset=0x0421
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x1A20]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x1A00]
       vmulps   ymm10, ymm0, ymmword ptr [rsp+0x19E0]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG30
 
G_M000_IG26:                ;; offset=0x0451
       mov      edx, edx
       lea      r9, [reloc @RWD128]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG27:                ;; offset=0x046B
       vaddps   ymm0, ymm9, ymm8
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       vsubps   ymm10, ymm0, ymm10
       jmp      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x048E
       vaddps   ymm0, ymm10, ymm8
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm9
       vaddps   ymm8, ymm1, ymm8
       vaddps   ymm10, ymm1, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x04C1
       vaddps   ymm0, ymm9, ymm8
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm10, ymm10, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm10
       vaddps   ymm8, ymm2, ymm8
       vaddps   ymm1, ymm9, ymm1
       vsubps   ymm9, ymm1, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm10, ymm0, ymm10
 
G_M000_IG30:                ;; offset=0x04F6
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovaps  ymm13, ymm10
       vmovss   xmm14, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0520
       cmp      r15d, 1
       jg       G_M000_IG148
 
G_M000_IG32:                ;; offset=0x052A
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm9
       vmovups  ymmword ptr [rsp+0xC0], ymm10
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x3A0]
       vextractf128 xmm15, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       vinsertf128 ymm6, ymm6, xmm15
       je       G_M000_IG153
 
G_M000_IG33:                ;; offset=0x059F
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG152
 
G_M000_IG34:                ;; offset=0x05B0
       cmp      edx, 3
       je       G_M000_IG151
 
G_M000_IG35:                ;; offset=0x05B9
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x3A0]
 
G_M000_IG36:                ;; offset=0x05C2
       vbroadcastss ymm0, ymm14
       vmulps   ymm8, ymm0, ymm1
 
G_M000_IG37:                ;; offset=0x05CB
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 4
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x30]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x05E7
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG39:                ;; offset=0x060B
       vmulps   ymm0, ymm8, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x19C0]
       mov      rdx, rdi
       cmp      ebp, 5
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x38]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0633
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm8, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm7, ymm7, xmm8
 
G_M000_IG41:                ;; offset=0x0657
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x19A0], ymm0
       vaddps   ymm7, ymm7, ymmword ptr [rsp+0x19A0]
       cmp      ebp, 6
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdi+0x40]
       cmp      qword ptr [rdi], r14
       je       SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0681
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm8, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm7, ymm7, xmm8
 
G_M000_IG43:                ;; offset=0x06A5
       vmovups  ymm9, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmulps   ymm0, ymm9, ymm7
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1980]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1960]
       lea      r8, [rsp+0x1980]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1920]
       lea      rdx, [rsp+0x1960]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0756
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG182
 
G_M000_IG45:                ;; offset=0x0769
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1900]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1900]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x18E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x18C0]
       lea      r8, [rsp+0x18E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1880]
       lea      rdx, [rsp+0x18C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x08B0
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG183
 
G_M000_IG47:                ;; offset=0x08C3
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1860]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 9
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x58]
       cmp      qword ptr [rbp], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x0959
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG49:                ;; offset=0x097D
       vmovups  ymm0, ymmword ptr [rsp+0x1860]
       vmulps   ymm0, ymm0, ymmword ptr [rbp+0x08]
       vaddps   ymm8, ymm0, ymm6
       cmp      dword ptr [rdi+0x08], 10
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x09A5
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG184
 
G_M000_IG51:                ;; offset=0x09B8
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1840]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 11
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x68]
       cmp      qword ptr [rdi], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0A56
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG53:                ;; offset=0x0A86
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1840]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1820]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1800]
       lea      r8, [rsp+0x1820]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x17C0]
       lea      rdx, [rsp+0x1800]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0B53
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG185
 
G_M000_IG55:                ;; offset=0x0B66
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x17A0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vmovups  ymm0, ymmword ptr [rsp+0x17A0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm6, ymm6, xmm15
       vaddps   ymm8, ymm0, ymm6
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 13
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x78]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0C11
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG186
 
G_M000_IG57:                ;; offset=0x0C24
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1780]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm9, ymmword ptr [rsp+0x1780]
       vaddps   ymm0, ymm0, ymm9
       vinsertf128 ymm8, ymm8, xmm10
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1760]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1740]
       lea      r8, [rsp+0x1760]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1700]
       lea      rdx, [rsp+0x1740]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 14
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x80]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG58:                ;; offset=0x0D75
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0D77
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG187
 
G_M000_IG60:                ;; offset=0x0D8A
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x16E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x16E0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x16C0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x16A0]
       lea      r8, [rsp+0x16C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1660]
       lea      rdx, [rsp+0x16A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 15
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x88]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0ED4
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG188
 
G_M000_IG62:                ;; offset=0x0EE7
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1640]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1640]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1620]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1600]
       lea      r8, [rsp+0x1620]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x15C0]
       lea      rdx, [rsp+0x1600]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 16
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x90]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x1031
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG189
 
G_M000_IG64:                ;; offset=0x1044
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x15A0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 17
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x98]
       cmp      qword ptr [r15], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x10DE
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG66:                ;; offset=0x1102
       vmovups  ymm0, ymmword ptr [rsp+0x15A0]
       vmulps   ymm8, ymm0, ymmword ptr [r15+0x08]
       mov      rdx, rdi
       cmp      ebp, 18
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0xA0]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x1129
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG68:                ;; offset=0x1159
       vaddps   ymm8, ymm8, ymmword ptr [r15+0x08]
       cmp      ebp, 19
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0xA8]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x1177
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG190
 
G_M000_IG70:                ;; offset=0x118A
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1580]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 20
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xB0]
       cmp      qword ptr [rdi], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
       je       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x122B
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG72:                ;; offset=0x125B
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1580]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1560]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1540]
       lea      r8, [rsp+0x1560]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1500]
       lea      rdx, [rsp+0x1540]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 21
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0xB8]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x132B
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG191
 
G_M000_IG74:                ;; offset=0x133E
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x14E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x14E0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x14C0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x14A0]
       lea      r8, [rsp+0x14C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1460]
       lea      rdx, [rsp+0x14A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 22
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0xC0]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x1488
       mov      rax, 0x7FFC658D3A98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG192
 
G_M000_IG76:                ;; offset=0x149B
       lea      rdx, [rsp+0x19E0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1440]
       lea      r8, [rsp+0x1A20]
       lea      r9, [rsp+0x1A00]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1440]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1420]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1400]
       lea      rdx, [rsp+0x19A0]
       lea      r8, [rsp+0x1420]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x13C0]
       lea      rdx, [rsp+0x1400]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 23
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xC8]
       mov      rbp, 0x7FFC658D7970
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x158C
       mov      rdx, rdi
       mov      rcx, rbp
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG78:                ;; offset=0x1598
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       vmovdqu  ymm0, ymmword ptr [rsp+0x1880]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x18A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1380]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 24
       jbe      G_M000_IG193
       mov      r14, gword ptr [rdx+0xD0]
       cmp      qword ptr [r14], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x1622
       mov      rdx, r14
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG80:                ;; offset=0x1646
       vmovups  ymm10, ymmword ptr [r14+0x08]
       vmovups  ymm11, ymmword ptr [r14+0x28]
       cmp      dword ptr [rdi+0x08], 25
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdi+0xD8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x1668
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG82:                ;; offset=0x16A4
       vmovups  ymm14, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x240], ymm14
       vmovups  ymm15, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x220], ymm15
       vmovdqu  ymm0, ymmword ptr [rsp+0x1700]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1720]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymmword ptr [rsp+0x40], ymm14
       vmovups  ymmword ptr [rsp+0x60], ymm15
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1340]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1300]
       lea      r8, [rsp+0x1340]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 26
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xE0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x179D
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG84:                ;; offset=0x17D9
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x200], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x1E0], ymm1
       vmovdqu  ymm2, ymmword ptr [rsp+0x1460]
       vmovdqu  ymmword ptr [rsp+0x80], ymm2
       vmovdqu  ymm2, ymmword ptr [rsp+0x1480]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm2
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x12C0]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 27
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xE8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x188A
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG86:                ;; offset=0x18C6
       vmovups  ymm8, ymmword ptr [rdi+0x08]
       vmovups  ymm9, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x12C0]
       lea      rcx, [rsp+0x1280]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1460]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1480]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x240]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x220]
       vmovups  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1240]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 28
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xF0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x19D3
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG88:                ;; offset=0x1A3B
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1240]
       lea      rcx, [rsp+0x1200]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmmword ptr [rsp+0x1D0], ymm8
       vextractf128 xmmword ptr [rsp+0x1B0], ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x11C0]
       lea      r8, [rsp+0x1200]
       vextractf128 xmm14, ymm10
       vextractf128 xmm15, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1180]
       lea      r8, [rsp+0x11C0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1180]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x11A0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1180]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x11A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1140]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 29
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xF8]
 
G_M000_IG89:                ;; offset=0x1BB9
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1D0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1B0]
       vinsertf128 ymm10, ymm10, xmm14
       vinsertf128 ymm11, ymm11, xmm15
       je       SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x1BEC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG91:                ;; offset=0x1C54
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x180], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x160], ymm1
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1100]
       lea      r8, [rsp+0x1180]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x10C0]
       lea      r8, [rsp+0x1100]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1080]
       lea      rdx, [rsp+0x1140]
       lea      r8, [rsp+0x10C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 30
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x100]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x1D76
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG93:                ;; offset=0x1DDE
       vmovdqu  ymm0, ymmword ptr [rsp+0x1920]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1940]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1040]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 31
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x108]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x1EA9
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG95:                ;; offset=0x1F11
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1040]
       lea      rcx, [rsp+0x1000]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1000]
       lea      rcx, [rsp+0xFC0]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x17C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x200]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1E0]
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xF80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 32
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x110]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x2066
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG97:                ;; offset=0x20CE
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF80]
       lea      rcx, [rsp+0xF40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 33
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x118]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x217E
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG99:                ;; offset=0x21E6
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF40]
       lea      rcx, [rsp+0xF00]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xEC0]
       lea      rdx, [rsp+0xFC0]
       lea      r8, [rsp+0xF00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 34
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x120]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x22B4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG101:                ;; offset=0x231C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1300]
       lea      rcx, [rsp+0xE80]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 35
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x128]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x23CC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG103:                ;; offset=0x2434
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xE80]
       lea      rcx, [rsp+0xE40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 36
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x130]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x24E4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG105:                ;; offset=0x254C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xE00]
       lea      r8, [rsp+0x1380]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xDC0]
       lea      rdx, [rsp+0xE40]
       lea      r8, [rsp+0xE00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD80]
       lea      rdx, [rsp+0xEC0]
       lea      r8, [rsp+0xDC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 37
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x138]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x2638
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG107:                ;; offset=0x26A0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1280]
       lea      rcx, [rsp+0xD40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD00]
       lea      rdx, [rsp+0xD80]
       lea      r8, [rsp+0xD40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x13C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1080]
       lea      rcx, [rsp+0xCC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x13C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xCC0]
       lea      rcx, [rsp+0xC80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 38
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x140]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x27F2
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG109:                ;; offset=0x285A
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC80]
       lea      rcx, [rsp+0xC40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xC00]
       lea      rdx, [rsp+0xD00]
       lea      r8, [rsp+0xC40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 39
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x148]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x2928
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG111:                ;; offset=0x2990
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC00]
       lea      rcx, [rsp+0xBC0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1500]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1520]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x40], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0x60], ymm9
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xB80]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB80]
       lea      rcx, [rsp+0xB40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xB00]
       lea      rdx, [rsp+0xB40]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Abs(Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 40
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x150]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
 
G_M000_IG112:                ;; offset=0x2AE9
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x2B01
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG114:                ;; offset=0x2B69
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB00]
       lea      rcx, [rsp+0xAC0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 41
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x158]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x2C19
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG116:                ;; offset=0x2C81
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xAC0]
       lea      rcx, [rsp+0xA80]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xA40]
       lea      r8, [rsp+0xA80]
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xA00]
       lea      r8, [rsp+0xA40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xA00]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA20]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA00]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA20]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x9C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
 
G_M000_IG117:                ;; offset=0x2E10
       lea      rcx, [rsp+0x980]
       lea      r8, [rsp+0xA00]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x940]
       lea      r8, [rsp+0x980]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x900]
       lea      rdx, [rsp+0x9C0]
       lea      r8, [rsp+0x940]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x8C0]
       lea      r8, [rsp+0x900]
       vextractf128 xmmword ptr [rsp+0x2D0], ymm6
       vextractf128 xmmword ptr [rsp+0x2B0], ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x40], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0x60], ymm11
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x880]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 42
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x160]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2D0]
 
G_M000_IG118:                ;; offset=0x2F74
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x2B0]
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x2F99
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG120:                ;; offset=0x3001
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x880]
       lea      rcx, [rsp+0x840]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x800]
       lea      r8, [rsp+0x840]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x7C0]
       lea      r8, [rsp+0x800]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x7C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7C0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7E0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x780]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x740]
       lea      r8, [rsp+0x7C0]
 
G_M000_IG121:                ;; offset=0x318A
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x700]
       lea      r8, [rsp+0x740]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x6C0]
       lea      rdx, [rsp+0x780]
       lea      r8, [rsp+0x700]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x680]
       lea      r8, [rsp+0x6C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x640]
       lea      rdx, [rsp+0x8C0]
       lea      r8, [rsp+0x680]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rbx, gword ptr [rbx+0x08]
       mov      rdx, rbx
       cmp      dword ptr [rdx+0x08], 43
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x168]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x3267
       mov      rdx, rdi
       mov      rcx, rbp
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG123:                ;; offset=0x3273
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       cmp      dword ptr [rbx+0x08], 44
       jbe      G_M000_IG193
       mov      rbx, gword ptr [rbx+0x170]
       cmp      qword ptr [rbx], rbp
       je       SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x3293
       mov      rdx, rbx
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG125:                ;; offset=0x32B7
       vmovdqu  ymm0, ymmword ptr [rsp+0x17C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x600]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm8
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm9
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x5C0]
       lea      r8, [rsp+0x600]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x5C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x5E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x5A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:LessThan(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):System.Numerics.Vector`1[int]]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x5C0]
       lea      rcx, [rsp+0x560]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x640]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x660]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x560]
       lea      rcx, [rsp+0x520]
 
G_M000_IG126:                ;; offset=0x342F
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x4E0]
       lea      r8, [rsp+0x520]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x4A0]
       lea      rdx, [rsp+0x5A0]
       lea      r8, [rsp+0x4E0]
       lea      r9, [rsp+0xBC0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Select(System.Numerics.Vector`1[int],Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG127:                ;; offset=0x349D
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG128:                ;; offset=0x34A7
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1920]
       xor      edx, edx
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG129:                ;; offset=0x34C2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG130:                ;; offset=0x34CC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1880]
       mov      edx, 1
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG131:                ;; offset=0x34EA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG132:                ;; offset=0x34F4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x17C0]
       mov      edx, 2
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG133:                ;; offset=0x3512
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG134:                ;; offset=0x351C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1700]
       mov      edx, 3
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG135:                ;; offset=0x353A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG136:                ;; offset=0x3544
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1660]
       mov      edx, 4
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG137:                ;; offset=0x3562
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG138:                ;; offset=0x356C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x15C0]
       mov      edx, 5
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG139:                ;; offset=0x358A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG140:                ;; offset=0x3594
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1500]
       mov      edx, 6
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG141:                ;; offset=0x35B2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG142:                ;; offset=0x35BC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1460]
       mov      edx, 7
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG143:                ;; offset=0x35DA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG144:                ;; offset=0x35E4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x13C0]
       mov      edx, 8
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG145:                ;; offset=0x3602
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG146:                ;; offset=0x360C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x4A0]
       mov      edx, 9
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       lea      r9, [rsp+0x640]
       mov      rcx, rsi
       mov      edx, 10
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       nop      
 
G_M000_IG147:                ;; offset=0x3647
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1B90]
       vmovaps  xmm7, xmmword ptr [rsp+0x1B80]
       vmovaps  xmm8, xmmword ptr [rsp+0x1B70]
       vmovaps  xmm9, xmmword ptr [rsp+0x1B60]
       vmovaps  xmm10, xmmword ptr [rsp+0x1B50]
       vmovaps  xmm11, xmmword ptr [rsp+0x1B40]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B30]
       vmovaps  xmm13, xmmword ptr [rsp+0x1B20]
       vmovaps  xmm14, xmmword ptr [rsp+0x1B10]
       vmovaps  xmm15, xmmword ptr [rsp+0x1B00]
       add      rsp, 0x1BA0
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG148:                ;; offset=0x36B6
       vxorps   ymm8, ymm8, ymm8
       vmovups  ymmword ptr [rsp+0x380], ymm8
       vbroadcastss ymm9, dword ptr [rdi+0x18]
       vbroadcastss ymm10, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm10
       vbroadcastss ymm0, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       vbroadcastss ymm1, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x300], ymm1
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG174
 
G_M000_IG149:                ;; offset=0x3703
       vmovups  ymm8, ymmword ptr [rsp+0x380]
 
G_M000_IG150:                ;; offset=0x370C
       jmp      G_M000_IG37
 
G_M000_IG151:                ;; offset=0x3711
       vbroadcastss ymm1, dword ptr [reloc @RWD140]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x3A0]
       vbroadcastss ymm3, dword ptr [rdi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vcvtdq2ps ymm3, ymm3
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm3, ymm3, ymm15
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vsubps   ymm3, ymm15, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG36
 
G_M000_IG152:                ;; offset=0x3790
       vmovups  ymm1, ymmword ptr [rsp+0x3A0]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG36
 
G_M000_IG153:                ;; offset=0x37BF
       vmovups  ymm1, ymmword ptr [rsp+0x3A0]
       jmp      G_M000_IG36
 
G_M000_IG154:                ;; offset=0x37CD
       vxorps   ymm7, ymm7, ymm7
       vmovups  ymmword ptr [rsp+0x460], ymm7
       vbroadcastss ymm8, dword ptr [rdi+0x18]
       vbroadcastss ymm9, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x420], ymm9
       vbroadcastss ymm14, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x400], ymm14
       vbroadcastss ymm15, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x3E0], ymm15
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG164
 
G_M000_IG155:                ;; offset=0x3819
       vmovups  ymm7, ymmword ptr [rsp+0x460]
 
G_M000_IG156:                ;; offset=0x3822
       jmp      G_M000_IG21
 
G_M000_IG157:                ;; offset=0x3827
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm9, ymmword ptr [rsp+0x480]
       vbroadcastss ymm2, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm2, ymm1
       vmulps   ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm2, ymm2
       vandps   ymm2, ymm3, ymm2
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm2, ymm2
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm2, ymm2, ymm15
       vsubps   ymm1, ymm1, ymm2
       vcmpltps ymm2, ymm1, ymm9
       vsubps   ymm3, ymm15, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG20
 
G_M000_IG158:                ;; offset=0x38A7
       vmovups  ymm1, ymmword ptr [rsp+0x480]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm1, ymm9
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG20
 
G_M000_IG159:                ;; offset=0x38D7
       vmovups  ymm1, ymmword ptr [rsp+0x480]
       jmp      G_M000_IG20
 
G_M000_IG160:                ;; offset=0x38E5
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
       vbroadcastss ymm1, dword ptr [rdi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vcvtdq2ps ymm1, ymm1
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm1, ymm1, ymm15
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm9
       vsubps   ymm2, ymm15, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vmulps   ymm0, ymm0, ymm15
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       jmp      SHORT G_M000_IG162
 
G_M000_IG161:                ;; offset=0x397E
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vsubps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
 
G_M000_IG162:                ;; offset=0x39C5
       vsubps   ymm0, ymm0, ymm9
       vmovups  ymm15, ymmword ptr [rsp+0x3E0]
       vmulps   ymm0, ymm0, ymm15
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm8, ymm0, ymm8
       vmovups  ymm9, ymmword ptr [rsp+0x420]
       vmulps   ymm10, ymm10, ymm9
       vmulps   ymm11, ymm11, ymm9
       vmulps   ymm12, ymm12, ymm9
       vmovups  ymm14, ymmword ptr [rsp+0x400]
       vmulps   ymm8, ymm8, ymm14
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG156
 
G_M000_IG163:                ;; offset=0x3A14
       vmovups  ymmword ptr [rsp+0x460], ymm7
 
G_M000_IG164:                ;; offset=0x3A1D
       vucomiss xmm13, dword ptr [reloc @RWD140]
       jp       SHORT G_M000_IG165
       je       SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x3A29
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x3A32
       vbroadcastss ymm0, ymm13
       vmulps   ymm8, ymm0, ymm8
 
G_M000_IG167:                ;; offset=0x3A3C
       lea      edx, [rbp+r13]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm10
       vmovups  ymmword ptr [rsp+0xE0], ymm11
       vmovups  ymmword ptr [rsp+0xC0], ymm12
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x3C0]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm10
       vextractf128 xmm7, ymm11
       vextractf128 xmm9, ymm12
       vextractf128 xmmword ptr [rsp+0x450], ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm7
       vinsertf128 ymm12, ymm12, xmm9
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x450]
       je       G_M000_IG161
 
G_M000_IG168:                ;; offset=0x3AF2
       cmp      edx, 3
       je       G_M000_IG160
 
G_M000_IG169:                ;; offset=0x3AFB
       vmulps   ymm0, ymm8, ymmword ptr [rsp+0x3C0]
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       jmp      G_M000_IG162
 
G_M000_IG170:                ;; offset=0x3B2C
       vbroadcastss ymm0, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x2E0]
       vbroadcastss ymm2, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm2, ymm1
       vmulps   ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm2, ymm2
       vandps   ymm2, ymm3, ymm2
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm2, ymm2
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm2, ymm2, ymm15
       vsubps   ymm1, ymm1, ymm2
       vcmpltps ymm2, ymm1, ymm0
       vsubps   ymm3, ymm15, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vmovups  ymmword ptr [rsp+0x2E0], ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm9
       vaddps   ymm8, ymm1, ymmword ptr [rsp+0x380]
       vmovups  ymm1, ymmword ptr [rsp+0x2E0]
       vmovaps  ymm2, ymm0
       vmovaps  ymm0, ymm1
       vmovaps  ymm1, ymm2
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x3BD0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vandps   ymm1, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x2E0], ymm1
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm1, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymm9
       vaddps   ymm8, ymm0, ymmword ptr [rsp+0x380]
       vsubps   ymm0, ymm1, ymmword ptr [rsp+0x2E0]
 
G_M000_IG172:                ;; offset=0x3C1F
       vsubps   ymm0, ymm0, ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymm2
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm9, ymm0, ymm9
       vmovups  ymm10, ymmword ptr [rsp+0x340]
       vmulps   ymm11, ymm11, ymm10
       vmulps   ymm12, ymm12, ymm10
       vmulps   ymm13, ymm13, ymm10
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm9, ymm9, ymm0
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG150
 
G_M000_IG173:                ;; offset=0x3C6A
       vmovups  ymmword ptr [rsp+0x380], ymm8
 
G_M000_IG174:                ;; offset=0x3C73
       vucomiss xmm14, dword ptr [reloc @RWD140]
       jp       SHORT G_M000_IG175
       je       SHORT G_M000_IG177
 
G_M000_IG175:                ;; offset=0x3C7F
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x3C88
       vbroadcastss ymm2, ymm14
       vmulps   ymm9, ymm2, ymm9
 
G_M000_IG177:                ;; offset=0x3C92
       lea      edx, [rbp+r13]
       vmovd    xmm2, edx
       vpbroadcastd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x120], ymm2
       vmovups  ymmword ptr [rsp+0x100], ymm11
       vmovups  ymmword ptr [rsp+0xE0], ymm12
       vmovups  ymmword ptr [rsp+0xC0], ymm13
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x2E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm11
       vextractf128 xmm8, ymm12
       vextractf128 xmm10, ymm13
       vextractf128 xmmword ptr [rsp+0x370], ymm9
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm11, ymm11, xmm7
       vinsertf128 ymm12, ymm12, xmm8
       vinsertf128 ymm13, ymm13, xmm10
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x370]
       je       G_M000_IG171
 
G_M000_IG178:                ;; offset=0x3D48
       cmp      edx, 3
       je       G_M000_IG170
 
G_M000_IG179:                ;; offset=0x3D51
       vmulps   ymm0, ymm9, ymmword ptr [rsp+0x2E0]
       vaddps   ymm8, ymm0, ymmword ptr [rsp+0x380]
       vbroadcastss ymm0, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmovaps  ymm2, ymm0
       vmovaps  ymm0, ymm1
       vmovaps  ymm1, ymm2
       jmp      G_M000_IG172
 
G_M000_IG180:                ;; offset=0x3D8E
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG181:                ;; offset=0x3D95
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG182:                ;; offset=0x3D9C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG183:                ;; offset=0x3DA6
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG184:                ;; offset=0x3DB0
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG185:                ;; offset=0x3DBA
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG186:                ;; offset=0x3DC4
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG187:                ;; offset=0x3DCE
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG188:                ;; offset=0x3DD8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG189:                ;; offset=0x3DE2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG190:                ;; offset=0x3DEC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG191:                ;; offset=0x3DF6
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG192:                ;; offset=0x3E00
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG193:                ;; offset=0x3E0A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000001EEh ; case G_M000_IG13
       	dd	000001BDh ; case G_M000_IG12
       	dd	0000019Ch ; case G_M000_IG11
RWD12  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD32  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD64  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD96  	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD128 	dd	0000040Fh ; case G_M000_IG29
       	dd	000003DCh ; case G_M000_IG28
       	dd	000003B9h ; case G_M000_IG27
RWD140 	dd	3F800000h		;         1
RWD144 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD160 	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD192 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD224 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD256 	dd	40000000h		;         2
RWD260 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD288 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h

; Total bytes of code 15888

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair (Tier0-FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier-0 switched to FullOpts code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 200.4397
; No PGO data
; 0 inlinees with PGO data; 8 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       sub      rsp, 40
       lea      rbp, [rsp+0x20]
       mov      rax, 0x89B6B666CBBC
       mov      qword ptr [rbp], rax
 
G_M000_IG02:                ;; offset=0x0019
       test     dword ptr [rsp], esp
       sub      rsp, 64
       lea      rax, [rsp+0x20]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rax], ymm0
       vmovdqu  ymmword ptr [rax+0x20], ymm0
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x0035
       mov      r11d, r10d
       imul     r11d, r9d
       add      r11d, r8d
       cmp      r11d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG07
       mov      rbx, bword ptr [rdx]
       vmovsd   xmm0, qword ptr [rbx+8*r11]
       vmovsd   qword ptr [rax+8*r10], xmm0
       inc      r10d
       cmp      r10d, 8
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x005D
       vmovups  ymm0, ymmword ptr [rax]
       add      rax, 32
       vmovups  ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rcx], ymm0
       vmovups  ymmword ptr [rcx+0x20], ymm1
       mov      rax, rcx
       mov      r8, 0x89B6B666CBBC
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG05
       call     CORINFO_HELP_FAIL_FAST
 
G_M000_IG05:                ;; offset=0x008A
       nop      
 
G_M000_IG06:                ;; offset=0x008B
       vzeroupper 
       lea      rsp, [rbp+0x08]
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0095
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 155

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC658DD938
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC658DD93C
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC658F5FD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC658F5FD4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair (Tier0-FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier-0 switched to FullOpts code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 200.4397
; No PGO data
; 0 inlinees with PGO data; 8 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       sub      rsp, 40
       lea      rbp, [rsp+0x20]
       mov      rax, 0x89B6B666CBBC
       mov      qword ptr [rbp], rax
 
G_M000_IG02:                ;; offset=0x0019
       test     dword ptr [rsp], esp
       sub      rsp, 64
       lea      rax, [rsp+0x20]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rax], ymm0
       vmovdqu  ymmword ptr [rax+0x20], ymm0
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x0035
       mov      r11d, r10d
       imul     r11d, r9d
       add      r11d, r8d
       cmp      r11d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG07
       mov      rbx, bword ptr [rdx]
       vmovsd   xmm0, qword ptr [rbx+8*r11]
       vmovsd   qword ptr [rax+8*r10], xmm0
       inc      r10d
       cmp      r10d, 8
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x005D
       vmovups  ymm0, ymmword ptr [rax]
       add      rax, 32
       vmovups  ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rcx], ymm0
       vmovups  ymmword ptr [rcx+0x20], ymm1
       mov      rax, rcx
       mov      r8, 0x89B6B666CBBC
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG05
       call     CORINFO_HELP_FAIL_FAST
 
G_M000_IG05:                ;; offset=0x008A
       nop      
 
G_M000_IG06:                ;; offset=0x008B
       vzeroupper 
       lea      rsp, [rbp+0x08]
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0095
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 155

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC658F7028
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC658F702C
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Internal.VectorOps:GradientCode3D(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int] (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 176
       lea      rbp, [rsp+0xB0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x003B
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x30]
       vpsrld   ymm0, ymm0, 1
       vpand    ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x30]
       vpermd   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vpsrlvd  ymm0, ymm0, ymmword ptr [rbp-0x50]
       vpand    ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vpor     ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       vbroadcastf128 ymm0, xmmword ptr [reloc @RWD128]
       vpshufb  ymm0, ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xB0], ymm0
       mov      rax, qword ptr [rbp+0x10]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rax], ymm0
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x00C3
       vzeroupper 
       add      rsp, 176
       pop      rbp
       ret      
 
RWD00  	dq	0000001C0000001Ch, 0000001C0000001Ch, 0000001C0000001Ch, 0000001C0000001Ch
RWD32  	dq	9159159180480480h, B37B37B3A26A26A2h, 1591591584804804h, 37B37B3796A26A26h
RWD64  	dq	0000000F0000000Fh, 0000000F0000000Fh, 0000000F0000000Fh, 0000000F0000000Fh
RWD96  	dq	8080800080808000h, 8080800080808000h, 8080800080808000h, 8080800080808000h
RWD128 	dq	1511050118100800h, 000000000E0A0602h

; Total bytes of code 207

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC658FECC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC658FECC4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      dword ptr [rbp+0x10], ecx
       vmovss   dword ptr [rbp+0x18], xmm1
       vmovss   dword ptr [rbp+0x20], xmm2
       vmovss   dword ptr [rbp+0x28], xmm3
 
G_M000_IG02:                ;; offset=0x0046
       mov      dword ptr [rbp-0x120], 0x3E8
       vmovss   xmm0, dword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x3C], eax
       vmovss   xmm0, dword ptr [rbp+0x20]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x40], eax
       vmovss   xmm0, dword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x124], xmm0
       vmovss   xmm1, dword ptr [rbp-0x124]
       vmovss   xmm0, dword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x128], xmm0
       vmovss   xmm1, dword ptr [rbp-0x128]
       vmovss   xmm0, dword ptr [rbp+0x20]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x4C], xmm0
       mov      ecx, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x12C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x12C]
       vmovss   xmm0, dword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x50], xmm0
       mov      ecx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x54], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x130], xmm0
       vmovss   xmm0, dword ptr [rbp-0x130]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x134], xmm0
       vmovss   xmm0, dword ptr [rbp-0x134]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x138], eax
       mov      ecx, dword ptr [rbp-0x138]
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x58], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x13C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x13C]
       vmovss   xmm1, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x140], xmm0
       vmovss   xmm0, dword ptr [rbp-0x140]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x144], eax
       mov      ecx, dword ptr [rbp-0x144]
 
G_M000_IG03:                ;; offset=0x01A5
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x5C], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x148], xmm0
       vmovss   xmm0, dword ptr [rbp-0x148]
       vmovss   xmm1, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x14C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x14C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x150], eax
       mov      ecx, dword ptr [rbp-0x150]
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x60], eax
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xC4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x154], xmm0
       vmovss   xmm1, dword ptr [rbp-0x154]
       vmovss   xmm0, dword ptr [rbp-0xC4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x64], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xC8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x158], xmm0
       vmovss   xmm1, dword ptr [rbp-0x158]
       vmovss   xmm0, dword ptr [rbp-0xC8]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       mov      ecx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xCC], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x15C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x15C]
       vmovss   xmm0, dword ptr [rbp-0xCC]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      ecx, dword ptr [rbp-0x3C]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      ecx, dword ptr [rbp-0x40]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
       mov      dword ptr [rbp-0x40], eax
       mov      ecx, dword ptr [rbp-0x44]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
 
G_M000_IG04:                ;; offset=0x02F5
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x70], eax
       mov      ecx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x74], eax
       mov      ecx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x78], eax
       vxorps   xmm0, xmm0, xmm0
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x7C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x7C]
       vmovss   dword ptr [rbp-0x80], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD04]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0xD0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x160], xmm0
       vmovss   xmm1, dword ptr [rbp-0x160]
       vmovss   xmm0, dword ptr [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0xD4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       vmovss   xmm1, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xD8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       vmovss   xmm1, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x164], xmm0
       vmovss   xmm1, dword ptr [rbp-0x164]
       vmovss   xmm0, dword ptr [rbp-0xD8]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x168], xmm0
       vmovss   xmm1, dword ptr [rbp-0x168]
       vmovss   xmm0, dword ptr [rbp-0xD4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x84], xmm0
       xor      eax, eax
       mov      dword ptr [rbp-0x88], eax
 
G_M000_IG05:                ;; offset=0x03FB
       mov      eax, dword ptr [rbp-0x120]
       dec      eax
       mov      dword ptr [rbp-0x120], eax
       cmp      dword ptr [rbp-0x120], 0
       jg       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0412
       lea      rcx, [rbp-0x120]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG07:                ;; offset=0x0423
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
       mov      dword ptr [rbp-0x8C], eax
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x84]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xDC], xmm0
       vmovss   xmm0, dword ptr [rbp-0xDC]
       vmovss   xmm1, dword ptr [rbp-0xDC]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xE0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       vmovss   dword ptr [rsp+0x20], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       vmovss   dword ptr [rsp+0x28], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       vmovss   dword ptr [rsp+0x30], xmm0
       mov      ecx, dword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x3C]
       mov      r8d, dword ptr [rbp-0x40]
       mov      r9d, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int,int,int,float,float,float):float]
       vmovss   dword ptr [rbp-0x16C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x16C]
       vmovss   xmm0, dword ptr [rbp-0xE0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x90], xmm0
       mov      ecx, dword ptr [rbp-0x8C]
       vmovss   xmm1, dword ptr [rbp-0x90]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x170], xmm0
       vmovss   xmm1, dword ptr [rbp-0x170]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x80], xmm0
       vmovss   xmm0, dword ptr [rbp-0x64]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0xE4], eax
       vmovss   xmm0, dword ptr [rbp-0x64]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x174], eax
       mov      edx, dword ptr [rbp-0x174]
       mov      ecx, dword ptr [rbp-0xE4]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x94], eax
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0xE8], eax
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
 
G_M000_IG08:                ;; offset=0x0582
       mov      dword ptr [rbp-0xEC], eax
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x178], eax
       mov      edx, dword ptr [rbp-0x178]
       mov      ecx, dword ptr [rbp-0xEC]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       mov      ecx, dword ptr [rbp-0xE8]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x98], eax
       mov      ecx, dword ptr [rbp-0x94]
       mov      edx, dword ptr [rbp-0x98]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x9C], eax
       mov      ecx, dword ptr [rbp-0x98]
       vmovss   xmm1, dword ptr [rbp-0x68]
       vmovss   xmm2, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x180], xmm0
       vmovss   xmm2, dword ptr [rbp-0x180]
       vmovss   xmm1, dword ptr [rbp-0x64]
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0xA0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0xA0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x184], xmm0
       vmovss   xmm0, dword ptr [rbp-0x184]
       vmovss   xmm1, dword ptr [rbp-0xA0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xF0], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD08]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x188], xmm0
       vmovss   xmm1, dword ptr [rbp-0x188]
       vmovss   xmm0, dword ptr [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0xF4], xmm0
       mov      ecx, dword ptr [rbp-0x58]
       mov      edx, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0xF8], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x18C], eax
       mov      r8d, dword ptr [rbp-0x18C]
       mov      edx, dword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x190], eax
       mov      edx, dword ptr [rbp-0x190]
       mov      ecx, dword ptr [rbp-0x3C]
 
G_M000_IG09:                ;; offset=0x06ED
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xA4], eax
       mov      ecx, dword ptr [rbp-0x5C]
       mov      edx, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0xFC], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x194], eax
       mov      r8d, dword ptr [rbp-0x194]
       mov      edx, dword ptr [rbp-0xFC]
       mov      ecx, dword ptr [rbp-0x98]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x198], eax
       mov      edx, dword ptr [rbp-0x198]
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xA8], eax
       mov      ecx, dword ptr [rbp-0x60]
       mov      edx, dword ptr [rbp-0x78]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0x100], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x19C], eax
       mov      r8d, dword ptr [rbp-0x19C]
       mov      edx, dword ptr [rbp-0x100]
       mov      ecx, dword ptr [rbp-0x9C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x104], eax
       mov      ecx, dword ptr [rbp-0x44]
       mov      edx, dword ptr [rbp-0x104]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xAC], eax
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1A0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A0]
       mov      ecx, dword ptr [rbp-0x94]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1A4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A4]
       vmovss   xmm0, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB0], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1A8], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A8]
       mov      ecx, dword ptr [rbp-0x98]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1AC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1AC]
       vmovss   xmm0, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB4], xmm0
       mov      ecx, dword ptr [rbp-0x60]
 
G_M000_IG10:                ;; offset=0x083E
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1B0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B0]
       mov      ecx, dword ptr [rbp-0x9C]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1B4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B4]
       vmovss   xmm0, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB8], xmm0
       vmovss   xmm0, dword ptr [rbp-0xF4]
       vmovss   xmm1, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
       mov      dword ptr [rbp-0xBC], eax
       vmovss   xmm0, dword ptr [rbp-0xF4]
       vmovss   xmm1, dword ptr [rbp-0xF4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x108], xmm0
       vmovss   xmm0, dword ptr [rbp-0x108]
       vmovss   xmm1, dword ptr [rbp-0x108]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x10C], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB0]
       vmovss   dword ptr [rsp+0x20], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB4]
       vmovss   dword ptr [rsp+0x28], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB8]
       vmovss   dword ptr [rsp+0x30], xmm0
       mov      ecx, dword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0xA4]
       mov      r8d, dword ptr [rbp-0xA8]
       mov      r9d, dword ptr [rbp-0xAC]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int,int,int,float,float,float):float]
       vmovss   dword ptr [rbp-0x1B8], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B8]
       vmovss   xmm0, dword ptr [rbp-0x10C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x110], xmm0
       vmovss   xmm0, dword ptr [rbp-0x110]
       vmovss   dword ptr [rbp-0xC0], xmm0
       mov      ecx, dword ptr [rbp-0xBC]
       vmovss   xmm1, dword ptr [rbp-0xC0]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1BC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1BC]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x80], xmm0
       cmp      dword ptr [rbp-0x88], 1
       je       G_M000_IG14
       mov      rcx, 0x7FFC658FF160
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C0], xmm0
 
G_M000_IG11:                ;; offset=0x09C5
       vmovss   xmm0, dword ptr [rbp-0x1C0]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x64], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1C4]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1C8]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1CC], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1CC]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1D0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D0]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x4C], xmm0
       mov      ecx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1D4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D4]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x50], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD16]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1D8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D8]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x1DC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1DC]
       vmovss   xmm0, dword ptr [rbp-0x114]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x1E0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1E0]
       vmovss   xmm0, dword ptr [rbp-0x84]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x84], xmm0
       mov      ecx, dword ptr [rbp-0x58]
 
G_M000_IG12:                ;; offset=0x0B3C
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1E4], eax
       mov      ecx, dword ptr [rbp-0x1E4]
       mov      edx, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1E8], eax
       mov      edx, dword ptr [rbp-0x1E8]
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      ecx, dword ptr [rbp-0x5C]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1EC], eax
       mov      ecx, dword ptr [rbp-0x1EC]
       mov      edx, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1F0], eax
       mov      edx, dword ptr [rbp-0x1F0]
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x40], eax
       mov      ecx, dword ptr [rbp-0x60]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1F4], eax
       mov      ecx, dword ptr [rbp-0x1F4]
       mov      edx, dword ptr [rbp-0x78]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1F8], eax
       mov      edx, dword ptr [rbp-0x1F8]
       mov      ecx, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x44], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x1FC], eax
       mov      ecx, dword ptr [rbp-0x1FC]
       mov      edx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x58], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x200], eax
       mov      ecx, dword ptr [rbp-0x200]
       mov      edx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x5C], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x204], eax
       mov      ecx, dword ptr [rbp-0x204]
       mov      edx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x60], eax
       mov      ecx, dword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp+0x10], eax
       mov      eax, dword ptr [rbp-0x88]
       inc      eax
 
G_M000_IG13:                ;; offset=0x0C5E
       mov      dword ptr [rbp-0x88], eax
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0C69
       mov      rcx, 0x7FFC658FF164
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm0, dword ptr [reloc @RWD20]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x208], xmm0
       vmovss   xmm1, dword ptr [rbp-0x208]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       nop      
 
G_M000_IG15:                ;; offset=0x0CA2
       add      rsp, 576
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 3243

; Assembly listing for method Tedd.FastNoise.Internal.ScalarOps:GradientCode3D(int):int (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 64
       lea      rbp, [rsp+0x40]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      dword ptr [rbp+0x10], ecx
 
G_M000_IG02:                ;; offset=0x0016
       lea      rcx, [rbp-0x10]
       call     [Tedd.FastNoise.Internal.Tables:get_GradientCodes3D():System.ReadOnlySpan`1[int]]
 
G_M000_IG03:                ;; offset=0x0020
       vmovdqu  xmm0, xmmword ptr [rbp-0x10]
       vmovdqu  xmmword ptr [rbp-0x20], xmm0
 
G_M000_IG04:                ;; offset=0x002A
       lea      rcx, [rbp-0x20]
       mov      edx, dword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.ScalarOps:GatherI(System.ReadOnlySpan`1[int],int):int]
       nop      
 
G_M000_IG05:                ;; offset=0x0038
       add      rsp, 64
       pop      rbp
       ret      
 
; Total bytes of code 62

; Assembly listing for method Tedd.FastNoise.Internal.VectorOps:GradientCode3D(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 176
       lea      rbp, [rsp+0xB0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       vmovdqu  ymmword ptr [rbp-0x30], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x003B
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x30]
       vpsrld   ymm0, ymm0, 1
       vpand    ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x30]
       vpermd   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vpsrlvd  ymm0, ymm0, ymmword ptr [rbp-0x50]
       vpand    ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vpor     ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       vbroadcastf128 ymm0, xmmword ptr [reloc @RWD128]
       vpshufb  ymm0, ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xB0], ymm0
       mov      rax, qword ptr [rbp+0x10]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rax], ymm0
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x00C3
       vzeroupper 
       add      rsp, 176
       pop      rbp
       ret      
 
RWD00  	dq	0000001C0000001Ch, 0000001C0000001Ch, 0000001C0000001Ch, 0000001C0000001Ch
RWD32  	dq	9159159180480480h, B37B37B3A26A26A2h, 1591591584804804h, 37B37B3796A26A26h
RWD64  	dq	0000000F0000000Fh, 0000000F0000000Fh, 0000000F0000000Fh, 0000000F0000000Fh
RWD96  	dq	8080800080808000h, 8080800080808000h, 8080800080808000h, 8080800080808000h
RWD128 	dq	1511050118100800h, 000000000E0A0602h

; Total bytes of code 207

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC658F7028
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC658F702C
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC658FECC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC658FECC4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Internal.ScalarOps:GradientCode3D(int):int (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 64
       lea      rbp, [rsp+0x40]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      dword ptr [rbp+0x10], ecx
 
G_M000_IG02:                ;; offset=0x0016
       lea      rcx, [rbp-0x10]
       call     [Tedd.FastNoise.Internal.Tables:get_GradientCodes3D():System.ReadOnlySpan`1[int]]
 
G_M000_IG03:                ;; offset=0x0020
       vmovdqu  xmm0, xmmword ptr [rbp-0x10]
       vmovdqu  xmmword ptr [rbp-0x20], xmm0
 
G_M000_IG04:                ;; offset=0x002A
       lea      rcx, [rbp-0x20]
       mov      edx, dword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.ScalarOps:GatherI(System.ReadOnlySpan`1[int],int):int]
       nop      
 
G_M000_IG05:                ;; offset=0x0038
       add      rsp, 64
       pop      rbp
       ret      
 
; Total bytes of code 62

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 576
       lea      rbp, [rsp+0x240]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      dword ptr [rbp+0x10], ecx
       vmovss   dword ptr [rbp+0x18], xmm1
       vmovss   dword ptr [rbp+0x20], xmm2
       vmovss   dword ptr [rbp+0x28], xmm3
 
G_M000_IG02:                ;; offset=0x0046
       mov      dword ptr [rbp-0x120], 0x3E8
       vmovss   xmm0, dword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x3C], eax
       vmovss   xmm0, dword ptr [rbp+0x20]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x40], eax
       vmovss   xmm0, dword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.ScalarOps,float,int](float):int]
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x124], xmm0
       vmovss   xmm1, dword ptr [rbp-0x124]
       vmovss   xmm0, dword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x128], xmm0
       vmovss   xmm1, dword ptr [rbp-0x128]
       vmovss   xmm0, dword ptr [rbp+0x20]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x4C], xmm0
       mov      ecx, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x12C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x12C]
       vmovss   xmm0, dword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x50], xmm0
       mov      ecx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x54], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x130], xmm0
       vmovss   xmm0, dword ptr [rbp-0x130]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x134], xmm0
       vmovss   xmm0, dword ptr [rbp-0x134]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x138], eax
       mov      ecx, dword ptr [rbp-0x138]
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x58], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x13C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x13C]
       vmovss   xmm1, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x140], xmm0
       vmovss   xmm0, dword ptr [rbp-0x140]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x144], eax
       mov      ecx, dword ptr [rbp-0x144]
 
G_M000_IG03:                ;; offset=0x01A5
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x5C], eax
       vmovss   xmm0, dword ptr [reloc @RWD00]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x148], xmm0
       vmovss   xmm0, dword ptr [rbp-0x148]
       vmovss   xmm1, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x14C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x14C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToInt(float):int]
       mov      dword ptr [rbp-0x150], eax
       mov      ecx, dword ptr [rbp-0x150]
       mov      edx, dword ptr [rbp-0x54]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      dword ptr [rbp-0x60], eax
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xC4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x154], xmm0
       vmovss   xmm1, dword ptr [rbp-0x154]
       vmovss   xmm0, dword ptr [rbp-0xC4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x64], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xC8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x158], xmm0
       vmovss   xmm1, dword ptr [rbp-0x158]
       vmovss   xmm0, dword ptr [rbp-0xC8]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       mov      ecx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0xCC], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Neg(float):float]
       vmovss   dword ptr [rbp-0x15C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x15C]
       vmovss   xmm0, dword ptr [rbp-0xCC]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      ecx, dword ptr [rbp-0x3C]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      ecx, dword ptr [rbp-0x40]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
       mov      dword ptr [rbp-0x40], eax
       mov      ecx, dword ptr [rbp-0x44]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int):int]
 
G_M000_IG04:                ;; offset=0x02F5
       mov      dword ptr [rbp-0x44], eax
       mov      ecx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x70], eax
       mov      ecx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x74], eax
       mov      ecx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x78], eax
       vxorps   xmm0, xmm0, xmm0
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x7C], xmm0
       vmovss   xmm0, dword ptr [rbp-0x7C]
       vmovss   dword ptr [rbp-0x80], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD04]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0xD0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       vmovss   xmm1, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x160], xmm0
       vmovss   xmm1, dword ptr [rbp-0x160]
       vmovss   xmm0, dword ptr [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0xD4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       vmovss   xmm1, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xD8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       vmovss   xmm1, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x164], xmm0
       vmovss   xmm1, dword ptr [rbp-0x164]
       vmovss   xmm0, dword ptr [rbp-0xD8]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x168], xmm0
       vmovss   xmm1, dword ptr [rbp-0x168]
       vmovss   xmm0, dword ptr [rbp-0xD4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x84], xmm0
       xor      eax, eax
       mov      dword ptr [rbp-0x88], eax
 
G_M000_IG05:                ;; offset=0x03FB
       mov      eax, dword ptr [rbp-0x120]
       dec      eax
       mov      dword ptr [rbp-0x120], eax
       cmp      dword ptr [rbp-0x120], 0
       jg       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0412
       lea      rcx, [rbp-0x120]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG07:                ;; offset=0x0423
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
       mov      dword ptr [rbp-0x8C], eax
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0x84]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xDC], xmm0
       vmovss   xmm0, dword ptr [rbp-0xDC]
       vmovss   xmm1, dword ptr [rbp-0xDC]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0xE0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x48]
       vmovss   dword ptr [rsp+0x20], xmm0
       vmovss   xmm0, dword ptr [rbp-0x4C]
       vmovss   dword ptr [rsp+0x28], xmm0
       vmovss   xmm0, dword ptr [rbp-0x50]
       vmovss   dword ptr [rsp+0x30], xmm0
       mov      ecx, dword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x3C]
       mov      r8d, dword ptr [rbp-0x40]
       mov      r9d, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int,int,int,float,float,float):float]
       vmovss   dword ptr [rbp-0x16C], xmm0
       vmovss   xmm1, dword ptr [rbp-0x16C]
       vmovss   xmm0, dword ptr [rbp-0xE0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x90], xmm0
       mov      ecx, dword ptr [rbp-0x8C]
       vmovss   xmm1, dword ptr [rbp-0x90]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x170], xmm0
       vmovss   xmm1, dword ptr [rbp-0x170]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x80], xmm0
       vmovss   xmm0, dword ptr [rbp-0x64]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0xE4], eax
       vmovss   xmm0, dword ptr [rbp-0x64]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x174], eax
       mov      edx, dword ptr [rbp-0x174]
       mov      ecx, dword ptr [rbp-0xE4]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x94], eax
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0xE8], eax
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
 
G_M000_IG08:                ;; offset=0x0582
       mov      dword ptr [rbp-0xEC], eax
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:LessThanF(float,float):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x178], eax
       mov      edx, dword ptr [rbp-0x178]
       mov      ecx, dword ptr [rbp-0xEC]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x17C], eax
       mov      edx, dword ptr [rbp-0x17C]
       mov      ecx, dword ptr [rbp-0xE8]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x98], eax
       mov      ecx, dword ptr [rbp-0x94]
       mov      edx, dword ptr [rbp-0x98]
       call     [Tedd.FastNoise.Internal.ScalarOps:OrI(int,int):int]
       mov      ecx, eax
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp-0x9C], eax
       mov      ecx, dword ptr [rbp-0x98]
       vmovss   xmm1, dword ptr [rbp-0x68]
       vmovss   xmm2, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x180], xmm0
       vmovss   xmm2, dword ptr [rbp-0x180]
       vmovss   xmm1, dword ptr [rbp-0x64]
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0xA0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x84]
       vmovss   xmm1, dword ptr [rbp-0xA0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x184], xmm0
       vmovss   xmm0, dword ptr [rbp-0x184]
       vmovss   xmm1, dword ptr [rbp-0xA0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xF0], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD08]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x188], xmm0
       vmovss   xmm1, dword ptr [rbp-0x188]
       vmovss   xmm0, dword ptr [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0xF4], xmm0
       mov      ecx, dword ptr [rbp-0x58]
       mov      edx, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0xF8], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x18C], eax
       mov      r8d, dword ptr [rbp-0x18C]
       mov      edx, dword ptr [rbp-0xF8]
       mov      ecx, dword ptr [rbp-0x94]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x190], eax
       mov      edx, dword ptr [rbp-0x190]
       mov      ecx, dword ptr [rbp-0x3C]
 
G_M000_IG09:                ;; offset=0x06ED
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xA4], eax
       mov      ecx, dword ptr [rbp-0x5C]
       mov      edx, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0xFC], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x194], eax
       mov      r8d, dword ptr [rbp-0x194]
       mov      edx, dword ptr [rbp-0xFC]
       mov      ecx, dword ptr [rbp-0x98]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x198], eax
       mov      edx, dword ptr [rbp-0x198]
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xA8], eax
       mov      ecx, dword ptr [rbp-0x60]
       mov      edx, dword ptr [rbp-0x78]
       call     [Tedd.FastNoise.Internal.ScalarOps:MulI(int,int):int]
       mov      dword ptr [rbp-0x100], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x19C], eax
       mov      r8d, dword ptr [rbp-0x19C]
       mov      edx, dword ptr [rbp-0x100]
       mov      ecx, dword ptr [rbp-0x9C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectI(int,int,int):int]
       mov      dword ptr [rbp-0x104], eax
       mov      ecx, dword ptr [rbp-0x44]
       mov      edx, dword ptr [rbp-0x104]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0xAC], eax
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1A0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A0]
       mov      ecx, dword ptr [rbp-0x94]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1A4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A4]
       vmovss   xmm0, dword ptr [rbp-0x48]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB0], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1A8], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1A8]
       mov      ecx, dword ptr [rbp-0x98]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1AC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1AC]
       vmovss   xmm0, dword ptr [rbp-0x4C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB4], xmm0
       mov      ecx, dword ptr [rbp-0x60]
 
G_M000_IG10:                ;; offset=0x083E
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1B0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B0]
       mov      ecx, dword ptr [rbp-0x9C]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1B4], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B4]
       vmovss   xmm0, dword ptr [rbp-0x50]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0xB8], xmm0
       vmovss   xmm0, dword ptr [rbp-0xF4]
       vmovss   xmm1, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:GreaterThanF(float,float):int]
       mov      dword ptr [rbp-0xBC], eax
       vmovss   xmm0, dword ptr [rbp-0xF4]
       vmovss   xmm1, dword ptr [rbp-0xF4]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x108], xmm0
       vmovss   xmm0, dword ptr [rbp-0x108]
       vmovss   xmm1, dword ptr [rbp-0x108]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x10C], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB0]
       vmovss   dword ptr [rsp+0x20], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB4]
       vmovss   dword ptr [rsp+0x28], xmm0
       vmovss   xmm0, dword ptr [rbp-0xB8]
       vmovss   dword ptr [rsp+0x30], xmm0
       mov      ecx, dword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0xA4]
       mov      r8d, dword ptr [rbp-0xA8]
       mov      r9d, dword ptr [rbp-0xAC]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,int,int,int,float,float,float):float]
       vmovss   dword ptr [rbp-0x1B8], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1B8]
       vmovss   xmm0, dword ptr [rbp-0x10C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x110], xmm0
       vmovss   xmm0, dword ptr [rbp-0x110]
       vmovss   dword ptr [rbp-0xC0], xmm0
       mov      ecx, dword ptr [rbp-0xBC]
       vmovss   xmm1, dword ptr [rbp-0xC0]
       vmovss   xmm2, dword ptr [rbp-0x7C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SelectF(int,float,float):float]
       vmovss   dword ptr [rbp-0x1BC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1BC]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x80], xmm0
       cmp      dword ptr [rbp-0x88], 1
       je       G_M000_IG14
       mov      rcx, 0x7FFC658FF160
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C0], xmm0
 
G_M000_IG11:                ;; offset=0x09C5
       vmovss   xmm0, dword ptr [rbp-0x1C0]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x64], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1C4]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x68], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD12]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1C8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1C8]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x6C], xmm0
       mov      ecx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1CC], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1CC]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x48], xmm0
       mov      ecx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1D0], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D0]
       vmovss   xmm1, dword ptr [rbp-0x68]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x4C], xmm0
       mov      ecx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:ToFloat(int):float]
       vmovss   dword ptr [rbp-0x1D4], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D4]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       vmovss   dword ptr [rbp-0x50], xmm0
       vmovss   xmm0, dword ptr [reloc @RWD16]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x1D8], xmm0
       vmovss   xmm0, dword ptr [rbp-0x1D8]
       vmovss   xmm1, dword ptr [rbp-0x64]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x68]
       vmovss   xmm1, dword ptr [rbp-0x6C]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x1DC], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1DC]
       vmovss   xmm0, dword ptr [rbp-0x114]
       call     [Tedd.FastNoise.Internal.ScalarOps:Sub(float,float):float]
       vmovss   dword ptr [rbp-0x1E0], xmm0
       vmovss   xmm1, dword ptr [rbp-0x1E0]
       vmovss   xmm0, dword ptr [rbp-0x84]
       call     [Tedd.FastNoise.Internal.ScalarOps:Add(float,float):float]
       vmovss   dword ptr [rbp-0x84], xmm0
       mov      ecx, dword ptr [rbp-0x58]
 
G_M000_IG12:                ;; offset=0x0B3C
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1E4], eax
       mov      ecx, dword ptr [rbp-0x1E4]
       mov      edx, dword ptr [rbp-0x70]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1E8], eax
       mov      edx, dword ptr [rbp-0x1E8]
       mov      ecx, dword ptr [rbp-0x3C]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x3C], eax
       mov      ecx, dword ptr [rbp-0x5C]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1EC], eax
       mov      ecx, dword ptr [rbp-0x1EC]
       mov      edx, dword ptr [rbp-0x74]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1F0], eax
       mov      edx, dword ptr [rbp-0x1F0]
       mov      ecx, dword ptr [rbp-0x40]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x40], eax
       mov      ecx, dword ptr [rbp-0x60]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.ScalarOps:ShiftRightArithmetic(int,int):int]
       mov      dword ptr [rbp-0x1F4], eax
       mov      ecx, dword ptr [rbp-0x1F4]
       mov      edx, dword ptr [rbp-0x78]
       call     [Tedd.FastNoise.Internal.ScalarOps:AndI(int,int):int]
       mov      dword ptr [rbp-0x1F8], eax
       mov      edx, dword ptr [rbp-0x1F8]
       mov      ecx, dword ptr [rbp-0x44]
       call     [Tedd.FastNoise.Internal.ScalarOps:AddI(int,int):int]
       mov      dword ptr [rbp-0x44], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x1FC], eax
       mov      ecx, dword ptr [rbp-0x1FC]
       mov      edx, dword ptr [rbp-0x58]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x58], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x200], eax
       mov      ecx, dword ptr [rbp-0x200]
       mov      edx, dword ptr [rbp-0x5C]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x5C], eax
       xor      ecx, ecx
       call     [Tedd.FastNoise.Internal.ScalarOps:I(int):int]
       mov      dword ptr [rbp-0x204], eax
       mov      ecx, dword ptr [rbp-0x204]
       mov      edx, dword ptr [rbp-0x60]
       call     [Tedd.FastNoise.Internal.ScalarOps:SubI(int,int):int]
       mov      dword ptr [rbp-0x60], eax
       mov      ecx, dword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.ScalarOps:NotI(int):int]
       mov      dword ptr [rbp+0x10], eax
       mov      eax, dword ptr [rbp-0x88]
       inc      eax
 
G_M000_IG13:                ;; offset=0x0C5E
       mov      dword ptr [rbp-0x88], eax
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0C69
       mov      rcx, 0x7FFC658FF164
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm0, dword ptr [reloc @RWD20]
       call     [Tedd.FastNoise.Internal.ScalarOps:F(float):float]
       vmovss   dword ptr [rbp-0x208], xmm0
       vmovss   xmm1, dword ptr [rbp-0x208]
       vmovss   xmm0, dword ptr [rbp-0x80]
       call     [Tedd.FastNoise.Internal.ScalarOps:Mul(float,float):float]
       nop      
 
G_M000_IG15:                ;; offset=0x0CA2
       add      rsp, 576
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 3243

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC658DD938
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC658DD93C
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC658F5FD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC658F5FD4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Internal.VectorOps:GradientCode3D(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int] (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 89.6
; No PGO data

G_M000_IG01:                ;; offset=0x0000
 
G_M000_IG02:                ;; offset=0x0000
       vmovups  ymm0, ymmword ptr [rdx]
       vpermd   ymm1, ymm0, ymmword ptr [reloc @RWD00]
       vpsrld   ymm0, ymm0, 1
       vpand    ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vpsrlvd  ymm0, ymm1, ymm0
       vpand    ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vpor     ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vbroadcastf128 ymm1, xmmword ptr [reloc @RWD128]
       vpshufb  ymm0, ymm1, ymm0
       vmovups  ymmword ptr [rcx], ymm0
       mov      rax, rcx
 
G_M000_IG03:                ;; offset=0x0044
       vzeroupper 
       ret      
 
RWD00  	dq	9159159180480480h, B37B37B3A26A26A2h, 1591591584804804h, 37B37B3796A26A26h
RWD32  	dq	0000001C0000001Ch, 0000001C0000001Ch, 0000001C0000001Ch, 0000001C0000001Ch
RWD64  	dq	0000000F0000000Fh, 0000000F0000000Fh, 0000000F0000000Fh, 0000000F0000000Fh
RWD96  	dq	8080800080808000h, 8080800080808000h, 8080800080808000h, 8080800080808000h
RWD128 	dq	1511050118100800h, 000000000E0A0602h

; Total bytes of code 72

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 19240
; 0 inlinees with PGO data; 289 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       sub      rsp, 984
       vmovaps  xmmword ptr [rsp+0x3C0], xmm6
       vmovaps  xmmword ptr [rsp+0x3B0], xmm7
       vmovaps  xmmword ptr [rsp+0x3A0], xmm8
       vmovaps  xmmword ptr [rsp+0x390], xmm9
       vmovaps  xmmword ptr [rsp+0x380], xmm10
       vmovaps  xmmword ptr [rsp+0x370], xmm11
       vmovaps  xmmword ptr [rsp+0x360], xmm12
       vmovaps  xmmword ptr [rsp+0x350], xmm13
       vmovaps  xmmword ptr [rsp+0x340], xmm14
       vmovaps  xmmword ptr [rsp+0x330], xmm15
       mov      rax, bword ptr [rsp+0x400]
 
G_M000_IG02:                ;; offset=0x0069
       vmovups  ymm0, ymmword ptr [r8]
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm0, ymm1
       vbroadcastss ymm2, dword ptr [reloc @RWD00]
       vbroadcastss ymm3, dword ptr [reloc @RWD04]
       vmovups  ymmword ptr [rsp+0x40], ymm3
       vblendvps ymm1, ymm3, ymm2, ymm1
       vaddps   ymm1, ymm1, ymm0
       vcmpeqps ymm4, ymm1, ymm1
       vandps   ymm1, ymm4, ymm1
       vbroadcastss ymm4, dword ptr [reloc @RWD08]
       vcmpgeps ymm5, ymm1, ymm4
       vbroadcastss ymm6, dword ptr [reloc @RWD12]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymm6, ymm5
       vmovups  ymm5, ymmword ptr [r9]
       vxorps   ymm7, ymm7, ymm7
       vcmpltps ymm7, ymm5, ymm7
       vblendvps ymm7, ymm3, ymm2, ymm7
       vaddps   ymm7, ymm7, ymm5
       vcmpeqps ymm8, ymm7, ymm7
       vandps   ymm7, ymm8, ymm7
       vcmpgeps ymm8, ymm7, ymm4
       vcvttps2dq ymm7, ymm7
       vpblendvb ymm7, ymm7, ymm6, ymm8
       vmovups  ymm8, ymmword ptr [rax]
       vxorps   ymm9, ymm9, ymm9
       vcmpltps ymm9, ymm8, ymm9
       vblendvps ymm2, ymm3, ymm2, ymm9
       vaddps   ymm2, ymm2, ymm8
       vcmpeqps ymm9, ymm2, ymm2
       vandps   ymm2, ymm9, ymm2
       vcmpgeps ymm9, ymm2, ymm4
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm6, ymm9
       vcvtdq2ps ymm9, ymm1
       vsubps   ymm0, ymm0, ymm9
       vcvtdq2ps ymm9, ymm7
       vsubps   ymm5, ymm5, ymm9
       vcvtdq2ps ymm9, ymm2
       vsubps   ymm8, ymm8, ymm9
       vbroadcastss ymm9, dword ptr [reloc @RWD16]
       vmovups  ymmword ptr [rsp+0x20], ymm9
       vmovaps  ymm10, ymm9
       vbroadcastss ymm11, dword ptr [reloc @RWD20]
       vsubps   ymm12, ymm11, ymm0
       vcmpeqps ymm13, ymm12, ymm12
       vandps   ymm12, ymm13, ymm12
       vcmpgeps ymm13, ymm12, ymm4
       vcvttps2dq ymm12, ymm12
       vpblendvb ymm12, ymm12, ymm6, ymm13
       vpor     ymm12, ymm12, ymm10
       vsubps   ymm13, ymm11, ymm5
       vcmpeqps ymm14, ymm13, ymm13
       vandps   ymm13, ymm14, ymm13
       vcmpgeps ymm14, ymm13, ymm4
       vcvttps2dq ymm13, ymm13
       vpblendvb ymm13, ymm13, ymm6, ymm14
       vpor     ymm13, ymm13, ymm10
       vsubps   ymm11, ymm11, ymm8
       vcmpeqps ymm14, ymm11, ymm11
       vandps   ymm11, ymm14, ymm11
 
G_M000_IG03:                ;; offset=0x01B5
       vcmpgeps ymm4, ymm11, ymm4
       vcvttps2dq ymm11, ymm11
       vpblendvb ymm4, ymm11, ymm6, ymm4
       vpor     ymm4, ymm4, ymm10
       vbroadcastss ymm6, dword ptr [reloc @RWD24]
       vxorps   ymm10, ymm6, ymm0
       vmovups  ymmword ptr [rsp+0x2C0], ymm12
       vcvtdq2ps ymm11, ymm12
       vmulps   ymm10, ymm10, ymm11
       vxorps   ymm11, ymm6, ymm5
       vmovups  ymmword ptr [rsp+0x2A0], ymm13
       vcvtdq2ps ymm14, ymm13
       vmulps   ymm11, ymm11, ymm14
       vxorps   ymm14, ymm6, ymm8
       vmovups  ymmword ptr [rsp+0x280], ymm4
       vcvtdq2ps ymm15, ymm4
       vmulps   ymm14, ymm14, ymm15
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD32]
       vpmulld  ymm7, ymm7, ymmword ptr [reloc @RWD64]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD96]
       vbroadcastss ymm15, dword ptr [reloc @RWD32]
       vmovups  ymmword ptr [rsp+0x260], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rsp+0x240], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0x220], ymm15
       vxorps   ymm15, ymm15, ymm15
       vxorps   ymm9, ymm9, ymm9
       vmulps   ymm3, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0x310], ymm3
       vmulps   ymm3, ymm8, ymm8
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x310]
       vmovups  ymmword ptr [rsp+0x310], ymm3
       vmulps   ymm3, ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x2F0], ymm3
       vbroadcastss ymm3, dword ptr [reloc @RWD128]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x2F0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x310]
       xor      eax, eax
 
G_M000_IG04:                ;; offset=0x02C1
       vcmpgtps ymm4, ymm3, ymm15
       vmovups  ymmword ptr [rsp+0x1E0], ymm4
       vmulps   ymm4, ymm3, ymm3
       vmulps   ymm4, ymm4, ymm4
       vmovups  ymmword ptr [rsp+0xA0], ymm4
       vmovups  ymm4, ymmword ptr [rdx]
       vmovups  ymmword ptr [rsp], ymm4
       vpxor    ymm4, ymm1, ymm4
       vpxor    ymm4, ymm4, ymm7
       vpxor    ymm4, ymm4, ymm2
       vpmulld  ymm4, ymm4, ymmword ptr [reloc @RWD160]
       vpsrad   ymm13, ymm4, 15
       vpxor    ymm4, ymm13, ymm4
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD192]
       vpsrld   ymm4, ymm4, 2
       vpermd   ymm13, ymm4, ymmword ptr [reloc @RWD224]
       vpsrld   ymm4, ymm4, 1
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD256]
       vpsrlvd  ymm4, ymm13, ymm4
       vpand    ymm4, ymm4, ymmword ptr [reloc @RWD288]
       vpor     ymm4, ymm4, ymmword ptr [reloc @RWD320]
       vbroadcastf128 ymm13, xmmword ptr [reloc @RWD352]
       vpshufb  ymm4, ymm13, ymm4
       vmovups  ymmword ptr [rsp+0x60], ymm4
       vpand    ymm13, ymm4, ymmword ptr [reloc @RWD384]
       vxorps   ymm12, ymm12, ymm12
       vpcmpeqd ymm12, ymm12, ymm13
       vmovups  ymmword ptr [rsp+0x310], ymm12
       vpslld   ymm12, ymm4, 29
       vpand    ymm12, ymm12, ymm6
       vpxor    ymm12, ymm12, ymm0
       vmovups  ymm4, ymmword ptr [rsp+0x310]
       vblendvps ymm4, ymm12, ymm15, ymm4
       vmovups  ymmword ptr [rsp+0x310], ymm4
       vmovups  ymm12, ymmword ptr [rsp+0x20]
       vpcmpeqd ymm12, ymm12, ymm13
       vmovups  ymm4, ymmword ptr [rsp+0x60]
       vpslld   ymm4, ymm4, 28
       vpand    ymm4, ymm4, ymm6
       vpxor    ymm4, ymm4, ymm5
       vblendvps ymm4, ymm4, ymm15, ymm12
       vaddps   ymm4, ymm4, ymmword ptr [rsp+0x310]
       vpcmpeqd ymm12, ymm13, ymmword ptr [reloc @RWD416]
       vmovups  ymm13, ymmword ptr [rsp+0x60]
       vpslld   ymm13, ymm13, 27
       vpand    ymm13, ymm13, ymm6
       vpxor    ymm13, ymm13, ymm8
       vblendvps ymm12, ymm13, ymm15, ymm12
       vaddps   ymm4, ymm12, ymm4
       vmovups  ymm12, ymmword ptr [rsp+0xA0]
       vmulps   ymm4, ymm12, ymm4
       vmovups  ymm12, ymmword ptr [rsp+0x1E0]
       vandps   ymm4, ymm4, ymm12
       vandnps  ymm12, ymm12, ymm15
       vorps    ymm4, ymm12, ymm4
       vaddps   ymm9, ymm4, ymm9
       vmovups  ymmword ptr [rsp+0x200], ymm9
       vcmpnltps ymm4, ymm10, ymm11
       vcmpnltps ymm12, ymm10, ymm14
 
G_M000_IG05:                ;; offset=0x0426
       vpand    ymm4, ymm12, ymm4
       vcmpgtps ymm12, ymm11, ymm10
       vcmpnltps ymm13, ymm11, ymm14
       vpand    ymm12, ymm13, ymm12
       vpandn   ymm12, ymm4, ymm12
       vpor     ymm13, ymm4, ymm12
       vmovups  ymmword ptr [rsp+0x310], ymm13
       vpcmpeqd ymm13, ymm13, ymm13
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x310]
       vmovups  ymmword ptr [rsp+0x1C0], ymm13
       vandps   ymm13, ymm10, ymm4
       vmovups  ymmword ptr [rsp+0x310], ymm13
       vandps   ymm13, ymm11, ymm12
       vmovups  ymmword ptr [rsp+0x2F0], ymm13
       vandnps  ymm13, ymm12, ymm14
       vorps    ymm13, ymm13, ymmword ptr [rsp+0x2F0]
       vandnps  ymm13, ymm4, ymm13
       vorps    ymm13, ymm13, ymmword ptr [rsp+0x310]
       vmovups  ymmword ptr [rsp+0x1A0], ymm13
       vaddps   ymm13, ymm3, ymm13
       vaddps   ymm13, ymm13, ymmword ptr [rsp+0x1A0]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD448]
       vmovups  ymm9, ymmword ptr [rsp+0x2C0]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x260]
       vpand    ymm9, ymm9, ymm4
       vmovups  ymmword ptr [rsp+0x310], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm4, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x310]
       vpsubd   ymm9, ymm1, ymm9
       vmovups  ymmword ptr [rsp+0x180], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x2A0]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x240]
       vpand    ymm9, ymm9, ymm12
       vmovups  ymmword ptr [rsp+0x310], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm12, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x310]
       vpsubd   ymm9, ymm7, ymm9
       vmovups  ymmword ptr [rsp+0x160], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x280]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x220]
       vpand    ymm9, ymm9, ymmword ptr [rsp+0x1C0]
       vmovups  ymmword ptr [rsp+0x310], ymm9
       vxorps   ymm9, ymm9, ymm9
       vmovups  ymmword ptr [rsp+0x2F0], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x1C0]
       vpandn   ymm9, ymm9, ymmword ptr [rsp+0x2F0]
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x310]
       vpsubd   ymm9, ymm2, ymm9
       vmovups  ymmword ptr [rsp+0x140], ymm9
       vcvtdq2ps ymm9, ymmword ptr [rsp+0x2C0]
       vandps   ymm9, ymm9, ymm4
       vandnps  ymm4, ymm4, ymm15
       vorps    ymm4, ymm4, ymm9
       vaddps   ymm0, ymm4, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm9, ymmword ptr [rsp+0x2A0]
       vcvtdq2ps ymm4, ymm9
 
G_M000_IG06:                ;; offset=0x05CC
       vandps   ymm4, ymm4, ymm12
       vandnps  ymm12, ymm12, ymm15
       vorps    ymm4, ymm12, ymm4
       vaddps   ymm5, ymm4, ymm5
       vmovups  ymmword ptr [rsp+0x100], ymm5
       vmovups  ymm4, ymmword ptr [rsp+0x280]
       vcvtdq2ps ymm12, ymm4
       vmovups  ymm5, ymmword ptr [rsp+0x1C0]
       vandps   ymm12, ymm12, ymm5
       vandnps  ymm5, ymm5, ymm15
       vorps    ymm5, ymm5, ymm12
       vaddps   ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm5
       vcmpgtps ymm8, ymm13, ymm15
       vmovups  ymmword ptr [rsp+0xC0], ymm8
       vmulps   ymm12, ymm13, ymm13
       vmulps   ymm12, ymm12, ymm12
       vmovups  ymmword ptr [rsp+0x80], ymm12
       vmovups  ymm13, ymmword ptr [rsp+0x180]
       vpxor    ymm13, ymm13, ymmword ptr [rsp]
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x160]
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x140]
       vpmulld  ymm13, ymm13, ymmword ptr [reloc @RWD160]
       vpsrad   ymm5, ymm13, 15
       vpxor    ymm5, ymm5, ymm13
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD192]
       vpsrld   ymm5, ymm5, 2
       vpermd   ymm13, ymm5, ymmword ptr [reloc @RWD224]
       vpsrld   ymm5, ymm5, 1
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD256]
       vpsrlvd  ymm5, ymm13, ymm5
       vpand    ymm5, ymm5, ymmword ptr [reloc @RWD288]
       vpor     ymm5, ymm5, ymmword ptr [reloc @RWD320]
       vbroadcastf128 ymm13, xmmword ptr [reloc @RWD352]
       vpshufb  ymm5, ymm13, ymm5
       vpand    ymm13, ymm5, ymmword ptr [reloc @RWD384]
       vxorps   ymm0, ymm0, ymm0
       vpcmpeqd ymm0, ymm0, ymm13
       vpslld   ymm8, ymm5, 29
       vpand    ymm8, ymm8, ymm6
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x120]
       vblendvps ymm0, ymm8, ymm15, ymm0
       vmovups  ymm8, ymmword ptr [rsp+0x20]
       vpcmpeqd ymm8, ymm8, ymm13
       vpslld   ymm12, ymm5, 28
       vpand    ymm12, ymm12, ymm6
       vpxor    ymm12, ymm12, ymmword ptr [rsp+0x100]
       vblendvps ymm8, ymm12, ymm15, ymm8
       vaddps   ymm0, ymm8, ymm0
       vpcmpeqd ymm8, ymm13, ymmword ptr [reloc @RWD416]
       vpslld   ymm5, ymm5, 27
       vpand    ymm5, ymm5, ymm6
       vpxor    ymm5, ymm5, ymmword ptr [rsp+0xE0]
       vblendvps ymm5, ymm5, ymm15, ymm8
       vaddps   ymm0, ymm5, ymm0
       vmovups  ymm12, ymmword ptr [rsp+0x80]
       vmulps   ymm0, ymm12, ymm0
       vmovups  ymm8, ymmword ptr [rsp+0xC0]
       vandps   ymm0, ymm0, ymm8
 
G_M000_IG07:                ;; offset=0x0744
       vandnps  ymm5, ymm8, ymm15
       vorps    ymm0, ymm5, ymm0
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x200]
       cmp      eax, 1
       jne      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x075B
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD480]
       vmovups  ymmword ptr [rcx], ymm0
       mov      rax, rcx
 
G_M000_IG09:                ;; offset=0x076A
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x3C0]
       vmovaps  xmm7, xmmword ptr [rsp+0x3B0]
       vmovaps  xmm8, xmmword ptr [rsp+0x3A0]
       vmovaps  xmm9, xmmword ptr [rsp+0x390]
       vmovaps  xmm10, xmmword ptr [rsp+0x380]
       vmovaps  xmm11, xmmword ptr [rsp+0x370]
       vmovaps  xmm12, xmmword ptr [rsp+0x360]
       vmovaps  xmm13, xmmword ptr [rsp+0x350]
       vmovaps  xmm14, xmmword ptr [rsp+0x340]
       vmovaps  xmm15, xmmword ptr [rsp+0x330]
       add      rsp, 984
       ret      
 
G_M000_IG10:                ;; offset=0x07CF
       vmovups  ymm5, ymmword ptr [rsp+0x40]
       vsubps   ymm10, ymm5, ymm10
       vsubps   ymm11, ymm5, ymm11
       vsubps   ymm14, ymm5, ymm14
       vmovups  ymm8, ymmword ptr [rsp+0x2C0]
       vcvtdq2ps ymm12, ymm8
       vmulps   ymm12, ymm12, ymm10
       vcvtdq2ps ymm13, ymm9
       vmulps   ymm13, ymm13, ymm11
       vmovups  ymmword ptr [rsp+0x280], ymm4
       vcvtdq2ps ymm5, ymm4
       vmulps   ymm5, ymm5, ymm14
       vaddps   ymm4, ymm11, ymm14
       vmovups  ymmword ptr [rsp+0x310], ymm4
       vbroadcastss ymm4, dword ptr [reloc @RWD512]
       vsubps   ymm4, ymm4, ymm10
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x310]
       vaddps   ymm3, ymm4, ymm3
       vpsrad   ymm4, ymm8, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x260]
       vpaddd   ymm1, ymm4, ymm1
       vpsrad   ymm4, ymm9, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x240]
       vpaddd   ymm7, ymm4, ymm7
       vmovups  ymm4, ymmword ptr [rsp+0x280]
       vpsrad   ymm4, ymm4, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x220]
       vpaddd   ymm2, ymm4, ymm2
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm8, ymm4, ymm8
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm9, ymm4, ymm9
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm4, ymm4, ymmword ptr [rsp+0x280]
       vmovups  ymmword ptr [rsp+0x280], ymm4
       vpcmpeqd ymm4, ymm4, ymm4
       vpxor    ymm4, ymm4, ymmword ptr [rsp]
       vmovups  ymmword ptr [rdx], ymm4
       inc      eax
       vmovups  ymmword ptr [rsp+0x2C0], ymm8
       vmovups  ymmword ptr [rsp+0x2A0], ymm9
       vmovaps  ymm8, ymm5
       vmovaps  ymm5, ymm13
       vmovaps  ymm9, ymm0
       vmovaps  ymm0, ymm12
       jmp      G_M000_IG04
 
RWD00  	dd	BF000000h		;      -0.5
RWD04  	dd	3F000000h		;       0.5
RWD08  	dd	4F000000h		; 2.14748e+09
RWD12  	dd	7FFFFFFFh		;       nan
RWD16  	dd	00000001h		; 1.4013e-45
RWD20  	dd	BF800000h		;        -1
RWD24  	dd	80000000h		;        -0
RWD28  	dd	00000000h
RWD32  	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD64  	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD96  	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD128 	dd	3F19999Ah		;       0.6
RWD132 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD160 	dq	27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh, 27D4EB2D27D4EB2Dh
RWD192 	dq	000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh, 000000FC000000FCh
RWD224 	dq	9159159180480480h, B37B37B3A26A26A2h, 1591591584804804h, 37B37B3796A26A26h
RWD256 	dq	0000001C0000001Ch, 0000001C0000001Ch, 0000001C0000001Ch, 0000001C0000001Ch
RWD288 	dq	0000000F0000000Fh, 0000000F0000000Fh, 0000000F0000000Fh, 0000000F0000000Fh
RWD320 	dq	8080800080808000h, 8080800080808000h, 8080800080808000h, 8080800080808000h
RWD352 	dq	1511050118100800h, 000000000E0A0602h
RWD368 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD384 	dq	0000000300000003h, 0000000300000003h, 0000000300000003h, 0000000300000003h
RWD416 	dq	0000000200000002h, 0000000200000002h, 0000000200000002h, 0000000200000002h
RWD448 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD480 	dq	4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h
RWD512 	dd	3F400000h		;      0.75

; Total bytes of code 2269

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 2 inlinees with PGO data; 182 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 544
       vmovaps  xmmword ptr [rsp+0x210], xmm6
       vmovaps  xmmword ptr [rsp+0x200], xmm7
       vmovaps  xmmword ptr [rsp+0x1F0], xmm8
       vmovaps  xmmword ptr [rsp+0x1E0], xmm9
       vmovaps  xmmword ptr [rsp+0x1D0], xmm10
       vmovaps  xmmword ptr [rsp+0x1C0], xmm11
       vmovaps  xmmword ptr [rsp+0x1B0], xmm12
       vmovaps  xmmword ptr [rsp+0x1A0], xmm13
       vmovaps  xmmword ptr [rsp+0x190], xmm14
       vmovaps  xmmword ptr [rsp+0x180], xmm15
       mov      rbx, rdx
       mov      rax, bword ptr [rsp+0x270]
 
G_M000_IG02:                ;; offset=0x0072
       mov      edx, dword ptr [rcx+0x64]
       vbroadcastss ymm0, dword ptr [rcx+0x0C]
       vmulps   ymm1, ymm0, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       dec      edx
       cmp      edx, 2
       jne      G_M000_IG21
 
G_M000_IG03:                ;; offset=0x00A2
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm1, ymm0, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD00]
       vsubps   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [r8], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x00D3
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       vmovups  ymm6, ymmword ptr [r8]
       vmovups  ymm7, ymmword ptr [r9]
       vmovups  ymm8, ymmword ptr [rax]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  ymm9, ymm6
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovss   xmm12, dword ptr [rcx+0x38]
       vmovss   dword ptr [rsp+0x14C], xmm12
       cmp      dword ptr [rsi], 0
       je       G_M000_IG15
       cmp      ebp, 1
       jle      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x011C
       vxorps   ymm6, ymm6, ymm6
       vmovups  ymmword ptr [rsp+0x110], ymm6
       vbroadcastss ymm7, dword ptr [rsi+0x18]
       vbroadcastss ymm8, dword ptr [rsi+0x08]
       vbroadcastss ymm13, dword ptr [rsi+0x0C]
       vmovups  ymmword ptr [rsp+0xF0], ymm13
       vbroadcastss ymm14, dword ptr [rsi+0x10]
       vmovups  ymmword ptr [rsp+0xD0], ymm14
       xor      r14d, r14d
       cmp      r14d, ebp
       jge      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x015F
       vucomiss xmm12, dword ptr [reloc @RWD32]
       jp       G_M000_IG26
       jne      G_M000_IG26
 
G_M000_IG07:                ;; offset=0x0173
       lea      edx, [rdi+r14]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm9
       vmovups  ymmword ptr [rsp+0x50], ymm10
       vmovups  ymmword ptr [rsp+0x30], ymm11
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xB0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm6, ymm7
       vextractf128 xmm12, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rsi]
       cmp      edx, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm10, ymm10, xmm13
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm8, ymm8, xmm12
       je       G_M000_IG11
 
G_M000_IG08:                ;; offset=0x020C
       cmp      edx, 3
       je       G_M000_IG27
       vmulps   ymm0, ymm7, ymmword ptr [rsp+0xB0]
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
 
G_M000_IG09:                ;; offset=0x0241
       vsubps   ymm0, ymm0, ymm12
       vmovups  ymm14, ymmword ptr [rsp+0xD0]
       vmulps   ymm0, ymm0, ymm14
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       vmulps   ymm9, ymm9, ymm8
       vmulps   ymm10, ymm10, ymm8
       vmulps   ymm11, ymm11, ymm8
       vmovups  ymm13, ymmword ptr [rsp+0xF0]
       vmulps   ymm7, ymm7, ymm13
       inc      r14d
       cmp      r14d, ebp
       vmovss   xmm12, dword ptr [rsp+0x14C]
       jge      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x028B
       vmovups  ymmword ptr [rsp+0x110], ymm6
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x0299
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vsubps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
G_M000_IG12:                ;; offset=0x02E4
       vmovups  ymm6, ymmword ptr [rsp+0x110]
 
G_M000_IG13:                ;; offset=0x02ED
       vmovups  ymmword ptr [rbx], ymm6
       mov      rax, rbx
 
G_M000_IG14:                ;; offset=0x02F4
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x210]
       vmovaps  xmm7, xmmword ptr [rsp+0x200]
       vmovaps  xmm8, xmmword ptr [rsp+0x1F0]
       vmovaps  xmm9, xmmword ptr [rsp+0x1E0]
       vmovaps  xmm10, xmmword ptr [rsp+0x1D0]
       vmovaps  xmm11, xmmword ptr [rsp+0x1C0]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B0]
       vmovaps  xmm13, xmmword ptr [rsp+0x1A0]
       vmovaps  xmm14, xmmword ptr [rsp+0x190]
       vmovaps  xmm15, xmmword ptr [rsp+0x180]
       add      rsp, 544
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG15:                ;; offset=0x035F
       vmovd    xmm0, edi
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm6
       vmovups  ymmword ptr [rsp+0x50], ymm7
       vmovups  ymmword ptr [rsp+0x30], ymm8
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x150]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG25
       vbroadcastss ymm0, dword ptr [rsi+0x18]
       mov      eax, dword ptr [rsi]
       cmp      eax, 2
       je       G_M000_IG20
 
G_M000_IG16:                ;; offset=0x03C7
       cmp      eax, 3
       je       SHORT G_M000_IG19
 
G_M000_IG17:                ;; offset=0x03CC
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x150]
 
G_M000_IG18:                ;; offset=0x03D5
       vbroadcastss ymm0, ymm12
       vmulps   ymm6, ymm0, ymm1
       jmp      G_M000_IG13
 
G_M000_IG19:                ;; offset=0x03E3
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x150]
       vbroadcastss ymm3, dword ptr [rsi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD160]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD96], ymm4
       vcvtdq2ps ymm3, ymm3
       vbroadcastss ymm13, dword ptr [reloc @RWD192]
       vmulps   ymm3, ymm3, ymm13
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vsubps   ymm3, ymm13, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD64]
       vmulps   ymm1, ymm1, ymm13
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG18
 
G_M000_IG20:                ;; offset=0x0462
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm2, dword ptr [reloc @RWD32]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG18
 
G_M000_IG21:                ;; offset=0x0491
       cmp      edx, 2
       ja       G_M000_IG04
       mov      edx, edx
       lea      r10, [reloc @RWD196]
       mov      r10d, dword ptr [r10+4*rdx]
       lea      r11, G_M000_IG02
       add      r10, r11
       jmp      r10
 
G_M000_IG22:                ;; offset=0x04B4
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymm2, ymmword ptr [rax]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [rax], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [rax]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vaddps   ymm1, ymm1, ymmword ptr [r9]
       vsubps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD256]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       jmp      G_M000_IG04
 
G_M000_IG23:                ;; offset=0x0507
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymm2, ymmword ptr [r9]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD256]
       vmovups  ymmword ptr [r9], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [r9]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vsubps   ymm1, ymm1, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD256]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       jmp      G_M000_IG04
 
G_M000_IG24:                ;; offset=0x055D
       jmp      G_M000_IG07
 
G_M000_IG25:                ;; offset=0x0562
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       jmp      G_M000_IG18
 
G_M000_IG26:                ;; offset=0x0570
       lea      edx, [rbp-0x01]
       cmp      r14d, edx
       jne      SHORT G_M000_IG24
       vbroadcastss ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       jmp      G_M000_IG07
 
G_M000_IG27:                ;; offset=0x0586
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vbroadcastss ymm1, dword ptr [rsi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD96], ymm2
       vcvtdq2ps ymm1, ymm1
       vbroadcastss ymm13, dword ptr [reloc @RWD192]
       vmulps   ymm1, ymm1, ymm13
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm12
       vsubps   ymm2, ymm13, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm0, ymm0, ymm13
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
RWD00  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD32  	dd	3F800000h		;         1
RWD36  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD64  	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD96  	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD128 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h
RWD160 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD192 	dd	40000000h		;         2
RWD196 	dd	00000442h ; case G_M000_IG22
       	dd	00000495h ; case G_M000_IG23
       	dd	00000030h ; case G_M000_IG03
RWD208 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD224 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD256 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah

; Total bytes of code 1569

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 6688
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rsi
       push     rbx
       sub      rsp, 40
 
G_M000_IG02:                ;; offset=0x0006
       mov      rax, bword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x000F
       mov      r11d, r10d
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       mov      ebx, r10d
       mov      esi, ebx
       vmovsd   xmm0, qword ptr [r9+8*rsi]
       vmovsd   qword ptr [rax+8*r11], xmm0
       lea      r11d, [r10+0x04]
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       vmovsd   xmm0, qword ptr [r9+8*rbx+0x20]
       vmovsd   qword ptr [rax+8*r11], xmm0
       inc      r10d
       cmp      r10d, 4
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x0055
       add      rsp, 40
       pop      rbx
       pop      rsi
       ret      
 
G_M000_IG05:                ;; offset=0x005C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 98

; Assembly listing for method Tedd.FastNoise.Internal.ScalarOps:GradientCode3D(int):int (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 1 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
 
G_M000_IG02:                ;; offset=0x0000
       mov      rax, 0x273FD801008
       mov      rax, gword ptr [rax]
       add      rax, 16
       mov      ecx, ecx
       mov      eax, dword ptr [rax+4*rcx]
 
G_M000_IG03:                ;; offset=0x0016
       ret      
 
; Total bytes of code 23

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.ScalarOps,float,int](int,float,float,float):float (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 160032
; 36 inlinees with PGO data; 199 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 120
       vmovaps  xmmword ptr [rsp+0x60], xmm6
       vmovaps  xmmword ptr [rsp+0x50], xmm7
       vmovaps  xmmword ptr [rsp+0x40], xmm8
       vmovaps  xmmword ptr [rsp+0x30], xmm9
       vmovaps  xmmword ptr [rsp+0x20], xmm10
       vmovaps  xmmword ptr [rsp+0x10], xmm11
 
G_M000_IG02:                ;; offset=0x0034
       vxorps   xmm0, xmm0, xmm0
       vucomiss xmm0, xmm1
       ja       G_M000_IG56
 
G_M000_IG03:                ;; offset=0x0042
       vmovss   xmm0, dword ptr [reloc @RWD00]
 
G_M000_IG04:                ;; offset=0x004A
       vaddss   xmm0, xmm1, xmm0
       vcmpordss xmm4, xmm0, xmm0
       vandps   xmm4, xmm4, xmm0
       mov      eax, 0x7FFFFFFF
       vcvttss2si edx, xmm4
       vucomiss xmm0, dword ptr [reloc @RWD04]
       cmovb    eax, edx
       vxorps   xmm0, xmm0, xmm0
       vucomiss xmm0, xmm2
       ja       G_M000_IG57
 
G_M000_IG05:                ;; offset=0x0079
       vmovss   xmm0, dword ptr [reloc @RWD00]
 
G_M000_IG06:                ;; offset=0x0081
       vaddss   xmm0, xmm2, xmm0
       vcmpordss xmm4, xmm0, xmm0
       vandps   xmm4, xmm4, xmm0
       mov      edx, 0x7FFFFFFF
       vcvttss2si r8d, xmm4
       vucomiss xmm0, dword ptr [reloc @RWD04]
       cmovb    edx, r8d
       vxorps   xmm0, xmm0, xmm0
       vucomiss xmm0, xmm3
       ja       G_M000_IG58
 
G_M000_IG07:                ;; offset=0x00B1
       vmovss   xmm0, dword ptr [reloc @RWD00]
 
G_M000_IG08:                ;; offset=0x00B9
       vaddss   xmm0, xmm3, xmm0
       vcmpordss xmm4, xmm0, xmm0
       vandps   xmm4, xmm4, xmm0
       mov      r8d, 0x7FFFFFFF
       vcvttss2si r10d, xmm4
       vucomiss xmm0, dword ptr [reloc @RWD04]
       cmovb    r8d, r10d
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, eax
       vsubss   xmm0, xmm1, xmm0
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, edx
       vsubss   xmm1, xmm2, xmm1
       vxorps   xmm2, xmm2, xmm2
       vcvtsi2ss xmm2, xmm2, r8d
       vsubss   xmm2, xmm3, xmm2
       vmovss   xmm3, dword ptr [reloc @RWD08]
       vsubss   xmm4, xmm3, xmm0
       vcmpordss xmm5, xmm4, xmm4
       vandps   xmm5, xmm5, xmm4
       mov      r10d, 0x7FFFFFFF
       vcvttss2si r9d, xmm5
       vucomiss xmm4, dword ptr [reloc @RWD04]
       cmovb    r10d, r9d
       or       r10d, 1
       vsubss   xmm4, xmm3, xmm1
       vcmpordss xmm5, xmm4, xmm4
       vandps   xmm5, xmm5, xmm4
       mov      r9d, 0x7FFFFFFF
       vcvttss2si r11d, xmm5
       vucomiss xmm4, dword ptr [reloc @RWD04]
       cmovb    r9d, r11d
       or       r9d, 1
       vsubss   xmm3, xmm3, xmm2
       vcmpordss xmm4, xmm3, xmm3
       vandps   xmm4, xmm4, xmm3
       mov      r11d, 0x7FFFFFFF
       vcvttss2si ebx, xmm4
       vucomiss xmm3, dword ptr [reloc @RWD04]
       cmovb    r11d, ebx
       or       r11d, 1
       vxorps   xmm3, xmm0, xmmword ptr [reloc @RWD16]
       vxorps   xmm4, xmm4, xmm4
       vcvtsi2ss xmm4, xmm4, r10d
       vmulss   xmm3, xmm3, xmm4
       vxorps   xmm4, xmm1, xmmword ptr [reloc @RWD16]
       vxorps   xmm5, xmm5, xmm5
       vcvtsi2ss xmm5, xmm5, r9d
       vmulss   xmm4, xmm4, xmm5
       vxorps   xmm5, xmm2, xmmword ptr [reloc @RWD16]
       vxorps   xmm6, xmm6, xmm6
       vcvtsi2ss xmm6, xmm6, r11d
       vmulss   xmm5, xmm5, xmm6
       imul     eax, eax, 0x1DDE90C9
       imul     edx, edx, 0x43C42E4D
       imul     r8d, r8d, 0x668B6E2F
       vxorps   xmm6, xmm6, xmm6
       vmulss   xmm7, xmm1, xmm1
       vmulss   xmm8, xmm2, xmm2
       vaddss   xmm7, xmm7, xmm8
 
G_M000_IG09:                ;; offset=0x01E1
       vmulss   xmm8, xmm0, xmm0
       vmovss   xmm9, dword ptr [reloc @RWD32]
       vsubss   xmm8, xmm9, xmm8
       vsubss   xmm7, xmm8, xmm7
       xor      ebx, ebx
 
G_M000_IG10:                ;; offset=0x01F8
       vxorps   xmm8, xmm8, xmm8
       vucomiss xmm7, xmm8
       jbe      G_M000_IG59
 
G_M000_IG11:                ;; offset=0x0208
       mov      esi, -1
 
G_M000_IG12:                ;; offset=0x020D
       vmulss   xmm8, xmm7, xmm7
       vmulss   xmm8, xmm8, xmm8
       mov      edi, ecx
       xor      edi, eax
       xor      edi, edx
       xor      edi, r8d
       imul     edi, edi, 0x27D4EB2D
       mov      ebp, edi
       sar      ebp, 15
       xor      ebp, edi
       mov      rdi, 0x273FD801008
       mov      rdi, gword ptr [rdi]
       mov      r14, rdi
       add      r14, 16
       and      ebp, 252
       shr      ebp, 2
       mov      ebp, dword ptr [r14+4*rbp]
       mov      r14d, ebp
       and      r14d, 3
       je       G_M000_IG60
 
G_M000_IG13:                ;; offset=0x025A
       vmovd    r15d, xmm0
       mov      r13d, ebp
       shl      r13d, 29
       and      r13d, 0xFFFFFFFF80000000
       xor      r15d, r13d
       vmovd    xmm9, r15d
 
G_M000_IG14:                ;; offset=0x0275
       cmp      r14d, 1
       je       G_M000_IG61
 
G_M000_IG15:                ;; offset=0x027F
       vmovd    r15d, xmm1
       mov      r13d, ebp
       shl      r13d, 28
       and      r13d, 0xFFFFFFFF80000000
       xor      r15d, r13d
       vmovd    xmm10, r15d
 
G_M000_IG16:                ;; offset=0x029A
       cmp      r14d, 2
       je       G_M000_IG62
 
G_M000_IG17:                ;; offset=0x02A4
       vmovd    r14d, xmm2
       shl      ebp, 27
       and      ebp, 0xFFFFFFFF80000000
       xor      ebp, r14d
       vmovd    xmm11, ebp
 
G_M000_IG18:                ;; offset=0x02B9
       vaddss   xmm9, xmm9, xmm10
       vaddss   xmm9, xmm9, xmm11
       vmulss   xmm8, xmm9, xmm8
       test     esi, esi
       jne      G_M000_IG63
 
G_M000_IG19:                ;; offset=0x02D0
       vxorps   xmm9, xmm9, xmm9
 
G_M000_IG20:                ;; offset=0x02D5
       vaddss   xmm6, xmm6, xmm9
       vucomiss xmm4, xmm3
       ja       G_M000_IG64
 
G_M000_IG21:                ;; offset=0x02E4
       xor      esi, esi
 
G_M000_IG22:                ;; offset=0x02E6
       not      esi
       vucomiss xmm5, xmm3
       ja       G_M000_IG65
 
G_M000_IG23:                ;; offset=0x02F2
       xor      ebp, ebp
 
G_M000_IG24:                ;; offset=0x02F4
       andn     esi, ebp, esi
       mov      ebp, esi
       not      ebp
       vucomiss xmm4, xmm3
       jbe      G_M000_IG66
 
G_M000_IG25:                ;; offset=0x0307
       mov      r14d, -1
 
G_M000_IG26:                ;; offset=0x030D
       vucomiss xmm5, xmm4
       ja       G_M000_IG67
 
G_M000_IG27:                ;; offset=0x0317
       xor      r15d, r15d
 
G_M000_IG28:                ;; offset=0x031A
       and      ebp, r14d
       andn     ebp, r15d, ebp
       mov      r14d, esi
       or       r14d, ebp
       not      r14d
       test     ebp, ebp
       jne      G_M000_IG68
 
G_M000_IG29:                ;; offset=0x0333
       vmovaps  xmm8, xmm5
 
G_M000_IG30:                ;; offset=0x0337
       test     esi, esi
       jne      G_M000_IG69
 
G_M000_IG31:                ;; offset=0x033F
       vaddss   xmm9, xmm7, xmm8
       vaddss   xmm8, xmm9, xmm8
       vsubss   xmm8, xmm8, dword ptr [reloc @RWD36]
       imul     r15d, r10d, 0x1DDE90C9
       test     esi, esi
       jne      G_M000_IG70
 
G_M000_IG32:                ;; offset=0x0360
       xor      r13d, r13d
 
G_M000_IG33:                ;; offset=0x0363
       mov      r15d, eax
       sub      r15d, r13d
       imul     r13d, r9d, 0x43C42E4D
       test     ebp, ebp
       jne      G_M000_IG71
 
G_M000_IG34:                ;; offset=0x0378
       xor      r12d, r12d
 
G_M000_IG35:                ;; offset=0x037B
       mov      r13d, edx
       sub      r13d, r12d
       mov      dword ptr [rsp+0x0C], r13d
       imul     r12d, r11d, 0x668B6E2F
       test     r14d, r14d
       jne      G_M000_IG72
 
G_M000_IG36:                ;; offset=0x0396
       xor      r12d, r12d
 
G_M000_IG37:                ;; offset=0x0399
       mov      r13d, r8d
       sub      r13d, r12d
       test     esi, esi
       jne      G_M000_IG73
 
G_M000_IG38:                ;; offset=0x03A7
       vxorps   xmm9, xmm9, xmm9
 
G_M000_IG39:                ;; offset=0x03AC
       vaddss   xmm0, xmm0, xmm9
       test     ebp, ebp
       jne      G_M000_IG74
 
G_M000_IG40:                ;; offset=0x03B9
       vxorps   xmm9, xmm9, xmm9
 
G_M000_IG41:                ;; offset=0x03BE
       vaddss   xmm1, xmm1, xmm9
       test     r14d, r14d
       jne      G_M000_IG75
 
G_M000_IG42:                ;; offset=0x03CC
       vxorps   xmm9, xmm9, xmm9
 
G_M000_IG43:                ;; offset=0x03D1
       vaddss   xmm2, xmm2, xmm9
       vxorps   xmm9, xmm9, xmm9
       vucomiss xmm8, xmm9
       jbe      G_M000_IG76
 
G_M000_IG44:                ;; offset=0x03E6
       mov      esi, -1
 
G_M000_IG45:                ;; offset=0x03EB
       vmulss   xmm8, xmm8, xmm8
       vmulss   xmm8, xmm8, xmm8
       xor      r15d, ecx
       xor      r15d, dword ptr [rsp+0x0C]
       xor      r15d, r13d
       imul     ebp, r15d, 0x27D4EB2D
       mov      r14d, ebp
       sar      r14d, 15
       xor      r14d, ebp
       add      rdi, 16
       and      r14d, 252
       shr      r14d, 2
       mov      ebp, r14d
       mov      edi, dword ptr [rdi+4*rbp]
       mov      ebp, edi
       and      ebp, 3
       je       G_M000_IG77
 
G_M000_IG46:                ;; offset=0x0431
       vmovd    r14d, xmm0
       mov      r15d, edi
       shl      r15d, 29
       and      r15d, 0xFFFFFFFF80000000
       xor      r14d, r15d
       vmovd    xmm0, r14d
 
G_M000_IG47:                ;; offset=0x044C
       cmp      ebp, 1
       je       G_M000_IG78
 
G_M000_IG48:                ;; offset=0x0455
       vmovd    r14d, xmm1
       mov      r15d, edi
       shl      r15d, 28
       and      r15d, 0xFFFFFFFF80000000
       xor      r14d, r15d
       vmovd    xmm1, r14d
 
G_M000_IG49:                ;; offset=0x0470
       cmp      ebp, 2
       je       G_M000_IG79
 
G_M000_IG50:                ;; offset=0x0479
       vmovd    ebp, xmm2
       shl      edi, 27
       and      edi, 0xFFFFFFFF80000000
       xor      edi, ebp
       vmovd    xmm2, edi
 
G_M000_IG51:                ;; offset=0x048C
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm2
       vmulss   xmm0, xmm0, xmm8
       test     esi, esi
       jne      G_M000_IG80
 
G_M000_IG52:                ;; offset=0x04A1
       vxorps   xmm1, xmm1, xmm1
 
G_M000_IG53:                ;; offset=0x04A5
       vaddss   xmm6, xmm6, xmm1
       cmp      ebx, 1
       jne      G_M000_IG81
 
G_M000_IG54:                ;; offset=0x04B2
       vmulss   xmm0, xmm6, dword ptr [reloc @RWD40]
 
G_M000_IG55:                ;; offset=0x04BA
       vmovaps  xmm6, xmmword ptr [rsp+0x60]
       vmovaps  xmm7, xmmword ptr [rsp+0x50]
       vmovaps  xmm8, xmmword ptr [rsp+0x40]
       vmovaps  xmm9, xmmword ptr [rsp+0x30]
       vmovaps  xmm10, xmmword ptr [rsp+0x20]
       vmovaps  xmm11, xmmword ptr [rsp+0x10]
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG56:                ;; offset=0x04EF
       vmovss   xmm0, dword ptr [reloc @RWD44]
       jmp      G_M000_IG04
 
G_M000_IG57:                ;; offset=0x04FC
       vmovss   xmm0, dword ptr [reloc @RWD44]
       jmp      G_M000_IG06
 
G_M000_IG58:                ;; offset=0x0509
       vmovss   xmm0, dword ptr [reloc @RWD44]
       jmp      G_M000_IG08
 
G_M000_IG59:                ;; offset=0x0516
       xor      esi, esi
       jmp      G_M000_IG12
 
G_M000_IG60:                ;; offset=0x051D
       vxorps   xmm9, xmm9, xmm9
       jmp      G_M000_IG14
 
G_M000_IG61:                ;; offset=0x0527
       vxorps   xmm10, xmm10, xmm10
       jmp      G_M000_IG16
 
G_M000_IG62:                ;; offset=0x0531
       vxorps   xmm11, xmm11, xmm11
       jmp      G_M000_IG18
 
G_M000_IG63:                ;; offset=0x053B
       vmovaps  xmm9, xmm8
       jmp      G_M000_IG20
 
G_M000_IG64:                ;; offset=0x0545
       mov      esi, -1
       jmp      G_M000_IG22
 
G_M000_IG65:                ;; offset=0x054F
       mov      ebp, -1
       jmp      G_M000_IG24
 
G_M000_IG66:                ;; offset=0x0559
       xor      r14d, r14d
       jmp      G_M000_IG26
 
G_M000_IG67:                ;; offset=0x0561
       mov      r15d, -1
       jmp      G_M000_IG28
 
G_M000_IG68:                ;; offset=0x056C
       vmovaps  xmm8, xmm4
       jmp      G_M000_IG30
 
G_M000_IG69:                ;; offset=0x0575
       vmovaps  xmm8, xmm3
       jmp      G_M000_IG31
 
G_M000_IG70:                ;; offset=0x057E
       mov      r13d, r15d
       jmp      G_M000_IG33
 
G_M000_IG71:                ;; offset=0x0586
       mov      r12d, r13d
       jmp      G_M000_IG35
 
G_M000_IG72:                ;; offset=0x058E
       jmp      G_M000_IG37
 
G_M000_IG73:                ;; offset=0x0593
       vxorps   xmm9, xmm9, xmm9
       vcvtsi2ss xmm9, xmm9, r10d
       jmp      G_M000_IG39
 
G_M000_IG74:                ;; offset=0x05A2
       vxorps   xmm9, xmm9, xmm9
       vcvtsi2ss xmm9, xmm9, r9d
       jmp      G_M000_IG41
 
G_M000_IG75:                ;; offset=0x05B1
       vxorps   xmm9, xmm9, xmm9
       vcvtsi2ss xmm9, xmm9, r11d
       jmp      G_M000_IG43
 
G_M000_IG76:                ;; offset=0x05C0
       xor      esi, esi
       jmp      G_M000_IG45
 
G_M000_IG77:                ;; offset=0x05C7
       vxorps   xmm0, xmm0, xmm0
       jmp      G_M000_IG47
 
G_M000_IG78:                ;; offset=0x05D0
       vxorps   xmm1, xmm1, xmm1
       jmp      G_M000_IG49
 
G_M000_IG79:                ;; offset=0x05D9
       vxorps   xmm2, xmm2, xmm2
       jmp      G_M000_IG51
 
G_M000_IG80:                ;; offset=0x05E2
       vmovaps  xmm1, xmm0
       jmp      G_M000_IG53
 
G_M000_IG81:                ;; offset=0x05EB
       vmovss   xmm0, dword ptr [reloc @RWD00]
       vsubss   xmm3, xmm0, xmm3
       vsubss   xmm4, xmm0, xmm4
       vsubss   xmm5, xmm0, xmm5
       vxorps   xmm0, xmm0, xmm0
       vcvtsi2ss xmm0, xmm0, r10d
       vmulss   xmm0, xmm0, xmm3
       vxorps   xmm1, xmm1, xmm1
       vcvtsi2ss xmm1, xmm1, r9d
       vmulss   xmm1, xmm1, xmm4
       vxorps   xmm2, xmm2, xmm2
       vcvtsi2ss xmm2, xmm2, r11d
       vmulss   xmm2, xmm2, xmm5
       vaddss   xmm8, xmm4, xmm5
       vmovss   xmm9, dword ptr [reloc @RWD48]
       vsubss   xmm9, xmm9, xmm3
       vsubss   xmm8, xmm9, xmm8
       vaddss   xmm7, xmm8, xmm7
       mov      esi, r10d
       sar      esi, 1
       and      esi, 0x1DDE90C9
       add      eax, esi
       mov      esi, r9d
       sar      esi, 1
       and      esi, 0x43C42E4D
       add      edx, esi
       mov      esi, r11d
       sar      esi, 1
       and      esi, 0x668B6E2F
       add      r8d, esi
       neg      r10d
       neg      r9d
       neg      r11d
       not      ecx
       inc      ebx
       jmp      G_M000_IG10
 
RWD00  	dd	3F000000h		;       0.5
RWD04  	dd	4F000000h		; 2.14748e+09
RWD08  	dd	BF800000h		;        -1
RWD12  	dd	00000000h
RWD16  	dq	8000000080000000h, 8000000080000000h
RWD32  	dd	3F19999Ah		;       0.6
RWD36  	dd	3F800000h		;         1
RWD40  	dd	4202C6F2h		;   32.6943
RWD44  	dd	BF000000h		;      -0.5
RWD48  	dd	3F400000h		;      0.75

; Total bytes of code 1657

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 13602
; 2 inlinees with PGO data; 295 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       sub      rsp, 0x438
       vmovaps  xmmword ptr [rsp+0x420], xmm6
       vmovaps  xmmword ptr [rsp+0x410], xmm7
       vmovaps  xmmword ptr [rsp+0x400], xmm8
       vmovaps  xmmword ptr [rsp+0x3F0], xmm9
       vmovaps  xmmword ptr [rsp+0x3E0], xmm10
       vmovaps  xmmword ptr [rsp+0x3D0], xmm11
       vmovaps  xmmword ptr [rsp+0x3C0], xmm12
       vmovaps  xmmword ptr [rsp+0x3B0], xmm13
       vmovaps  xmmword ptr [rsp+0x3A0], xmm14
       vmovaps  xmmword ptr [rsp+0x390], xmm15
       mov      rax, bword ptr [rsp+0x460]
 
G_M000_IG02:                ;; offset=0x0069
       vmovups  ymm0, ymmword ptr [r8]
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm0, ymm1
       vbroadcastss ymm2, dword ptr [reloc @RWD00]
       vbroadcastss ymm3, dword ptr [reloc @RWD04]
       vmovups  ymmword ptr [rsp+0xC0], ymm3
       vblendvps ymm1, ymm3, ymm2, ymm1
       vaddps   ymm1, ymm1, ymm0
       vcmpeqps ymm4, ymm1, ymm1
       vandps   ymm1, ymm4, ymm1
       vbroadcastss ymm4, dword ptr [reloc @RWD08]
       vcmpgeps ymm5, ymm1, ymm4
       vbroadcastss ymm6, dword ptr [reloc @RWD12]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymm6, ymm5
       vmovups  ymm5, ymmword ptr [r9]
       vxorps   ymm7, ymm7, ymm7
       vcmpltps ymm7, ymm5, ymm7
       vblendvps ymm7, ymm3, ymm2, ymm7
       vaddps   ymm7, ymm7, ymm5
       vcmpeqps ymm8, ymm7, ymm7
       vandps   ymm7, ymm8, ymm7
       vcmpgeps ymm8, ymm7, ymm4
       vcvttps2dq ymm7, ymm7
       vpblendvb ymm7, ymm7, ymm6, ymm8
       vmovups  ymm8, ymmword ptr [rax]
       vxorps   ymm9, ymm9, ymm9
       vcmpltps ymm9, ymm8, ymm9
       vblendvps ymm2, ymm3, ymm2, ymm9
       vaddps   ymm2, ymm2, ymm8
       vcmpeqps ymm9, ymm2, ymm2
       vandps   ymm2, ymm9, ymm2
       vcmpgeps ymm9, ymm2, ymm4
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm6, ymm9
       vcvtdq2ps ymm9, ymm1
       vsubps   ymm0, ymm0, ymm9
       vcvtdq2ps ymm9, ymm7
       vsubps   ymm5, ymm5, ymm9
       vcvtdq2ps ymm9, ymm2
       vsubps   ymm8, ymm8, ymm9
       vbroadcastss ymm9, dword ptr [reloc @RWD16]
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       vmovaps  ymm10, ymm9
       vbroadcastss ymm11, dword ptr [reloc @RWD20]
       vsubps   ymm12, ymm11, ymm0
       vcmpeqps ymm13, ymm12, ymm12
       vandps   ymm12, ymm13, ymm12
       vcmpgeps ymm13, ymm12, ymm4
       vcvttps2dq ymm12, ymm12
       vpblendvb ymm12, ymm12, ymm6, ymm13
       vpor     ymm12, ymm12, ymm10
       vsubps   ymm13, ymm11, ymm5
       vcmpeqps ymm14, ymm13, ymm13
       vandps   ymm13, ymm14, ymm13
       vcmpgeps ymm14, ymm13, ymm4
       vcvttps2dq ymm13, ymm13
       vpblendvb ymm13, ymm13, ymm6, ymm14
       vpor     ymm13, ymm13, ymm10
       vsubps   ymm11, ymm11, ymm8
       vcmpeqps ymm14, ymm11, ymm11
       vandps   ymm11, ymm14, ymm11
 
G_M000_IG03:                ;; offset=0x01BB
       vcmpgeps ymm4, ymm11, ymm4
       vcvttps2dq ymm11, ymm11
       vpblendvb ymm4, ymm11, ymm6, ymm4
       vpor     ymm4, ymm4, ymm10
       vbroadcastss ymm6, dword ptr [reloc @RWD24]
       vxorps   ymm10, ymm6, ymm0
       vcvtdq2ps ymm11, ymm12
       vmulps   ymm10, ymm10, ymm11
       vxorps   ymm11, ymm6, ymm5
       vcvtdq2ps ymm14, ymm13
       vmulps   ymm11, ymm11, ymm14
       vxorps   ymm14, ymm6, ymm8
       vcvtdq2ps ymm15, ymm4
       vmulps   ymm14, ymm14, ymm15
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD32]
       vpmulld  ymm7, ymm7, ymmword ptr [reloc @RWD64]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD96]
       vbroadcastss ymm15, dword ptr [reloc @RWD32]
       vmovups  ymmword ptr [rsp+0x280], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rsp+0x260], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0x240], ymm15
       vxorps   ymm15, ymm15, ymm15
       vxorps   ymm9, ymm9, ymm9
       vmovups  ymmword ptr [rsp+0x2C0], ymm5
       vmulps   ymm3, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0x370], ymm3
       vmovups  ymmword ptr [rsp+0x2A0], ymm8
       vmulps   ymm3, ymm8, ymm8
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x370], ymm3
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       vmulps   ymm3, ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x350], ymm3
       vbroadcastss ymm3, dword ptr [reloc @RWD128]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x350]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x370]
       xor      eax, eax
       mov      r8, 0x273FD800FE0
       mov      r8, gword ptr [r8]
       jmp      G_M000_IG05
 
G_M000_IG04:                ;; offset=0x02D9
       vmovups  ymm0, ymmword ptr [rsp+0xC0]
       vsubps   ymm10, ymm0, ymm10
       vsubps   ymm11, ymm0, ymm11
       vsubps   ymm14, ymm0, ymm14
       vcvtdq2ps ymm2, ymm12
       vmulps   ymm2, ymm2, ymm10
       vmovups  ymmword ptr [rsp+0x2E0], ymm2
       vcvtdq2ps ymm5, ymm13
       vmulps   ymm5, ymm5, ymm11
       vcvtdq2ps ymm7, ymm4
       vmulps   ymm7, ymm7, ymm14
       vmovaps  ymm8, ymm7
       vaddps   ymm7, ymm11, ymm14
       vbroadcastss ymm0, dword ptr [reloc @RWD132]
       vsubps   ymm0, ymm0, ymm10
       vsubps   ymm0, ymm0, ymm7
       vaddps   ymm3, ymm0, ymm3
       vpsrad   ymm0, ymm12, 1
       vpand    ymm0, ymm0, ymmword ptr [rsp+0x280]
       vpaddd   ymm1, ymm0, ymm1
       vpsrad   ymm0, ymm13, 1
       vpand    ymm0, ymm0, ymmword ptr [rsp+0x260]
       vpaddd   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vpsrad   ymm7, ymm4, 1
       vpand    ymm7, ymm7, ymmword ptr [rsp+0x240]
       vpaddd   ymm7, ymm7, ymmword ptr [rsp+0x300]
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm12, ymm2, ymm12
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm13, ymm2, ymm13
       vxorps   ymm2, ymm2, ymm2
       vpsubd   ymm4, ymm2, ymm4
       vpcmpeqd ymm2, ymm2, ymm2
       vpxor    ymm2, ymm2, ymmword ptr [rsp+0x80]
       vmovups  ymmword ptr [rdx], ymm2
       inc      eax
       vmovups  ymmword ptr [rsp+0x2C0], ymm5
       vmovups  ymmword ptr [rsp+0x2A0], ymm8
       vmovaps  ymm2, ymm7
       vmovaps  ymm7, ymm0
 
G_M000_IG05:                ;; offset=0x03BF
       vcmpgtps ymm8, ymm3, ymm15
       vmovups  ymmword ptr [rsp+0x220], ymm8
       vmulps   ymm8, ymm3, ymm3
       vmulps   ymm8, ymm8, ymm8
       vmovups  ymmword ptr [rsp+0x100], ymm8
       vmovups  ymm8, ymmword ptr [rdx]
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vpxor    ymm8, ymm1, ymm8
       vmovups  ymmword ptr [rsp+0x320], ymm7
       vpxor    ymm8, ymm8, ymm7
       vmovups  ymmword ptr [rsp+0x300], ymm2
       vpxor    ymm8, ymm8, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm8
       vbroadcastss ymm8, dword ptr [reloc @RWD136]
       vmovups  ymmword ptr [rsp+0x60], ymm8
       vmovups  ymm8, ymmword ptr [rsp+0x370]
       vpmulld  ymm8, ymm8, ymmword ptr [rsp+0x60]
       vpsrad   ymm5, ymm8, 15
       vpxor    ymm5, ymm5, ymm8
       vbroadcastss ymm8, dword ptr [reloc @RWD140]
       vmovups  ymmword ptr [rsp+0x40], ymm8
       vpand    ymm5, ymm5, ymm8
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm5, ymm5, 2
       vpcmpeqd ymm8, ymm8, ymm8
       vpgatherdd ymm0, dword ptr [r10+4*xmm5], ymm8
       vbroadcastss ymm5, dword ptr [reloc @RWD144]
       vmovups  ymmword ptr [rsp+0x20], ymm5
       vpand    ymm8, ymm5, ymm0
       vxorps   ymm5, ymm5, ymm5
       vpcmpeqd ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0x370], ymm5
       vpslld   ymm5, ymm0, 29
       vpand    ymm5, ymm5, ymm6
       vpxor    ymm5, ymm5, ymmword ptr [rsp+0x2E0]
       vmovups  ymm2, ymmword ptr [rsp+0x370]
       vblendvps ymm2, ymm5, ymm15, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm2
       vmovups  ymm5, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0x350], ymm5
       vpslld   ymm2, ymm0, 28
       vpand    ymm2, ymm2, ymm6
       vpxor    ymm2, ymm2, ymmword ptr [rsp+0x2C0]
       vmovups  ymm5, ymmword ptr [rsp+0x350]
       vblendvps ymm2, ymm2, ymm15, ymm5
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x370]
       vbroadcastss ymm5, dword ptr [reloc @RWD148]
       vmovups  ymmword ptr [rsp], ymm5
       vpcmpeqd ymm8, ymm5, ymm8
       vpslld   ymm0, ymm0, 27
       vpand    ymm0, ymm0, ymm6
       vpxor    ymm0, ymm0, ymmword ptr [rsp+0x2A0]
       vblendvps ymm0, ymm0, ymm15, ymm8
       vaddps   ymm0, ymm0, ymm2
       vmovups  ymm8, ymmword ptr [rsp+0x100]
       vmulps   ymm0, ymm8, ymm0
 
G_M000_IG06:                ;; offset=0x0536
       vmovups  ymm8, ymmword ptr [rsp+0x220]
       vandps   ymm0, ymm0, ymm8
       vandnps  ymm2, ymm8, ymm15
       vorps    ymm0, ymm2, ymm0
       vaddps   ymm9, ymm0, ymm9
       vcmpnltps ymm0, ymm10, ymm11
       vcmpnltps ymm2, ymm10, ymm14
       vpand    ymm0, ymm2, ymm0
       vcmpgtps ymm2, ymm11, ymm10
       vcmpnltps ymm8, ymm11, ymm14
       vpand    ymm2, ymm8, ymm2
       vpandn   ymm2, ymm0, ymm2
       vpor     ymm8, ymm0, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm8
       vpcmpeqd ymm8, ymm8, ymm8
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x370]
       vandps   ymm5, ymm10, ymm0
       vmovups  ymmword ptr [rsp+0x370], ymm5
       vandps   ymm5, ymm11, ymm2
       vmovups  ymmword ptr [rsp+0x350], ymm5
       vandnps  ymm5, ymm2, ymm14
       vorps    ymm5, ymm5, ymmword ptr [rsp+0x350]
       vandnps  ymm5, ymm0, ymm5
       vorps    ymm5, ymm5, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x200], ymm5
       vaddps   ymm5, ymm3, ymm5
       vaddps   ymm5, ymm5, ymmword ptr [rsp+0x200]
       vsubps   ymm5, ymm5, ymmword ptr [reloc @RWD160]
       vpmulld  ymm7, ymm12, ymmword ptr [rsp+0x280]
       vpand    ymm7, ymm7, ymm0
       vmovups  ymmword ptr [rsp+0x370], ymm7
       vxorps   ymm7, ymm7, ymm7
       vpandn   ymm7, ymm0, ymm7
       vpor     ymm7, ymm7, ymmword ptr [rsp+0x370]
       vpsubd   ymm7, ymm1, ymm7
       vmovups  ymmword ptr [rsp+0x1E0], ymm7
       vpmulld  ymm7, ymm13, ymmword ptr [rsp+0x260]
       vpand    ymm7, ymm7, ymm2
       vmovups  ymmword ptr [rsp+0x370], ymm7
       vxorps   ymm7, ymm7, ymm7
       vpandn   ymm7, ymm2, ymm7
       vpor     ymm7, ymm7, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x370], ymm7
       vmovups  ymm7, ymmword ptr [rsp+0x320]
       vpsubd   ymm7, ymm7, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x1C0], ymm7
       vpmulld  ymm7, ymm4, ymmword ptr [rsp+0x240]
       vpand    ymm7, ymm7, ymm8
       vmovups  ymmword ptr [rsp+0x370], ymm7
       vxorps   ymm7, ymm7, ymm7
       vpandn   ymm7, ymm8, ymm7
       vpor     ymm7, ymm7, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x370], ymm7
       vmovups  ymm7, ymmword ptr [rsp+0x300]
       vpsubd   ymm7, ymm7, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0x1A0], ymm7
       vcvtdq2ps ymm7, ymm12
       vandps   ymm7, ymm7, ymm0
       vandnps  ymm0, ymm0, ymm15
 
G_M000_IG07:                ;; offset=0x06C0
       vorps    ymm0, ymm0, ymm7
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x180], ymm0
       vcvtdq2ps ymm7, ymm13
       vandps   ymm7, ymm7, ymm2
       vandnps  ymm2, ymm2, ymm15
       vorps    ymm2, ymm2, ymm7
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x2C0]
       vmovups  ymmword ptr [rsp+0x160], ymm2
       vcvtdq2ps ymm7, ymm4
       vandps   ymm7, ymm7, ymm8
       vandnps  ymm8, ymm8, ymm15
       vorps    ymm7, ymm8, ymm7
       vaddps   ymm7, ymm7, ymmword ptr [rsp+0x2A0]
       vmovups  ymmword ptr [rsp+0x140], ymm7
       vcmpgtps ymm8, ymm5, ymm15
       vmovups  ymmword ptr [rsp+0x120], ymm8
       vmulps   ymm5, ymm5, ymm5
       vmulps   ymm5, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0xE0], ymm5
       vmovups  ymm7, ymmword ptr [rsp+0x1E0]
       vpxor    ymm7, ymm7, ymmword ptr [rsp+0x80]
       vpxor    ymm7, ymm7, ymmword ptr [rsp+0x1C0]
       vpxor    ymm7, ymm7, ymmword ptr [rsp+0x1A0]
       vpmulld  ymm7, ymm7, ymmword ptr [rsp+0x60]
       vpsrad   ymm2, ymm7, 15
       vpxor    ymm2, ymm2, ymm7
       vpand    ymm7, ymm2, ymmword ptr [rsp+0x40]
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm2, ymm7, 2
       vpcmpeqd ymm7, ymm7, ymm7
       vpgatherdd ymm0, dword ptr [r10+4*xmm2], ymm7
       vmovups  ymm2, ymmword ptr [rsp+0x20]
       vpand    ymm2, ymm2, ymm0
       vxorps   ymm7, ymm7, ymm7
       vpcmpeqd ymm7, ymm7, ymm2
       vpslld   ymm8, ymm0, 29
       vpand    ymm8, ymm8, ymm6
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x180]
       vblendvps ymm7, ymm8, ymm15, ymm7
       vmovups  ymm8, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm8, ymm8, ymm2
       vpslld   ymm5, ymm0, 28
       vpand    ymm5, ymm5, ymm6
       vpxor    ymm5, ymm5, ymmword ptr [rsp+0x160]
       vblendvps ymm5, ymm5, ymm15, ymm8
       vaddps   ymm5, ymm5, ymm7
       vmovups  ymm7, ymmword ptr [rsp]
       vpcmpeqd ymm2, ymm7, ymm2
       vpslld   ymm0, ymm0, 27
       vpand    ymm0, ymm0, ymm6
       vpxor    ymm0, ymm0, ymmword ptr [rsp+0x140]
       vblendvps ymm0, ymm0, ymm15, ymm2
       vaddps   ymm0, ymm0, ymm5
       vmovups  ymm5, ymmword ptr [rsp+0xE0]
       vmulps   ymm0, ymm5, ymm0
       vmovups  ymm8, ymmword ptr [rsp+0x120]
       vandps   ymm0, ymm0, ymm8
 
G_M000_IG08:                ;; offset=0x0821
       vandnps  ymm2, ymm8, ymm15
       vorps    ymm0, ymm2, ymm0
       vaddps   ymm9, ymm0, ymm9
       cmp      eax, 1
       jne      G_M000_IG04
 
G_M000_IG09:                ;; offset=0x0838
       vmulps   ymm0, ymm9, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rcx], ymm0
       mov      rax, rcx
 
G_M000_IG10:                ;; offset=0x0847
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x420]
       vmovaps  xmm7, xmmword ptr [rsp+0x410]
       vmovaps  xmm8, xmmword ptr [rsp+0x400]
       vmovaps  xmm9, xmmword ptr [rsp+0x3F0]
       vmovaps  xmm10, xmmword ptr [rsp+0x3E0]
       vmovaps  xmm11, xmmword ptr [rsp+0x3D0]
       vmovaps  xmm12, xmmword ptr [rsp+0x3C0]
       vmovaps  xmm13, xmmword ptr [rsp+0x3B0]
       vmovaps  xmm14, xmmword ptr [rsp+0x3A0]
       vmovaps  xmm15, xmmword ptr [rsp+0x390]
       add      rsp, 0x438
       ret      
 
RWD00  	dd	BF000000h		;      -0.5
RWD04  	dd	3F000000h		;       0.5
RWD08  	dd	4F000000h		; 2.14748e+09
RWD12  	dd	7FFFFFFFh		;       nan
RWD16  	dd	00000001h		; 1.4013e-45
RWD20  	dd	BF800000h		;        -1
RWD24  	dd	80000000h		;        -0
RWD28  	dd	00000000h
RWD32  	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD64  	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD96  	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD128 	dd	3F19999Ah		;       0.6
RWD132 	dd	3F400000h		;      0.75
RWD136 	dd	27D4EB2Dh		; 5.90968e-15
RWD140 	dd	000000FCh		; 3.53127e-43
RWD144 	dd	00000003h		; 4.2039e-45
RWD148 	dd	00000002h		; 2.8026e-45
RWD152 	dd	00000000h, 00000000h
RWD160 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD192 	dq	4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h

; Total bytes of code 2220

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 3 inlinees with PGO data; 182 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 544
       vmovaps  xmmword ptr [rsp+0x210], xmm6
       vmovaps  xmmword ptr [rsp+0x200], xmm7
       vmovaps  xmmword ptr [rsp+0x1F0], xmm8
       vmovaps  xmmword ptr [rsp+0x1E0], xmm9
       vmovaps  xmmword ptr [rsp+0x1D0], xmm10
       vmovaps  xmmword ptr [rsp+0x1C0], xmm11
       vmovaps  xmmword ptr [rsp+0x1B0], xmm12
       vmovaps  xmmword ptr [rsp+0x1A0], xmm13
       vmovaps  xmmword ptr [rsp+0x190], xmm14
       vmovaps  xmmword ptr [rsp+0x180], xmm15
       mov      rbx, rdx
       mov      rax, bword ptr [rsp+0x270]
 
G_M000_IG02:                ;; offset=0x0072
       mov      edx, dword ptr [rcx+0x64]
       vbroadcastss ymm0, dword ptr [rcx+0x0C]
       vmulps   ymm1, ymm0, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       dec      edx
       cmp      edx, 2
       jne      G_M000_IG17
 
G_M000_IG03:                ;; offset=0x00A2
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm1, ymm0, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD00]
       vsubps   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [r8], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x00D3
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       vmovups  ymm6, ymmword ptr [r8]
       vmovups  ymm7, ymmword ptr [r9]
       vmovups  ymm8, ymmword ptr [rax]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  ymm9, ymm6
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovss   xmm12, dword ptr [rcx+0x38]
       vmovss   dword ptr [rsp+0x14C], xmm12
       cmp      dword ptr [rsi], 0
       je       G_M000_IG15
       cmp      ebp, 1
       jle      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x011C
       vxorps   ymm6, ymm6, ymm6
       vmovups  ymmword ptr [rsp+0x110], ymm6
       vbroadcastss ymm7, dword ptr [rsi+0x18]
       vbroadcastss ymm8, dword ptr [rsi+0x08]
       vbroadcastss ymm13, dword ptr [rsi+0x0C]
       vmovups  ymmword ptr [rsp+0xF0], ymm13
       vbroadcastss ymm14, dword ptr [rsi+0x10]
       vmovups  ymmword ptr [rsp+0xD0], ymm14
       xor      r14d, r14d
       cmp      r14d, ebp
       jge      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x015F
       vucomiss xmm12, dword ptr [reloc @RWD32]
       jp       G_M000_IG24
       jne      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x0173
       lea      edx, [rdi+r14]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm9
       vmovups  ymmword ptr [rsp+0x50], ymm10
       vmovups  ymmword ptr [rsp+0x30], ymm11
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xB0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm6, ymm7
       vextractf128 xmm12, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rsi]
       cmp      edx, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm10, ymm10, xmm13
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm8, ymm8, xmm12
       je       G_M000_IG11
 
G_M000_IG08:                ;; offset=0x020C
       cmp      edx, 3
       je       G_M000_IG25
       vmulps   ymm0, ymm7, ymmword ptr [rsp+0xB0]
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
 
G_M000_IG09:                ;; offset=0x0241
       vsubps   ymm0, ymm0, ymm12
       vmovups  ymm14, ymmword ptr [rsp+0xD0]
       vmulps   ymm0, ymm0, ymm14
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       vmulps   ymm9, ymm9, ymm8
       vmulps   ymm10, ymm10, ymm8
       vmulps   ymm11, ymm11, ymm8
       vmovups  ymm13, ymmword ptr [rsp+0xF0]
       vmulps   ymm7, ymm7, ymm13
       inc      r14d
       cmp      r14d, ebp
       vmovss   xmm12, dword ptr [rsp+0x14C]
       jge      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x028B
       vmovups  ymmword ptr [rsp+0x110], ymm6
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x0299
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vsubps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
G_M000_IG12:                ;; offset=0x02E4
       vmovups  ymm6, ymmword ptr [rsp+0x110]
 
G_M000_IG13:                ;; offset=0x02ED
       vmovups  ymmword ptr [rbx], ymm6
       mov      rax, rbx
 
G_M000_IG14:                ;; offset=0x02F4
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x210]
       vmovaps  xmm7, xmmword ptr [rsp+0x200]
       vmovaps  xmm8, xmmword ptr [rsp+0x1F0]
       vmovaps  xmm9, xmmword ptr [rsp+0x1E0]
       vmovaps  xmm10, xmmword ptr [rsp+0x1D0]
       vmovaps  xmm11, xmmword ptr [rsp+0x1C0]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B0]
       vmovaps  xmm13, xmmword ptr [rsp+0x1A0]
       vmovaps  xmm14, xmmword ptr [rsp+0x190]
       vmovaps  xmm15, xmmword ptr [rsp+0x180]
       add      rsp, 544
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG15:                ;; offset=0x035F
       vmovd    xmm0, edi
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm6
       vmovups  ymmword ptr [rsp+0x50], ymm7
       vmovups  ymmword ptr [rsp+0x30], ymm8
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x150]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG23
       vbroadcastss ymm0, dword ptr [rsi+0x18]
       mov      eax, dword ptr [rsi]
       cmp      eax, 2
       je       G_M000_IG20
       cmp      eax, 3
       je       G_M000_IG22
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x150]
 
G_M000_IG16:                ;; offset=0x03D9
       vbroadcastss ymm0, ymm12
       vmulps   ymm6, ymm0, ymm1
       jmp      G_M000_IG13
 
G_M000_IG17:                ;; offset=0x03E7
       cmp      edx, 2
       ja       G_M000_IG04
       mov      edx, edx
       lea      r10, [reloc @RWD160]
       mov      r10d, dword ptr [r10+4*rdx]
       lea      r11, G_M000_IG02
       add      r10, r11
       jmp      r10
 
G_M000_IG18:                ;; offset=0x040A
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymm2, ymmword ptr [rax]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rax], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [rax]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vaddps   ymm1, ymm1, ymmword ptr [r9]
       vsubps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       jmp      G_M000_IG04
 
G_M000_IG19:                ;; offset=0x045D
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymm2, ymmword ptr [r9]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [r9], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [r9]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vsubps   ymm1, ymm1, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       jmp      G_M000_IG04
 
G_M000_IG20:                ;; offset=0x04B3
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm2, dword ptr [reloc @RWD32]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG16
 
G_M000_IG21:                ;; offset=0x04E2
       jmp      G_M000_IG07
 
G_M000_IG22:                ;; offset=0x04E7
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x150]
       vbroadcastss ymm3, dword ptr [rsi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD96], ymm4
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD288]
       vsubps   ymm3, ymm3, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD64]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG16
 
G_M000_IG23:                ;; offset=0x056C
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       jmp      G_M000_IG16
 
G_M000_IG24:                ;; offset=0x057A
       lea      edx, [rbp-0x01]
       cmp      r14d, edx
       jne      G_M000_IG21
       vbroadcastss ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       jmp      G_M000_IG07
 
G_M000_IG25:                ;; offset=0x0594
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vbroadcastss ymm1, dword ptr [rsi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD96], ymm2
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm12
       vbroadcastss ymm2, dword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
RWD00  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD32  	dd	3F800000h		;         1
RWD36  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD64  	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD96  	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD128 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h
RWD160 	dd	00000398h ; case G_M000_IG18
       	dd	000003EBh ; case G_M000_IG19
       	dd	00000030h ; case G_M000_IG03
RWD172 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD192 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD224 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD256 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD288 	dq	4000000040000000h, 4000000040000000h, 4000000040000000h, 4000000040000000h

; Total bytes of code 1589

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 8802
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rsi
       push     rbx
       sub      rsp, 40
 
G_M000_IG02:                ;; offset=0x0006
       mov      rax, bword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x000F
       mov      r11d, r10d
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       mov      ebx, r10d
       mov      esi, ebx
       vmovsd   xmm0, qword ptr [r9+8*rsi]
       vmovsd   qword ptr [rax+8*r11], xmm0
       lea      r11d, [r10+0x04]
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       vmovsd   xmm0, qword ptr [r9+8*rbx+0x20]
       vmovsd   qword ptr [rax+8*r11], xmm0
       inc      r10d
       cmp      r10d, 4
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x0055
       add      rsp, 40
       pop      rbx
       pop      rsi
       ret      
 
G_M000_IG05:                ;; offset=0x005C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 98


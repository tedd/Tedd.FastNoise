; Assembly listing for method (dynamicClass):lambda_method1(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 14 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 256
       vmovaps  xmmword ptr [rsp+0xF0], xmm6
       vmovaps  xmmword ptr [rsp+0xE0], xmm7
       vmovaps  xmmword ptr [rsp+0xD0], xmm8
       vmovaps  xmmword ptr [rsp+0xC0], xmm9
       vmovaps  xmmword ptr [rsp+0xB0], xmm10
       vmovaps  xmmword ptr [rsp+0xA0], xmm11
       vmovaps  xmmword ptr [rsp+0x90], xmm12
       vmovaps  xmmword ptr [rsp+0x80], xmm13
       vmovaps  xmmword ptr [rsp+0x70], xmm14
       vmovaps  xmmword ptr [rsp+0x60], xmm15
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0061
       mov      rsi, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       test     eax, eax
       je       G_M000_IG48
       vmovsd   xmm1, qword ptr [rcx]
       cmp      eax, 1
       jbe      G_M000_IG48
       vmovsd   xmm2, qword ptr [rcx+0x08]
       cmp      eax, 2
       jbe      G_M000_IG48
       vmovsd   xmm3, qword ptr [rcx+0x10]
       vcvtsd2ss xmm6, xmm6, xmm1
       vcvtsd2ss xmm7, xmm7, xmm2
       vcvtsd2ss xmm8, xmm8, xmm3
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 0
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x00CF
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD00]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm9, xmm1, xmm2
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 1
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x18]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x010E
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG35
 
G_M000_IG06:                ;; offset=0x0121
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD04]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm9
       vmovss   xmm9, dword ptr [reloc @RWD08]
       vaddss   xmm1, xmm1, xmm9
       vxorps   xmm10, xmm10, xmm10
       vmovaps  xmm2, xmm10
       vmovss   xmm11, dword ptr [reloc @RWD12]
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vcmpneqps xmm12, xmm2, xmm2
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vbroadcastss xmm13, dword ptr [reloc @RWD08]
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm14, xmm14, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 2
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x20]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01DE
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG36
 
G_M000_IG08:                ;; offset=0x01F1
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm15, xmm15, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 3
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x027E
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG37
 
G_M000_IG10:                ;; offset=0x0291
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD16]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vmovss   dword ptr [rsp+0x2C], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 4
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x30]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x02D6
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG38
 
G_M000_IG12:                ;; offset=0x02E9
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD20]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x2C]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x58], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 5
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x38]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x038A
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG39
 
G_M000_IG14:                ;; offset=0x039D
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vmovss   dword ptr [rsp+0x28], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 6
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x03DA
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG40
 
G_M000_IG16:                ;; offset=0x03ED
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, xmm11
       vaddss   xmm1, xmm1, xmm11
       vmulss   xmm1, xmm1, dword ptr [rsp+0x28]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x50], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0488
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG41
 
G_M000_IG18:                ;; offset=0x049B
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x48], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x052E
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG42
 
G_M000_IG20:                ;; offset=0x0541
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x40], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 9
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x58]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x05D4
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG43
 
G_M000_IG22:                ;; offset=0x05E7
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD24]
       vaddss   xmm1, xmm1, dword ptr [reloc @RWD28]
       vmovss   dword ptr [rsp+0x24], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 10
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x062C
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG44
 
G_M000_IG24:                ;; offset=0x063F
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD32]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x24]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x38], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 11
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x68]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x06E0
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG45
 
G_M000_IG26:                ;; offset=0x06F3
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x30], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0786
       mov      rax, 0x7FFC657EBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG46
 
G_M000_IG28:                ;; offset=0x0799
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm9
       vmulss   xmm0, xmm0, xmm11
       vcmpeqps xmm1, xmm10, xmm0
       vxorps   xmm2, xmm2, xmm2
       vpcmpgtd xmm2, xmm2, xmm0
       vandps   xmm1, xmm2, xmm1
       vorps    xmm1, xmm1, xmm12
       vcmpltps xmm2, xmm0, xmm10
       vorps    xmm1, xmm2, xmm1
       vandps   xmm2, xmm10, xmm1
       vandnps  xmm0, xmm1, xmm0
       vorps    xmm0, xmm0, xmm2
       vxorps   xmm1, xmm1, xmm1
       vcmpltps xmm2, xmm13, xmm0
       vorps    xmm1, xmm2, xmm1
       vblendvps xmm0, xmm0, xmm13, xmm1
       vcvtss2sd xmm0, xmm0, xmm0
       vmovsd   xmm1, qword ptr [reloc @RWD40]
       vsubsd   xmm2, xmm1, xmm15
       vxorps   xmm3, xmm3, xmm3
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vsubsd   xmm5, xmm4, qword ptr [reloc @RWD48]
       vcmpeqpd xmm6, xmm3, xmm5
       vxorps   xmm7, xmm7, xmm7
       vpcmpgtq xmm7, xmm7, xmm5
       vandpd   xmm6, xmm7, xmm6
       vcmpneqpd xmm7, xmm3, xmm3
       vorpd    xmm6, xmm6, xmm7
       vcmpltpd xmm8, xmm5, xmm3
       vorpd    xmm6, xmm8, xmm6
       vandpd   xmm3, xmm3, xmm6
       vandnpd  xmm5, xmm6, xmm5
       vorpd    xmm3, xmm5, xmm3
       vmovsd   xmm6, qword ptr [rsp+0x30]
       vsubsd   xmm5, xmm6, qword ptr [reloc @RWD56]
       vaddsd   xmm5, xmm5, xmm5
       vxorps   xmm8, xmm8, xmm8
       vsubsd   xmm9, xmm6, qword ptr [reloc @RWD48]
       vdivsd   xmm9, xmm9, qword ptr [reloc @RWD64]
       vcmpeqpd xmm10, xmm8, xmm9
       vxorps   xmm11, xmm11, xmm11
       vpcmpgtq xmm11, xmm11, xmm9
       vandpd   xmm10, xmm11, xmm10
       vorpd    xmm10, xmm10, xmm7
       vcmpltpd xmm11, xmm9, xmm8
       vorpd    xmm10, xmm11, xmm10
       vandpd   xmm8, xmm8, xmm10
       vandnpd  xmm9, xmm10, xmm9
       vorpd    xmm8, xmm9, xmm8
       vmovddup xmm9, qword ptr [reloc @RWD40]
       vmovaps  xmm10, xmm9
 
G_M000_IG29:                ;; offset=0x08B9
       vxorps   xmm11, xmm11, xmm11
       vcmpltpd xmm12, xmm10, xmm8
       vorpd    xmm11, xmm12, xmm11
       vblendvpd xmm8, xmm8, xmm10, xmm11
       vmulsd   xmm10, xmm8, xmm8
       vaddsd   xmm8, xmm8, xmm8
       vmovsd   xmm11, qword ptr [reloc @RWD72]
       vsubsd   xmm8, xmm11, xmm8
       vmulsd   xmm8, xmm8, xmm10
       vsubsd   xmm10, xmm14, qword ptr [reloc @RWD80]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD88]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD96]
       vmovsd   xmm12, qword ptr [rsp+0x58]
       vsubsd   xmm13, xmm12, qword ptr [reloc @RWD56]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD104]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD112]
       vaddsd   xmm10, xmm10, xmm13
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD120]
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD128]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD136]
       vmulsd   xmm2, xmm3, xmm2
       vaddsd   xmm2, xmm10, xmm2
       vmulsd   xmm3, xmm5, qword ptr [reloc @RWD144]
       vaddsd   xmm2, xmm2, xmm3
       vmulsd   xmm3, xmm8, xmm0
       vmulsd   xmm3, xmm3, xmm0
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD152]
       vaddsd   xmm2, xmm2, xmm3
       vsubsd   xmm2, xmm2, qword ptr [reloc @RWD160]
       vmovaps  xmm3, xmm2
       vxorps   xmm5, xmm5, xmm5
       vmovsd   xmm8, qword ptr [rsp+0x38]
       vaddsd   xmm10, xmm8, xmm8
       vsubsd   xmm10, xmm10, xmm1
       vandps   xmm10, xmm10, xmmword ptr [reloc @RWD176]
       vsubsd   xmm10, xmm10, qword ptr [reloc @RWD192]
       vdivsd   xmm10, xmm10, qword ptr [reloc @RWD200]
       vcmpeqpd xmm13, xmm5, xmm10
       vxorps   xmm4, xmm4, xmm4
       vpcmpgtq xmm4, xmm4, xmm10
       vandpd   xmm4, xmm4, xmm13
       vorpd    xmm4, xmm4, xmm7
       vcmpltpd xmm13, xmm10, xmm5
       vorpd    xmm4, xmm13, xmm4
       vandpd   xmm5, xmm5, xmm4
       vandnpd  xmm4, xmm4, xmm10
       vorpd    xmm4, xmm4, xmm5
       vmovaps  xmm5, xmm9
       vxorps   xmm10, xmm10, xmm10
       vcmpltpd xmm13, xmm5, xmm4
       vorpd    xmm10, xmm13, xmm10
       vblendvpd xmm4, xmm4, xmm5, xmm10
       vmulsd   xmm5, xmm4, xmm4
       vaddsd   xmm4, xmm4, xmm4
       vsubsd   xmm4, xmm11, xmm4
       vmulsd   xmm4, xmm5, xmm4
       vsubsd   xmm4, xmm1, xmm4
       vxorps   xmm5, xmm5, xmm5
       vdivsd   xmm2, xmm2, qword ptr [reloc @RWD208]
 
G_M000_IG30:                ;; offset=0x0A05
       vcmpeqpd xmm10, xmm5, xmm2
       vxorps   xmm13, xmm13, xmm13
       vpcmpgtq xmm13, xmm13, xmm2
       vandpd   xmm10, xmm13, xmm10
       vorpd    xmm7, xmm10, xmm7
       vcmpltpd xmm10, xmm2, xmm5
       vorpd    xmm7, xmm10, xmm7
       vandpd   xmm5, xmm5, xmm7
       vandnpd  xmm2, xmm7, xmm2
       vorpd    xmm2, xmm2, xmm5
       vxorps   xmm5, xmm5, xmm5
       vcmpltpd xmm7, xmm9, xmm2
       vorpd    xmm5, xmm7, xmm5
       vblendvpd xmm2, xmm2, xmm9, xmm5
       vmulsd   xmm5, xmm2, xmm2
       vaddsd   xmm2, xmm2, xmm2
       vsubsd   xmm2, xmm11, xmm2
       vmulsd   xmm2, xmm5, xmm2
       vsubsd   xmm1, xmm1, xmm2
       vmulsd   xmm1, xmm1, xmm4
       vmulsd   xmm2, xmm12, qword ptr [reloc @RWD216]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD224]
       vucomisd xmm3, xmm2
       seta     dl
       movzx    rdx, dl
       vsubsd   xmm2, xmm2, xmm3
       vmulsd   xmm2, xmm2, xmm1
       vaddsd   xmm2, xmm2, xmm3
       test     edx, edx
       je       G_M000_IG33
 
G_M000_IG31:                ;; offset=0x0A8B
       cmp      edi, 10
       jle      G_M000_IG47
       vmovsd   qword ptr [rsi], xmm14
       vmovsd   qword ptr [rsi+0x08], xmm15
       vmovsd   qword ptr [rsi+0x10], xmm12
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       vmovsd   qword ptr [rsi+0x30], xmm8
       vmovsd   qword ptr [rsi+0x38], xmm6
       vmovsd   qword ptr [rsi+0x40], xmm0
       vmovsd   qword ptr [rsi+0x48], xmm2
       vmovsd   qword ptr [rsi+0x50], xmm1
 
G_M000_IG32:                ;; offset=0x0ADC
       vmovaps  xmm6, xmmword ptr [rsp+0xF0]
       vmovaps  xmm7, xmmword ptr [rsp+0xE0]
       vmovaps  xmm8, xmmword ptr [rsp+0xD0]
       vmovaps  xmm9, xmmword ptr [rsp+0xC0]
       vmovaps  xmm10, xmmword ptr [rsp+0xB0]
       vmovaps  xmm11, xmmword ptr [rsp+0xA0]
       vmovaps  xmm12, xmmword ptr [rsp+0x90]
       vmovaps  xmm13, xmmword ptr [rsp+0x80]
       vmovaps  xmm14, xmmword ptr [rsp+0x70]
       vmovaps  xmm15, xmmword ptr [rsp+0x60]
       add      rsp, 256
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG33:                ;; offset=0x0B3B
       vmovaps  xmm2, xmm3
       jmp      G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0B44
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG35:                ;; offset=0x0B4E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG36:                ;; offset=0x0B58
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG37:                ;; offset=0x0B62
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG38:                ;; offset=0x0B6C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG39:                ;; offset=0x0B76
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG40:                ;; offset=0x0B80
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG41:                ;; offset=0x0B8A
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG42:                ;; offset=0x0B94
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG43:                ;; offset=0x0B9E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG44:                ;; offset=0x0BA8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG45:                ;; offset=0x0BB2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG46:                ;; offset=0x0BBC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG47:                ;; offset=0x0BC6
       test     edi, edi
       je       G_M000_IG48
       vmovsd   qword ptr [rsi], xmm14
       cmp      edi, 1
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x08], xmm15
       cmp      edi, 2
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x10], xmm12
       cmp      edi, 3
       jbe      SHORT G_M000_IG48
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       cmp      edi, 4
       jbe      SHORT G_M000_IG48
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       cmp      edi, 5
       jbe      SHORT G_M000_IG48
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       cmp      edi, 6
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x30], xmm8
       cmp      edi, 7
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x38], xmm6
       cmp      edi, 8
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x40], xmm0
       cmp      edi, 9
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x48], xmm2
       cmp      edi, 10
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x50], xmm1
       jmp      G_M000_IG32
 
G_M000_IG48:                ;; offset=0x0C4D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	3F47AE14h		;      0.78
RWD04  	dd	3E6147AEh		;      0.22
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F51EB85h		;      0.82
RWD20  	dd	3E3851ECh		;      0.18
RWD24  	dd	3F666666h		;       0.9
RWD28  	dd	3E570A3Dh		;      0.21
RWD32  	dd	3DCCCCCDh		;       0.1
RWD36  	dd	00000000h
RWD40  	dq	3FF0000000000000h	;            1
RWD48  	dq	3FDEB851EB851EB8h	;         0.48
RWD56  	dq	3FE0000000000000h	;          0.5
RWD64  	dq	3FCEB851EB851EB8h	;         0.24
RWD72  	dq	4008000000000000h	;            3
RWD80  	dq	3FD6666666666666h	;         0.35
RWD88  	dq	4038000000000000h	;           24
RWD96  	dq	4000000000000000h	;            2
RWD104 	dq	4044000000000000h	;           40
RWD112 	dq	3FE1EB851EB851ECh	;         0.56
RWD120 	dq	4067C00000000000h	;          190
RWD128 	dq	3FF6666666666666h	;          1.4
RWD136 	dq	3FD3333333333333h	;          0.3
RWD144 	dq	4074000000000000h	;          320
RWD152 	dq	408F400000000000h	;         1000
RWD160 	dq	4010000000000000h	;            4
RWD168 	dd	00000000h, 00000000h
RWD176 	dq	7FFFFFFFFFFFFFFFh, 7FFFFFFFFFFFFFFFh
RWD192 	dq	3F9999999999999Ah	;        0.025
RWD200 	dq	3FB5C28F5C28F5C2h	;        0.085
RWD208 	dq	4042000000000000h	;           36
RWD216 	dq	3FF3333333333333h	;          1.2
RWD224 	dq	C014000000000000h	;           -5

; Total bytes of code 3155

; Assembly listing for method (dynamicClass):lambda_method2(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 105 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       lea      r11, [rsp-0x20C8]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       vmovaps  xmmword ptr [rsp+0x20B0], xmm6
       vmovaps  xmmword ptr [rsp+0x20A0], xmm7
       vmovaps  xmmword ptr [rsp+0x2090], xmm8
       vmovaps  xmmword ptr [rsp+0x2080], xmm9
       vmovaps  xmmword ptr [rsp+0x2070], xmm10
       vmovaps  xmmword ptr [rsp+0x2060], xmm11
       vmovaps  xmmword ptr [rsp+0x2050], xmm12
       vmovaps  xmmword ptr [rsp+0x2040], xmm13
       vmovaps  xmmword ptr [rsp+0x2030], xmm14
       vmovaps  xmmword ptr [rsp+0x2020], xmm15
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x60], xmm4
       mov      rax, -0x14A0
       vmovdqa  xmmword ptr [rsp+rax+0x1510], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x1520], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x1530], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r8
 
G_M000_IG02:                ;; offset=0x00B4
       mov      rbp, gword ptr [rbx+0x08]
       mov      r14d, dword ptr [rbp+0x08]
       cmp      r14d, 1
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x18]
       mov      r13, 0x7FFC658C3210
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00D9
       mov      rdx, r15
       mov      rcx, r13
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG04:                ;; offset=0x00E5
       vmovups  ymm6, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1FF0], ymm6
       cmp      r14d, 3
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x28]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0107
       mov      rdx, r15
       mov      rcx, r13
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG06:                ;; offset=0x0113
       vmovups  ymm8, ymmword ptr [r15+0x08]
       cmp      r14d, 6
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x40]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x012C
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG08:                ;; offset=0x0144
       vmovups  ymm10, ymmword ptr [r15+0x08]
       cmp      r14d, 7
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x48]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x015D
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm11, ymm10
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG10:                ;; offset=0x0181
       vmovups  ymm12, ymmword ptr [r15+0x08]
       cmp      r14d, 8
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x50]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x019A
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm11, ymm10
       vextractf128 xmm9, ymm8
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG12:                ;; offset=0x01CA
       vmovups  ymm14, ymmword ptr [r15+0x08]
       cmp      r14d, 12
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x70]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01E3
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm11, ymm10
       vextractf128 xmm15, ymm14
       vextractf128 xmm9, ymm8
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm15
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG14:                ;; offset=0x021F
       vmovups  ymm7, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1F50], ymm7
       cmp      r14d, 14
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x80]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0244
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm11, ymm10
       vextractf128 xmm15, ymm14
       vextractf128 xmm9, ymm8
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm15
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG16:                ;; offset=0x0280
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1F30], ymm0
       cmp      r14d, 16
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x90]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x02A5
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm11, ymm10
       vextractf128 xmm15, ymm14
       vextractf128 xmm9, ymm8
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm15
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG18:                ;; offset=0x02E1
       vmovups  ymm9, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1F10], ymm9
       cmp      r14d, 17
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x98]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0306
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm11, ymm10
       vextractf128 xmm15, ymm14
       vextractf128 xmm13, ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm15
       vinsertf128 ymm8, ymm8, xmm13
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG20:                ;; offset=0x034C
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1EF0], ymm1
       cmp      r14d, 18
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0xA0]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x0371
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm11, ymm10
       vextractf128 xmm15, ymm14
       vextractf128 xmm13, ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm15
       vinsertf128 ymm8, ymm8, xmm13
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG22:                ;; offset=0x03B7
       vmovups  ymm11, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1ED0], ymm11
       cmp      r14d, 23
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0xC8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x03DC
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm10
       vextractf128 xmm15, ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm13
       vinsertf128 ymm14, ymm14, xmm15
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG24:                ;; offset=0x042C
       vmovups  ymm13, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1EB0], ymm13
       cmp      r14d, 25
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0xD8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0451
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm15, ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG26:                ;; offset=0x04AB
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1E90], ymm15
       cmp      r14d, 28
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0xF0]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x04D0
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG28:                ;; offset=0x0534
       vmovups  ymm2, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1E70], ymm2
       cmp      r14d, 29
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0xF8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x0559
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG30:                ;; offset=0x05BD
       vmovups  ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1E50], ymm3
       cmp      r14d, 30
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x100]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x05E2
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG32:                ;; offset=0x0646
       vmovups  ymm4, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1E30], ymm4
       cmp      r14d, 33
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x118]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x066B
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG34:                ;; offset=0x06CF
       vmovups  ymm5, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1E10], ymm5
       cmp      r14d, 35
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x128]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x06F4
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG36:                ;; offset=0x0758
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1DF0], ymm0
       cmp      r14d, 38
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x140]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x077D
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG38:                ;; offset=0x07E1
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1DD0], ymm1
       cmp      r14d, 39
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x148]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x0806
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG40:                ;; offset=0x086A
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1DB0], ymm0
       cmp      r14d, 40
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x150]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x088F
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG42:                ;; offset=0x08F3
       vmovups  ymm5, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1D90], ymm5
       cmp      r14d, 44
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x170]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0918
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG44:                ;; offset=0x097C
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1D70], ymm0
       cmp      r14d, 46
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x180]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG46
 
G_M000_IG45:                ;; offset=0x09A1
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG46:                ;; offset=0x0A05
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1D50], ymm0
       cmp      r14d, 48
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x190]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x0A2A
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG48:                ;; offset=0x0A8E
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1D30], ymm0
       cmp      r14d, 49
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x198]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0AB3
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG50:                ;; offset=0x0B17
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1D10], ymm0
       cmp      r14d, 50
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x1A0]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0B3C
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG52:                ;; offset=0x0BA0
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1CF0], ymm0
       cmp      r14d, 53
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x1B8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0BC5
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG54:                ;; offset=0x0C29
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1CD0], ymm0
       cmp      r14d, 55
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x1C8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x0C4E
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG56:                ;; offset=0x0CB2
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1CB0], ymm0
       cmp      r14d, 58
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x1E0]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0CD7
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG58:                ;; offset=0x0D3B
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1C90], ymm0
       cmp      r14d, 59
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x1E8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0D60
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG60:                ;; offset=0x0DC4
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1C70], ymm0
       cmp      r14d, 60
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x1F0]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0DE9
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG62:                ;; offset=0x0E4D
       vmovups  ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1C50], ymm3
       cmp      r14d, 61
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x1F8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x0E72
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG64:                ;; offset=0x0ED6
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1C30], ymm15
       cmp      r14d, 65
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x218]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x0EFB
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG66:                ;; offset=0x0F5F
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1C10], ymm15
       cmp      r14d, 67
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x228]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x0F84
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG68:                ;; offset=0x0FE8
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1BF0], ymm15
       cmp      r14d, 69
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x238]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x100D
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG70:                ;; offset=0x1071
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1BD0], ymm15
       cmp      r14d, 70
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x240]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x1096
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG72:                ;; offset=0x10FA
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1BB0], ymm15
       cmp      r14d, 71
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x248]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x111F
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG74:                ;; offset=0x1183
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1B90], ymm15
       cmp      r14d, 73
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x258]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x11A8
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG76:                ;; offset=0x120C
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1B70], ymm15
       cmp      r14d, 75
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x268]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x1231
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG78:                ;; offset=0x1295
       vmovups  ymm15, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1B50], ymm15
       cmp      r14d, 78
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x280]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x12BA
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG80:                ;; offset=0x131E
       vmovups  ymm15, ymmword ptr [r15+0x08]
       cmp      r14d, 79
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x288]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x133A
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
 
G_M000_IG82:                ;; offset=0x13B4
       vmovups  ymm13, ymmword ptr [r15+0x08]
       cmp      r14d, 80
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x290]
       cmp      qword ptr [r15], r13
       je       G_M000_IG84
 
G_M000_IG83:                ;; offset=0x13D4
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
 
G_M000_IG84:                ;; offset=0x1464
       vmovups  ymm11, ymmword ptr [r15+0x08]
       cmp      r14d, 83
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x2A8]
       cmp      qword ptr [r15], r13
       je       G_M000_IG86
 
G_M000_IG85:                ;; offset=0x1484
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
 
G_M000_IG86:                ;; offset=0x152A
       vmovups  ymm9, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1AD0], ymm9
       cmp      r14d, 85
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x2B8]
       cmp      qword ptr [r15], r13
       je       G_M000_IG88
 
G_M000_IG87:                ;; offset=0x1553
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
 
G_M000_IG88:                ;; offset=0x15F9
       vmovups  ymm9, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1AB0], ymm9
       cmp      r14d, 88
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x2D0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1622
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
 
G_M000_IG90:                ;; offset=0x16C8
       vmovups  ymm9, ymmword ptr [r15+0x08]
       cmp      r14d, 89
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x2D8]
       cmp      qword ptr [r15], r13
       je       G_M000_IG92
 
G_M000_IG91:                ;; offset=0x16E8
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
 
G_M000_IG92:                ;; offset=0x17A4
       vmovups  ymm7, ymmword ptr [r15+0x08]
       cmp      r14d, 90
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x2E0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG94
 
G_M000_IG93:                ;; offset=0x17C4
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG94:                ;; offset=0x1896
       vmovups  ymm6, ymmword ptr [r15+0x08]
       cmp      r14d, 93
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x2F8]
       cmp      qword ptr [r15], r13
       je       G_M000_IG96
 
G_M000_IG95:                ;; offset=0x18B6
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG96:                ;; offset=0x199E
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1A30], ymm1
       cmp      r14d, 99
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x328]
       cmp      qword ptr [r15], r13
       je       G_M000_IG98
 
G_M000_IG97:                ;; offset=0x19C7
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG98:                ;; offset=0x1AAF
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1A10], ymm1
       cmp      r14d, 101
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x338]
       cmp      qword ptr [r15], r13
       je       G_M000_IG100
 
G_M000_IG99:                ;; offset=0x1AD8
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG100:                ;; offset=0x1BC0
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x19F0], ymm1
       cmp      r14d, 103
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x348]
       cmp      qword ptr [r15], r13
       je       G_M000_IG102
 
G_M000_IG101:                ;; offset=0x1BE9
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG102:                ;; offset=0x1CD1
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x19D0], ymm1
       cmp      r14d, 104
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x350]
       cmp      qword ptr [r15], r13
       je       G_M000_IG104
 
G_M000_IG103:                ;; offset=0x1CFA
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG104:                ;; offset=0x1DE2
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x19B0], ymm1
       cmp      r14d, 105
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x358]
       cmp      qword ptr [r15], r13
       je       G_M000_IG106
 
G_M000_IG105:                ;; offset=0x1E0B
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG106:                ;; offset=0x1EF3
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1990], ymm1
       cmp      r14d, 108
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x370]
       cmp      qword ptr [r15], r13
       je       G_M000_IG108
 
G_M000_IG107:                ;; offset=0x1F1C
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG108:                ;; offset=0x2004
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1970], ymm1
       cmp      r14d, 110
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x380]
       cmp      qword ptr [r15], r13
       je       G_M000_IG110
 
G_M000_IG109:                ;; offset=0x202D
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG110:                ;; offset=0x2115
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1950], ymm1
       cmp      r14d, 112
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x390]
       cmp      qword ptr [r15], r13
       je       G_M000_IG112
 
G_M000_IG111:                ;; offset=0x213E
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG112:                ;; offset=0x2226
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1930], ymm1
       cmp      r14d, 113
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x398]
       cmp      qword ptr [r15], r13
       je       G_M000_IG114
 
G_M000_IG113:                ;; offset=0x224F
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG114:                ;; offset=0x2337
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1910], ymm1
       cmp      r14d, 114
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x3A0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG116
 
G_M000_IG115:                ;; offset=0x2360
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG116:                ;; offset=0x2448
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x18F0], ymm1
       cmp      r14d, 116
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x3B0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG118
 
G_M000_IG117:                ;; offset=0x2471
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG118:                ;; offset=0x2559
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x18D0], ymm1
       cmp      r14d, 118
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x3C0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG120
 
G_M000_IG119:                ;; offset=0x2582
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG120:                ;; offset=0x266A
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x18B0], ymm1
       cmp      r14d, 121
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x3D8]
       cmp      qword ptr [r15], r13
       je       G_M000_IG122
 
G_M000_IG121:                ;; offset=0x2693
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG122:                ;; offset=0x277B
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1890], ymm1
       cmp      r14d, 122
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x3E0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG124
 
G_M000_IG123:                ;; offset=0x27A4
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG124:                ;; offset=0x288C
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1870], ymm1
       cmp      r14d, 123
       jbe      G_M000_IG363
       mov      r15, gword ptr [rbp+0x03E8]
       cmp      qword ptr [r15], r13
       je       G_M000_IG126
 
G_M000_IG125:                ;; offset=0x28B5
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG126:                ;; offset=0x299D
       vmovups  ymm2, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1850], ymm2
       cmp      r14d, 124
       jbe      G_M000_IG363
       mov      rbp, gword ptr [rbp+0x03F0]
       cmp      qword ptr [rbp], r13
       je       G_M000_IG128
 
G_M000_IG127:                ;; offset=0x29C7
       mov      rdx, rbp
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG128:                ;; offset=0x2AAF
       vmovups  ymm2, ymmword ptr [rbp+0x08]
       vmovups  ymmword ptr [rsp+0x1830], ymm2
 
G_M000_IG129:                ;; offset=0x2ABD
       vmovdqu  xmm2, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x180], xmm2
 
G_M000_IG130:                ;; offset=0x2ACA
       lea      rdx, [rsp+0x180]
       lea      rcx, [rsp+0x17F0]
       xor      r8d, r8d
       mov      r9d, 3
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG131:                ;; offset=0x2B57
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x180], xmm0
 
G_M000_IG132:                ;; offset=0x2B64
       lea      rdx, [rsp+0x180]
       lea      rcx, [rsp+0x17B0]
       mov      r8d, 1
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1770]
       mov      rdx, rdi
       mov      r8d, 2
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x17F0]
       vmovups  ymm1, ymmword ptr [rsp+0x1810]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1750], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x17B0]
       vmovups  ymm2, ymmword ptr [rsp+0x17D0]
       vcvtpd2ps ymm1, ymm1
       vcvtpd2ps ymm2, ymm2
       vinsertf128 ymm1, ymm1, xmm2
       vmovups  ymmword ptr [rsp+0x1730], ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x1770]
       vmovups  ymm3, ymmword ptr [rsp+0x1790]
       vcvtpd2ps ymm2, ymm2
       vcvtpd2ps ymm3, ymm3
       vinsertf128 ymm2, ymm2, xmm3
       vmovups  ymmword ptr [rsp+0x1710], ymm2
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       test     ebp, ebp
       je       G_M000_IG363
       mov      r14, gword ptr [rdx+0x10]
       cmp      qword ptr [r14], r13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG134
 
G_M000_IG133:                ;; offset=0x2CAB
       mov      rdx, r14
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG134:                ;; offset=0x2D93
       vmovups  ymm3, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x16F0], ymm3
       vmovups  ymm0, ymmword ptr [rsp+0x1750]
       vmovups  ymm4, ymmword ptr [rsp+0x1FF0]
       vmulps   ymm5, ymm0, ymm4
       vmovups  ymmword ptr [rsp+0x650], ymm5
       vmovups  ymm1, ymmword ptr [rsp+0x1730]
       vmulps   ymm5, ymm1, ymm4
       vmovups  ymmword ptr [rsp+0x630], ymm5
       vmovups  ymm2, ymmword ptr [rsp+0x1710]
       vmulps   ymm4, ymm2, ymm4
       vmovups  ymmword ptr [rsp+0x610], ymm4
       mov      rdx, rdi
       cmp      ebp, 2
       jbe      G_M000_IG363
       mov      r14, gword ptr [rdx+0x20]
       cmp      qword ptr [r14], r13
       je       G_M000_IG136
 
G_M000_IG135:                ;; offset=0x2E06
       mov      rdx, r14
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG136:                ;; offset=0x2EEE
       vmovups  ymm4, ymmword ptr [rsp+0x650]
       vaddps   ymm4, ymm4, ymmword ptr [rsp+0x630]
       vaddps   ymm4, ymm4, ymmword ptr [rsp+0x610]
       vmulps   ymm4, ymm4, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x5F0], ymm4
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x5F0]
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x5F0]
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm4
       vmovups  ymmword ptr [rsp+0x5B0], ymm8
       mov      rdx, rdi
       cmp      ebp, 4
       jbe      G_M000_IG363
       mov      r14, gword ptr [rdx+0x30]
       cmp      qword ptr [r14], r13
       je       G_M000_IG138
 
G_M000_IG137:                ;; offset=0x2F82
       mov      rdx, r14
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG138:                ;; offset=0x306A
       vmovups  ymm4, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x590], ymm4
       cmp      ebp, 5
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x38]
       mov      rbp, 0x7FFC658BD020
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG140
 
G_M000_IG139:                ;; offset=0x3099
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG140:                ;; offset=0x3181
       vmovups  ymm4, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm4
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vaddps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vaddps   ymm0, ymm10, ymmword ptr [rsp+0x5D0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vmulps   ymm0, ymm0, ymm12
       vsubps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vmulps   ymm0, ymm14, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm0
       vmulps   ymm0, ymm14, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmulps   ymm0, ymm14, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmulps   ymm0, ymm12, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 9
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x58]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
 
G_M000_IG141:                ;; offset=0x3354
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG143
 
G_M000_IG142:                ;; offset=0x3386
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG143:                ;; offset=0x346E
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm0
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmmword ptr [rsp+0x1FC0], ymm10
       vextractf128 xmmword ptr [rsp+0x1F80], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1FE0], ymm8
       vextractf128 xmmword ptr [rsp+0x1FA0], ymm12
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1FC0]
       vaddps   ymm0, ymm10, ymmword ptr [rsp+0x5D0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1FA0]
       vmulps   ymm0, ymm0, ymm12
       vsubps   ymm0, ymm0, ymm10
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1FE0]
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1F80]
       vmulps   ymm0, ymm14, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm0
       vmulps   ymm0, ymm14, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmulps   ymm0, ymm14, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmulps   ymm0, ymm12, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 10
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x60]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
 
G_M000_IG144:                ;; offset=0x3645
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       SHORT G_M000_IG146
 
G_M000_IG145:                ;; offset=0x3673
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm15
       vextractf128 xmm10, ymm11
       vextractf128 xmm12, ymm9
       vextractf128 xmm14, ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm15, ymm15, xmm8
       vinsertf128 ymm11, ymm11, xmm10
       vinsertf128 ymm9, ymm9, xmm12
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG146:                ;; offset=0x36DB
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x610]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5D0]
       lea      r8, [rsp+0x650]
       lea      r9, [rsp+0x630]
       vextractf128 xmm8, ymm15
       vextractf128 xmm10, ymm11
       vextractf128 xmm12, ymm9
       vextractf128 xmm14, ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x16D0], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 11
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x68]
       cmp      qword ptr [r15], r13
       vinsertf128 ymm15, ymm15, xmm8
       vinsertf128 ymm11, ymm11, xmm10
       vinsertf128 ymm9, ymm9, xmm12
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       SHORT G_M000_IG148
 
G_M000_IG147:                ;; offset=0x37BA
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm8, ymm15
       vextractf128 xmm10, ymm11
       vextractf128 xmm12, ymm9
       vextractf128 xmm14, ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm15, ymm15, xmm8
       vinsertf128 ymm11, ymm11, xmm10
       vinsertf128 ymm9, ymm9, xmm12
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG148:                ;; offset=0x3822
       vmovups  ymm0, ymmword ptr [rsp+0x16D0]
       vmulps   ymm0, ymm0, ymmword ptr [r15+0x08]
       vmovups  ymm8, ymmword ptr [rsp+0x16F0]
       vaddps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0x16B0], ymm0
       vmovups  ymm10, ymmword ptr [rsp+0x1750]
       vmovups  ymm12, ymmword ptr [rsp+0x1F50]
       vmulps   ymm1, ymm10, ymm12
       vmovups  ymmword ptr [rsp+0x570], ymm1
       vmovups  ymm14, ymmword ptr [rsp+0x1730]
       vmulps   ymm1, ymm14, ymm12
       vmovups  ymmword ptr [rsp+0x590], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1710]
       vmulps   ymm2, ymm1, ymm12
       vmovups  ymmword ptr [rsp+0x5B0], ymm2
       mov      rdx, rdi
       cmp      r14d, 13
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x78]
       mov      r12, r15
       cmp      qword ptr [r12], r13
       je       G_M000_IG150
 
G_M000_IG149:                ;; offset=0x38B4
       mov      rdx, r12
       mov      rcx, r13
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG150:                ;; offset=0x397C
       vmovups  ymm2, ymmword ptr [rsp+0x570]
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x590]
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x5B0]
       vmulps   ymm2, ymm2, ymmword ptr [r12+0x08]
       vmovups  ymmword ptr [rsp+0x5D0], ymm2
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x5D0]
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x5D0]
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x1F30]
       vmovups  ymmword ptr [rsp+0x610], ymm2
       cmp      qword ptr [r15], r13
       je       G_M000_IG152
 
G_M000_IG151:                ;; offset=0x3A0A
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG152:                ;; offset=0x3AD2
       vmovups  ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x630], ymm3
       cmp      r14d, 15
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x88]
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG154
 
G_M000_IG153:                ;; offset=0x3AFB
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG154:                ;; offset=0x3BC3
       vmovups  ymm3, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm3
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1F10]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x5F0]
       vmovups  ymm2, ymmword ptr [rsp+0x1EF0]
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1F30]
       vaddps   ymm0, ymm1, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1ED0]
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmulps   ymm0, ymm2, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 19
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0xA8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
 
G_M000_IG155:                ;; offset=0x3D8E
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG157
 
G_M000_IG156:                ;; offset=0x3DCB
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG157:                ;; offset=0x3E93
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x5B0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5F0]
       lea      r8, [rsp+0x570]
       lea      r9, [rsp+0x590]
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x1690], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 20
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0xB0]
       cmp      qword ptr [r15], r13
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG159
 
G_M000_IG158:                ;; offset=0x3FD9
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG159:                ;; offset=0x40A1
       vmovups  ymm0, ymmword ptr [rsp+0x1690]
       vmulps   ymm0, ymm0, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x16B0]
       vmovups  ymmword ptr [rsp+0x1670], ymm0
       mov      rdx, rdi
       cmp      r14d, 21
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0xB8]
       cmp      qword ptr [r15], r13
       je       G_M000_IG161
 
G_M000_IG160:                ;; offset=0x40E4
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG161:                ;; offset=0x41AC
       vmovups  ymm12, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0x1670]
       vmovups  ymmword ptr [rsp+0x1630], ymm0
       mov      rdx, rdi
       cmp      r14d, 22
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0xC0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG163
 
G_M000_IG162:                ;; offset=0x41E1
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG163:                ;; offset=0x42C9
       vmovups  ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1610], ymm1
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x1630]
       vcmpeqps ymm2, ymm8, ymm8
       vcmpeqps ymm3, ymm8, ymm0
       vandps   ymm4, ymm8, ymm0
       vcmpgtps ymm5, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm8, ymm0, ymm2
       vcmpeqps ymm2, ymm12, ymm12
       vcmpeqps ymm3, ymm12, ymm0
       vorps    ymm4, ymm12, ymm0
       vcmpltps ymm5, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm12, ymm0, ymm2
       vmovaps  ymm2, ymm0
       vcvtps2pd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x530], ymm2
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x510], ymm0
       vmovups  ymm3, ymmword ptr [rsp+0x1EB0]
       vmulps   ymm4, ymm10, ymm3
       vmovups  ymmword ptr [rsp+0x650], ymm4
       vmulps   ymm4, ymm14, ymm3
       vmovups  ymmword ptr [rsp+0x630], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x1710]
       vmulps   ymm3, ymm4, ymm3
       vmovups  ymmword ptr [rsp+0x610], ymm3
       mov      rdx, rdi
       cmp      r14d, 24
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0xD0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG165
 
G_M000_IG164:                ;; offset=0x43A7
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG165:                ;; offset=0x448F
       vmovups  ymm3, ymmword ptr [rsp+0x650]
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x630]
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x610]
       vmulps   ymm3, ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x5F0], ymm3
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5F0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5F0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x1E90]
       vmovups  ymmword ptr [rsp+0x5B0], ymm3
       mov      rdx, rdi
       cmp      r14d, 26
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0xE0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG167
 
G_M000_IG166:                ;; offset=0x4530
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG167:                ;; offset=0x4618
       vmovups  ymm5, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x590], ymm5
       cmp      r14d, 27
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0xE8]
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG169
 
G_M000_IG168:                ;; offset=0x4641
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG169:                ;; offset=0x4729
       vmovups  ymm5, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm5
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1E70]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x5D0]
       vmovups  ymm2, ymmword ptr [rsp+0x1E50]
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1E90]
       vaddps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1E30]
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm4
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm4
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm4
       vmulps   ymm4, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm4
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 31
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x108]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
 
G_M000_IG170:                ;; offset=0x48FE
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG172
 
G_M000_IG171:                ;; offset=0x4951
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG172:                ;; offset=0x4A39
       vmovups  ymm4, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm4
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1E70]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x5D0]
       vmovups  ymm2, ymmword ptr [rsp+0x1E50]
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1E90]
       vaddps   ymm0, ymm1, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1E30]
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmulps   ymm0, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 32
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x110]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
 
G_M000_IG173:                ;; offset=0x4C0E
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG175
 
G_M000_IG174:                ;; offset=0x4C61
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG175:                ;; offset=0x4D49
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x610]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5D0]
       lea      r8, [rsp+0x650]
       lea      r9, [rsp+0x630]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vmulps   ymm0, ymm0, ymm12
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1610]
       vcmpeqps ymm2, ymm8, ymm8
       vcmpeqps ymm3, ymm8, ymm0
       vandps   ymm4, ymm8, ymm0
       vcmpgtps ymm5, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm8, ymm0, ymm2
       vcmpeqps ymm2, ymm12, ymm12
       vcmpeqps ymm3, ymm12, ymm0
       vorps    ymm4, ymm12, ymm0
       vcmpltps ymm5, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm12, ymm0, ymm2
       vmovaps  ymm2, ymm0
       vcvtps2pd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x4F0], ymm2
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x4D0], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vmovups  ymm5, ymmword ptr [rsp+0x1E10]
       vmulps   ymm3, ymm10, ymm5
       vmovups  ymmword ptr [rsp+0x570], ymm3
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vmulps   ymm3, ymm14, ymm5
       vmovups  ymmword ptr [rsp+0x590], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x1710]
       vmulps   ymm4, ymm3, ymm5
       vmovups  ymmword ptr [rsp+0x5B0], ymm4
 
G_M000_IG176:                ;; offset=0x4F00
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 34
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x120]
       cmp      qword ptr [r15], r13
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG178
 
G_M000_IG177:                ;; offset=0x4F67
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG178:                ;; offset=0x504F
       vmovups  ymm4, ymmword ptr [rsp+0x570]
       vaddps   ymm4, ymm4, ymmword ptr [rsp+0x590]
       vaddps   ymm4, ymm4, ymmword ptr [rsp+0x5B0]
       vmulps   ymm4, ymm4, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x5D0], ymm4
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x5D0]
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x5D0]
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x1DF0]
       vmovups  ymmword ptr [rsp+0x610], ymm4
       mov      rdx, rdi
       cmp      r14d, 36
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x130]
       cmp      qword ptr [r15], r13
       je       G_M000_IG180
 
G_M000_IG179:                ;; offset=0x50F0
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG180:                ;; offset=0x51D8
       vmovups  ymm5, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x630], ymm5
       cmp      r14d, 37
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x138]
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG182
 
G_M000_IG181:                ;; offset=0x5201
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG182:                ;; offset=0x52E9
       vmovups  ymm5, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm5
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1DD0]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x5F0]
       vmovups  ymm2, ymmword ptr [rsp+0x1DB0]
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1DF0]
       vaddps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1D90]
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm4
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm4
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm4
       vmulps   ymm4, ymm2, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm4
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 41
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x158]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
 
G_M000_IG183:                ;; offset=0x54BE
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG185
 
G_M000_IG184:                ;; offset=0x5511
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG185:                ;; offset=0x55F9
       vmovups  ymm4, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm4
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1DD0]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x5F0]
       vmovups  ymm2, ymmword ptr [rsp+0x1DB0]
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1DF0]
       vaddps   ymm0, ymm1, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1D90]
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmulps   ymm0, ymm2, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 42
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x160]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
 
G_M000_IG186:                ;; offset=0x57CE
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG188
 
G_M000_IG187:                ;; offset=0x5821
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG188:                ;; offset=0x5909
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x5B0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5F0]
       lea      r8, [rsp+0x570]
       lea      r9, [rsp+0x590]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x15F0], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 43
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x168]
       cmp      qword ptr [r15], r13
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG190
 
G_M000_IG189:                ;; offset=0x5A6F
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG190:                ;; offset=0x5B57
       vmovups  ymm0, ymmword ptr [rsp+0x15F0]
       vmulps   ymm0, ymm0, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0x15D0], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1D70]
       vmulps   ymm2, ymm10, ymm1
       vmovups  ymmword ptr [rsp+0x650], ymm2
       vmulps   ymm2, ymm14, ymm1
       vmovups  ymmword ptr [rsp+0x630], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x1710]
       vmulps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rsp+0x610], ymm1
       mov      rdx, rdi
       cmp      r14d, 45
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x178]
       mov      r12, r15
       cmp      qword ptr [r12], r13
       je       G_M000_IG192
 
G_M000_IG191:                ;; offset=0x5BCE
       mov      rdx, r12
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG192:                ;; offset=0x5CB6
       vmovups  ymm1, ymmword ptr [rsp+0x650]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x610]
       vmulps   ymm1, ymm1, ymmword ptr [r12+0x08]
       vmovups  ymmword ptr [rsp+0x5F0], ymm1
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x5F0]
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x5F0]
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1D50]
       vmovups  ymmword ptr [rsp+0x5B0], ymm1
       cmp      qword ptr [r15], r13
       je       G_M000_IG194
 
G_M000_IG193:                ;; offset=0x5D44
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG194:                ;; offset=0x5E2C
       vmovups  ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x590], ymm3
       cmp      r14d, 47
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x188]
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG196
 
G_M000_IG195:                ;; offset=0x5E55
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG196:                ;; offset=0x5F3D
       vmovups  ymm3, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm3
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1D30]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x5D0]
       vmovups  ymm2, ymmword ptr [rsp+0x1D10]
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1D50]
       vaddps   ymm0, ymm1, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1CF0]
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmulps   ymm0, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 51
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x1A8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
 
G_M000_IG197:                ;; offset=0x6112
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG199
 
G_M000_IG198:                ;; offset=0x6165
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG199:                ;; offset=0x624D
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x610]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5D0]
       lea      r8, [rsp+0x650]
       lea      r9, [rsp+0x630]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x15B0], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 52
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x1B0]
       cmp      qword ptr [r15], r13
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG201
 
G_M000_IG200:                ;; offset=0x63B3
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG201:                ;; offset=0x649B
       vmovups  ymm0, ymmword ptr [rsp+0x15B0]
       vmulps   ymm0, ymm0, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x15D0]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1610]
       vcmpeqps ymm2, ymm8, ymm8
       vcmpeqps ymm3, ymm8, ymm0
       vandps   ymm4, ymm8, ymm0
       vcmpgtps ymm5, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm8, ymm0, ymm2
       vcmpeqps ymm2, ymm12, ymm12
       vcmpeqps ymm3, ymm12, ymm0
       vorps    ymm4, ymm12, ymm0
       vcmpltps ymm5, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm12, ymm0, ymm2
       vmovaps  ymm2, ymm0
       vcvtps2pd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x4B0], ymm2
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x490], ymm0
       vmovups  ymm3, ymmword ptr [rsp+0x1CD0]
       vmulps   ymm4, ymm10, ymm3
       vmovups  ymmword ptr [rsp+0x570], ymm4
       vmulps   ymm4, ymm14, ymm3
       vmovups  ymmword ptr [rsp+0x590], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x1710]
       vmulps   ymm3, ymm4, ymm3
       vmovups  ymmword ptr [rsp+0x5B0], ymm3
       mov      rdx, rdi
       cmp      r14d, 54
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x1C0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG203
 
G_M000_IG202:                ;; offset=0x658C
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG203:                ;; offset=0x6674
       vmovups  ymm3, ymmword ptr [rsp+0x570]
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x590]
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x5B0]
       vmulps   ymm3, ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x5D0], ymm3
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5D0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5D0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x1CB0]
       vmovups  ymmword ptr [rsp+0x610], ymm3
       mov      rdx, rdi
       cmp      r14d, 56
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x1D0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG205
 
G_M000_IG204:                ;; offset=0x6715
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG205:                ;; offset=0x67FD
       vmovups  ymm5, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x630], ymm5
       cmp      r14d, 57
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x1D8]
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG207
 
G_M000_IG206:                ;; offset=0x6826
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG207:                ;; offset=0x690E
       vmovups  ymm5, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm5
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x5F0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1C90]
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x5F0]
       vmovups  ymm2, ymmword ptr [rsp+0x1C70]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm1
       vsubps   ymm1, ymm2, ymmword ptr [rsp+0x5F0]
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1CB0]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1C50]
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm4
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm4
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x1C30]
       vmulps   ymm5, ymm4, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm5
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 62
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x200]
 
G_M000_IG208:                ;; offset=0x6AE2
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG210
 
G_M000_IG209:                ;; offset=0x6B59
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG210:                ;; offset=0x6C41
       vmovups  ymm5, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm5
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x5F0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1C90]
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x5F0]
       vmovups  ymm2, ymmword ptr [rsp+0x1C70]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm1
       vsubps   ymm1, ymm2, ymmword ptr [rsp+0x5F0]
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1CB0]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1C50]
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm4
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm4
       vmulps   ymm4, ymm1, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x1C30]
       vmulps   ymm5, ymm4, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm5
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 63
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x208]
 
G_M000_IG211:                ;; offset=0x6E15
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG213
 
G_M000_IG212:                ;; offset=0x6E8C
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG213:                ;; offset=0x6F74
       vmovups  ymm5, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm5
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x5F0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1C90]
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x5F0]
       vmovups  ymm2, ymmword ptr [rsp+0x1C70]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm1
       vsubps   ymm1, ymm2, ymmword ptr [rsp+0x5F0]
       vsubps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1CB0]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1C50]
       vmulps   ymm3, ymm1, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm3
       vmulps   ymm3, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm3
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm1
       vmovups  ymm4, ymmword ptr [rsp+0x1C30]
       vmulps   ymm1, ymm4, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 64
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x210]
 
G_M000_IG214:                ;; offset=0x7148
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG216
 
G_M000_IG215:                ;; offset=0x71BF
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG216:                ;; offset=0x72A7
       vmovups  ymm1, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm1
       lea      rdx, [rsp+0x5B0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5F0]
       lea      r8, [rsp+0x570]
       lea      r9, [rsp+0x590]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1C90]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x1C70]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vmulps   ymm0, ymm0, ymm12
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vaddps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0x1590], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vmovups  ymm1, ymmword ptr [rsp+0x1C10]
       vmulps   ymm2, ymm10, ymm1
       vmovups  ymmword ptr [rsp+0x650], ymm2
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vmulps   ymm2, ymm14, ymm1
       vmovups  ymmword ptr [rsp+0x630], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x1710]
       vmulps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rsp+0x610], ymm1
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 66
       jbe      G_M000_IG363
       mov      r14, gword ptr [rdx+0x220]
       mov      r15, r14
       cmp      qword ptr [r15], r13
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG218
 
G_M000_IG217:                ;; offset=0x7469
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG218:                ;; offset=0x7551
       vmovups  ymm1, ymmword ptr [rsp+0x650]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x610]
       vmulps   ymm1, ymm1, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x5F0], ymm1
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x5F0]
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x5F0]
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1BF0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm1
       cmp      qword ptr [r14], r13
       je       G_M000_IG220
 
G_M000_IG219:                ;; offset=0x75DE
       mov      rdx, r14
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG220:                ;; offset=0x76C6
       vmovups  ymm3, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x590], ymm3
       cmp      dword ptr [rdi+0x08], 68
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x230]
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG222
 
G_M000_IG221:                ;; offset=0x76EF
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG222:                ;; offset=0x77D7
       vmovups  ymm3, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm3
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1BD0]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x5D0]
       vmovups  ymm2, ymmword ptr [rsp+0x1BB0]
       vmulps   ymm1, ymm1, ymm2
       vsubps   ymm1, ymm1, ymm0
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x1BF0]
       vaddps   ymm0, ymm1, ymm0
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1B90]
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmulps   ymm0, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 72
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x250]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
 
G_M000_IG223:                ;; offset=0x79AC
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG225
 
G_M000_IG224:                ;; offset=0x79FF
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG225:                ;; offset=0x7AE7
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x610]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5D0]
       lea      r8, [rsp+0x650]
       lea      r9, [rsp+0x630]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymm1, ymmword ptr [rsp+0x1610]
       vmulps   ymm0, ymm0, ymm1
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1590]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymm1
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vcmpeqps ymm2, ymm8, ymm8
       vcmpeqps ymm3, ymm8, ymm0
       vandps   ymm4, ymm8, ymm0
       vcmpgtps ymm5, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm8, ymm0, ymm2
       vcmpeqps ymm2, ymm12, ymm12
       vcmpeqps ymm3, ymm12, ymm0
       vorps    ymm4, ymm12, ymm0
       vcmpltps ymm5, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm12, ymm0, ymm2
       vmovaps  ymm2, ymm0
       vcvtps2pd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x470], ymm2
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x450], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vmovups  ymm3, ymmword ptr [rsp+0x1B70]
       vmulps   ymm4, ymm10, ymm3
       vmovups  ymmword ptr [rsp+0x570], ymm4
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vmulps   ymm4, ymm14, ymm3
       vmovups  ymmword ptr [rsp+0x590], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x1710]
 
G_M000_IG226:                ;; offset=0x7C9C
       vmulps   ymm3, ymm4, ymm3
       vmovups  ymmword ptr [rsp+0x5B0], ymm3
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 74
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x260]
       cmp      qword ptr [r15], r13
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG228
 
G_M000_IG227:                ;; offset=0x7D10
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG228:                ;; offset=0x7DF8
       vmovups  ymm3, ymmword ptr [rsp+0x570]
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x590]
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x5B0]
       vmulps   ymm3, ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x5D0], ymm3
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5D0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5D0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x1B50]
       vmovups  ymmword ptr [rsp+0x610], ymm3
       mov      rdx, rdi
       cmp      r14d, 76
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x270]
       cmp      qword ptr [r15], r13
       je       G_M000_IG230
 
G_M000_IG229:                ;; offset=0x7E99
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG230:                ;; offset=0x7F81
       vmovups  ymm5, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x630], ymm5
       cmp      r14d, 77
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x278]
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG232
 
G_M000_IG231:                ;; offset=0x7FAA
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG232:                ;; offset=0x8092
       vmovups  ymm5, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm5
       vmovups  ymm5, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm5
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vaddps   ymm0, ymm15, ymmword ptr [rsp+0x5F0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vmulps   ymm0, ymm0, ymm13
       vsubps   ymm0, ymm0, ymm15
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1B50]
       vaddps   ymm0, ymm0, ymm15
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vmulps   ymm0, ymm11, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm0
       vmulps   ymm0, ymm11, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmulps   ymm0, ymm11, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmulps   ymm0, ymm13, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 81
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x298]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
 
G_M000_IG233:                ;; offset=0x8270
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG235
 
G_M000_IG234:                ;; offset=0x82A2
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG235:                ;; offset=0x838A
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm0
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmmword ptr [rsp+0x1660], ymm12
       vextractf128 xmmword ptr [rsp+0x1700], ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1B40], ymm15
       vextractf128 xmmword ptr [rsp+0x1B00], ymm11
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1B20], ymm13
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vinsertf128 ymm15, ymm15, xmmword ptr [rsp+0x1B40]
       vaddps   ymm0, ymm15, ymmword ptr [rsp+0x5F0]
       vinsertf128 ymm13, ymm13, xmmword ptr [rsp+0x1B20]
       vmulps   ymm0, ymm0, ymm13
       vsubps   ymm0, ymm0, ymm15
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1B50]
       vaddps   ymm0, ymm0, ymm15
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1B00]
       vmulps   ymm0, ymm11, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm0
       vmulps   ymm0, ymm11, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmulps   ymm0, ymm11, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmulps   ymm0, ymm13, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 82
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x2A0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1660]
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1700]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
 
G_M000_IG236:                ;; offset=0x8568
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG238
 
G_M000_IG237:                ;; offset=0x859A
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm11, ymm12
       vextractf128 xmm13, ymm8
       vextractf128 xmm15, ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm11
       vinsertf128 ymm8, ymm8, xmm13
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG238:                ;; offset=0x8622
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x5B0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5F0]
       lea      r8, [rsp+0x570]
       lea      r9, [rsp+0x590]
       vextractf128 xmm11, ymm12
       vextractf128 xmm13, ymm8
       vextractf128 xmm15, ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vinsertf128 ymm12, ymm12, xmm11
       vmulps   ymm0, ymm0, ymm12
       vinsertf128 ymm8, ymm8, xmm13
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1610]
       vcmpeqps ymm2, ymm8, ymm8
       vcmpeqps ymm3, ymm8, ymm0
       vandps   ymm4, ymm8, ymm0
       vcmpgtps ymm5, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm8, ymm0, ymm2
       vcmpeqps ymm2, ymm12, ymm12
       vcmpeqps ymm3, ymm12, ymm0
       vorps    ymm4, ymm12, ymm0
       vcmpltps ymm5, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm5
       vblendvps ymm0, ymm0, ymm4, ymm3
       vblendvps ymm0, ymm12, ymm0, ymm2
       vmovaps  ymm2, ymm0
       vcvtps2pd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x430], ymm2
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x410], ymm0
       vinsertf128 ymm10, ymm10, xmm15
       vmovups  ymm3, ymmword ptr [rsp+0x1AD0]
       vmulps   ymm4, ymm10, ymm3
       vmovups  ymmword ptr [rsp+0x650], ymm4
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vmulps   ymm4, ymm14, ymm3
       vmovups  ymmword ptr [rsp+0x630], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x1710]
       vmulps   ymm3, ymm4, ymm3
       vmovups  ymmword ptr [rsp+0x610], ymm3
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 84
 
G_M000_IG239:                ;; offset=0x87A9
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x2B0]
       cmp      qword ptr [r15], r13
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       je       G_M000_IG241
 
G_M000_IG240:                ;; offset=0x87E0
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm11, ymm12
       vextractf128 xmm13, ymm8
       vextractf128 xmm15, ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm11
       vinsertf128 ymm8, ymm8, xmm13
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG241:                ;; offset=0x8868
       vmovups  ymm3, ymmword ptr [rsp+0x650]
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x630]
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x610]
       vmulps   ymm3, ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x5F0], ymm3
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5F0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5F0]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm3
       vmovups  ymm11, ymmword ptr [rsp+0x1AB0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm11
       mov      rdx, rdi
       cmp      r14d, 86
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x2C0]
       cmp      qword ptr [r15], r13
       je       G_M000_IG243
 
G_M000_IG242:                ;; offset=0x8909
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG243:                ;; offset=0x899B
       vmovups  ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x590], ymm3
       cmp      r14d, 87
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x2C8]
       cmp      qword ptr [rdi], rbp
       je       G_M000_IG245
 
G_M000_IG244:                ;; offset=0x89C4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmmword ptr [rsp+0x1760], ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x1760]
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG245:                ;; offset=0x8A56
       vmovups  ymm3, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm3
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x5D0]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       vmulps   ymm0, ymm0, ymm7
       vsubps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1AB0]
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vmulps   ymm0, ymm6, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm0
       vmulps   ymm0, ymm6, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmulps   ymm0, ymm6, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmulps   ymm0, ymm7, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 91
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x2E8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       je       G_M000_IG247
 
G_M000_IG246:                ;; offset=0x8C05
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
 
G_M000_IG247:                ;; offset=0x8C8D
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm0
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1AA0], ymm9
       vextractf128 xmmword ptr [rsp+0x1A60], ymm6
       vextractf128 xmmword ptr [rsp+0x1A80], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1AA0]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x5D0]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1A80]
       vmulps   ymm0, ymm0, ymm7
       vsubps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1AB0]
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1A60]
       vmulps   ymm0, ymm6, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm0
       vmulps   ymm0, ymm6, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmulps   ymm0, ymm6, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmulps   ymm0, ymm7, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 92
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x2F0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       je       SHORT G_M000_IG249
 
G_M000_IG248:                ;; offset=0x8E38
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm6, ymm14
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm6
 
G_M000_IG249:                ;; offset=0x8E74
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x610]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5D0]
       lea      r8, [rsp+0x650]
       lea      r9, [rsp+0x630]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm6, ymm14
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vinsertf128 ymm12, ymm12, xmm13
       vmulps   ymm0, ymm0, ymm12
       vinsertf128 ymm8, ymm8, xmm15
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymm12
       vmovups  ymm7, ymmword ptr [rsp+0x1610]
       vmulps   ymm0, ymm0, ymm7
       vcmpeqps ymm1, ymm8, ymm8
       vcmpeqps ymm2, ymm8, ymm0
       vandps   ymm3, ymm8, ymm0
       vcmpgtps ymm4, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm4
       vblendvps ymm0, ymm0, ymm3, ymm2
       vblendvps ymm0, ymm8, ymm0, ymm1
       vcmpeqps ymm1, ymm12, ymm12
       vcmpeqps ymm2, ymm12, ymm0
       vorps    ymm3, ymm12, ymm0
       vcmpltps ymm4, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm4
       vblendvps ymm0, ymm0, ymm3, ymm2
       vblendvps ymm0, ymm12, ymm0, ymm1
       vmovaps  ymm1, ymm0
       vcvtps2pd ymm9, ymm1
       vmovups  ymmword ptr [rsp+0x3F0], ymm9
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x3D0], ymm0
       vinsertf128 ymm10, ymm10, xmm11
       vmovups  ymm1, ymmword ptr [rsp+0x1A30]
       vmulps   ymm2, ymm10, ymm1
       vmovups  ymmword ptr [rsp+0x570], ymm2
       vinsertf128 ymm14, ymm14, xmm6
       vmulps   ymm2, ymm14, ymm1
       vmovups  ymmword ptr [rsp+0x590], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x1710]
       vmulps   ymm1, ymm2, ymm1
       vmovups  ymmword ptr [rsp+0x5B0], ymm1
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 94
       jbe      G_M000_IG363
       mov      r14, gword ptr [rdx+0x300]
 
G_M000_IG250:                ;; offset=0x8FDD
       cmp      qword ptr [r14], r13
       je       SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x8FE2
       mov      rdx, r14
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG252:                ;; offset=0x9034
       vmovups  ymm1, ymmword ptr [rsp+0x570]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x590]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x5B0]
       vmulps   ymm1, ymm1, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x5D0], ymm1
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x5D0]
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x5D0]
       vsubps   ymm1, ymm1, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm1
       cmp      dword ptr [rdi+0x08], 95
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x308]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG254
 
G_M000_IG253:                ;; offset=0x90BC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG254:                ;; offset=0x9104
       vmovups  ymm1, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm1
       lea      rdx, [rsp+0x5B0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5F0]
       lea      r8, [rsp+0x570]
       lea      r9, [rsp+0x590]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 96
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x310]
       mov      r12, r15
       cmp      qword ptr [r12], r13
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm7, ymm7, xmm9
       je       SHORT G_M000_IG256
 
G_M000_IG255:                ;; offset=0x91A6
       mov      rdx, r12
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG256:                ;; offset=0x91EE
       vmovups  ymm0, ymmword ptr [r12+0x08]
       vmovups  ymmword ptr [rsp+0x30], ymm0
       vmulps   ymm6, ymm0, ymmword ptr [rsp+0x5F0]
       mov      rdx, r15
       cmp      qword ptr [rdx], r13
       je       SHORT G_M000_IG258
 
G_M000_IG257:                ;; offset=0x920C
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm9, ymm14
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       vextractf128 xmmword ptr [rsp+0x560], ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm9
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x560]
 
G_M000_IG258:                ;; offset=0x9271
       vmovups  ymm0, ymmword ptr [rsp+0x30]
       vmulps   ymm6, ymm0, ymm6
       mov      rdx, rdi
       cmp      r14d, 97
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x318]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG260
 
G_M000_IG259:                ;; offset=0x9294
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm9, ymm14
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       vextractf128 xmmword ptr [rsp+0x1580], ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm9
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1580]
 
G_M000_IG260:                ;; offset=0x92FC
       vmulps   ymm6, ymm6, ymmword ptr [r15+0x08]
       mov      rdx, rdi
       cmp      r14d, 98
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x320]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG262
 
G_M000_IG261:                ;; offset=0x931B
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm9, ymm14
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       vextractf128 xmmword ptr [rsp+0x1560], ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm14, ymm14, xmm9
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x1560]
 
G_M000_IG262:                ;; offset=0x9383
       vaddps   ymm6, ymm6, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x1530], ymm6
       vmovups  ymm9, ymmword ptr [rsp+0x1A10]
       vmulps   ymm0, ymm10, ymm9
       vmovups  ymmword ptr [rsp+0x650], ymm0
       vmulps   ymm0, ymm14, ymm9
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmovups  ymm11, ymmword ptr [rsp+0x1710]
       vmulps   ymm0, ymm11, ymm9
       vmovups  ymmword ptr [rsp+0x610], ymm0
       mov      rdx, rdi
       cmp      r14d, 100
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x330]
       mov      r12, r15
       cmp      qword ptr [r12], r13
       je       SHORT G_M000_IG264
 
G_M000_IG263:                ;; offset=0x93EB
       mov      rdx, r12
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmmword ptr [rsp+0x1740], ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmmword ptr [rsp+0x1740]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG264:                ;; offset=0x945D
       vmovups  ymm0, ymmword ptr [rsp+0x650]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmulps   ymm0, ymm0, ymmword ptr [r12+0x08]
       vmovups  ymmword ptr [rsp+0x5F0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x19F0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm1
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG266
 
G_M000_IG265:                ;; offset=0x94E7
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG266:                ;; offset=0x954F
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       cmp      r14d, 102
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x340]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG268
 
G_M000_IG267:                ;; offset=0x9574
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG268:                ;; offset=0x95DC
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm0
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x19D0]
       vaddps   ymm0, ymm1, ymmword ptr [rsp+0x5D0]
       vmovups  ymm2, ymmword ptr [rsp+0x19B0]
       vmulps   ymm0, ymm0, ymm2
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19F0]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1990]
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmulps   ymm0, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 106
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x360]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
       je       SHORT G_M000_IG270
 
G_M000_IG269:                ;; offset=0x9780
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG270:                ;; offset=0x97E8
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x610]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5D0]
       lea      r8, [rsp+0x650]
       lea      r9, [rsp+0x630]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x1510], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 107
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x368]
       cmp      qword ptr [r15], r13
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
       je       SHORT G_M000_IG272
 
G_M000_IG271:                ;; offset=0x98CA
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG272:                ;; offset=0x9932
       vmovups  ymm0, ymmword ptr [rsp+0x1510]
       vmulps   ymm0, ymm0, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x1530]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymm7
       vcmpeqps ymm1, ymm8, ymm8
       vcmpeqps ymm2, ymm8, ymm0
       vandps   ymm3, ymm8, ymm0
       vcmpgtps ymm4, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm4
       vblendvps ymm0, ymm0, ymm3, ymm2
       vblendvps ymm0, ymm8, ymm0, ymm1
       vcmpeqps ymm1, ymm12, ymm12
       vcmpeqps ymm2, ymm12, ymm0
       vorps    ymm3, ymm12, ymm0
       vcmpltps ymm4, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm4
       vblendvps ymm0, ymm0, ymm3, ymm2
       vblendvps ymm0, ymm12, ymm0, ymm1
       vmovaps  ymm1, ymm0
       vcvtps2pd ymm1, ymm1
       vmovups  ymmword ptr [rsp+0x3B0], ymm1
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x390], ymm0
       vmovups  ymm6, ymmword ptr [rsp+0x1970]
       vmulps   ymm2, ymm10, ymm6
       vmovups  ymmword ptr [rsp+0x570], ymm2
       vmulps   ymm2, ymm14, ymm6
       vmovups  ymmword ptr [rsp+0x590], ymm2
       vmulps   ymm2, ymm11, ymm6
       vmovups  ymmword ptr [rsp+0x5B0], ymm2
       mov      rdx, rdi
       cmp      r14d, 109
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x378]
       mov      r12, r15
       cmp      qword ptr [r12], r13
       je       SHORT G_M000_IG274
 
G_M000_IG273:                ;; offset=0x9A15
       mov      rdx, r12
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG274:                ;; offset=0x9A7D
       vmovups  ymm2, ymmword ptr [rsp+0x570]
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x590]
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x5B0]
       vmulps   ymm2, ymm2, ymmword ptr [r12+0x08]
       vmovups  ymmword ptr [rsp+0x5D0], ymm2
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x5D0]
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x5D0]
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x1950]
       vmovups  ymmword ptr [rsp+0x610], ymm2
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG276
 
G_M000_IG275:                ;; offset=0x9B07
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG276:                ;; offset=0x9B6F
       vmovups  ymm3, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x630], ymm3
       cmp      r14d, 111
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x388]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG278
 
G_M000_IG277:                ;; offset=0x9B94
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG278:                ;; offset=0x9BFC
       vmovups  ymm3, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x130], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x110], ymm3
       vmovups  ymm3, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0xF0], ymm3
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5F0]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1930]
       vaddps   ymm0, ymm1, ymmword ptr [rsp+0x5F0]
       vmovups  ymm2, ymmword ptr [rsp+0x1910]
       vmulps   ymm0, ymm0, ymm2
       vsubps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1950]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x18F0]
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x570]
       vmovups  ymmword ptr [rsp+0x570], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmulps   ymm0, ymm1, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vmulps   ymm0, ymm2, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 115
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x3A8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
       je       SHORT G_M000_IG280
 
G_M000_IG279:                ;; offset=0x9DA0
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm10, ymm10, xmm9
       vinsertf128 ymm14, ymm14, xmm6
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
 
G_M000_IG280:                ;; offset=0x9E08
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm0
       lea      rdx, [rsp+0x5B0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5F0]
       lea      r8, [rsp+0x570]
       lea      r9, [rsp+0x590]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm9, ymm10
       vextractf128 xmm6, ymm14
       vextractf128 xmmword ptr [rsp+0x1720], ymm11
       vextractf128 xmmword ptr [rsp+0x1620], ymm7
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5F0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x630]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x610]
       vinsertf128 ymm12, ymm12, xmm13
       vmulps   ymm0, ymm0, ymm12
       vinsertf128 ymm8, ymm8, xmm15
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymm12
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x1620]
       vmulps   ymm0, ymm0, ymm7
       vcmpeqps ymm1, ymm8, ymm8
       vcmpeqps ymm2, ymm8, ymm0
       vandps   ymm3, ymm8, ymm0
       vcmpgtps ymm4, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm4
       vblendvps ymm0, ymm0, ymm3, ymm2
       vblendvps ymm0, ymm8, ymm0, ymm1
       vcmpeqps ymm1, ymm12, ymm12
       vcmpeqps ymm2, ymm12, ymm0
       vorps    ymm3, ymm12, ymm0
       vcmpltps ymm4, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm4
       vblendvps ymm0, ymm0, ymm3, ymm2
       vblendvps ymm0, ymm12, ymm0, ymm1
       vmovaps  ymm1, ymm0
       vcvtps2pd ymm1, ymm1
       vmovups  ymmword ptr [rsp+0x370], ymm1
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x350], ymm0
       vinsertf128 ymm10, ymm10, xmm9
       vmovups  ymm2, ymmword ptr [rsp+0x18D0]
       vmulps   ymm3, ymm10, ymm2
       vmovups  ymmword ptr [rsp+0x650], ymm3
       vinsertf128 ymm14, ymm14, xmm6
       vmulps   ymm3, ymm14, ymm2
       vmovups  ymmword ptr [rsp+0x630], ymm3
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x1720]
       vmulps   ymm2, ymm11, ymm2
       vmovups  ymmword ptr [rsp+0x610], ymm2
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 117
 
G_M000_IG281:                ;; offset=0x9F82
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x3B8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG283
 
G_M000_IG282:                ;; offset=0x9F94
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm6, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm7, ymm7, xmm6
 
G_M000_IG283:                ;; offset=0x9FC4
       vmovups  ymm2, ymmword ptr [rsp+0x650]
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x630]
       vaddps   ymm2, ymm2, ymmword ptr [rsp+0x610]
       vmulps   ymm2, ymm2, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x5F0], ymm2
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x5F0]
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x5F0]
       vsubps   ymm2, ymm2, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm2
       vmovups  ymm9, ymmword ptr [rsp+0x18B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm9
       mov      rdx, rdi
       cmp      r14d, 119
       jbe      G_M000_IG363
       mov      r15, gword ptr [rdx+0x3C8]
       cmp      qword ptr [r15], r13
       je       SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0xA061
       mov      rdx, r15
       mov      rcx, r13
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm6, ymm7
       vextractf128 xmm10, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm9, ymm9, xmm10
 
G_M000_IG285:                ;; offset=0xA09D
       vmovups  ymm2, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x590], ymm2
       cmp      r14d, 120
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x3D0]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG287
 
G_M000_IG286:                ;; offset=0xA0C2
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm6, ymm7
       vextractf128 xmm10, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm9, ymm9, xmm10
 
G_M000_IG287:                ;; offset=0xA0FE
       vmovups  ymm2, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm2
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm6, ymm7
       vextractf128 xmm10, ymm9
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x5D0], ymm0
       vmovups  ymm11, ymmword ptr [rsp+0x1890]
       vmulps   ymm0, ymm11, ymmword ptr [rsp+0x5D0]
       vmovups  ymm14, ymmword ptr [rsp+0x1870]
       vaddps   ymm0, ymm0, ymm14
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm0
       vsubps   ymm0, ymm14, ymmword ptr [rsp+0x5D0]
       vsubps   ymm0, ymm0, ymm14
       vinsertf128 ymm9, ymm9, xmm10
       vmulps   ymm0, ymm0, ymm9
       vaddps   ymm0, ymm0, ymm14
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1850]
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x1830]
       vmulps   ymm1, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm1
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 125
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x03F8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm7, ymm7, xmm6
       je       SHORT G_M000_IG289
 
G_M000_IG288:                ;; offset=0xA298
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm6, ymm7
       vextractf128 xmm10, ymm14
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm14, ymm14, xmm10
 
G_M000_IG289:                ;; offset=0xA2D4
       vmovups  ymm1, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x130], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x110], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0xF0], ymm1
       lea      rdx, [rsp+0x150]
       lea      r8, [rsp+0x130]
       lea      r9, [rsp+0x110]
       lea      rcx, [rsp+0xF0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x5D0]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm6, ymm7
       vextractf128 xmm10, ymm14
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x5D0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1890]
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x5D0]
       vinsertf128 ymm14, ymm14, xmm10
       vaddps   ymm1, ymm1, ymm14
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x590]
       vaddps   ymm1, ymm1, ymmword ptr [rsp+0x5B0]
       vmovups  ymmword ptr [rsp+0x5B0], ymm1
       vsubps   ymm1, ymm14, ymmword ptr [rsp+0x5D0]
       vsubps   ymm1, ymm1, ymm14
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x18B0]
       vaddps   ymm1, ymm1, ymm14
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm1
       vmovups  ymm1, ymmword ptr [rsp+0x1850]
       vmulps   ymm2, ymm1, ymmword ptr [rsp+0x650]
       vmovups  ymmword ptr [rsp+0x650], ymm2
       vmulps   ymm2, ymm1, ymmword ptr [rsp+0x630]
       vmovups  ymmword ptr [rsp+0x630], ymm2
       vmulps   ymm1, ymm1, ymmword ptr [rsp+0x610]
       vmovups  ymmword ptr [rsp+0x610], ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x1830]
       vmulps   ymm1, ymm2, ymmword ptr [rsp+0x590]
       vmovups  ymmword ptr [rsp+0x590], ymm1
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 126
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0400]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm7, ymm7, xmm6
       je       SHORT G_M000_IG291
 
G_M000_IG290:                ;; offset=0xA469
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm6, ymm7
       vextractf128 xmm10, ymm14
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm14, ymm14, xmm10
 
G_M000_IG291:                ;; offset=0xA4A5
       vmovups  ymm1, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x150], ymm1
       lea      rdx, [rsp+0x610]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x5D0]
       lea      r8, [rsp+0x650]
       lea      r9, [rsp+0x630]
       vextractf128 xmm13, ymm12
       vextractf128 xmm15, ymm8
       vextractf128 xmm6, ymm7
       vextractf128 xmm10, ymm14
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x5D0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1890]
       vinsertf128 ymm14, ymm14, xmm10
       vaddps   ymm0, ymm0, ymm14
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x590]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x5B0]
       vinsertf128 ymm12, ymm12, xmm13
       vmulps   ymm0, ymm0, ymm12
       vinsertf128 ymm8, ymm8, xmm15
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymm12
       vinsertf128 ymm7, ymm7, xmm6
       vmulps   ymm0, ymm7, ymm0
       vcmpeqps ymm1, ymm8, ymm8
       vcmpeqps ymm2, ymm8, ymm0
       vandps   ymm3, ymm8, ymm0
       vcmpgtps ymm4, ymm8, ymm0
       vblendvps ymm0, ymm0, ymm8, ymm4
       vblendvps ymm0, ymm0, ymm3, ymm2
       vblendvps ymm0, ymm8, ymm0, ymm1
       vcmpeqps ymm1, ymm12, ymm12
       vcmpeqps ymm2, ymm12, ymm0
       vorps    ymm3, ymm12, ymm0
       vcmpltps ymm4, ymm12, ymm0
       vblendvps ymm0, ymm0, ymm12, ymm4
       vblendvps ymm0, ymm0, ymm3, ymm2
       vblendvps ymm0, ymm12, ymm0, ymm1
       vmovaps  ymm1, ymm0
       vcvtps2pd ymm7, ymm1
       vmovups  ymmword ptr [rsp+0x330], ymm7
       vextractf128 xmm0, ymm0
       vcvtps2pd ymm8, ymm0
       vmovups  ymmword ptr [rsp+0x310], ymm8
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 127
       jbe      G_M000_IG363
       mov      r14, gword ptr [rdx+0x0408]
       mov      r15, 0x7FFC658C0890
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG293
 
G_M000_IG292:                ;; offset=0xA5F3
       mov      rdx, r14
       mov      rcx, r15
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG293:                ;; offset=0xA5FF
       vmovups  ymm10, ymmword ptr [r14+0x08]
       vmovups  ymm11, ymmword ptr [r14+0x28]
       vsubpd   ymm12, ymm10, ymmword ptr [rsp+0x4F0]
       vmovups  ymmword ptr [rsp+0x2F0], ymm12
       vsubpd   ymm13, ymm11, ymmword ptr [rsp+0x4D0]
       vmovups  ymmword ptr [rsp+0x2D0], ymm13
       mov      rdx, rdi
       cmp      ebp, 128
       jbe      G_M000_IG363
       mov      r14, gword ptr [rdx+0x0410]
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG295
 
G_M000_IG294:                ;; offset=0xA64A
       mov      rdx, r14
       mov      rcx, r15
       vextractf128 xmm14, ymm10
       vextractf128 xmm15, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm14
       vinsertf128 ymm11, ymm11, xmm15
 
G_M000_IG295:                ;; offset=0xA66E
       vmovups  ymm6, ymmword ptr [r14+0x08]
       vmovups  ymm9, ymmword ptr [r14+0x28]
       cmp      ebp, 129
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdi+0x0418]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG297
 
G_M000_IG296:                ;; offset=0xA692
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm14, ymm10
       vextractf128 xmm15, ymm11
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm14
       vinsertf128 ymm11, ymm11, xmm15
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG297:                ;; offset=0xA6E2
       vmovups  ymm1, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x270], ymm1
       vmovups  ymm3, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x250], ymm3
       vmovups  ymm4, ymmword ptr [rsp+0x470]
       vsubpd   ymm5, ymm4, ymm1
       vmovups  ymm14, ymmword ptr [rsp+0x450]
       vsubpd   ymm15, ymm14, ymm3
       vmovups  ymmword ptr [rsp+0xB0], ymm6
       vmovups  ymmword ptr [rsp+0xD0], ymm9
       vmovups  ymmword ptr [rsp+0x70], ymm5
       vmovups  ymmword ptr [rsp+0x90], ymm15
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0x14D0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 130
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0420]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG299
 
G_M000_IG298:                ;; offset=0xA7A1
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG299:                ;; offset=0xA7DD
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x230], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x210], ymm1
       vmovups  ymm7, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0xB0], ymm7
       vmovups  ymm8, ymmword ptr [rsp+0x350]
       vmovups  ymmword ptr [rsp+0xD0], ymm8
       vmovups  ymmword ptr [rsp+0x70], ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm1
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0x1490]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm6
       vextractf128 xmm8, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 131
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0428]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm6, ymm6, xmm13
       vinsertf128 ymm9, ymm9, xmm8
       je       SHORT G_M000_IG301
 
G_M000_IG300:                ;; offset=0xA894
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm13, ymm6
       vextractf128 xmm8, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm6, ymm6, xmm13
       vinsertf128 ymm9, ymm9, xmm8
 
G_M000_IG301:                ;; offset=0xA8D0
       vmovups  ymm7, ymmword ptr [rdi+0x08]
       vmovups  ymm12, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0xB0], ymm7
       vmovups  ymmword ptr [rsp+0xD0], ymm12
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x1490]
       lea      rcx, [rsp+0x1450]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x350]
       vmovups  ymmword ptr [rsp+0xD0], ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0x70], ymm2
       vmovups  ymm3, ymmword ptr [rsp+0x250]
       vmovups  ymmword ptr [rsp+0x90], ymm3
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0x1410]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 132
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0430]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG303
 
G_M000_IG302:                ;; offset=0xA9E3
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG303:                ;; offset=0xAA4B
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x1410]
       lea      rcx, [rsp+0x13D0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmmword ptr [rsp+0x200], ymm7
       vextractf128 xmmword ptr [rsp+0x1E0], ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vmovups  ymmword ptr [rsp+0xB0], ymm6
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       vmovups  ymmword ptr [rsp+0xD0], ymm9
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x1390]
       lea      r8, [rsp+0x13D0]
       vextractf128 xmm8, ymm6
       vextractf128 xmm13, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm15
       vmovups  ymmword ptr [rsp+0xB0], ymm10
       vinsertf128 ymm11, ymm11, xmm14
       vmovups  ymmword ptr [rsp+0xD0], ymm11
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x1350]
       lea      r8, [rsp+0x1390]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1350]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1370]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1350]
       vmovdqu  ymmword ptr [rsp+0x70], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1370]
       vmovdqu  ymmword ptr [rsp+0x90], ymm0
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0x1310]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 133
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0438]
 
G_M000_IG304:                ;; offset=0xABCF
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x200]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1E0]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm9, ymm9, xmm13
       je       SHORT G_M000_IG306
 
G_M000_IG305:                ;; offset=0xAC02
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG306:                ;; offset=0xAC6A
       vmovups  ymm8, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x1B0], ymm8
       vmovups  ymm13, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x190], ymm13
       vmovups  ymmword ptr [rsp+0xB0], ymm7
       vmovups  ymmword ptr [rsp+0xD0], ymm12
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x12D0]
       lea      r8, [rsp+0x1350]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmmword ptr [rsp+0x200], ymm7
       vextractf128 xmmword ptr [rsp+0x1E0], ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       vextractf128 xmm8, ymm13
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x1B0]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vinsertf128 ymm13, ymm13, xmm8
       vmovups  ymmword ptr [rsp+0xD0], ymm13
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x1290]
       lea      r8, [rsp+0x12D0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1250]
       lea      rdx, [rsp+0x1310]
       lea      r8, [rsp+0x1290]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 134
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0440]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x200]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1E0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG308
 
G_M000_IG307:                ;; offset=0xADA6
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmmword ptr [rsp+0x1E0], ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1E0]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG308:                ;; offset=0xAE18
       vmovups  ymm2, ymmword ptr [rsp+0x530]
       vmovups  ymmword ptr [rsp+0xB0], ymm2
       vmovups  ymm0, ymmword ptr [rsp+0x510]
       vmovups  ymmword ptr [rsp+0xD0], ymm0
       vmovdqu  ymm1, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x70], ymm1
       vmovdqu  ymm1, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0x90], ymm1
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0x1210]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 135
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0448]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG310
 
G_M000_IG309:                ;; offset=0xAEE9
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG310:                ;; offset=0xAF51
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x1210]
       lea      rcx, [rsp+0x11D0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm7, ymm7, xmm8
       vmovups  ymmword ptr [rsp+0xB0], ymm7
       vinsertf128 ymm12, ymm12, xmm13
       vmovups  ymmword ptr [rsp+0xD0], ymm12
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x11D0]
       lea      rcx, [rsp+0x1190]
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x4B0]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x490]
       vmovups  ymmword ptr [rsp+0xD0], ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x230]
       vmovups  ymmword ptr [rsp+0x70], ymm2
       vmovups  ymm2, ymmword ptr [rsp+0x210]
       vmovups  ymmword ptr [rsp+0x90], ymm2
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0x1150]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 136
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0450]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG312
 
G_M000_IG311:                ;; offset=0xB0AC
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG312:                ;; offset=0xB114
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x1150]
       lea      rcx, [rsp+0x1110]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 137
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0458]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG314
 
G_M000_IG313:                ;; offset=0xB1C7
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG314:                ;; offset=0xB22F
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x1110]
       lea      rcx, [rsp+0x10D0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1090]
       lea      rdx, [rsp+0x1190]
       lea      r8, [rsp+0x10D0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 138
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0460]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG316
 
G_M000_IG315:                ;; offset=0xB300
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG316:                ;; offset=0xB368
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x14D0]
       lea      rcx, [rsp+0x1050]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 139
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0468]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG318
 
G_M000_IG317:                ;; offset=0xB41B
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG318:                ;; offset=0xB483
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x1050]
       lea      rcx, [rsp+0x1010]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 140
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0470]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG320
 
G_M000_IG319:                ;; offset=0xB536
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG320:                ;; offset=0xB59E
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       vmovups  ymm8, ymmword ptr [rsp+0x2F0]
       vmovups  ymmword ptr [rsp+0x70], ymm8
       vmovups  ymm13, ymmword ptr [rsp+0x2D0]
       vmovups  ymmword ptr [rsp+0x90], ymm13
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0xFD0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xF90]
       lea      rdx, [rsp+0x1010]
       lea      r8, [rsp+0xFD0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xF50]
       lea      rdx, [rsp+0x1090]
       lea      r8, [rsp+0xF90]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 141
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0478]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG322
 
G_M000_IG321:                ;; offset=0xB6AB
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG322:                ;; offset=0xB713
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x1450]
       lea      rcx, [rsp+0xF10]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xED0]
       lea      rdx, [rsp+0xF50]
       lea      r8, [rsp+0xF10]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x330]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x310]
       vmovups  ymmword ptr [rsp+0xD0], ymm1
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x1250]
       lea      rcx, [rsp+0xE90]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x330]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x310]
       vmovups  ymmword ptr [rsp+0xD0], ymm1
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0xE90]
       lea      rcx, [rsp+0xE50]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 142
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0480]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG324
 
G_M000_IG323:                ;; offset=0xB868
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG324:                ;; offset=0xB8D0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0xE50]
       lea      rcx, [rsp+0xE10]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xDD0]
       lea      rdx, [rsp+0xED0]
       lea      r8, [rsp+0xE10]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 143
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0488]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG326
 
G_M000_IG325:                ;; offset=0xB9A1
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG326:                ;; offset=0xBA09
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0xDD0]
       lea      rcx, [rsp+0xD90]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm1, ymmword ptr [rsp+0x3B0]
       vmovups  ymmword ptr [rsp+0xB0], ymm1
       vmovups  ymm0, ymmword ptr [rsp+0x390]
       vmovups  ymmword ptr [rsp+0xD0], ymm0
       vinsertf128 ymm7, ymm7, xmm8
       vmovups  ymmword ptr [rsp+0x70], ymm7
       vinsertf128 ymm12, ymm12, xmm13
       vmovups  ymmword ptr [rsp+0x90], ymm12
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0xD50]
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm15
       vmovups  ymmword ptr [rsp+0xB0], ymm10
       vinsertf128 ymm11, ymm11, xmm14
       vmovups  ymmword ptr [rsp+0xD0], ymm11
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0xD50]
       lea      rcx, [rsp+0xD10]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xCD0]
       lea      rdx, [rsp+0xD10]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Abs(Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 144
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0490]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG327:                ;; offset=0xBB68
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG329
 
G_M000_IG328:                ;; offset=0xBB80
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG329:                ;; offset=0xBBE8
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0xCD0]
       lea      rcx, [rsp+0xC90]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 145
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x0498]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       je       SHORT G_M000_IG331
 
G_M000_IG330:                ;; offset=0xBC9B
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG331:                ;; offset=0xBD03
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0xC90]
       lea      rcx, [rsp+0xC50]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vmovups  ymmword ptr [rsp+0xB0], ymm6
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       vmovups  ymmword ptr [rsp+0xD0], ymm9
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0xC10]
       lea      r8, [rsp+0xC50]
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm15
       vmovups  ymmword ptr [rsp+0xB0], ymm10
       vinsertf128 ymm11, ymm11, xmm14
       vmovups  ymmword ptr [rsp+0xD0], ymm11
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0xBD0]
       lea      r8, [rsp+0xC10]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBD0]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBF0]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBD0]
       vmovdqu  ymmword ptr [rsp+0x70], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBF0]
       vmovdqu  ymmword ptr [rsp+0x90], ymm0
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0xB90]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm7, ymm7, xmm8
       vmovups  ymmword ptr [rsp+0xB0], ymm7
       vinsertf128 ymm12, ymm12, xmm13
       vmovups  ymmword ptr [rsp+0xD0], ymm12
       lea      rdx, [rsp+0xB0]
 
G_M000_IG332:                ;; offset=0xBE95
       lea      rcx, [rsp+0xB50]
       lea      r8, [rsp+0xBD0]
       vextractf128 xmmword ptr [rsp+0x200], ymm7
       vextractf128 xmmword ptr [rsp+0x1E0], ymm12
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x1B0]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x190]
       vmovups  ymmword ptr [rsp+0xD0], ymm1
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0xB10]
       lea      r8, [rsp+0xB50]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xAD0]
       lea      rdx, [rsp+0xB90]
       lea      r8, [rsp+0xB10]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm15
       vmovups  ymmword ptr [rsp+0xB0], ymm10
       vinsertf128 ymm11, ymm11, xmm14
       vmovups  ymmword ptr [rsp+0xD0], ymm11
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0xA90]
       lea      r8, [rsp+0xAD0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xD90]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xDB0]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vmovups  ymmword ptr [rsp+0x70], ymm6
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       vmovups  ymmword ptr [rsp+0x90], ymm9
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0xA50]
       vextractf128 xmm8, ymm6
       vextractf128 xmm13, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 146
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x04A0]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm10, ymm10, xmm15
 
G_M000_IG333:                ;; offset=0xBFFA
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x200]
       vinsertf128 ymm12, ymm12, xmmword ptr [rsp+0x1E0]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm9, ymm9, xmm13
       je       SHORT G_M000_IG335
 
G_M000_IG334:                ;; offset=0xC024
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm8
       vinsertf128 ymm12, ymm12, xmm13
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
 
G_M000_IG335:                ;; offset=0xC08C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0xA50]
       lea      rcx, [rsp+0xA10]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm8, ymm7
       vextractf128 xmm13, ymm12
       vextractf128 xmmword ptr [rsp+0x2C0], ymm6
       vextractf128 xmmword ptr [rsp+0x2A0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2C0]
       vmovups  ymmword ptr [rsp+0xB0], ymm6
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x2A0]
       vmovups  ymmword ptr [rsp+0xD0], ymm9
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x9D0]
       lea      r8, [rsp+0xA10]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm15
       vmovups  ymmword ptr [rsp+0xB0], ymm10
       vinsertf128 ymm11, ymm11, xmm14
       vmovups  ymmword ptr [rsp+0xD0], ymm11
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x990]
       lea      r8, [rsp+0x9D0]
       vextractf128 xmm15, ymm10
       vextractf128 xmm14, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x990]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x9B0]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x990]
       vmovdqu  ymmword ptr [rsp+0x70], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x9B0]
       vmovdqu  ymmword ptr [rsp+0x90], ymm0
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0x950]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm7, ymm7, xmm8
       vmovups  ymmword ptr [rsp+0xB0], ymm7
       vinsertf128 ymm12, ymm12, xmm13
       vmovups  ymmword ptr [rsp+0xD0], ymm12
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x910]
       lea      r8, [rsp+0x990]
 
G_M000_IG336:                ;; offset=0xC218
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm8, ymmword ptr [rsp+0x1B0]
       vmovups  ymmword ptr [rsp+0xB0], ymm8
       vmovups  ymm13, ymmword ptr [rsp+0x190]
       vmovups  ymmword ptr [rsp+0xD0], ymm13
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x8D0]
       lea      r8, [rsp+0x910]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x890]
       lea      rdx, [rsp+0x950]
       lea      r8, [rsp+0x8D0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm15
       vmovups  ymmword ptr [rsp+0xB0], ymm10
       vinsertf128 ymm11, ymm11, xmm14
       vmovups  ymmword ptr [rsp+0xD0], ymm11
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x850]
       lea      r8, [rsp+0x890]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x810]
       lea      rdx, [rsp+0xA90]
       lea      r8, [rsp+0x850]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rbx, gword ptr [rbx+0x08]
       mov      rdx, rbx
       cmp      dword ptr [rdx+0x08], 147
       jbe      G_M000_IG363
       mov      rdi, gword ptr [rdx+0x04A8]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG338
 
G_M000_IG337:                ;; offset=0xC2F8
       mov      rdx, rdi
       mov      rcx, r15
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG338:                ;; offset=0xC304
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       cmp      dword ptr [rbx+0x08], 148
       jbe      G_M000_IG363
       mov      rbx, gword ptr [rbx+0x04B0]
       cmp      qword ptr [rbx], r15
       je       SHORT G_M000_IG340
 
G_M000_IG339:                ;; offset=0xC327
       mov      rdx, rbx
       mov      rcx, r15
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG340:                ;; offset=0xC34B
       vmovups  ymm10, ymmword ptr [rsp+0x4B0]
       vmovups  ymmword ptr [rsp+0xB0], ymm10
       vmovups  ymm11, ymmword ptr [rsp+0x490]
       vmovups  ymmword ptr [rsp+0xD0], ymm11
       vmovdqu  ymm0, ymmword ptr [rbx+0x08]
       vmovdqu  ymmword ptr [rsp+0x70], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x28]
       vmovdqu  ymmword ptr [rsp+0x90], ymm0
       lea      rdx, [rsp+0xB0]
       lea      r8, [rsp+0x70]
       lea      rcx, [rsp+0x7D0]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm8
       vmovups  ymmword ptr [rsp+0xB0], ymm6
       vinsertf128 ymm7, ymm7, xmm9
       vmovups  ymmword ptr [rsp+0xD0], ymm7
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x790]
       lea      r8, [rsp+0x7D0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x790]
       vmovups  ymm1, ymmword ptr [rsp+0x7B0]
       vmovups  ymm2, ymmword ptr [rsp+0xD90]
       vmovups  ymm3, ymmword ptr [rsp+0xDB0]
       vcmpltpd ymm0, ymm0, ymm2
       vcmpltpd ymm1, ymm1, ymm3
       vpunpckldq ymm2, ymm0, ymm1
       vpunpckhdq ymm0, ymm0, ymm1
       vpunpckldq ymm0, ymm2, ymm0
       vpermq   ymm0, ymm0, -40
       vmovups  ymmword ptr [rsp+0x770], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xD90]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xDB0]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x790]
       lea      rcx, [rsp+0x730]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x810]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x830]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      r8, [rsp+0xB0]
       lea      rdx, [rsp+0x730]
       lea      rcx, [rsp+0x6F0]
 
G_M000_IG341:                ;; offset=0xC4BE
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xD90]
       vmovdqu  ymmword ptr [rsp+0xB0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xDB0]
       vmovdqu  ymmword ptr [rsp+0xD0], ymm0
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x6B0]
       lea      r8, [rsp+0x6F0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x670]
       lea      rdx, [rsp+0x770]
       lea      r8, [rsp+0x6B0]
       lea      r9, [rsp+0xD90]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Select(System.Numerics.Vector`1[int],Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG342:                ;; offset=0xC52C
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG343:                ;; offset=0xC536
       vmovups  ymm2, ymmword ptr [rsp+0x530]
       vmovups  ymmword ptr [rsp+0xB0], ymm2
       vmovups  ymm0, ymmword ptr [rsp+0x510]
       vmovups  ymmword ptr [rsp+0xD0], ymm0
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       xor      edx, edx
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG344:                ;; offset=0xC575
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG345:                ;; offset=0xC57F
       vmovups  ymm2, ymmword ptr [rsp+0x4F0]
       vmovups  ymmword ptr [rsp+0xB0], ymm2
       vmovups  ymm0, ymmword ptr [rsp+0x4D0]
       vmovups  ymmword ptr [rsp+0xD0], ymm0
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       mov      edx, 1
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG346:                ;; offset=0xC5C1
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG347:                ;; offset=0xC5CB
       vinsertf128 ymm10, ymm10, xmm12
       vmovups  ymmword ptr [rsp+0xB0], ymm10
       vinsertf128 ymm11, ymm11, xmm13
       vmovups  ymmword ptr [rsp+0xD0], ymm11
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       mov      edx, 2
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG348:                ;; offset=0xC607
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG349:                ;; offset=0xC611
       vmovups  ymm4, ymmword ptr [rsp+0x470]
       vmovups  ymmword ptr [rsp+0xB0], ymm4
       vmovups  ymm14, ymmword ptr [rsp+0x450]
       vmovups  ymmword ptr [rsp+0xD0], ymm14
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       mov      edx, 3
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG350:                ;; offset=0xC653
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG351:                ;; offset=0xC65D
       vmovups  ymm2, ymmword ptr [rsp+0x430]
       vmovups  ymmword ptr [rsp+0xB0], ymm2
       vmovups  ymm0, ymmword ptr [rsp+0x410]
       vmovups  ymmword ptr [rsp+0xD0], ymm0
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       mov      edx, 4
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG352:                ;; offset=0xC69F
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG353:                ;; offset=0xC6A9
       vmovups  ymm9, ymmword ptr [rsp+0x3F0]
       vmovups  ymmword ptr [rsp+0xB0], ymm9
       vmovups  ymm0, ymmword ptr [rsp+0x3D0]
       vmovups  ymmword ptr [rsp+0xD0], ymm0
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       mov      edx, 5
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG354:                ;; offset=0xC6EB
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG355:                ;; offset=0xC6F5
       vmovups  ymm1, ymmword ptr [rsp+0x3B0]
       vmovups  ymmword ptr [rsp+0xB0], ymm1
       vmovups  ymm0, ymmword ptr [rsp+0x390]
       vmovups  ymmword ptr [rsp+0xD0], ymm0
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       mov      edx, 6
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG356:                ;; offset=0xC737
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG357:                ;; offset=0xC741
       vmovups  ymm7, ymmword ptr [rsp+0x370]
       vmovups  ymmword ptr [rsp+0xB0], ymm7
       vmovups  ymm8, ymmword ptr [rsp+0x350]
       vmovups  ymmword ptr [rsp+0xD0], ymm8
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       mov      edx, 7
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG358:                ;; offset=0xC783
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG359:                ;; offset=0xC78D
       vmovups  ymm7, ymmword ptr [rsp+0x330]
       vmovups  ymmword ptr [rsp+0xB0], ymm7
       vmovups  ymm8, ymmword ptr [rsp+0x310]
       vmovups  ymmword ptr [rsp+0xD0], ymm8
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0xB0]
       mov      edx, 8
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG360:                ;; offset=0xC7CF
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG361:                ;; offset=0xC7D9
       lea      rcx, [rsp+0x60]
       lea      r9, [rsp+0x670]
       mov      edx, 9
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       lea      r9, [rsp+0x810]
       mov      rcx, rsi
       mov      edx, 10
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       nop      
 
G_M000_IG362:                ;; offset=0xC814
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x20B0]
       vmovaps  xmm7, xmmword ptr [rsp+0x20A0]
       vmovaps  xmm8, xmmword ptr [rsp+0x2090]
       vmovaps  xmm9, xmmword ptr [rsp+0x2080]
       vmovaps  xmm10, xmmword ptr [rsp+0x2070]
       vmovaps  xmm11, xmmword ptr [rsp+0x2060]
       vmovaps  xmm12, xmmword ptr [rsp+0x2050]
       vmovaps  xmm13, xmmword ptr [rsp+0x2040]
       vmovaps  xmm14, xmmword ptr [rsp+0x2030]
       vmovaps  xmm15, xmmword ptr [rsp+0x2020]
       add      rsp, 0x20C8
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG363:                ;; offset=0xC885
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh

; Total bytes of code 51339

; Assembly listing for method (dynamicClass):lambda_method3(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 14 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 256
       vmovaps  xmmword ptr [rsp+0xF0], xmm6
       vmovaps  xmmword ptr [rsp+0xE0], xmm7
       vmovaps  xmmword ptr [rsp+0xD0], xmm8
       vmovaps  xmmword ptr [rsp+0xC0], xmm9
       vmovaps  xmmword ptr [rsp+0xB0], xmm10
       vmovaps  xmmword ptr [rsp+0xA0], xmm11
       vmovaps  xmmword ptr [rsp+0x90], xmm12
       vmovaps  xmmword ptr [rsp+0x80], xmm13
       vmovaps  xmmword ptr [rsp+0x70], xmm14
       vmovaps  xmmword ptr [rsp+0x60], xmm15
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0061
       mov      rsi, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       test     eax, eax
       je       G_M000_IG48
       vmovsd   xmm1, qword ptr [rcx]
       cmp      eax, 1
       jbe      G_M000_IG48
       vmovsd   xmm2, qword ptr [rcx+0x08]
       cmp      eax, 2
       jbe      G_M000_IG48
       vmovsd   xmm3, qword ptr [rcx+0x10]
       vcvtsd2ss xmm6, xmm6, xmm1
       vcvtsd2ss xmm7, xmm7, xmm2
       vcvtsd2ss xmm8, xmm8, xmm3
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 0
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x00CF
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD00]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm9, xmm1, xmm2
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 1
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x18]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x010E
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG35
 
G_M000_IG06:                ;; offset=0x0121
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD04]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm9
       vmovss   xmm9, dword ptr [reloc @RWD08]
       vaddss   xmm1, xmm1, xmm9
       vxorps   xmm10, xmm10, xmm10
       vmovaps  xmm2, xmm10
       vmovss   xmm11, dword ptr [reloc @RWD12]
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vcmpneqps xmm12, xmm2, xmm2
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vbroadcastss xmm13, dword ptr [reloc @RWD08]
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm14, xmm14, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 2
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x20]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01DE
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG36
 
G_M000_IG08:                ;; offset=0x01F1
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm15, xmm15, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 3
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x027E
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG37
 
G_M000_IG10:                ;; offset=0x0291
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD16]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vmovss   dword ptr [rsp+0x2C], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 4
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x30]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x02D6
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG38
 
G_M000_IG12:                ;; offset=0x02E9
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD20]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x2C]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x58], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 5
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x38]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x038A
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG39
 
G_M000_IG14:                ;; offset=0x039D
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vmovss   dword ptr [rsp+0x28], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 6
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x03DA
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG40
 
G_M000_IG16:                ;; offset=0x03ED
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, xmm11
       vaddss   xmm1, xmm1, xmm11
       vmulss   xmm1, xmm1, dword ptr [rsp+0x28]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x50], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0488
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG41
 
G_M000_IG18:                ;; offset=0x049B
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x48], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x052E
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG42
 
G_M000_IG20:                ;; offset=0x0541
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x40], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 9
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x58]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x05D4
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG43
 
G_M000_IG22:                ;; offset=0x05E7
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD24]
       vaddss   xmm1, xmm1, dword ptr [reloc @RWD28]
       vmovss   dword ptr [rsp+0x24], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 10
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x062C
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG44
 
G_M000_IG24:                ;; offset=0x063F
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD32]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x24]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x38], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 11
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x68]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x06E0
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG45
 
G_M000_IG26:                ;; offset=0x06F3
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x30], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0786
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG46
 
G_M000_IG28:                ;; offset=0x0799
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm9
       vmulss   xmm0, xmm0, xmm11
       vcmpeqps xmm1, xmm10, xmm0
       vxorps   xmm2, xmm2, xmm2
       vpcmpgtd xmm2, xmm2, xmm0
       vandps   xmm1, xmm2, xmm1
       vorps    xmm1, xmm1, xmm12
       vcmpltps xmm2, xmm0, xmm10
       vorps    xmm1, xmm2, xmm1
       vandps   xmm2, xmm10, xmm1
       vandnps  xmm0, xmm1, xmm0
       vorps    xmm0, xmm0, xmm2
       vxorps   xmm1, xmm1, xmm1
       vcmpltps xmm2, xmm13, xmm0
       vorps    xmm1, xmm2, xmm1
       vblendvps xmm0, xmm0, xmm13, xmm1
       vcvtss2sd xmm0, xmm0, xmm0
       vmovsd   xmm1, qword ptr [reloc @RWD40]
       vsubsd   xmm2, xmm1, xmm15
       vxorps   xmm3, xmm3, xmm3
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vsubsd   xmm5, xmm4, qword ptr [reloc @RWD48]
       vcmpeqpd xmm6, xmm3, xmm5
       vxorps   xmm7, xmm7, xmm7
       vpcmpgtq xmm7, xmm7, xmm5
       vandpd   xmm6, xmm7, xmm6
       vcmpneqpd xmm7, xmm3, xmm3
       vorpd    xmm6, xmm6, xmm7
       vcmpltpd xmm8, xmm5, xmm3
       vorpd    xmm6, xmm8, xmm6
       vandpd   xmm3, xmm3, xmm6
       vandnpd  xmm5, xmm6, xmm5
       vorpd    xmm3, xmm5, xmm3
       vmovsd   xmm6, qword ptr [rsp+0x30]
       vsubsd   xmm5, xmm6, qword ptr [reloc @RWD56]
       vaddsd   xmm5, xmm5, xmm5
       vxorps   xmm8, xmm8, xmm8
       vsubsd   xmm9, xmm6, qword ptr [reloc @RWD48]
       vdivsd   xmm9, xmm9, qword ptr [reloc @RWD64]
       vcmpeqpd xmm10, xmm8, xmm9
       vxorps   xmm11, xmm11, xmm11
       vpcmpgtq xmm11, xmm11, xmm9
       vandpd   xmm10, xmm11, xmm10
       vorpd    xmm10, xmm10, xmm7
       vcmpltpd xmm11, xmm9, xmm8
       vorpd    xmm10, xmm11, xmm10
       vandpd   xmm8, xmm8, xmm10
       vandnpd  xmm9, xmm10, xmm9
       vorpd    xmm8, xmm9, xmm8
       vmovddup xmm9, qword ptr [reloc @RWD40]
       vmovaps  xmm10, xmm9
 
G_M000_IG29:                ;; offset=0x08B9
       vxorps   xmm11, xmm11, xmm11
       vcmpltpd xmm12, xmm10, xmm8
       vorpd    xmm11, xmm12, xmm11
       vblendvpd xmm8, xmm8, xmm10, xmm11
       vmulsd   xmm10, xmm8, xmm8
       vaddsd   xmm8, xmm8, xmm8
       vmovsd   xmm11, qword ptr [reloc @RWD72]
       vsubsd   xmm8, xmm11, xmm8
       vmulsd   xmm8, xmm8, xmm10
       vsubsd   xmm10, xmm14, qword ptr [reloc @RWD80]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD88]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD96]
       vmovsd   xmm12, qword ptr [rsp+0x58]
       vsubsd   xmm13, xmm12, qword ptr [reloc @RWD56]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD104]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD112]
       vaddsd   xmm10, xmm10, xmm13
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD120]
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD128]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD136]
       vmulsd   xmm2, xmm3, xmm2
       vaddsd   xmm2, xmm10, xmm2
       vmulsd   xmm3, xmm5, qword ptr [reloc @RWD144]
       vaddsd   xmm2, xmm2, xmm3
       vmulsd   xmm3, xmm8, xmm0
       vmulsd   xmm3, xmm3, xmm0
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD152]
       vaddsd   xmm2, xmm2, xmm3
       vsubsd   xmm2, xmm2, qword ptr [reloc @RWD160]
       vmovaps  xmm3, xmm2
       vxorps   xmm5, xmm5, xmm5
       vmovsd   xmm8, qword ptr [rsp+0x38]
       vaddsd   xmm10, xmm8, xmm8
       vsubsd   xmm10, xmm10, xmm1
       vandps   xmm10, xmm10, xmmword ptr [reloc @RWD176]
       vsubsd   xmm10, xmm10, qword ptr [reloc @RWD192]
       vdivsd   xmm10, xmm10, qword ptr [reloc @RWD200]
       vcmpeqpd xmm13, xmm5, xmm10
       vxorps   xmm4, xmm4, xmm4
       vpcmpgtq xmm4, xmm4, xmm10
       vandpd   xmm4, xmm4, xmm13
       vorpd    xmm4, xmm4, xmm7
       vcmpltpd xmm13, xmm10, xmm5
       vorpd    xmm4, xmm13, xmm4
       vandpd   xmm5, xmm5, xmm4
       vandnpd  xmm4, xmm4, xmm10
       vorpd    xmm4, xmm4, xmm5
       vmovaps  xmm5, xmm9
       vxorps   xmm10, xmm10, xmm10
       vcmpltpd xmm13, xmm5, xmm4
       vorpd    xmm10, xmm13, xmm10
       vblendvpd xmm4, xmm4, xmm5, xmm10
       vmulsd   xmm5, xmm4, xmm4
       vaddsd   xmm4, xmm4, xmm4
       vsubsd   xmm4, xmm11, xmm4
       vmulsd   xmm4, xmm5, xmm4
       vsubsd   xmm4, xmm1, xmm4
       vxorps   xmm5, xmm5, xmm5
       vdivsd   xmm2, xmm2, qword ptr [reloc @RWD208]
 
G_M000_IG30:                ;; offset=0x0A05
       vcmpeqpd xmm10, xmm5, xmm2
       vxorps   xmm13, xmm13, xmm13
       vpcmpgtq xmm13, xmm13, xmm2
       vandpd   xmm10, xmm13, xmm10
       vorpd    xmm7, xmm10, xmm7
       vcmpltpd xmm10, xmm2, xmm5
       vorpd    xmm7, xmm10, xmm7
       vandpd   xmm5, xmm5, xmm7
       vandnpd  xmm2, xmm7, xmm2
       vorpd    xmm2, xmm2, xmm5
       vxorps   xmm5, xmm5, xmm5
       vcmpltpd xmm7, xmm9, xmm2
       vorpd    xmm5, xmm7, xmm5
       vblendvpd xmm2, xmm2, xmm9, xmm5
       vmulsd   xmm5, xmm2, xmm2
       vaddsd   xmm2, xmm2, xmm2
       vsubsd   xmm2, xmm11, xmm2
       vmulsd   xmm2, xmm5, xmm2
       vsubsd   xmm1, xmm1, xmm2
       vmulsd   xmm1, xmm1, xmm4
       vmulsd   xmm2, xmm12, qword ptr [reloc @RWD216]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD224]
       vucomisd xmm3, xmm2
       seta     dl
       movzx    rdx, dl
       vsubsd   xmm2, xmm2, xmm3
       vmulsd   xmm2, xmm2, xmm1
       vaddsd   xmm2, xmm2, xmm3
       test     edx, edx
       je       G_M000_IG33
 
G_M000_IG31:                ;; offset=0x0A8B
       cmp      edi, 10
       jle      G_M000_IG47
       vmovsd   qword ptr [rsi], xmm14
       vmovsd   qword ptr [rsi+0x08], xmm15
       vmovsd   qword ptr [rsi+0x10], xmm12
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       vmovsd   qword ptr [rsi+0x30], xmm8
       vmovsd   qword ptr [rsi+0x38], xmm6
       vmovsd   qword ptr [rsi+0x40], xmm0
       vmovsd   qword ptr [rsi+0x48], xmm2
       vmovsd   qword ptr [rsi+0x50], xmm1
 
G_M000_IG32:                ;; offset=0x0ADC
       vmovaps  xmm6, xmmword ptr [rsp+0xF0]
       vmovaps  xmm7, xmmword ptr [rsp+0xE0]
       vmovaps  xmm8, xmmword ptr [rsp+0xD0]
       vmovaps  xmm9, xmmword ptr [rsp+0xC0]
       vmovaps  xmm10, xmmword ptr [rsp+0xB0]
       vmovaps  xmm11, xmmword ptr [rsp+0xA0]
       vmovaps  xmm12, xmmword ptr [rsp+0x90]
       vmovaps  xmm13, xmmword ptr [rsp+0x80]
       vmovaps  xmm14, xmmword ptr [rsp+0x70]
       vmovaps  xmm15, xmmword ptr [rsp+0x60]
       add      rsp, 256
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG33:                ;; offset=0x0B3B
       vmovaps  xmm2, xmm3
       jmp      G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0B44
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG35:                ;; offset=0x0B4E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG36:                ;; offset=0x0B58
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG37:                ;; offset=0x0B62
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG38:                ;; offset=0x0B6C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG39:                ;; offset=0x0B76
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG40:                ;; offset=0x0B80
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG41:                ;; offset=0x0B8A
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG42:                ;; offset=0x0B94
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG43:                ;; offset=0x0B9E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG44:                ;; offset=0x0BA8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG45:                ;; offset=0x0BB2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG46:                ;; offset=0x0BBC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG47:                ;; offset=0x0BC6
       test     edi, edi
       je       G_M000_IG48
       vmovsd   qword ptr [rsi], xmm14
       cmp      edi, 1
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x08], xmm15
       cmp      edi, 2
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x10], xmm12
       cmp      edi, 3
       jbe      SHORT G_M000_IG48
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       cmp      edi, 4
       jbe      SHORT G_M000_IG48
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       cmp      edi, 5
       jbe      SHORT G_M000_IG48
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       cmp      edi, 6
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x30], xmm8
       cmp      edi, 7
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x38], xmm6
       cmp      edi, 8
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x40], xmm0
       cmp      edi, 9
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x48], xmm2
       cmp      edi, 10
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x50], xmm1
       jmp      G_M000_IG32
 
G_M000_IG48:                ;; offset=0x0C4D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	3F47AE14h		;      0.78
RWD04  	dd	3E6147AEh		;      0.22
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F51EB85h		;      0.82
RWD20  	dd	3E3851ECh		;      0.18
RWD24  	dd	3F666666h		;       0.9
RWD28  	dd	3E570A3Dh		;      0.21
RWD32  	dd	3DCCCCCDh		;       0.1
RWD36  	dd	00000000h
RWD40  	dq	3FF0000000000000h	;            1
RWD48  	dq	3FDEB851EB851EB8h	;         0.48
RWD56  	dq	3FE0000000000000h	;          0.5
RWD64  	dq	3FCEB851EB851EB8h	;         0.24
RWD72  	dq	4008000000000000h	;            3
RWD80  	dq	3FD6666666666666h	;         0.35
RWD88  	dq	4038000000000000h	;           24
RWD96  	dq	4000000000000000h	;            2
RWD104 	dq	4044000000000000h	;           40
RWD112 	dq	3FE1EB851EB851ECh	;         0.56
RWD120 	dq	4067C00000000000h	;          190
RWD128 	dq	3FF6666666666666h	;          1.4
RWD136 	dq	3FD3333333333333h	;          0.3
RWD144 	dq	4074000000000000h	;          320
RWD152 	dq	408F400000000000h	;         1000
RWD160 	dq	4010000000000000h	;            4
RWD168 	dd	00000000h, 00000000h
RWD176 	dq	7FFFFFFFFFFFFFFFh, 7FFFFFFFFFFFFFFFh
RWD192 	dq	3F9999999999999Ah	;        0.025
RWD200 	dq	3FB5C28F5C28F5C2h	;        0.085
RWD208 	dq	4042000000000000h	;           36
RWD216 	dq	3FF3333333333333h	;          1.2
RWD224 	dq	C014000000000000h	;           -5

; Total bytes of code 3155

; Assembly listing for method (dynamicClass):lambda_method4(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 384 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       lea      r11, [rsp-0x1BA0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       vmovaps  xmmword ptr [rsp+0x1B90], xmm6
       vmovaps  xmmword ptr [rsp+0x1B80], xmm7
       vmovaps  xmmword ptr [rsp+0x1B70], xmm8
       vmovaps  xmmword ptr [rsp+0x1B60], xmm9
       vmovaps  xmmword ptr [rsp+0x1B50], xmm10
       vmovaps  xmmword ptr [rsp+0x1B40], xmm11
       vmovaps  xmmword ptr [rsp+0x1B30], xmm12
       vmovaps  xmmword ptr [rsp+0x1B20], xmm13
       vmovaps  xmmword ptr [rsp+0x1B10], xmm14
       vmovaps  xmmword ptr [rsp+0x1B00], xmm15
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x30], xmm4
       mov      rax, -0x1980
       vmovdqa  xmmword ptr [rsp+rax+0x19C0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x19D0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x19E0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r8
 
G_M000_IG02:                ;; offset=0x00B2
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG03:                ;; offset=0x00BF
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1AC0]
       xor      r8d, r8d
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG04:                ;; offset=0x00DE
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG05:                ;; offset=0x00EB
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1A80]
       mov      r8d, 1
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1A40]
       mov      rdx, rdi
       mov      r8d, 2
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x1AC0]
       vmovups  ymm1, ymmword ptr [rsp+0x1AE0]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1A20], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A80]
       vmovups  ymm1, ymmword ptr [rsp+0x1AA0]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1A00], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A40]
       vmovups  ymm1, ymmword ptr [rsp+0x1A60]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x19E0], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 0
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x10]
       mov      r14, 0x7FFC658C3210
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x01CA
       mov      rdx, rbp
       mov      rcx, r14
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG07:                ;; offset=0x01D6
       vmovups  ymm6, ymmword ptr [rbp+0x08]
       cmp      dword ptr [rdi+0x08], 1
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x18]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01F1
       mov      rcx, 0x7FFC6590B160
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG180
 
G_M000_IG09:                ;; offset=0x0204
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm7, ymm0, ymmword ptr [rsp+0x1A20]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x1A00]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x19E0]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0234
       mov      edx, edx
       lea      r9, [reloc @RWD00]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG11:                ;; offset=0x024E
       vaddps   ymm0, ymm8, ymm7
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm7, ymm0, ymm7
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x026F
       vaddps   ymm0, ymm9, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm8, ymm8, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm8
       vaddps   ymm7, ymm1, ymm7
       vaddps   ymm9, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm8, ymm0, ymm8
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02A0
       vaddps   ymm0, ymm8, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm9
       vaddps   ymm7, ymm2, ymm7
       vaddps   ymm1, ymm8, ymm1
       vsubps   ymm8, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
 
G_M000_IG14:                ;; offset=0x02D3
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovss   xmm13, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02FC
       cmp      r15d, 1
       jg       G_M000_IG154
 
G_M000_IG16:                ;; offset=0x0306
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm7
       vmovups  ymmword ptr [rsp+0xE0], ymm8
       vmovups  ymmword ptr [rsp+0xC0], ymm9
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x480]
       vextractf128 xmm14, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       vinsertf128 ymm6, ymm6, xmm14
       je       G_M000_IG159
 
G_M000_IG17:                ;; offset=0x037B
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG158
 
G_M000_IG18:                ;; offset=0x038C
       cmp      edx, 3
       je       G_M000_IG157
 
G_M000_IG19:                ;; offset=0x0395
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x480]
 
G_M000_IG20:                ;; offset=0x039E
       vbroadcastss ymm0, ymm13
       vmulps   ymm7, ymm0, ymm1
 
G_M000_IG21:                ;; offset=0x03A7
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 2
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x20]
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x03C2
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm14, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG23:                ;; offset=0x03E6
       vmulps   ymm0, ymm7, ymmword ptr [rbp+0x08]
       vaddps   ymm7, ymm0, ymm6
       vmovups  ymmword ptr [rsp+0x19C0], ymm7
       cmp      dword ptr [rdi+0x08], 3
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x28]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x040E
       mov      rcx, 0x7FFC6590B160
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG181
 
G_M000_IG25:                ;; offset=0x0421
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x1A20]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x1A00]
       vmulps   ymm10, ymm0, ymmword ptr [rsp+0x19E0]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG30
 
G_M000_IG26:                ;; offset=0x0451
       mov      edx, edx
       lea      r9, [reloc @RWD128]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG27:                ;; offset=0x046B
       vaddps   ymm0, ymm9, ymm8
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       vsubps   ymm10, ymm0, ymm10
       jmp      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x048E
       vaddps   ymm0, ymm10, ymm8
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm9
       vaddps   ymm8, ymm1, ymm8
       vaddps   ymm10, ymm1, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x04C1
       vaddps   ymm0, ymm9, ymm8
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm10, ymm10, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm10
       vaddps   ymm8, ymm2, ymm8
       vaddps   ymm1, ymm9, ymm1
       vsubps   ymm9, ymm1, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm10, ymm0, ymm10
 
G_M000_IG30:                ;; offset=0x04F6
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovaps  ymm13, ymm10
       vmovss   xmm14, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0520
       cmp      r15d, 1
       jg       G_M000_IG148
 
G_M000_IG32:                ;; offset=0x052A
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm9
       vmovups  ymmword ptr [rsp+0xC0], ymm10
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x3A0]
       vextractf128 xmm15, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       vinsertf128 ymm6, ymm6, xmm15
       je       G_M000_IG153
 
G_M000_IG33:                ;; offset=0x059F
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG152
 
G_M000_IG34:                ;; offset=0x05B0
       cmp      edx, 3
       je       G_M000_IG151
 
G_M000_IG35:                ;; offset=0x05B9
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x3A0]
 
G_M000_IG36:                ;; offset=0x05C2
       vbroadcastss ymm0, ymm14
       vmulps   ymm8, ymm0, ymm1
 
G_M000_IG37:                ;; offset=0x05CB
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 4
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x30]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x05E7
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG39:                ;; offset=0x060B
       vmulps   ymm0, ymm8, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x19C0]
       mov      rdx, rdi
       cmp      ebp, 5
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x38]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0633
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm8, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm7, ymm7, xmm8
 
G_M000_IG41:                ;; offset=0x0657
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x19A0], ymm0
       vaddps   ymm7, ymm7, ymmword ptr [rsp+0x19A0]
       cmp      ebp, 6
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdi+0x40]
       cmp      qword ptr [rdi], r14
       je       SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0681
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm8, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm7, ymm7, xmm8
 
G_M000_IG43:                ;; offset=0x06A5
       vmovups  ymm9, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmulps   ymm0, ymm9, ymm7
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1980]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1960]
       lea      r8, [rsp+0x1980]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1920]
       lea      rdx, [rsp+0x1960]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0756
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG182
 
G_M000_IG45:                ;; offset=0x0769
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1900]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1900]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x18E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x18C0]
       lea      r8, [rsp+0x18E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1880]
       lea      rdx, [rsp+0x18C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x08B0
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG183
 
G_M000_IG47:                ;; offset=0x08C3
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1860]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 9
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x58]
       cmp      qword ptr [rbp], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x0959
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG49:                ;; offset=0x097D
       vmovups  ymm0, ymmword ptr [rsp+0x1860]
       vmulps   ymm0, ymm0, ymmword ptr [rbp+0x08]
       vaddps   ymm8, ymm0, ymm6
       cmp      dword ptr [rdi+0x08], 10
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x09A5
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG184
 
G_M000_IG51:                ;; offset=0x09B8
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1840]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 11
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x68]
       cmp      qword ptr [rdi], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0A56
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG53:                ;; offset=0x0A86
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1840]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1820]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1800]
       lea      r8, [rsp+0x1820]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x17C0]
       lea      rdx, [rsp+0x1800]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0B53
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG185
 
G_M000_IG55:                ;; offset=0x0B66
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x17A0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vmovups  ymm0, ymmword ptr [rsp+0x17A0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm6, ymm6, xmm15
       vaddps   ymm8, ymm0, ymm6
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 13
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x78]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0C11
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG186
 
G_M000_IG57:                ;; offset=0x0C24
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1780]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm9, ymmword ptr [rsp+0x1780]
       vaddps   ymm0, ymm0, ymm9
       vinsertf128 ymm8, ymm8, xmm10
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1760]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1740]
       lea      r8, [rsp+0x1760]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1700]
       lea      rdx, [rsp+0x1740]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 14
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x80]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG58:                ;; offset=0x0D75
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0D77
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG187
 
G_M000_IG60:                ;; offset=0x0D8A
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x16E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x16E0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x16C0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x16A0]
       lea      r8, [rsp+0x16C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1660]
       lea      rdx, [rsp+0x16A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 15
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x88]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0ED4
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG188
 
G_M000_IG62:                ;; offset=0x0EE7
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1640]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1640]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1620]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1600]
       lea      r8, [rsp+0x1620]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x15C0]
       lea      rdx, [rsp+0x1600]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 16
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x90]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x1031
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG189
 
G_M000_IG64:                ;; offset=0x1044
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x15A0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 17
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x98]
       cmp      qword ptr [r15], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x10DE
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG66:                ;; offset=0x1102
       vmovups  ymm0, ymmword ptr [rsp+0x15A0]
       vmulps   ymm8, ymm0, ymmword ptr [r15+0x08]
       mov      rdx, rdi
       cmp      ebp, 18
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0xA0]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x1129
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG68:                ;; offset=0x1159
       vaddps   ymm8, ymm8, ymmword ptr [r15+0x08]
       cmp      ebp, 19
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0xA8]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x1177
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG190
 
G_M000_IG70:                ;; offset=0x118A
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1580]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 20
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xB0]
       cmp      qword ptr [rdi], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
       je       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x122B
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG72:                ;; offset=0x125B
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1580]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1560]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1540]
       lea      r8, [rsp+0x1560]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1500]
       lea      rdx, [rsp+0x1540]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 21
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0xB8]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x132B
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG191
 
G_M000_IG74:                ;; offset=0x133E
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x14E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x14E0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x14C0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x14A0]
       lea      r8, [rsp+0x14C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1460]
       lea      rdx, [rsp+0x14A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 22
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0xC0]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x1488
       mov      rax, 0x7FFC6590B160
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG192
 
G_M000_IG76:                ;; offset=0x149B
       lea      rdx, [rsp+0x19E0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1440]
       lea      r8, [rsp+0x1A20]
       lea      r9, [rsp+0x1A00]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1440]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1420]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1400]
       lea      rdx, [rsp+0x19A0]
       lea      r8, [rsp+0x1420]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x13C0]
       lea      rdx, [rsp+0x1400]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 23
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xC8]
       mov      rbp, 0x7FFC6590F038
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x158C
       mov      rdx, rdi
       mov      rcx, rbp
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG78:                ;; offset=0x1598
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       vmovdqu  ymm0, ymmword ptr [rsp+0x1880]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x18A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1380]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 24
       jbe      G_M000_IG193
       mov      r14, gword ptr [rdx+0xD0]
       cmp      qword ptr [r14], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x1622
       mov      rdx, r14
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG80:                ;; offset=0x1646
       vmovups  ymm10, ymmword ptr [r14+0x08]
       vmovups  ymm11, ymmword ptr [r14+0x28]
       cmp      dword ptr [rdi+0x08], 25
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdi+0xD8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x1668
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG82:                ;; offset=0x16A4
       vmovups  ymm14, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x240], ymm14
       vmovups  ymm15, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x220], ymm15
       vmovdqu  ymm0, ymmword ptr [rsp+0x1700]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1720]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymmword ptr [rsp+0x40], ymm14
       vmovups  ymmword ptr [rsp+0x60], ymm15
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1340]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1300]
       lea      r8, [rsp+0x1340]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 26
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xE0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x179D
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG84:                ;; offset=0x17D9
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x200], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x1E0], ymm1
       vmovdqu  ymm2, ymmword ptr [rsp+0x1460]
       vmovdqu  ymmword ptr [rsp+0x80], ymm2
       vmovdqu  ymm2, ymmword ptr [rsp+0x1480]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm2
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x12C0]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 27
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xE8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x188A
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG86:                ;; offset=0x18C6
       vmovups  ymm8, ymmword ptr [rdi+0x08]
       vmovups  ymm9, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x12C0]
       lea      rcx, [rsp+0x1280]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1460]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1480]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x240]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x220]
       vmovups  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1240]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 28
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xF0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x19D3
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG88:                ;; offset=0x1A3B
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1240]
       lea      rcx, [rsp+0x1200]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmmword ptr [rsp+0x1D0], ymm8
       vextractf128 xmmword ptr [rsp+0x1B0], ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x11C0]
       lea      r8, [rsp+0x1200]
       vextractf128 xmm14, ymm10
       vextractf128 xmm15, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1180]
       lea      r8, [rsp+0x11C0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1180]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x11A0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1180]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x11A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1140]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 29
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xF8]
 
G_M000_IG89:                ;; offset=0x1BB9
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1D0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1B0]
       vinsertf128 ymm10, ymm10, xmm14
       vinsertf128 ymm11, ymm11, xmm15
       je       SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x1BEC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG91:                ;; offset=0x1C54
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x180], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x160], ymm1
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1100]
       lea      r8, [rsp+0x1180]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x10C0]
       lea      r8, [rsp+0x1100]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1080]
       lea      rdx, [rsp+0x1140]
       lea      r8, [rsp+0x10C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 30
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x100]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x1D76
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG93:                ;; offset=0x1DDE
       vmovdqu  ymm0, ymmword ptr [rsp+0x1920]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1940]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1040]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 31
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x108]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x1EA9
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG95:                ;; offset=0x1F11
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1040]
       lea      rcx, [rsp+0x1000]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1000]
       lea      rcx, [rsp+0xFC0]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x17C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x200]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1E0]
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xF80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 32
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x110]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x2066
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG97:                ;; offset=0x20CE
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF80]
       lea      rcx, [rsp+0xF40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 33
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x118]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x217E
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG99:                ;; offset=0x21E6
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF40]
       lea      rcx, [rsp+0xF00]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xEC0]
       lea      rdx, [rsp+0xFC0]
       lea      r8, [rsp+0xF00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 34
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x120]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x22B4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG101:                ;; offset=0x231C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1300]
       lea      rcx, [rsp+0xE80]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 35
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x128]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x23CC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG103:                ;; offset=0x2434
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xE80]
       lea      rcx, [rsp+0xE40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 36
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x130]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x24E4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG105:                ;; offset=0x254C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xE00]
       lea      r8, [rsp+0x1380]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xDC0]
       lea      rdx, [rsp+0xE40]
       lea      r8, [rsp+0xE00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD80]
       lea      rdx, [rsp+0xEC0]
       lea      r8, [rsp+0xDC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 37
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x138]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x2638
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG107:                ;; offset=0x26A0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1280]
       lea      rcx, [rsp+0xD40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD00]
       lea      rdx, [rsp+0xD80]
       lea      r8, [rsp+0xD40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x13C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1080]
       lea      rcx, [rsp+0xCC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x13C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xCC0]
       lea      rcx, [rsp+0xC80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 38
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x140]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x27F2
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG109:                ;; offset=0x285A
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC80]
       lea      rcx, [rsp+0xC40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xC00]
       lea      rdx, [rsp+0xD00]
       lea      r8, [rsp+0xC40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 39
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x148]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x2928
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG111:                ;; offset=0x2990
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC00]
       lea      rcx, [rsp+0xBC0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1500]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1520]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x40], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0x60], ymm9
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xB80]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB80]
       lea      rcx, [rsp+0xB40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xB00]
       lea      rdx, [rsp+0xB40]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Abs(Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 40
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x150]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
 
G_M000_IG112:                ;; offset=0x2AE9
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x2B01
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG114:                ;; offset=0x2B69
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB00]
       lea      rcx, [rsp+0xAC0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 41
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x158]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x2C19
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG116:                ;; offset=0x2C81
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xAC0]
       lea      rcx, [rsp+0xA80]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xA40]
       lea      r8, [rsp+0xA80]
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xA00]
       lea      r8, [rsp+0xA40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xA00]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA20]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA00]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA20]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x9C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
 
G_M000_IG117:                ;; offset=0x2E10
       lea      rcx, [rsp+0x980]
       lea      r8, [rsp+0xA00]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x940]
       lea      r8, [rsp+0x980]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x900]
       lea      rdx, [rsp+0x9C0]
       lea      r8, [rsp+0x940]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x8C0]
       lea      r8, [rsp+0x900]
       vextractf128 xmmword ptr [rsp+0x2D0], ymm6
       vextractf128 xmmword ptr [rsp+0x2B0], ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x40], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0x60], ymm11
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x880]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 42
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x160]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2D0]
 
G_M000_IG118:                ;; offset=0x2F74
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x2B0]
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x2F99
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG120:                ;; offset=0x3001
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x880]
       lea      rcx, [rsp+0x840]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x800]
       lea      r8, [rsp+0x840]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x7C0]
       lea      r8, [rsp+0x800]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x7C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7C0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7E0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x780]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x740]
       lea      r8, [rsp+0x7C0]
 
G_M000_IG121:                ;; offset=0x318A
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x700]
       lea      r8, [rsp+0x740]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x6C0]
       lea      rdx, [rsp+0x780]
       lea      r8, [rsp+0x700]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x680]
       lea      r8, [rsp+0x6C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x640]
       lea      rdx, [rsp+0x8C0]
       lea      r8, [rsp+0x680]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rbx, gword ptr [rbx+0x08]
       mov      rdx, rbx
       cmp      dword ptr [rdx+0x08], 43
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x168]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x3267
       mov      rdx, rdi
       mov      rcx, rbp
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG123:                ;; offset=0x3273
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       cmp      dword ptr [rbx+0x08], 44
       jbe      G_M000_IG193
       mov      rbx, gword ptr [rbx+0x170]
       cmp      qword ptr [rbx], rbp
       je       SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x3293
       mov      rdx, rbx
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG125:                ;; offset=0x32B7
       vmovdqu  ymm0, ymmword ptr [rsp+0x17C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x600]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm8
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm9
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x5C0]
       lea      r8, [rsp+0x600]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x5C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x5E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x5A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:LessThan(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):System.Numerics.Vector`1[int]]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x5C0]
       lea      rcx, [rsp+0x560]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x640]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x660]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x560]
       lea      rcx, [rsp+0x520]
 
G_M000_IG126:                ;; offset=0x342F
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x4E0]
       lea      r8, [rsp+0x520]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x4A0]
       lea      rdx, [rsp+0x5A0]
       lea      r8, [rsp+0x4E0]
       lea      r9, [rsp+0xBC0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Select(System.Numerics.Vector`1[int],Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG127:                ;; offset=0x349D
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG128:                ;; offset=0x34A7
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1920]
       xor      edx, edx
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG129:                ;; offset=0x34C2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG130:                ;; offset=0x34CC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1880]
       mov      edx, 1
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG131:                ;; offset=0x34EA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG132:                ;; offset=0x34F4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x17C0]
       mov      edx, 2
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG133:                ;; offset=0x3512
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG134:                ;; offset=0x351C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1700]
       mov      edx, 3
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG135:                ;; offset=0x353A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG136:                ;; offset=0x3544
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1660]
       mov      edx, 4
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG137:                ;; offset=0x3562
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG138:                ;; offset=0x356C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x15C0]
       mov      edx, 5
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG139:                ;; offset=0x358A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG140:                ;; offset=0x3594
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1500]
       mov      edx, 6
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG141:                ;; offset=0x35B2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG142:                ;; offset=0x35BC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1460]
       mov      edx, 7
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG143:                ;; offset=0x35DA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG144:                ;; offset=0x35E4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x13C0]
       mov      edx, 8
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG145:                ;; offset=0x3602
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG146:                ;; offset=0x360C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x4A0]
       mov      edx, 9
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       lea      r9, [rsp+0x640]
       mov      rcx, rsi
       mov      edx, 10
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       nop      
 
G_M000_IG147:                ;; offset=0x3647
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1B90]
       vmovaps  xmm7, xmmword ptr [rsp+0x1B80]
       vmovaps  xmm8, xmmword ptr [rsp+0x1B70]
       vmovaps  xmm9, xmmword ptr [rsp+0x1B60]
       vmovaps  xmm10, xmmword ptr [rsp+0x1B50]
       vmovaps  xmm11, xmmword ptr [rsp+0x1B40]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B30]
       vmovaps  xmm13, xmmword ptr [rsp+0x1B20]
       vmovaps  xmm14, xmmword ptr [rsp+0x1B10]
       vmovaps  xmm15, xmmword ptr [rsp+0x1B00]
       add      rsp, 0x1BA0
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG148:                ;; offset=0x36B6
       vxorps   ymm8, ymm8, ymm8
       vmovups  ymmword ptr [rsp+0x380], ymm8
       vbroadcastss ymm9, dword ptr [rdi+0x18]
       vbroadcastss ymm10, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm10
       vbroadcastss ymm0, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       vbroadcastss ymm1, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x300], ymm1
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG174
 
G_M000_IG149:                ;; offset=0x3703
       vmovups  ymm8, ymmword ptr [rsp+0x380]
 
G_M000_IG150:                ;; offset=0x370C
       jmp      G_M000_IG37
 
G_M000_IG151:                ;; offset=0x3711
       vbroadcastss ymm1, dword ptr [reloc @RWD140]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x3A0]
       vbroadcastss ymm3, dword ptr [rdi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vcvtdq2ps ymm3, ymm3
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm3, ymm3, ymm15
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vsubps   ymm3, ymm15, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG36
 
G_M000_IG152:                ;; offset=0x3790
       vmovups  ymm1, ymmword ptr [rsp+0x3A0]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG36
 
G_M000_IG153:                ;; offset=0x37BF
       vmovups  ymm1, ymmword ptr [rsp+0x3A0]
       jmp      G_M000_IG36
 
G_M000_IG154:                ;; offset=0x37CD
       vxorps   ymm7, ymm7, ymm7
       vmovups  ymmword ptr [rsp+0x460], ymm7
       vbroadcastss ymm8, dword ptr [rdi+0x18]
       vbroadcastss ymm9, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x420], ymm9
       vbroadcastss ymm14, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x400], ymm14
       vbroadcastss ymm15, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x3E0], ymm15
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG164
 
G_M000_IG155:                ;; offset=0x3819
       vmovups  ymm7, ymmword ptr [rsp+0x460]
 
G_M000_IG156:                ;; offset=0x3822
       jmp      G_M000_IG21
 
G_M000_IG157:                ;; offset=0x3827
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm9, ymmword ptr [rsp+0x480]
       vbroadcastss ymm2, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm2, ymm1
       vmulps   ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm2, ymm2
       vandps   ymm2, ymm3, ymm2
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm2, ymm2
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm2, ymm2, ymm15
       vsubps   ymm1, ymm1, ymm2
       vcmpltps ymm2, ymm1, ymm9
       vsubps   ymm3, ymm15, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG20
 
G_M000_IG158:                ;; offset=0x38A7
       vmovups  ymm1, ymmword ptr [rsp+0x480]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm1, ymm9
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG20
 
G_M000_IG159:                ;; offset=0x38D7
       vmovups  ymm1, ymmword ptr [rsp+0x480]
       jmp      G_M000_IG20
 
G_M000_IG160:                ;; offset=0x38E5
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
       vbroadcastss ymm1, dword ptr [rdi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vcvtdq2ps ymm1, ymm1
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm1, ymm1, ymm15
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm9
       vsubps   ymm2, ymm15, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vmulps   ymm0, ymm0, ymm15
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       jmp      SHORT G_M000_IG162
 
G_M000_IG161:                ;; offset=0x397E
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vsubps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
 
G_M000_IG162:                ;; offset=0x39C5
       vsubps   ymm0, ymm0, ymm9
       vmovups  ymm15, ymmword ptr [rsp+0x3E0]
       vmulps   ymm0, ymm0, ymm15
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm8, ymm0, ymm8
       vmovups  ymm9, ymmword ptr [rsp+0x420]
       vmulps   ymm10, ymm10, ymm9
       vmulps   ymm11, ymm11, ymm9
       vmulps   ymm12, ymm12, ymm9
       vmovups  ymm14, ymmword ptr [rsp+0x400]
       vmulps   ymm8, ymm8, ymm14
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG156
 
G_M000_IG163:                ;; offset=0x3A14
       vmovups  ymmword ptr [rsp+0x460], ymm7
 
G_M000_IG164:                ;; offset=0x3A1D
       vucomiss xmm13, dword ptr [reloc @RWD140]
       jp       SHORT G_M000_IG165
       je       SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x3A29
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x3A32
       vbroadcastss ymm0, ymm13
       vmulps   ymm8, ymm0, ymm8
 
G_M000_IG167:                ;; offset=0x3A3C
       lea      edx, [rbp+r13]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm10
       vmovups  ymmword ptr [rsp+0xE0], ymm11
       vmovups  ymmword ptr [rsp+0xC0], ymm12
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x3C0]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm10
       vextractf128 xmm7, ymm11
       vextractf128 xmm9, ymm12
       vextractf128 xmmword ptr [rsp+0x450], ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm7
       vinsertf128 ymm12, ymm12, xmm9
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x450]
       je       G_M000_IG161
 
G_M000_IG168:                ;; offset=0x3AF2
       cmp      edx, 3
       je       G_M000_IG160
 
G_M000_IG169:                ;; offset=0x3AFB
       vmulps   ymm0, ymm8, ymmword ptr [rsp+0x3C0]
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       jmp      G_M000_IG162
 
G_M000_IG170:                ;; offset=0x3B2C
       vbroadcastss ymm0, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x2E0]
       vbroadcastss ymm2, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm2, ymm1
       vmulps   ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm2, ymm2
       vandps   ymm2, ymm3, ymm2
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm2, ymm2
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm2, ymm2, ymm15
       vsubps   ymm1, ymm1, ymm2
       vcmpltps ymm2, ymm1, ymm0
       vsubps   ymm3, ymm15, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vmovups  ymmword ptr [rsp+0x2E0], ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm9
       vaddps   ymm8, ymm1, ymmword ptr [rsp+0x380]
       vmovups  ymm1, ymmword ptr [rsp+0x2E0]
       vmovaps  ymm2, ymm0
       vmovaps  ymm0, ymm1
       vmovaps  ymm1, ymm2
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x3BD0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vandps   ymm1, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x2E0], ymm1
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm1, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymm9
       vaddps   ymm8, ymm0, ymmword ptr [rsp+0x380]
       vsubps   ymm0, ymm1, ymmword ptr [rsp+0x2E0]
 
G_M000_IG172:                ;; offset=0x3C1F
       vsubps   ymm0, ymm0, ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymm2
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm9, ymm0, ymm9
       vmovups  ymm10, ymmword ptr [rsp+0x340]
       vmulps   ymm11, ymm11, ymm10
       vmulps   ymm12, ymm12, ymm10
       vmulps   ymm13, ymm13, ymm10
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm9, ymm9, ymm0
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG150
 
G_M000_IG173:                ;; offset=0x3C6A
       vmovups  ymmword ptr [rsp+0x380], ymm8
 
G_M000_IG174:                ;; offset=0x3C73
       vucomiss xmm14, dword ptr [reloc @RWD140]
       jp       SHORT G_M000_IG175
       je       SHORT G_M000_IG177
 
G_M000_IG175:                ;; offset=0x3C7F
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x3C88
       vbroadcastss ymm2, ymm14
       vmulps   ymm9, ymm2, ymm9
 
G_M000_IG177:                ;; offset=0x3C92
       lea      edx, [rbp+r13]
       vmovd    xmm2, edx
       vpbroadcastd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x120], ymm2
       vmovups  ymmword ptr [rsp+0x100], ymm11
       vmovups  ymmword ptr [rsp+0xE0], ymm12
       vmovups  ymmword ptr [rsp+0xC0], ymm13
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x2E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm11
       vextractf128 xmm8, ymm12
       vextractf128 xmm10, ymm13
       vextractf128 xmmword ptr [rsp+0x370], ymm9
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm11, ymm11, xmm7
       vinsertf128 ymm12, ymm12, xmm8
       vinsertf128 ymm13, ymm13, xmm10
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x370]
       je       G_M000_IG171
 
G_M000_IG178:                ;; offset=0x3D48
       cmp      edx, 3
       je       G_M000_IG170
 
G_M000_IG179:                ;; offset=0x3D51
       vmulps   ymm0, ymm9, ymmword ptr [rsp+0x2E0]
       vaddps   ymm8, ymm0, ymmword ptr [rsp+0x380]
       vbroadcastss ymm0, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmovaps  ymm2, ymm0
       vmovaps  ymm0, ymm1
       vmovaps  ymm1, ymm2
       jmp      G_M000_IG172
 
G_M000_IG180:                ;; offset=0x3D8E
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG181:                ;; offset=0x3D95
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG182:                ;; offset=0x3D9C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG183:                ;; offset=0x3DA6
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG184:                ;; offset=0x3DB0
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG185:                ;; offset=0x3DBA
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG186:                ;; offset=0x3DC4
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG187:                ;; offset=0x3DCE
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG188:                ;; offset=0x3DD8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG189:                ;; offset=0x3DE2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG190:                ;; offset=0x3DEC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG191:                ;; offset=0x3DF6
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG192:                ;; offset=0x3E00
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG193:                ;; offset=0x3E0A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000001EEh ; case G_M000_IG13
       	dd	000001BDh ; case G_M000_IG12
       	dd	0000019Ch ; case G_M000_IG11
RWD12  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD32  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD64  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD96  	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD128 	dd	0000040Fh ; case G_M000_IG29
       	dd	000003DCh ; case G_M000_IG28
       	dd	000003B9h ; case G_M000_IG27
RWD140 	dd	3F800000h		;         1
RWD144 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD160 	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD192 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD224 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD256 	dd	40000000h		;         2
RWD260 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD288 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h

; Total bytes of code 15888

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair (Tier0-FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier-0 switched to FullOpts code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 200.4397
; No PGO data
; 0 inlinees with PGO data; 8 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       sub      rsp, 40
       lea      rbp, [rsp+0x20]
       mov      rax, 0xBFE28412CAE8
       mov      qword ptr [rbp], rax
 
G_M000_IG02:                ;; offset=0x0019
       test     dword ptr [rsp], esp
       sub      rsp, 64
       lea      rax, [rsp+0x20]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rax], ymm0
       vmovdqu  ymmword ptr [rax+0x20], ymm0
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x0035
       mov      r11d, r10d
       imul     r11d, r9d
       add      r11d, r8d
       cmp      r11d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG07
       mov      rbx, bword ptr [rdx]
       vmovsd   xmm0, qword ptr [rbx+8*r11]
       vmovsd   qword ptr [rax+8*r10], xmm0
       inc      r10d
       cmp      r10d, 8
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x005D
       vmovups  ymm0, ymmword ptr [rax]
       add      rax, 32
       vmovups  ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rcx], ymm0
       vmovups  ymmword ptr [rcx+0x20], ymm1
       mov      rax, rcx
       mov      r8, 0xBFE28412CAE8
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG05
       call     CORINFO_HELP_FAIL_FAST
 
G_M000_IG05:                ;; offset=0x008A
       nop      
 
G_M000_IG06:                ;; offset=0x008B
       vzeroupper 
       lea      rsp, [rbp+0x08]
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0095
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 155

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC65917478
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC6591747C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair (Tier0-FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier-0 switched to FullOpts code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 200.4397
; No PGO data
; 0 inlinees with PGO data; 8 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       sub      rsp, 40
       lea      rbp, [rsp+0x20]
       mov      rax, 0xBFE28412CAE8
       mov      qword ptr [rbp], rax
 
G_M000_IG02:                ;; offset=0x0019
       test     dword ptr [rsp], esp
       sub      rsp, 64
       lea      rax, [rsp+0x20]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rax], ymm0
       vmovdqu  ymmword ptr [rax+0x20], ymm0
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x0035
       mov      r11d, r10d
       imul     r11d, r9d
       add      r11d, r8d
       cmp      r11d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG07
       mov      rbx, bword ptr [rdx]
       vmovsd   xmm0, qword ptr [rbx+8*r11]
       vmovsd   qword ptr [rax+8*r10], xmm0
       inc      r10d
       cmp      r10d, 8
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x005D
       vmovups  ymm0, ymmword ptr [rax]
       add      rax, 32
       vmovups  ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rcx], ymm0
       vmovups  ymmword ptr [rcx+0x20], ymm1
       mov      rax, rcx
       mov      r8, 0xBFE28412CAE8
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG05
       call     CORINFO_HELP_FAIL_FAST
 
G_M000_IG05:                ;; offset=0x008A
       nop      
 
G_M000_IG06:                ;; offset=0x008B
       vzeroupper 
       lea      rsp, [rbp+0x08]
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0095
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 155

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC6591A118
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC6591A11C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC65917478
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC6591747C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC6591A118
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC6591A11C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 3 inlinees with PGO data; 182 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 544
       vmovaps  xmmword ptr [rsp+0x210], xmm6
       vmovaps  xmmword ptr [rsp+0x200], xmm7
       vmovaps  xmmword ptr [rsp+0x1F0], xmm8
       vmovaps  xmmword ptr [rsp+0x1E0], xmm9
       vmovaps  xmmword ptr [rsp+0x1D0], xmm10
       vmovaps  xmmword ptr [rsp+0x1C0], xmm11
       vmovaps  xmmword ptr [rsp+0x1B0], xmm12
       vmovaps  xmmword ptr [rsp+0x1A0], xmm13
       vmovaps  xmmword ptr [rsp+0x190], xmm14
       vmovaps  xmmword ptr [rsp+0x180], xmm15
       mov      rbx, rdx
       mov      rax, bword ptr [rsp+0x270]
 
G_M000_IG02:                ;; offset=0x0072
       mov      edx, dword ptr [rcx+0x64]
       vbroadcastss ymm0, dword ptr [rcx+0x0C]
       vmulps   ymm1, ymm0, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       dec      edx
       cmp      edx, 2
       jne      G_M000_IG17
 
G_M000_IG03:                ;; offset=0x00A2
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm1, ymm0, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD00]
       vsubps   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [r8], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x00D3
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       vmovups  ymm6, ymmword ptr [r8]
       vmovups  ymm7, ymmword ptr [r9]
       vmovups  ymm8, ymmword ptr [rax]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  ymm9, ymm6
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovss   xmm12, dword ptr [rcx+0x38]
       vmovss   dword ptr [rsp+0x14C], xmm12
       cmp      dword ptr [rsi], 0
       je       G_M000_IG15
       cmp      ebp, 1
       jle      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x011C
       vxorps   ymm6, ymm6, ymm6
       vmovups  ymmword ptr [rsp+0x110], ymm6
       vbroadcastss ymm7, dword ptr [rsi+0x18]
       vbroadcastss ymm8, dword ptr [rsi+0x08]
       vbroadcastss ymm13, dword ptr [rsi+0x0C]
       vmovups  ymmword ptr [rsp+0xF0], ymm13
       vbroadcastss ymm14, dword ptr [rsi+0x10]
       vmovups  ymmword ptr [rsp+0xD0], ymm14
       xor      r14d, r14d
       cmp      r14d, ebp
       jge      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x015F
       vucomiss xmm12, dword ptr [reloc @RWD32]
       jp       G_M000_IG24
       jne      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x0173
       lea      edx, [rdi+r14]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm9
       vmovups  ymmword ptr [rsp+0x50], ymm10
       vmovups  ymmword ptr [rsp+0x30], ymm11
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xB0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm6, ymm7
       vextractf128 xmm12, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rsi]
       cmp      edx, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm10, ymm10, xmm13
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm8, ymm8, xmm12
       je       G_M000_IG11
 
G_M000_IG08:                ;; offset=0x020C
       cmp      edx, 3
       je       G_M000_IG25
       vmulps   ymm0, ymm7, ymmword ptr [rsp+0xB0]
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
 
G_M000_IG09:                ;; offset=0x0241
       vsubps   ymm0, ymm0, ymm12
       vmovups  ymm14, ymmword ptr [rsp+0xD0]
       vmulps   ymm0, ymm0, ymm14
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       vmulps   ymm9, ymm9, ymm8
       vmulps   ymm10, ymm10, ymm8
       vmulps   ymm11, ymm11, ymm8
       vmovups  ymm13, ymmword ptr [rsp+0xF0]
       vmulps   ymm7, ymm7, ymm13
       inc      r14d
       cmp      r14d, ebp
       vmovss   xmm12, dword ptr [rsp+0x14C]
       jge      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x028B
       vmovups  ymmword ptr [rsp+0x110], ymm6
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x0299
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vsubps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
G_M000_IG12:                ;; offset=0x02E4
       vmovups  ymm6, ymmword ptr [rsp+0x110]
 
G_M000_IG13:                ;; offset=0x02ED
       vmovups  ymmword ptr [rbx], ymm6
       mov      rax, rbx
 
G_M000_IG14:                ;; offset=0x02F4
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x210]
       vmovaps  xmm7, xmmword ptr [rsp+0x200]
       vmovaps  xmm8, xmmword ptr [rsp+0x1F0]
       vmovaps  xmm9, xmmword ptr [rsp+0x1E0]
       vmovaps  xmm10, xmmword ptr [rsp+0x1D0]
       vmovaps  xmm11, xmmword ptr [rsp+0x1C0]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B0]
       vmovaps  xmm13, xmmword ptr [rsp+0x1A0]
       vmovaps  xmm14, xmmword ptr [rsp+0x190]
       vmovaps  xmm15, xmmword ptr [rsp+0x180]
       add      rsp, 544
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG15:                ;; offset=0x035F
       vmovd    xmm0, edi
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm6
       vmovups  ymmword ptr [rsp+0x50], ymm7
       vmovups  ymmword ptr [rsp+0x30], ymm8
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x150]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG23
       vbroadcastss ymm0, dword ptr [rsi+0x18]
       mov      eax, dword ptr [rsi]
       cmp      eax, 2
       je       G_M000_IG20
       cmp      eax, 3
       je       G_M000_IG22
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x150]
 
G_M000_IG16:                ;; offset=0x03D9
       vbroadcastss ymm0, ymm12
       vmulps   ymm6, ymm0, ymm1
       jmp      G_M000_IG13
 
G_M000_IG17:                ;; offset=0x03E7
       cmp      edx, 2
       ja       G_M000_IG04
       mov      edx, edx
       lea      r10, [reloc @RWD160]
       mov      r10d, dword ptr [r10+4*rdx]
       lea      r11, G_M000_IG02
       add      r10, r11
       jmp      r10
 
G_M000_IG18:                ;; offset=0x040A
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymm2, ymmword ptr [rax]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rax], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [rax]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vaddps   ymm1, ymm1, ymmword ptr [r9]
       vsubps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       jmp      G_M000_IG04
 
G_M000_IG19:                ;; offset=0x045D
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymm2, ymmword ptr [r9]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [r9], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [r9]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vsubps   ymm1, ymm1, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       jmp      G_M000_IG04
 
G_M000_IG20:                ;; offset=0x04B3
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm2, dword ptr [reloc @RWD32]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG16
 
G_M000_IG21:                ;; offset=0x04E2
       jmp      G_M000_IG07
 
G_M000_IG22:                ;; offset=0x04E7
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x150]
       vbroadcastss ymm3, dword ptr [rsi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD96], ymm4
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD288]
       vsubps   ymm3, ymm3, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD64]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG16
 
G_M000_IG23:                ;; offset=0x056C
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       jmp      G_M000_IG16
 
G_M000_IG24:                ;; offset=0x057A
       lea      edx, [rbp-0x01]
       cmp      r14d, edx
       jne      G_M000_IG21
       vbroadcastss ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       jmp      G_M000_IG07
 
G_M000_IG25:                ;; offset=0x0594
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vbroadcastss ymm1, dword ptr [rsi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD96], ymm2
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm12
       vbroadcastss ymm2, dword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
RWD00  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD32  	dd	3F800000h		;         1
RWD36  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD64  	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD96  	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD128 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h
RWD160 	dd	00000398h ; case G_M000_IG18
       	dd	000003EBh ; case G_M000_IG19
       	dd	00000030h ; case G_M000_IG03
RWD172 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD192 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD224 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD256 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD288 	dq	4000000040000000h, 4000000040000000h, 4000000040000000h, 4000000040000000h

; Total bytes of code 1589

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 11276
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rsi
       push     rbx
       sub      rsp, 40
 
G_M000_IG02:                ;; offset=0x0006
       mov      rax, bword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x000F
       mov      r11d, r10d
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       mov      ebx, r10d
       mov      esi, ebx
       vmovsd   xmm0, qword ptr [r9+8*rsi]
       vmovsd   qword ptr [rax+8*r11], xmm0
       lea      r11d, [r10+0x04]
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       vmovsd   xmm0, qword ptr [r9+8*rbx+0x20]
       vmovsd   qword ptr [rax+8*r11], xmm0
       inc      r10d
       cmp      r10d, 4
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x0055
       add      rsp, 40
       pop      rbx
       pop      rsi
       ret      
 
G_M000_IG05:                ;; offset=0x005C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 98

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 7040
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rsi
       push     rbx
       sub      rsp, 40
 
G_M000_IG02:                ;; offset=0x0006
       mov      rax, bword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x000F
       mov      r11d, r10d
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       mov      ebx, r10d
       mov      esi, ebx
       vmovsd   xmm0, qword ptr [r9+8*rsi]
       vmovsd   qword ptr [rax+8*r11], xmm0
       lea      r11d, [r10+0x04]
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       vmovsd   xmm0, qword ptr [r9+8*rbx+0x20]
       vmovsd   qword ptr [rax+8*r11], xmm0
       inc      r10d
       cmp      r10d, 4
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x0055
       add      rsp, 40
       pop      rbx
       pop      rsi
       ret      
 
G_M000_IG05:                ;; offset=0x005C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 98


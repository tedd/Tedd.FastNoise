// Compares generated octave expressions with the released wide call, including raw NaN payloads.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Numerics;
using Tedd.FastNoise.Procedural;

namespace Tedd.FastNoise.Tests;

public sealed class OpenSimplex3WideExpressionTests
{
    private delegate Vector<float> WideNoise(Vector<float> x, Vector<float> y, Vector<float> z);
    private delegate void WideExecutor(ReadOnlySpan<double> inputs, Span<double> outputs);

    [Fact]
    public void FloatConstantPoolingRetainsRawBitsAndSourceScope()
    {
        var request = Request(FractalType.FBm, RotationType3D.None, 4) with
        {
            Frequency = -0f, WeightedStrength = 0f,
            FractalBounding = BitConverter.Int32BitsToSingle(0x7FC12345),
            Lacunarity = BitConverter.Int32BitsToSingle(0x7F812345),
            LastOctaveFade = BitConverter.Int32BitsToSingle(unchecked((int)0xFFC54321)),
        };
        var input = Expression.Parameter(typeof(Vector<float>), "input");
        Dictionary<int, ConstantExpression>? previousSource = null;
        for (int source = 0; source < 2; source++)
        {
            int budget = 64;
            Assert.True(OpenSimplex3WideExpression.TryEmit(request, input, input, input, ref budget, out var expression));
            var visitor = new FloatConstants();
            visitor.Visit(expression);
            Dictionary<int, ConstantExpression> byBits = [];
            foreach (var constant in visitor.Values)
            {
                var vector = (Vector<float>)constant.Value!;
                int bits = BitConverter.SingleToInt32Bits(vector[0]);
                for (int lane = 1; lane < Vector<float>.Count; lane++)
                    Assert.Equal(bits, BitConverter.SingleToInt32Bits(vector[lane]));
                if (byBits.TryGetValue(bits, out var previous)) Assert.Same(previous, constant);
                else byBits.Add(bits, constant);
            }
            foreach (int bits in new[] { 0, int.MinValue, 0x7FC12345, 0x7F812345, unchecked((int)0xFFC54321) })
                Assert.True(byBits.ContainsKey(bits), $"Missing raw constant bits {bits:X8}");
            Assert.True(visitor.Values.Count > byBits.Count);
            if (previousSource is not null)
                foreach (var pair in byBits) Assert.NotSame(previousSource[pair.Key], pair.Value);
            previousSource = byBits;
        }
    }

    private sealed class FloatConstants : ExpressionVisitor
    {
        internal List<ConstantExpression> Values { get; } = [];
        protected override Expression VisitConstant(ConstantExpression node)
        {
            if (node.Value is Vector<float>) Values.Add(node);
            return base.VisitConstant(node);
        }
    }

    [Theory]
    [InlineData(FractalType.FBm, RotationType3D.None)]
    [InlineData(FractalType.FBm, RotationType3D.ImproveXYPlanes)]
    [InlineData(FractalType.FBm, RotationType3D.ImproveXZPlanes)]
    [InlineData(FractalType.Ridged, RotationType3D.None)]
    [InlineData(FractalType.Ridged, RotationType3D.ImproveXYPlanes)]
    [InlineData(FractalType.Ridged, RotationType3D.ImproveXZPlanes)]
    public void FiniteShapesRetainReleasedWideBits(FractalType fractal, RotationType3D rotation)
    {
        for (int octaves = 1; octaves <= 4; octaves++)
        for (int variant = 0; variant < 4; variant++)
        {
            var request = Request(fractal, rotation, octaves) with
            {
                Seed = variant % 2 == 0 ? int.MaxValue - 1 : int.MinValue,
                WeightedStrength = variant < 2 ? 0f : .4f,
                LastOctaveFade = new[] { 1f, .375f, 0f, -0f }[variant],
                // Bounding deliberately reflects more configured octaves than the surviving shape.
                FractalBounding = .49382716f,
            };
            Compare(request, FiniteCoordinates());
        }
    }

    [Theory]
    [InlineData(FractalType.FBm, RotationType3D.None)]
    [InlineData(FractalType.FBm, RotationType3D.ImproveXYPlanes)]
    [InlineData(FractalType.FBm, RotationType3D.ImproveXZPlanes)]
    [InlineData(FractalType.Ridged, RotationType3D.None)]
    [InlineData(FractalType.Ridged, RotationType3D.ImproveXYPlanes)]
    [InlineData(FractalType.Ridged, RotationType3D.ImproveXZPlanes)]
    public void ExceptionalCoordinatesRetainReleasedWideBits(FractalType fractal, RotationType3D rotation)
    {
        foreach (int octaves in new[] { 1, 4 })
            Compare(Request(fractal, rotation, octaves), ExceptionalCoordinates());
    }

    [Theory]
    [InlineData(FractalType.FBm)]
    [InlineData(FractalType.Ridged)]
    public void ExceptionalParametersRetainReleasedWideBits(FractalType fractal)
    {
        float nanA = BitConverter.Int32BitsToSingle(0x7FC12345);
        float nanB = BitConverter.Int32BitsToSingle(unchecked((int)0xFFC54321));
        float signaling = BitConverter.Int32BitsToSingle(0x7F812345);
        foreach (int octaves in new[] { 1, 4 })
        {
            var request = Request(fractal, RotationType3D.None, octaves);
            NoiseFillRequest3D[] cases =
            [
                request with { Frequency = nanA },
                request with { Frequency = signaling },
                request with { Frequency = float.PositiveInfinity },
                request with { Frequency = float.MaxValue, Lacunarity = float.MaxValue },
                request with { Frequency = -0f, FractalBounding = -0f, LastOctaveFade = -0f },
                request with { FractalBounding = nanA, LastOctaveFade = nanB },
                request with { WeightedStrength = nanA, Gain = nanB },
                request with { Lacunarity = nanA, WeightedStrength = nanB },
                request with { Gain = float.PositiveInfinity, LastOctaveFade = 0f },
                request with { FractalBounding = float.MaxValue, Gain = float.MaxValue },
                request with { LastOctaveFade = signaling },
            ];
            foreach (var item in cases)
            {
                Compare(item, FiniteCoordinates());
                Compare(item, ExceptionalCoordinates());
            }
        }
    }

    [Fact]
    public void ExpansionBudgetAndUnsupportedShapesRetainLegacyCalls()
    {
        var x = Expression.Parameter(typeof(Vector<float>), "x");
        var request = Request(FractalType.FBm, RotationType3D.None, 4);
        int budget = OpenSimplex3WideExpression.GraphOctaveBudget;
        for (int i = 0; i < 16; i++)
            Assert.True(OpenSimplex3WideExpression.TryEmit(request, x, x, x, ref budget, out _));
        Assert.Equal(0, budget);
        Assert.False(OpenSimplex3WideExpression.TryEmit(request, x, x, x, ref budget, out _));
        foreach (var unsupported in new[]
        {
            request with { NoiseType = NoiseType.Perlin },
            request with { FractalType = FractalType.None },
            request with { FractalType = FractalType.PingPong },
            request with { Octaves = 0 }, request with { Octaves = 5 },
        })
        {
            budget = 64;
            Assert.False(OpenSimplex3WideExpression.TryEmit(unsupported, x, x, x, ref budget, out _));
            Assert.Equal(64, budget);
            var node = new ProceduralNode { Operation = ProceduralOperation.Noise3D, NoiseRequest = unsupported, A = 0, B = 0, C = 0 };
            var call = Assert.IsAssignableFrom<MethodCallExpression>(ProceduralWideRuntime.Emit(node, _ => x, _ => ProceduralType.Float32, ref budget));
            Assert.Equal(typeof(ProceduralNoise), call.Method.DeclaringType);
            Assert.Equal(64, budget);
        }
    }

    [Theory]
    [InlineData(FractalType.FBm, false, false)]
    [InlineData(FractalType.FBm, false, true)]
    [InlineData(FractalType.FBm, true, false)]
    [InlineData(FractalType.FBm, true, true)]
    [InlineData(FractalType.Ridged, false, false)]
    [InlineData(FractalType.Ridged, false, true)]
    [InlineData(FractalType.Ridged, true, false)]
    [InlineData(FractalType.Ridged, true, true)]
    public void ExceptionalGraphBoundariesAndTailsRetainLegacyBits(FractalType fractal, bool exceptionalParameters, bool exceptionalCoordinates)
    {
        foreach (var rotation in Enum.GetValues<RotationType3D>())
        {
            var request = Request(fractal, rotation, 4);
            var otherRequest = exceptionalParameters
                ? request with { Seed = -317, FractalBounding = BitConverter.Int32BitsToSingle(0x7FC12345), LastOctaveFade = BitConverter.Int32BitsToSingle(unchecked((int)0xFFC54321)) }
                : request with { Seed = -317 };
            CompareGraph(request, otherRequest, exceptionalCoordinates ? ExceptionalCoordinates() : FiniteCoordinates());
        }
    }

    [Theory]
    [InlineData(FractalType.FBm)]
    [InlineData(FractalType.Ridged)]
    public void FiniteOverflowGraphsRetainLegacyBits(FractalType fractal)
    {
        foreach (var rotation in Enum.GetValues<RotationType3D>())
        foreach (int variant in new[] { 0, 1 })
        {
            var request = Request(fractal, rotation, 4) with
            {
                Frequency = variant == 0 ? .0037f : float.MaxValue,
                FractalBounding = float.MaxValue, Gain = float.MaxValue,
                Lacunarity = float.MaxValue, WeightedStrength = float.MaxValue,
            };
            Assert.True(OpenSimplex3WideExpression.HasFiniteParameters(request));
            CompareGraph(request, request with { Seed = -317 }, FiniteCoordinates());
            CompareGraph(request, request with { Seed = -317 }, ExceptionalCoordinates());
        }
    }

    private static void CompareGraph(NoiseFillRequest3D request, NoiseFillRequest3D otherRequest, float[] coordinates)
    {
        var nodes = new[]
        {
            new ProceduralNode { Id = 0, Operation = ProceduralOperation.Input, Type = ProceduralType.Float32, InputIndex = 0 },
            new ProceduralNode { Id = 1, Operation = ProceduralOperation.Input, Type = ProceduralType.Float32, InputIndex = 1 },
            new ProceduralNode { Id = 2, Operation = ProceduralOperation.Input, Type = ProceduralType.Float32, InputIndex = 2 },
            new ProceduralNode { Id = 3, Operation = ProceduralOperation.Noise3D, Type = ProceduralType.Float32, A = 0, B = 1, C = 2, NoiseRequest = request },
            new ProceduralNode { Id = 4, Operation = ProceduralOperation.Noise3D, Type = ProceduralType.Float32, A = 1, B = 2, C = 0,
                NoiseRequest = otherRequest },
            new ProceduralNode { Id = 5, Operation = ProceduralOperation.Add, Type = ProceduralType.Float32, A = 3, B = 4 },
        };
        var program = new CompiledProceduralGraph(nodes, [3, 4, 5], nodes.Length);
        var legacy = CompileLegacy(program);
        int lanes = Vector<float>.Count, count = lanes * 2 + 3;
        double[] input = new double[count * 3], expected = new double[count * 3], actual = new double[count * 3 + 5];
        for (int i = 0; i < input.Length; i++) input[i] = coordinates[(i * 5) % coordinates.Length];
        Array.Fill(actual, 12345d);
        int record = 0;
        if (program.IsVectorised)
            for (; record <= count - lanes; record += lanes)
                legacy(input.AsSpan(record * 3), expected.AsSpan(record * 3));
        for (; record < count; record++)
            program.Evaluate(input.AsSpan(record * 3), expected.AsSpan(record * 3));
        program.Fill(input, actual, count, NoiseBackend.Auto);
        for (int i = 0; i < expected.Length; i++)
            Assert.True(BitConverter.DoubleToInt64Bits(expected[i]) == BitConverter.DoubleToInt64Bits(actual[i]),
                $"{request}; output={i}; expected={BitConverter.DoubleToInt64Bits(expected[i]):X16} actual={BitConverter.DoubleToInt64Bits(actual[i]):X16}");
        Assert.All(actual[expected.Length..], value => Assert.Equal(12345d, value));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void IndependentExceptionalArithmeticRetainsLegacyBits(bool exceptionalConstant)
    {
        var graph = new ProceduralGraph();
        var x = graph.Input(0, ProceduralType.Float32);
        var y = graph.Input(1, ProceduralType.Float32);
        var z = graph.Input(2, ProceduralType.Float32);
        var a = graph.Input(3, ProceduralType.Float32);
        var b = graph.Input(4, ProceduralType.Float32);
        var c = graph.Input(5, ProceduralType.Float64);
        var d = graph.Input(6, ProceduralType.Float64);
        var noise = graph.Noise3D(new NoiseGenerator(1337)
        {
            NoiseType = NoiseType.OpenSimplex2, FractalType = FractalType.FBm,
            Frequency = .0037f, Octaves = 4, WeightedStrength = .4f, Lod = LodPolicy.Disabled,
        }, x, y, z);
        var constant = graph.Constant(exceptionalConstant ? BitConverter.Int64BitsToDouble(unchecked((long)0xFFF8123456789ABC)) : .125d);
        var program = graph.Compile(noise, a + b, a * b, a - b, a * graph.Constant(0f),
            a + graph.Constant(-0f), c + d, c * d, c - d, c * graph.Constant(0d),
            c + constant, graph.Convert(noise, ProceduralType.Float64) + c);
        var legacy = CompileLegacy(program);
        int lanes = Vector<float>.Count, count = lanes * 3 + 3;
        double[] exceptional =
        [
            BitConverter.Int32BitsToSingle(0x7FC12345), BitConverter.Int32BitsToSingle(unchecked((int)0xFFC54321)),
            BitConverter.Int64BitsToDouble(0x7FF0123456789ABC),
            BitConverter.Int64BitsToDouble(unchecked((long)0xFFF056789ABC1234)),
            double.PositiveInfinity, double.NegativeInfinity, 0d, -0d,
        ];
        double[] input = new double[count * 7], expected = new double[count * program.OutputCount], actual = new double[count * program.OutputCount];
        for (int i = 0; i < count; i++)
        {
            input[i * 7] = i * .125; input[i * 7 + 1] = i * -.25; input[i * 7 + 2] = 11d;
            for (int j = 3; j < 7; j++) input[i * 7 + j] = exceptional[(i + j * 3) % exceptional.Length];
        }
        int record = 0;
        if (program.IsVectorised)
            for (; record <= count - lanes; record += lanes)
                legacy(input.AsSpan(record * 7), expected.AsSpan(record * program.OutputCount));
        for (; record < count; record++)
            program.Evaluate(input.AsSpan(record * 7), expected.AsSpan(record * program.OutputCount));
        program.Fill(input, actual, count, NoiseBackend.Auto);
        for (int i = 0; i < expected.Length; i++)
            Assert.True(BitConverter.DoubleToInt64Bits(expected[i]) == BitConverter.DoubleToInt64Bits(actual[i]),
                $"constantExceptional={exceptionalConstant}; record={i / program.OutputCount} output={i % program.OutputCount}; expected={BitConverter.DoubleToInt64Bits(expected[i]):X16} actual={BitConverter.DoubleToInt64Bits(actual[i]):X16}");
    }

    [Theory]
    [InlineData(1)]
    [InlineData(4)]
    [InlineData(5)]
    [InlineData(17)]
    public void GraphBudgetMixedOutputsAndScalarTailsRetainLegacyBits(int sources)
    {
        var graph = new ProceduralGraph();
        var x = graph.Input(0, ProceduralType.Float32);
        var y = graph.Input(1, ProceduralType.Float32);
        var z = graph.Input(2, ProceduralType.Float32);
        List<ProceduralValue> fields = [];
        for (int i = 0; i < sources; i++)
            fields.Add(graph.Noise3D(new NoiseGenerator(int.MaxValue - i)
            {
                NoiseType = NoiseType.OpenSimplex2,
                FractalType = i % 2 == 0 ? FractalType.FBm : FractalType.Ridged,
                RotationType3D = (RotationType3D)(i % 3),
                Frequency = .0037f, Octaves = 4, Gain = .65f, Lacunarity = 2.3f,
                WeightedStrength = .4f, Lod = LodPolicy.Disabled,
            }, x, y, z));
        fields.Add(graph.Convert(x * y + z, ProceduralType.Float64));
        var program = graph.Compile(fields.ToArray());
        var legacy = CompileLegacy(program);
        int lanes = Vector<float>.Count;
        int count = lanes * 2 + 3;
        double[] input = new double[count * 3];
        for (int i = 0; i < input.Length; i++) input[i] = ((i * 83) % 257 - 128) * .125;
        double[] expected = new double[count * program.OutputCount];
        double[] actual = Enumerable.Repeat(12345d, expected.Length + 5).ToArray();
        int record = 0;
        if (program.IsVectorised)
            for (; record <= count - lanes; record += lanes)
                legacy(input.AsSpan(record * 3), expected.AsSpan(record * program.OutputCount));
        for (; record < count; record++)
            program.Evaluate(input.AsSpan(record * 3), expected.AsSpan(record * program.OutputCount));
        foreach (var backend in new[] { NoiseBackend.Auto, NoiseBackend.Simd })
        {
            program.Fill(input, actual, count, backend);
            for (int i = 0; i < expected.Length; i++)
                Assert.Equal(BitConverter.DoubleToInt64Bits(expected[i]), BitConverter.DoubleToInt64Bits(actual[i]));
            Assert.All(actual[expected.Length..], value => Assert.Equal(12345d, value));
        }
    }

    private static void Compare(NoiseFillRequest3D request, float[] coordinates)
    {
        var x = Expression.Parameter(typeof(Vector<float>), "x");
        var y = Expression.Parameter(typeof(Vector<float>), "y");
        var z = Expression.Parameter(typeof(Vector<float>), "z");
        int budget = 64;
        Assert.True(OpenSimplex3WideExpression.TryEmit(request, x, y, z, ref budget, out var expression));
        var emitted = Expression.Lambda<WideNoise>(expression, x, y, z).Compile();
        var released = new ProceduralNoise(request);
        int lanes = Vector<float>.Count;
        for (int group = 0; group < 4; group++)
        {
            float[] a = new float[lanes], b = new float[lanes], c = new float[lanes];
            for (int lane = 0; lane < lanes; lane++)
            {
                a[lane] = coordinates[(lane + group) % coordinates.Length];
                b[lane] = coordinates[(lane * 3 + group + 1) % coordinates.Length];
                c[lane] = coordinates[(lane * 5 + group + 2) % coordinates.Length];
            }
            var expected = released.SampleOpenSimplex3Wide(new(a), new(b), new(c));
            var actual = emitted(new(a), new(b), new(c));
            for (int lane = 0; lane < lanes; lane++)
            {
                int expectedBits = BitConverter.SingleToInt32Bits(expected[lane]);
                int actualBits = BitConverter.SingleToInt32Bits(actual[lane]);
                Assert.True(expectedBits == actualBits,
                    $"{request}; group={group} lane={lane} XYZ={BitConverter.SingleToInt32Bits(a[lane]):X8}/{BitConverter.SingleToInt32Bits(b[lane]):X8}/{BitConverter.SingleToInt32Bits(c[lane]):X8}; expected={expectedBits:X8} actual={actualBits:X8}");
            }
        }
    }

    private static NoiseFillRequest3D Request(FractalType fractal, RotationType3D rotation, int octaves) => new()
    {
        Seed = int.MaxValue - 1, Frequency = .0037f, NoiseType = NoiseType.OpenSimplex2,
        RotationType3D = rotation, FractalType = fractal, Octaves = octaves,
        Gain = .65f, Lacunarity = 2.3f, WeightedStrength = .4f,
        FractalBounding = .49382716f, LastOctaveFade = .375f,
        Region = new GridRegion3D(0f, 0f, 0f, 1, 1, 1),
    };

    private static float[] FiniteCoordinates() => [-257.25f, 0f, -0f, 113f, 8192.125f, -.125f, 1e-20f, -98304.5f, 131071f];
    private static float[] ExceptionalCoordinates() =>
    [
        0f, -0f, float.PositiveInfinity, float.NegativeInfinity, float.MaxValue, -float.MaxValue,
        BitConverter.Int32BitsToSingle(0x7FC12345), BitConverter.Int32BitsToSingle(unchecked((int)0xFFC54321)),
        BitConverter.Int32BitsToSingle(0x7F812345), float.Epsilon, -float.Epsilon, 1f,
    ];

    private static WideExecutor CompileLegacy(CompiledProceduralGraph program)
    {
        var input = Expression.Parameter(typeof(ReadOnlySpan<double>), "input");
        var output = Expression.Parameter(typeof(Span<double>), "output");
        var locals = program.Nodes.Select(node => Expression.Variable(ProceduralWideRuntime.ClrType(node.Type), $"legacy{node.Id}")).ToArray();
        List<Expression> body = [];
        foreach (var node in program.Nodes)
            body.Add(Expression.Assign(locals[node.Id], node.Operation == ProceduralOperation.Input
                ? ProceduralWideRuntime.Read(input, node.InputIndex, program.InputCount, node.Type)
                : ProceduralWideRuntime.Emit(node, id => locals[id], id => program.Nodes[id].Type)));
        for (int i = 0; i < program.OutputCount; i++)
            body.Add(ProceduralRuntime.Call(typeof(ProceduralWideRuntime), nameof(ProceduralWideRuntime.Write),
                output, Expression.Constant(i), Expression.Constant(program.OutputCount),
                ProceduralWideRuntime.ToOutput(locals[program.Outputs[i]], program.Nodes[program.Outputs[i]].Type)));
        return Expression.Lambda<WideExecutor>(Expression.Block(locals, body), input, output).Compile();
    }
}

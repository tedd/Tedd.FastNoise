; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC6579BF78
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC6579BF7C
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC657BCDA8
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC657BCDAC
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC657BCDA8
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC657BCDAC
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 66400
; 2 inlinees with PGO data; 295 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       sub      rsp, 0x458
       vmovaps  xmmword ptr [rsp+0x440], xmm6
       vmovaps  xmmword ptr [rsp+0x430], xmm7
       vmovaps  xmmword ptr [rsp+0x420], xmm8
       vmovaps  xmmword ptr [rsp+0x410], xmm9
       vmovaps  xmmword ptr [rsp+0x400], xmm10
       vmovaps  xmmword ptr [rsp+0x3F0], xmm11
       vmovaps  xmmword ptr [rsp+0x3E0], xmm12
       vmovaps  xmmword ptr [rsp+0x3D0], xmm13
       vmovaps  xmmword ptr [rsp+0x3C0], xmm14
       vmovaps  xmmword ptr [rsp+0x3B0], xmm15
       mov      rax, bword ptr [rsp+0x480]
 
G_M000_IG02:                ;; offset=0x0069
       vmovups  ymm0, ymmword ptr [r8]
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm0, ymm1
       vbroadcastss ymm2, dword ptr [reloc @RWD00]
       vbroadcastss ymm3, dword ptr [reloc @RWD04]
       vmovups  ymmword ptr [rsp+0xC0], ymm3
       vblendvps ymm1, ymm3, ymm2, ymm1
       vaddps   ymm1, ymm1, ymm0
       vcmpeqps ymm4, ymm1, ymm1
       vandps   ymm1, ymm4, ymm1
       vbroadcastss ymm4, dword ptr [reloc @RWD08]
       vcmpgeps ymm5, ymm1, ymm4
       vbroadcastss ymm6, dword ptr [reloc @RWD12]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymm6, ymm5
       vmovups  ymm5, ymmword ptr [r9]
       vxorps   ymm7, ymm7, ymm7
       vcmpltps ymm7, ymm5, ymm7
       vblendvps ymm7, ymm3, ymm2, ymm7
       vaddps   ymm7, ymm7, ymm5
       vcmpeqps ymm8, ymm7, ymm7
       vandps   ymm7, ymm8, ymm7
       vcmpgeps ymm8, ymm7, ymm4
       vcvttps2dq ymm7, ymm7
       vpblendvb ymm7, ymm7, ymm6, ymm8
       vmovups  ymm8, ymmword ptr [rax]
       vxorps   ymm9, ymm9, ymm9
       vcmpltps ymm9, ymm8, ymm9
       vblendvps ymm2, ymm3, ymm2, ymm9
       vaddps   ymm2, ymm2, ymm8
       vcmpeqps ymm9, ymm2, ymm2
       vandps   ymm2, ymm9, ymm2
       vcmpgeps ymm9, ymm2, ymm4
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm6, ymm9
       vcvtdq2ps ymm9, ymm1
       vsubps   ymm0, ymm0, ymm9
       vcvtdq2ps ymm9, ymm7
       vsubps   ymm5, ymm5, ymm9
       vcvtdq2ps ymm9, ymm2
       vsubps   ymm8, ymm8, ymm9
       vbroadcastss ymm9, dword ptr [reloc @RWD16]
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       vmovaps  ymm10, ymm9
       vbroadcastss ymm11, dword ptr [reloc @RWD20]
       vsubps   ymm12, ymm11, ymm0
       vcmpeqps ymm13, ymm12, ymm12
       vandps   ymm12, ymm13, ymm12
       vcmpgeps ymm13, ymm12, ymm4
       vcvttps2dq ymm12, ymm12
       vpblendvb ymm12, ymm12, ymm6, ymm13
       vpor     ymm12, ymm12, ymm10
       vsubps   ymm13, ymm11, ymm5
       vcmpeqps ymm14, ymm13, ymm13
       vandps   ymm13, ymm14, ymm13
       vcmpgeps ymm14, ymm13, ymm4
       vcvttps2dq ymm13, ymm13
       vpblendvb ymm13, ymm13, ymm6, ymm14
       vpor     ymm13, ymm13, ymm10
       vsubps   ymm11, ymm11, ymm8
       vcmpeqps ymm14, ymm11, ymm11
       vandps   ymm11, ymm14, ymm11
 
G_M000_IG03:                ;; offset=0x01BB
       vcmpgeps ymm4, ymm11, ymm4
       vcvttps2dq ymm11, ymm11
       vpblendvb ymm4, ymm11, ymm6, ymm4
       vpor     ymm4, ymm4, ymm10
       vbroadcastss ymm6, dword ptr [reloc @RWD24]
       vxorps   ymm10, ymm6, ymm0
       vmovups  ymmword ptr [rsp+0x340], ymm12
       vcvtdq2ps ymm11, ymm12
       vmulps   ymm10, ymm10, ymm11
       vxorps   ymm11, ymm6, ymm5
       vmovups  ymmword ptr [rsp+0x320], ymm13
       vcvtdq2ps ymm14, ymm13
       vmulps   ymm11, ymm11, ymm14
       vxorps   ymm14, ymm6, ymm8
       vmovups  ymmword ptr [rsp+0x300], ymm4
       vcvtdq2ps ymm15, ymm4
       vmulps   ymm14, ymm14, ymm15
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD32]
       vpmulld  ymm7, ymm7, ymmword ptr [reloc @RWD64]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD96]
       vbroadcastss ymm15, dword ptr [reloc @RWD32]
       vmovups  ymmword ptr [rsp+0x2E0], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rsp+0x2C0], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0x2A0], ymm15
       vxorps   ymm15, ymm15, ymm15
       vxorps   ymm9, ymm9, ymm9
       vmulps   ymm3, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0x390], ymm3
       vmulps   ymm3, ymm8, ymm8
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x390]
       vmovups  ymmword ptr [rsp+0x390], ymm3
       vmulps   ymm3, ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x370], ymm3
       vbroadcastss ymm3, dword ptr [reloc @RWD128]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x370]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x390]
       xor      eax, eax
       mov      r8, 0x13A6C800C10
       mov      r8, gword ptr [r8]
 
G_M000_IG04:                ;; offset=0x02D4
       vcmpgtps ymm4, ymm3, ymm15
       vmovups  ymmword ptr [rsp+0x260], ymm4
       vmulps   ymm4, ymm3, ymm3
       vmulps   ymm4, ymm4, ymm4
       vmovups  ymmword ptr [rsp+0x120], ymm4
       vmovups  ymm4, ymmword ptr [rdx]
       vmovups  ymmword ptr [rsp+0x80], ymm4
       vpxor    ymm4, ymm1, ymm4
       vpxor    ymm4, ymm4, ymm7
       vpxor    ymm4, ymm4, ymm2
       vmovups  ymmword ptr [rsp+0x390], ymm4
       vbroadcastss ymm4, dword ptr [reloc @RWD132]
       vmovups  ymmword ptr [rsp+0x60], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x390]
       vpmulld  ymm4, ymm4, ymmword ptr [rsp+0x60]
       vpsrad   ymm13, ymm4, 15
       vpxor    ymm4, ymm13, ymm4
       vbroadcastss ymm13, dword ptr [reloc @RWD136]
       vmovups  ymmword ptr [rsp+0x40], ymm13
       vpand    ymm4, ymm4, ymm13
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm4, ymm4, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm12, dword ptr [r10+4*xmm4], ymm13
       vmovups  ymmword ptr [rsp+0xE0], ymm12
       vbroadcastss ymm4, dword ptr [reloc @RWD140]
       vmovups  ymmword ptr [rsp+0x20], ymm4
       vpand    ymm13, ymm4, ymm12
       vxorps   ymm4, ymm4, ymm4
       vpcmpeqd ymm4, ymm4, ymm13
       vmovups  ymmword ptr [rsp+0x390], ymm4
       vpslld   ymm4, ymm12, 29
       vpand    ymm4, ymm4, ymm6
       vpxor    ymm4, ymm4, ymm0
       vmovups  ymm12, ymmword ptr [rsp+0x390]
       vblendvps ymm4, ymm4, ymm15, ymm12
       vmovups  ymmword ptr [rsp+0x390], ymm4
       vmovups  ymm12, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm12, ymm12, ymm13
       vmovups  ymm4, ymmword ptr [rsp+0xE0]
       vpslld   ymm4, ymm4, 28
       vpand    ymm4, ymm4, ymm6
       vpxor    ymm4, ymm4, ymm5
       vblendvps ymm4, ymm4, ymm15, ymm12
       vaddps   ymm4, ymm4, ymmword ptr [rsp+0x390]
       vbroadcastss ymm12, dword ptr [reloc @RWD144]
       vmovups  ymmword ptr [rsp], ymm12
       vpcmpeqd ymm13, ymm12, ymm13
       vmovups  ymm12, ymmword ptr [rsp+0xE0]
       vpslld   ymm12, ymm12, 27
       vpand    ymm12, ymm12, ymm6
       vpxor    ymm12, ymm12, ymm8
       vblendvps ymm12, ymm12, ymm15, ymm13
       vaddps   ymm4, ymm12, ymm4
       vmovups  ymm12, ymmword ptr [rsp+0x120]
       vmulps   ymm4, ymm12, ymm4
       vmovups  ymm12, ymmword ptr [rsp+0x260]
 
G_M000_IG05:                ;; offset=0x043C
       vandps   ymm4, ymm4, ymm12
       vandnps  ymm12, ymm12, ymm15
       vorps    ymm4, ymm12, ymm4
       vaddps   ymm9, ymm4, ymm9
       vmovups  ymmword ptr [rsp+0x280], ymm9
       vcmpnltps ymm4, ymm10, ymm11
       vcmpnltps ymm12, ymm10, ymm14
       vpand    ymm4, ymm12, ymm4
       vcmpgtps ymm12, ymm11, ymm10
       vcmpnltps ymm13, ymm11, ymm14
       vpand    ymm12, ymm13, ymm12
       vpandn   ymm12, ymm4, ymm12
       vpor     ymm13, ymm4, ymm12
       vmovups  ymmword ptr [rsp+0x390], ymm13
       vpcmpeqd ymm13, ymm13, ymm13
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x390]
       vmovups  ymmword ptr [rsp+0x240], ymm13
       vandps   ymm13, ymm10, ymm4
       vmovups  ymmword ptr [rsp+0x390], ymm13
       vandps   ymm13, ymm11, ymm12
       vmovups  ymmword ptr [rsp+0x370], ymm13
       vandnps  ymm13, ymm12, ymm14
       vorps    ymm13, ymm13, ymmword ptr [rsp+0x370]
       vandnps  ymm13, ymm4, ymm13
       vorps    ymm13, ymm13, ymmword ptr [rsp+0x390]
       vmovups  ymmword ptr [rsp+0x220], ymm13
       vaddps   ymm13, ymm3, ymm13
       vaddps   ymm13, ymm13, ymmword ptr [rsp+0x220]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD160]
       vmovups  ymm9, ymmword ptr [rsp+0x340]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x2E0]
       vpand    ymm9, ymm9, ymm4
       vmovups  ymmword ptr [rsp+0x390], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm4, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x390]
       vpsubd   ymm9, ymm1, ymm9
       vmovups  ymmword ptr [rsp+0x200], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x320]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x2C0]
       vpand    ymm9, ymm9, ymm12
       vmovups  ymmword ptr [rsp+0x390], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm12, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x390]
       vpsubd   ymm9, ymm7, ymm9
       vmovups  ymmword ptr [rsp+0x1E0], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x300]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x2A0]
       vpand    ymm9, ymm9, ymmword ptr [rsp+0x240]
       vmovups  ymmword ptr [rsp+0x390], ymm9
       vxorps   ymm9, ymm9, ymm9
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x240]
       vpandn   ymm9, ymm9, ymmword ptr [rsp+0x370]
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x390]
       vpsubd   ymm9, ymm2, ymm9
       vmovups  ymmword ptr [rsp+0x1C0], ymm9
       vcvtdq2ps ymm9, ymmword ptr [rsp+0x340]
 
G_M000_IG06:                ;; offset=0x05E1
       vandps   ymm9, ymm9, ymm4
       vandnps  ymm4, ymm4, ymm15
       vorps    ymm4, ymm4, ymm9
       vaddps   ymm0, ymm4, ymm0
       vmovups  ymmword ptr [rsp+0x1A0], ymm0
       vmovups  ymm9, ymmword ptr [rsp+0x320]
       vcvtdq2ps ymm4, ymm9
       vandps   ymm4, ymm4, ymm12
       vandnps  ymm12, ymm12, ymm15
       vorps    ymm4, ymm12, ymm4
       vaddps   ymm5, ymm4, ymm5
       vmovups  ymmword ptr [rsp+0x180], ymm5
       vmovups  ymm4, ymmword ptr [rsp+0x300]
       vcvtdq2ps ymm12, ymm4
       vmovups  ymm5, ymmword ptr [rsp+0x240]
       vandps   ymm12, ymm12, ymm5
       vandnps  ymm5, ymm5, ymm15
       vorps    ymm5, ymm5, ymm12
       vaddps   ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0x160], ymm5
       vcmpgtps ymm8, ymm13, ymm15
       vmovups  ymmword ptr [rsp+0x140], ymm8
       vmulps   ymm12, ymm13, ymm13
       vmulps   ymm12, ymm12, ymm12
       vmovups  ymmword ptr [rsp+0x100], ymm12
       vmovups  ymm13, ymmword ptr [rsp+0x200]
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x80]
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x1E0]
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x1C0]
       vpmulld  ymm13, ymm13, ymmword ptr [rsp+0x60]
       vpsrad   ymm5, ymm13, 15
       vpxor    ymm5, ymm5, ymm13
       vpand    ymm13, ymm5, ymmword ptr [rsp+0x40]
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm5, ymm13, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm0, dword ptr [r10+4*xmm5], ymm13
       vmovups  ymm5, ymmword ptr [rsp+0x20]
       vpand    ymm5, ymm5, ymm0
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm5
       vpslld   ymm8, ymm0, 29
       vpand    ymm8, ymm8, ymm6
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x1A0]
       vblendvps ymm8, ymm8, ymm15, ymm13
       vmovups  ymm13, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm13, ymm13, ymm5
       vpslld   ymm12, ymm0, 28
       vpand    ymm12, ymm12, ymm6
       vpxor    ymm12, ymm12, ymmword ptr [rsp+0x180]
       vblendvps ymm12, ymm12, ymm15, ymm13
       vaddps   ymm8, ymm12, ymm8
       vmovups  ymm12, ymmword ptr [rsp]
       vpcmpeqd ymm5, ymm12, ymm5
       vpslld   ymm0, ymm0, 27
       vpand    ymm0, ymm0, ymm6
       vpxor    ymm0, ymm0, ymmword ptr [rsp+0x160]
       vblendvps ymm0, ymm0, ymm15, ymm5
 
G_M000_IG07:                ;; offset=0x0743
       vaddps   ymm0, ymm0, ymm8
       vmovups  ymm12, ymmword ptr [rsp+0x100]
       vmulps   ymm0, ymm12, ymm0
       vmovups  ymm8, ymmword ptr [rsp+0x140]
       vandps   ymm0, ymm0, ymm8
       vandnps  ymm5, ymm8, ymm15
       vorps    ymm0, ymm5, ymm0
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x280]
       cmp      eax, 1
       jne      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x077A
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rcx], ymm0
       mov      rax, rcx
 
G_M000_IG09:                ;; offset=0x0789
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x440]
       vmovaps  xmm7, xmmword ptr [rsp+0x430]
       vmovaps  xmm8, xmmword ptr [rsp+0x420]
       vmovaps  xmm9, xmmword ptr [rsp+0x410]
       vmovaps  xmm10, xmmword ptr [rsp+0x400]
       vmovaps  xmm11, xmmword ptr [rsp+0x3F0]
       vmovaps  xmm12, xmmword ptr [rsp+0x3E0]
       vmovaps  xmm13, xmmword ptr [rsp+0x3D0]
       vmovaps  xmm14, xmmword ptr [rsp+0x3C0]
       vmovaps  xmm15, xmmword ptr [rsp+0x3B0]
       add      rsp, 0x458
       ret      
 
G_M000_IG10:                ;; offset=0x07EE
       vmovups  ymm5, ymmword ptr [rsp+0xC0]
       vsubps   ymm10, ymm5, ymm10
       vsubps   ymm11, ymm5, ymm11
       vsubps   ymm14, ymm5, ymm14
       vmovups  ymm8, ymmword ptr [rsp+0x340]
       vcvtdq2ps ymm12, ymm8
       vmulps   ymm12, ymm12, ymm10
       vcvtdq2ps ymm13, ymm9
       vmulps   ymm13, ymm13, ymm11
       vmovups  ymmword ptr [rsp+0x300], ymm4
       vcvtdq2ps ymm5, ymm4
       vmulps   ymm5, ymm5, ymm14
       vaddps   ymm4, ymm11, ymm14
       vmovups  ymmword ptr [rsp+0x390], ymm4
       vbroadcastss ymm4, dword ptr [reloc @RWD224]
       vsubps   ymm4, ymm4, ymm10
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x390]
       vaddps   ymm3, ymm4, ymm3
       vpsrad   ymm4, ymm8, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x2E0]
       vpaddd   ymm1, ymm4, ymm1
       vpsrad   ymm4, ymm9, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x2C0]
       vpaddd   ymm7, ymm4, ymm7
       vmovups  ymm4, ymmword ptr [rsp+0x300]
       vpsrad   ymm4, ymm4, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x2A0]
       vpaddd   ymm2, ymm4, ymm2
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm8, ymm4, ymm8
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm9, ymm4, ymm9
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm4, ymm4, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm4
       vpcmpeqd ymm4, ymm4, ymm4
       vpxor    ymm4, ymm4, ymmword ptr [rsp+0x80]
       vmovups  ymmword ptr [rdx], ymm4
       inc      eax
       vmovups  ymmword ptr [rsp+0x340], ymm8
       vmovups  ymmword ptr [rsp+0x320], ymm9
       vmovaps  ymm8, ymm5
       vmovaps  ymm5, ymm13
       vmovaps  ymm9, ymm0
       vmovaps  ymm0, ymm12
       jmp      G_M000_IG04
 
RWD00  	dd	BF000000h		;      -0.5
RWD04  	dd	3F000000h		;       0.5
RWD08  	dd	4F000000h		; 2.14748e+09
RWD12  	dd	7FFFFFFFh		;       nan
RWD16  	dd	00000001h		; 1.4013e-45
RWD20  	dd	BF800000h		;        -1
RWD24  	dd	80000000h		;        -0
RWD28  	dd	00000000h
RWD32  	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD64  	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD96  	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD128 	dd	3F19999Ah		;       0.6
RWD132 	dd	27D4EB2Dh		; 5.90968e-15
RWD136 	dd	000000FCh		; 3.53127e-43
RWD140 	dd	00000003h		; 4.2039e-45
RWD144 	dd	00000002h		; 2.8026e-45
RWD148 	dd	00000000h, 00000000h, 00000000h
RWD160 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD192 	dq	4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h
RWD224 	dd	3F400000h		;      0.75

; Total bytes of code 2307

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       lea      r11, [rsp-0x29F0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       lea      rbp, [rsp+0x29F0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x490], xmm4
       vmovdqa  xmmword ptr [rbp-0x480], xmm4
       mov      rax, -0x420
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      qword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x005F
       mov      dword ptr [rbp-0xEF8], 0x3E8
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF30], ymm0
       lea      rdx, [rbp-0xF30]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF50], ymm0
       lea      rdx, [rbp-0xF50]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xF70], ymm0
       lea      rdx, [rbp-0xF70]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.NoiseMath:FastRound[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF90], ymm0
       lea      rdx, [rbp-0xF90]
       lea      rcx, [rbp-0x4B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0xFB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4B0]
       vmovups  ymmword ptr [rbp-0xFD0], ymm0
       lea      rdx, [rbp-0xFB0]
       lea      r8, [rbp-0xFD0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0xFF0], ymm0
       lea      rdx, [rbp-0xFF0]
       lea      rcx, [rbp-0x4D0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4D0]
       vmovups  ymmword ptr [rbp-0x1030], ymm0
       lea      rdx, [rbp-0x1010]
       lea      r8, [rbp-0x1030]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1050], ymm0
       lea      rdx, [rbp-0x1050]
       lea      rcx, [rbp-0x4F0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x1070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x4F0]
       vmovups  ymmword ptr [rbp-0x1090], ymm0
       lea      rdx, [rbp-0x1070]
 
G_M000_IG03:                ;; offset=0x01D8
       lea      r8, [rbp-0x1090]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rbp-0x130]
       mov      edx, 1
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x510]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x510]
       vmovups  ymmword ptr [rbp-0x10B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x10D0], ymm0
       lea      rdx, [rbp-0x10B0]
       lea      r8, [rbp-0x10D0]
       lea      rcx, [rbp-0x530]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x530]
       vmovups  ymmword ptr [rbp-0x10F0], ymm0
       lea      rdx, [rbp-0x10F0]
       lea      rcx, [rbp-0x550]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x550]
       vmovups  ymmword ptr [rbp-0x1110], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1130], ymm0
       lea      rdx, [rbp-0x1110]
       lea      r8, [rbp-0x1130]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x570]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x570]
       vmovups  ymmword ptr [rbp-0x1150], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1170], ymm0
       lea      rdx, [rbp-0x1150]
       lea      r8, [rbp-0x1170]
       lea      rcx, [rbp-0x590]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x590]
       vmovups  ymmword ptr [rbp-0x1190], ymm0
       lea      rdx, [rbp-0x1190]
       lea      rcx, [rbp-0x5B0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x5B0]
       vmovups  ymmword ptr [rbp-0x11B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x11D0], ymm0
       lea      rdx, [rbp-0x11B0]
       lea      r8, [rbp-0x11D0]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovss   xmm1, dword ptr [reloc @RWD00]
       lea      rcx, [rbp-0x5D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5D0]
       vmovups  ymmword ptr [rbp-0x11F0], ymm0
 
G_M000_IG04:                ;; offset=0x0381
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1210], ymm0
       lea      rdx, [rbp-0x11F0]
       lea      r8, [rbp-0x1210]
       lea      rcx, [rbp-0x5F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x5F0]
       vmovups  ymmword ptr [rbp-0x1230], ymm0
       lea      rdx, [rbp-0x1230]
       lea      rcx, [rbp-0x610]
       call     [Tedd.FastNoise.Internal.VectorOps:ToInt(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x610]
       vmovups  ymmword ptr [rbp-0x1250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x130]
       vmovups  ymmword ptr [rbp-0x1270], ymm0
       lea      rdx, [rbp-0x1250]
       lea      r8, [rbp-0x1270]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1290], ymm0
       lea      rdx, [rbp-0x1290]
       lea      rcx, [rbp-0x630]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x12B0], ymm0
       lea      rdx, [rbp-0x12B0]
       lea      rcx, [rbp-0x650]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x630]
       vmovups  ymmword ptr [rbp-0x12D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x650]
       vmovups  ymmword ptr [rbp-0x12F0], ymm0
       lea      rdx, [rbp-0x12D0]
       lea      r8, [rbp-0x12F0]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1310], ymm0
       lea      rdx, [rbp-0x1310]
       lea      rcx, [rbp-0x670]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1330], ymm0
       lea      rdx, [rbp-0x1330]
       lea      rcx, [rbp-0x690]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x670]
       vmovups  ymmword ptr [rbp-0x1350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x690]
       vmovups  ymmword ptr [rbp-0x1370], ymm0
       lea      rdx, [rbp-0x1350]
       lea      r8, [rbp-0x1370]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1390], ymm0
       lea      rdx, [rbp-0x1390]
       lea      rcx, [rbp-0x6B0]
 
G_M000_IG05:                ;; offset=0x052F
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x13B0], ymm0
       lea      rdx, [rbp-0x13B0]
       lea      rcx, [rbp-0x6D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Neg(System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x6B0]
       vmovups  ymmword ptr [rbp-0x13D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x6D0]
       vmovups  ymmword ptr [rbp-0x13F0], ymm0
       lea      rdx, [rbp-0x13D0]
       lea      r8, [rbp-0x13F0]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1410], ymm0
       lea      rdx, [rbp-0x1410]
       lea      rcx, [rbp-0x70]
       mov      r8d, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1430], ymm0
       lea      rdx, [rbp-0x1430]
       lea      rcx, [rbp-0x90]
       mov      r8d, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1450], ymm0
       lea      rdx, [rbp-0x1450]
       lea      rcx, [rbp-0xB0]
       mov      r8d, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.Hashing:Prime[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x210]
       mov      edx, 0x1DDE90C9
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x230]
       mov      edx, 0x43C42E4D
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0x250]
       mov      edx, 0x668B6E2F
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vxorps   xmm1, xmm1, xmm1
       lea      rcx, [rbp-0x270]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x290], ymm0
       vmovss   xmm1, dword ptr [reloc @RWD04]
       lea      rcx, [rbp-0x6F0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1490], ymm0
       lea      rdx, [rbp-0x1470]
       lea      r8, [rbp-0x1490]
       lea      rcx, [rbp-0x710]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
 
G_M000_IG06:                ;; offset=0x06B3
       vmovups  ymm0, ymmword ptr [rbp-0x6F0]
       vmovups  ymmword ptr [rbp-0x14B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x710]
       vmovups  ymmword ptr [rbp-0x14D0], ymm0
       lea      rdx, [rbp-0x14B0]
       lea      r8, [rbp-0x14D0]
       lea      rcx, [rbp-0x730]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x14F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1510], ymm0
       lea      rdx, [rbp-0x14F0]
       lea      r8, [rbp-0x1510]
       lea      rcx, [rbp-0x750]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1550], ymm0
       lea      rdx, [rbp-0x1530]
       lea      r8, [rbp-0x1550]
       lea      rcx, [rbp-0x770]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x750]
       vmovups  ymmword ptr [rbp-0x1570], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x770]
       vmovups  ymmword ptr [rbp-0x1590], ymm0
       lea      rdx, [rbp-0x1570]
       lea      r8, [rbp-0x1590]
       lea      rcx, [rbp-0x790]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x730]
       vmovups  ymmword ptr [rbp-0x15B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x790]
       vmovups  ymmword ptr [rbp-0x15D0], ymm0
       lea      rdx, [rbp-0x15B0]
       lea      r8, [rbp-0x15D0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       xor      eax, eax
       mov      dword ptr [rbp-0x2B4], eax
 
G_M000_IG07:                ;; offset=0x07E2
       mov      eax, dword ptr [rbp-0xEF8]
       dec      eax
       mov      dword ptr [rbp-0xEF8], eax
       cmp      dword ptr [rbp-0xEF8], 0
       jg       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x07F9
       lea      rcx, [rbp-0xEF8]
       mov      edx, 601
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG09:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x15F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1610], ymm0
       lea      rdx, [rbp-0x15F0]
       lea      r8, [rbp-0x1610]
       lea      rcx, [rbp-0x2F0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1630], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1650], ymm0
       lea      rdx, [rbp-0x1630]
       lea      r8, [rbp-0x1650]
       lea      rcx, [rbp-0x7B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1670], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7B0]
       vmovups  ymmword ptr [rbp-0x1690], ymm0
       lea      rdx, [rbp-0x1670]
       lea      r8, [rbp-0x1690]
       lea      rcx, [rbp-0x7D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x16B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x16D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x16F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1710], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x1750], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x1770], ymm0
       lea      rdx, [rbp-0x16B0]
       lea      r8, [rbp-0x16D0]
       lea      r9, [rbp-0x16F0]
       lea      rax, [rbp-0x1710]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x1730]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x1750]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x1770]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0x7F0]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x7D0]
       vmovups  ymmword ptr [rbp-0x1790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x7F0]
       vmovups  ymmword ptr [rbp-0x17B0], ymm0
       lea      rdx, [rbp-0x1790]
       lea      r8, [rbp-0x17B0]
       lea      rcx, [rbp-0x310]
 
G_M000_IG10:                ;; offset=0x09AF
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2F0]
       vmovups  ymmword ptr [rbp-0x17D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x310]
       vmovups  ymmword ptr [rbp-0x17F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1810], ymm0
       lea      rdx, [rbp-0x17D0]
       lea      r8, [rbp-0x17F0]
       lea      r9, [rbp-0x1810]
       lea      rcx, [rbp-0x810]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x1830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x810]
       vmovups  ymmword ptr [rbp-0x1850], ymm0
       lea      rdx, [rbp-0x1830]
       lea      r8, [rbp-0x1850]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1890], ymm0
       lea      rdx, [rbp-0x1870]
       lea      r8, [rbp-0x1890]
       lea      rcx, [rbp-0x830]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x830]
       vmovups  ymmword ptr [rbp-0x18B0], ymm0
       lea      rdx, [rbp-0x18B0]
       lea      rcx, [rbp-0x850]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x18D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x18F0], ymm0
       lea      rdx, [rbp-0x18D0]
       lea      r8, [rbp-0x18F0]
       lea      rcx, [rbp-0x870]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x870]
       vmovups  ymmword ptr [rbp-0x1910], ymm0
       lea      rdx, [rbp-0x1910]
       lea      rcx, [rbp-0x890]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x850]
       vmovups  ymmword ptr [rbp-0x1930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x890]
       vmovups  ymmword ptr [rbp-0x1950], ymm0
       lea      rdx, [rbp-0x1930]
       lea      r8, [rbp-0x1950]
       lea      rcx, [rbp-0x330]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1970], ymm0
       lea      rdx, [rbp-0x1970]
       lea      rcx, [rbp-0x8B0]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG11:                ;; offset=0x0B5F
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x19B0], ymm0
       lea      rdx, [rbp-0x1990]
       lea      r8, [rbp-0x19B0]
       lea      rcx, [rbp-0x8D0]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x19D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x19F0], ymm0
       lea      rdx, [rbp-0x19D0]
       lea      r8, [rbp-0x19F0]
       lea      rcx, [rbp-0x8F0]
       call     [Tedd.FastNoise.Internal.VectorOps:LessThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8F0]
       vmovups  ymmword ptr [rbp-0x1A10], ymm0
       lea      rdx, [rbp-0x1A10]
       lea      rcx, [rbp-0x910]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8D0]
       vmovups  ymmword ptr [rbp-0x1A30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x910]
       vmovups  ymmword ptr [rbp-0x1A50], ymm0
       lea      rdx, [rbp-0x1A30]
       lea      r8, [rbp-0x1A50]
       lea      rcx, [rbp-0x930]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x8B0]
       vmovups  ymmword ptr [rbp-0x1A70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x930]
       vmovups  ymmword ptr [rbp-0x1A90], ymm0
       lea      rdx, [rbp-0x1A70]
       lea      r8, [rbp-0x1A90]
       lea      rcx, [rbp-0x350]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1AB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1AD0], ymm0
       lea      rdx, [rbp-0x1AB0]
       lea      r8, [rbp-0x1AD0]
       lea      rcx, [rbp-0x950]
       call     [Tedd.FastNoise.Internal.VectorOps:OrI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x950]
       vmovups  ymmword ptr [rbp-0x1AF0], ymm0
       lea      rdx, [rbp-0x1AF0]
       lea      rcx, [rbp-0x370]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1B10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x1B30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x1B50], ymm0
       lea      rdx, [rbp-0x1B10]
       lea      r8, [rbp-0x1B30]
       lea      r9, [rbp-0x1B50]
 
G_M000_IG12:                ;; offset=0x0D13
       lea      rcx, [rbp-0x970]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1B70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x1B90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x970]
       vmovups  ymmword ptr [rbp-0x1BB0], ymm0
       lea      rdx, [rbp-0x1B70]
       lea      r8, [rbp-0x1B90]
       lea      r9, [rbp-0x1BB0]
       lea      rcx, [rbp-0x390]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x1BD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1BF0], ymm0
       lea      rdx, [rbp-0x1BD0]
       lea      r8, [rbp-0x1BF0]
       lea      rcx, [rbp-0x990]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x990]
       vmovups  ymmword ptr [rbp-0x1C10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x390]
       vmovups  ymmword ptr [rbp-0x1C30], ymm0
       lea      rdx, [rbp-0x1C10]
       lea      r8, [rbp-0x1C30]
       lea      rcx, [rbp-0x9B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD08]
       lea      rcx, [rbp-0x9D0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9B0]
       vmovups  ymmword ptr [rbp-0x1C50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9D0]
       vmovups  ymmword ptr [rbp-0x1C70], ymm0
       lea      rdx, [rbp-0x1C50]
       lea      r8, [rbp-0x1C70]
       lea      rcx, [rbp-0x9F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1C90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x1CB0], ymm0
       lea      rdx, [rbp-0x1C90]
       lea      r8, [rbp-0x1CB0]
       lea      rcx, [rbp-0xA10]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA30]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1CD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA10]
       vmovups  ymmword ptr [rbp-0x1CF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA30]
       vmovups  ymmword ptr [rbp-0x1D10], ymm0
       lea      rdx, [rbp-0x1CD0]
       lea      r8, [rbp-0x1CF0]
 
G_M000_IG13:                ;; offset=0x0EC0
       lea      r9, [rbp-0x1D10]
       lea      rcx, [rbp-0xA50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x1D30], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA50]
       vmovups  ymmword ptr [rbp-0x1D50], ymm0
       lea      rdx, [rbp-0x1D30]
       lea      r8, [rbp-0x1D50]
       lea      rcx, [rbp-0x3B0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1D70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x1D90], ymm0
       lea      rdx, [rbp-0x1D70]
       lea      r8, [rbp-0x1D90]
       lea      rcx, [rbp-0xA70]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xA90]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x1DB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA70]
       vmovups  ymmword ptr [rbp-0x1DD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xA90]
       vmovups  ymmword ptr [rbp-0x1DF0], ymm0
       lea      rdx, [rbp-0x1DB0]
       lea      r8, [rbp-0x1DD0]
       lea      r9, [rbp-0x1DF0]
       lea      rcx, [rbp-0xAB0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x1E10], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAB0]
       vmovups  ymmword ptr [rbp-0x1E30], ymm0
       lea      rdx, [rbp-0x1E10]
       lea      r8, [rbp-0x1E30]
       lea      rcx, [rbp-0x3D0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x1E50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x1E70], ymm0
       lea      rdx, [rbp-0x1E50]
       lea      r8, [rbp-0x1E70]
       lea      rcx, [rbp-0xAD0]
       call     [Tedd.FastNoise.Internal.VectorOps:MulI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xAF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x1E90], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAD0]
       vmovups  ymmword ptr [rbp-0x1EB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xAF0]
       vmovups  ymmword ptr [rbp-0x1ED0], ymm0
       lea      rdx, [rbp-0x1E90]
 
G_M000_IG14:                ;; offset=0x1064
       lea      r8, [rbp-0x1EB0]
       lea      r9, [rbp-0x1ED0]
       lea      rcx, [rbp-0xB10]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x1EF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB10]
       vmovups  ymmword ptr [rbp-0x1F10], ymm0
       lea      rdx, [rbp-0x1EF0]
       lea      r8, [rbp-0x1F10]
       lea      rcx, [rbp-0x3F0]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x1F30], ymm0
       lea      rdx, [rbp-0x1F30]
       lea      rcx, [rbp-0xB30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x330]
       vmovups  ymmword ptr [rbp-0x1F50], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB30]
       vmovups  ymmword ptr [rbp-0x1F70], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x1F90], ymm0
       lea      rdx, [rbp-0x1F50]
       lea      r8, [rbp-0x1F70]
       lea      r9, [rbp-0x1F90]
       lea      rcx, [rbp-0xB50]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD0]
       vmovups  ymmword ptr [rbp-0x1FB0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB50]
       vmovups  ymmword ptr [rbp-0x1FD0], ymm0
       lea      rdx, [rbp-0x1FB0]
       lea      r8, [rbp-0x1FD0]
       lea      rcx, [rbp-0x410]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x1FF0], ymm0
       lea      rdx, [rbp-0x1FF0]
       lea      rcx, [rbp-0xB70]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x350]
       vmovups  ymmword ptr [rbp-0x2010], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB70]
       vmovups  ymmword ptr [rbp-0x2030], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2050], ymm0
       lea      rdx, [rbp-0x2010]
       lea      r8, [rbp-0x2030]
       lea      r9, [rbp-0x2050]
       lea      rcx, [rbp-0xB90]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xF0]
       vmovups  ymmword ptr [rbp-0x2070], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xB90]
       vmovups  ymmword ptr [rbp-0x2090], ymm0
       lea      rdx, [rbp-0x2070]
       lea      r8, [rbp-0x2090]
       lea      rcx, [rbp-0x430]
 
G_M000_IG15:                ;; offset=0x1216
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x20B0], ymm0
       lea      rdx, [rbp-0x20B0]
       lea      rcx, [rbp-0xBB0]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x370]
       vmovups  ymmword ptr [rbp-0x20D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBB0]
       vmovups  ymmword ptr [rbp-0x20F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2110], ymm0
       lea      rdx, [rbp-0x20D0]
       lea      r8, [rbp-0x20F0]
       lea      r9, [rbp-0x2110]
       lea      rcx, [rbp-0xBD0]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x110]
       vmovups  ymmword ptr [rbp-0x2130], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBD0]
       vmovups  ymmword ptr [rbp-0x2150], ymm0
       lea      rdx, [rbp-0x2130]
       lea      r8, [rbp-0x2150]
       lea      rcx, [rbp-0x450]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x2170], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2190], ymm0
       lea      rdx, [rbp-0x2170]
       lea      r8, [rbp-0x2190]
       lea      rcx, [rbp-0x470]
       call     [Tedd.FastNoise.Internal.VectorOps:GreaterThanF(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x9F0]
       vmovups  ymmword ptr [rbp-0x21D0], ymm0
       lea      rdx, [rbp-0x21B0]
       lea      r8, [rbp-0x21D0]
       lea      rcx, [rbp-0xBF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x21F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xBF0]
       vmovups  ymmword ptr [rbp-0x2210], ymm0
       lea      rdx, [rbp-0x21F0]
       lea      r8, [rbp-0x2210]
       lea      rcx, [rbp-0xC10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2230], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3B0]
       vmovups  ymmword ptr [rbp-0x2250], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3D0]
       vmovups  ymmword ptr [rbp-0x2270], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x3F0]
       vmovups  ymmword ptr [rbp-0x2290], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x410]
 
G_M000_IG16:                ;; offset=0x13C6
       vmovups  ymmword ptr [rbp-0x22B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x430]
       vmovups  ymmword ptr [rbp-0x22D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x450]
       vmovups  ymmword ptr [rbp-0x22F0], ymm0
       lea      rdx, [rbp-0x2230]
       lea      r8, [rbp-0x2250]
       lea      r9, [rbp-0x2270]
       lea      rax, [rbp-0x2290]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x22B0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x22D0]
       mov      qword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x22F0]
       mov      qword ptr [rsp+0x38], rax
       lea      rcx, [rbp-0xC30]
       call     [Tedd.FastNoise.Internal.Hashing:GradCoord3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC10]
       vmovups  ymmword ptr [rbp-0x2310], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC30]
       vmovups  ymmword ptr [rbp-0x2330], ymm0
       lea      rdx, [rbp-0x2310]
       lea      r8, [rbp-0x2330]
       lea      rcx, [rbp-0xC50]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xC50]
       vmovups  ymmword ptr [rbp-0x490], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x470]
       vmovups  ymmword ptr [rbp-0x2350], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x490]
       vmovups  ymmword ptr [rbp-0x2370], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x270]
       vmovups  ymmword ptr [rbp-0x2390], ymm0
       lea      rdx, [rbp-0x2350]
       lea      r8, [rbp-0x2370]
       lea      r9, [rbp-0x2390]
       lea      rcx, [rbp-0xC70]
       call     [Tedd.FastNoise.Internal.VectorOps:SelectF(System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x23B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC70]
       vmovups  ymmword ptr [rbp-0x23D0], ymm0
       lea      rdx, [rbp-0x23B0]
       lea      r8, [rbp-0x23D0]
       lea      rcx, [rbp-0x290]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rbp-0x2B4], 1
       je       G_M000_IG21
       mov      rcx, 0x7FFC6579BF78
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCB0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCB0]
       vmovups  ymmword ptr [rbp-0x23F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
 
G_M000_IG17:                ;; offset=0x1561
       vmovups  ymmword ptr [rbp-0x2410], ymm0
       lea      rdx, [rbp-0x23F0]
       lea      r8, [rbp-0x2410]
       lea      rcx, [rbp-0x1B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCD0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCD0]
       vmovups  ymmword ptr [rbp-0x2430], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2450], ymm0
       lea      rdx, [rbp-0x2430]
       lea      r8, [rbp-0x2450]
       lea      rcx, [rbp-0x1D0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD12]
       lea      rcx, [rbp-0xCF0]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xCF0]
       vmovups  ymmword ptr [rbp-0x2470], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2490], ymm0
       lea      rdx, [rbp-0x2470]
       lea      r8, [rbp-0x2490]
       lea      rcx, [rbp-0x1F0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x24B0], ymm0
       lea      rdx, [rbp-0x24B0]
       lea      rcx, [rbp-0xD10]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD10]
       vmovups  ymmword ptr [rbp-0x24D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x24F0], ymm0
       lea      rdx, [rbp-0x24D0]
       lea      r8, [rbp-0x24F0]
       lea      rcx, [rbp-0xD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2510], ymm0
       lea      rdx, [rbp-0x2510]
       lea      rcx, [rbp-0xD30]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD30]
       vmovups  ymmword ptr [rbp-0x2530], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2550], ymm0
       lea      rdx, [rbp-0x2530]
       lea      r8, [rbp-0x2550]
       lea      rcx, [rbp-0xF0]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2570], ymm0
       lea      rdx, [rbp-0x2570]
       lea      rcx, [rbp-0xD50]
       call     [Tedd.FastNoise.Internal.VectorOps:ToFloat(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD50]
 
G_M000_IG18:                ;; offset=0x170E
       vmovups  ymmword ptr [rbp-0x2590], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x25B0], ymm0
       lea      rdx, [rbp-0x2590]
       lea      r8, [rbp-0x25B0]
       lea      rcx, [rbp-0x110]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovss   xmm1, dword ptr [reloc @RWD16]
       lea      rcx, [rbp-0xD70]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD70]
       vmovups  ymmword ptr [rbp-0x25D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1B0]
       vmovups  ymmword ptr [rbp-0x25F0], ymm0
       lea      rdx, [rbp-0x25D0]
       lea      r8, [rbp-0x25F0]
       lea      rcx, [rbp-0xD90]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x1D0]
       vmovups  ymmword ptr [rbp-0x2610], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x1F0]
       vmovups  ymmword ptr [rbp-0x2630], ymm0
       lea      rdx, [rbp-0x2610]
       lea      r8, [rbp-0x2630]
       lea      rcx, [rbp-0xDB0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0xD90]
       vmovups  ymmword ptr [rbp-0x2650], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDB0]
       vmovups  ymmword ptr [rbp-0x2670], ymm0
       lea      rdx, [rbp-0x2650]
       lea      r8, [rbp-0x2670]
       lea      rcx, [rbp-0xDD0]
       call     [Tedd.FastNoise.Internal.VectorOps:Sub(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x2B0]
       vmovups  ymmword ptr [rbp-0x2690], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xDD0]
       vmovups  ymmword ptr [rbp-0x26B0], ymm0
       lea      rdx, [rbp-0x2690]
       lea      r8, [rbp-0x26B0]
       lea      rcx, [rbp-0x2B0]
       call     [Tedd.FastNoise.Internal.VectorOps:Add(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x26D0], ymm0
       lea      rdx, [rbp-0x26D0]
       lea      rcx, [rbp-0xDF0]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xDF0]
       vmovups  ymmword ptr [rbp-0x26F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x210]
       vmovups  ymmword ptr [rbp-0x2710], ymm0
       lea      rdx, [rbp-0x26F0]
       lea      r8, [rbp-0x2710]
       lea      rcx, [rbp-0xE10]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0x2730], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE10]
 
G_M000_IG19:                ;; offset=0x18BC
       vmovups  ymmword ptr [rbp-0x2750], ymm0
       lea      rdx, [rbp-0x2730]
       lea      r8, [rbp-0x2750]
       lea      rcx, [rbp-0x70]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2770], ymm0
       lea      rdx, [rbp-0x2770]
       lea      rcx, [rbp-0xE30]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE30]
       vmovups  ymmword ptr [rbp-0x2790], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x230]
       vmovups  ymmword ptr [rbp-0x27B0], ymm0
       lea      rdx, [rbp-0x2790]
       lea      r8, [rbp-0x27B0]
       lea      rcx, [rbp-0xE50]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x27D0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE50]
       vmovups  ymmword ptr [rbp-0x27F0], ymm0
       lea      rdx, [rbp-0x27D0]
       lea      r8, [rbp-0x27F0]
       lea      rcx, [rbp-0x90]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2810], ymm0
       lea      rdx, [rbp-0x2810]
       lea      rcx, [rbp-0xE70]
       mov      r8d, 1
       call     [Tedd.FastNoise.Internal.VectorOps:ShiftRightArithmetic(System.Numerics.Vector`1[int],int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xE70]
       vmovups  ymmword ptr [rbp-0x2830], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x250]
       vmovups  ymmword ptr [rbp-0x2850], ymm0
       lea      rdx, [rbp-0x2830]
       lea      r8, [rbp-0x2850]
       lea      rcx, [rbp-0xE90]
       call     [Tedd.FastNoise.Internal.VectorOps:AndI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xB0]
       vmovups  ymmword ptr [rbp-0x2870], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xE90]
       vmovups  ymmword ptr [rbp-0x2890], ymm0
       lea      rdx, [rbp-0x2870]
       lea      r8, [rbp-0x2890]
       lea      rcx, [rbp-0xB0]
       call     [Tedd.FastNoise.Internal.VectorOps:AddI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEB0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEB0]
       vmovups  ymmword ptr [rbp-0x28B0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x150]
       vmovups  ymmword ptr [rbp-0x28D0], ymm0
       lea      rdx, [rbp-0x28B0]
       lea      r8, [rbp-0x28D0]
       lea      rcx, [rbp-0x150]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
 
G_M000_IG20:                ;; offset=0x1A66
       lea      rcx, [rbp-0xED0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xED0]
       vmovups  ymmword ptr [rbp-0x28F0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x170]
       vmovups  ymmword ptr [rbp-0x2910], ymm0
       lea      rdx, [rbp-0x28F0]
       lea      r8, [rbp-0x2910]
       lea      rcx, [rbp-0x170]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       lea      rcx, [rbp-0xEF0]
       xor      edx, edx
       call     [Tedd.FastNoise.Internal.VectorOps:I(int):System.Numerics.Vector`1[int]]
       vmovups  ymm0, ymmword ptr [rbp-0xEF0]
       vmovups  ymmword ptr [rbp-0x2930], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x190]
       vmovups  ymmword ptr [rbp-0x2950], ymm0
       lea      rdx, [rbp-0x2930]
       lea      r8, [rbp-0x2950]
       lea      rcx, [rbp-0x190]
       call     [Tedd.FastNoise.Internal.VectorOps:SubI(System.Numerics.Vector`1[int],System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      rax, bword ptr [rbp+0x18]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x2970], ymm0
       lea      rdx, [rbp-0x2970]
       mov      rcx, bword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.VectorOps:NotI(System.Numerics.Vector`1[int]):System.Numerics.Vector`1[int]]
       mov      eax, dword ptr [rbp-0x2B4]
       inc      eax
       mov      dword ptr [rbp-0x2B4], eax
       jmp      G_M000_IG07
 
G_M000_IG21:                ;; offset=0x1B2E
       mov      rcx, 0x7FFC6579BF7C
       call     CORINFO_HELP_COUNTPROFILE32
       vmovss   xmm1, dword ptr [reloc @RWD20]
       lea      rcx, [rbp-0xC90]
       call     [Tedd.FastNoise.Internal.VectorOps:F(float):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rbp-0x290]
       vmovups  ymmword ptr [rbp-0x2990], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0xC90]
       vmovups  ymmword ptr [rbp-0x29B0], ymm0
       lea      rdx, [rbp-0x2990]
       lea      r8, [rbp-0x29B0]
       mov      rcx, qword ptr [rbp+0x10]
       call     [Tedd.FastNoise.Internal.VectorOps:Mul(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG22:                ;; offset=0x1B8E
       vzeroupper 
       add      rsp, 0x29F0
       pop      rbp
       ret      
 
RWD00  	dd	BF800000h		;        -1
RWD04  	dd	3F19999Ah		;       0.6
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F400000h		;      0.75
RWD20  	dd	4202C6F2h		;   32.6943

; Total bytes of code 7066

; Assembly listing for method Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float] (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 114768
; 2 inlinees with PGO data; 295 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       sub      rsp, 0x458
       vmovaps  xmmword ptr [rsp+0x440], xmm6
       vmovaps  xmmword ptr [rsp+0x430], xmm7
       vmovaps  xmmword ptr [rsp+0x420], xmm8
       vmovaps  xmmword ptr [rsp+0x410], xmm9
       vmovaps  xmmword ptr [rsp+0x400], xmm10
       vmovaps  xmmword ptr [rsp+0x3F0], xmm11
       vmovaps  xmmword ptr [rsp+0x3E0], xmm12
       vmovaps  xmmword ptr [rsp+0x3D0], xmm13
       vmovaps  xmmword ptr [rsp+0x3C0], xmm14
       vmovaps  xmmword ptr [rsp+0x3B0], xmm15
       mov      rax, bword ptr [rsp+0x480]
 
G_M000_IG02:                ;; offset=0x0069
       vmovups  ymm0, ymmword ptr [r8]
       vxorps   ymm1, ymm1, ymm1
       vcmpltps ymm1, ymm0, ymm1
       vbroadcastss ymm2, dword ptr [reloc @RWD00]
       vbroadcastss ymm3, dword ptr [reloc @RWD04]
       vmovups  ymmword ptr [rsp+0xC0], ymm3
       vblendvps ymm1, ymm3, ymm2, ymm1
       vaddps   ymm1, ymm1, ymm0
       vcmpeqps ymm4, ymm1, ymm1
       vandps   ymm1, ymm4, ymm1
       vbroadcastss ymm4, dword ptr [reloc @RWD08]
       vcmpgeps ymm5, ymm1, ymm4
       vbroadcastss ymm6, dword ptr [reloc @RWD12]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymm6, ymm5
       vmovups  ymm5, ymmword ptr [r9]
       vxorps   ymm7, ymm7, ymm7
       vcmpltps ymm7, ymm5, ymm7
       vblendvps ymm7, ymm3, ymm2, ymm7
       vaddps   ymm7, ymm7, ymm5
       vcmpeqps ymm8, ymm7, ymm7
       vandps   ymm7, ymm8, ymm7
       vcmpgeps ymm8, ymm7, ymm4
       vcvttps2dq ymm7, ymm7
       vpblendvb ymm7, ymm7, ymm6, ymm8
       vmovups  ymm8, ymmword ptr [rax]
       vxorps   ymm9, ymm9, ymm9
       vcmpltps ymm9, ymm8, ymm9
       vblendvps ymm2, ymm3, ymm2, ymm9
       vaddps   ymm2, ymm2, ymm8
       vcmpeqps ymm9, ymm2, ymm2
       vandps   ymm2, ymm9, ymm2
       vcmpgeps ymm9, ymm2, ymm4
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymm6, ymm9
       vcvtdq2ps ymm9, ymm1
       vsubps   ymm0, ymm0, ymm9
       vcvtdq2ps ymm9, ymm7
       vsubps   ymm5, ymm5, ymm9
       vcvtdq2ps ymm9, ymm2
       vsubps   ymm8, ymm8, ymm9
       vbroadcastss ymm9, dword ptr [reloc @RWD16]
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       vmovaps  ymm10, ymm9
       vbroadcastss ymm11, dword ptr [reloc @RWD20]
       vsubps   ymm12, ymm11, ymm0
       vcmpeqps ymm13, ymm12, ymm12
       vandps   ymm12, ymm13, ymm12
       vcmpgeps ymm13, ymm12, ymm4
       vcvttps2dq ymm12, ymm12
       vpblendvb ymm12, ymm12, ymm6, ymm13
       vpor     ymm12, ymm12, ymm10
       vsubps   ymm13, ymm11, ymm5
       vcmpeqps ymm14, ymm13, ymm13
       vandps   ymm13, ymm14, ymm13
       vcmpgeps ymm14, ymm13, ymm4
       vcvttps2dq ymm13, ymm13
       vpblendvb ymm13, ymm13, ymm6, ymm14
       vpor     ymm13, ymm13, ymm10
       vsubps   ymm11, ymm11, ymm8
       vcmpeqps ymm14, ymm11, ymm11
       vandps   ymm11, ymm14, ymm11
 
G_M000_IG03:                ;; offset=0x01BB
       vcmpgeps ymm4, ymm11, ymm4
       vcvttps2dq ymm11, ymm11
       vpblendvb ymm4, ymm11, ymm6, ymm4
       vpor     ymm4, ymm4, ymm10
       vbroadcastss ymm6, dword ptr [reloc @RWD24]
       vxorps   ymm10, ymm6, ymm0
       vmovups  ymmword ptr [rsp+0x340], ymm12
       vcvtdq2ps ymm11, ymm12
       vmulps   ymm10, ymm10, ymm11
       vxorps   ymm11, ymm6, ymm5
       vmovups  ymmword ptr [rsp+0x320], ymm13
       vcvtdq2ps ymm14, ymm13
       vmulps   ymm11, ymm11, ymm14
       vxorps   ymm14, ymm6, ymm8
       vmovups  ymmword ptr [rsp+0x300], ymm4
       vcvtdq2ps ymm15, ymm4
       vmulps   ymm14, ymm14, ymm15
       vpmulld  ymm1, ymm1, ymmword ptr [reloc @RWD32]
       vpmulld  ymm7, ymm7, ymmword ptr [reloc @RWD64]
       vpmulld  ymm2, ymm2, ymmword ptr [reloc @RWD96]
       vbroadcastss ymm15, dword ptr [reloc @RWD32]
       vmovups  ymmword ptr [rsp+0x2E0], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD64]
       vmovups  ymmword ptr [rsp+0x2C0], ymm15
       vbroadcastss ymm15, dword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0x2A0], ymm15
       vxorps   ymm15, ymm15, ymm15
       vxorps   ymm9, ymm9, ymm9
       vmulps   ymm3, ymm5, ymm5
       vmovups  ymmword ptr [rsp+0x390], ymm3
       vmulps   ymm3, ymm8, ymm8
       vaddps   ymm3, ymm3, ymmword ptr [rsp+0x390]
       vmovups  ymmword ptr [rsp+0x390], ymm3
       vmulps   ymm3, ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x370], ymm3
       vbroadcastss ymm3, dword ptr [reloc @RWD128]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x370]
       vsubps   ymm3, ymm3, ymmword ptr [rsp+0x390]
       xor      eax, eax
       mov      r8, 0x13A6C800BE0
       mov      r8, gword ptr [r8]
 
G_M000_IG04:                ;; offset=0x02D4
       vcmpgtps ymm4, ymm3, ymm15
       vmovups  ymmword ptr [rsp+0x260], ymm4
       vmulps   ymm4, ymm3, ymm3
       vmulps   ymm4, ymm4, ymm4
       vmovups  ymmword ptr [rsp+0x120], ymm4
       vmovups  ymm4, ymmword ptr [rdx]
       vmovups  ymmword ptr [rsp+0x80], ymm4
       vpxor    ymm4, ymm1, ymm4
       vpxor    ymm4, ymm4, ymm7
       vpxor    ymm4, ymm4, ymm2
       vmovups  ymmword ptr [rsp+0x390], ymm4
       vbroadcastss ymm4, dword ptr [reloc @RWD132]
       vmovups  ymmword ptr [rsp+0x60], ymm4
       vmovups  ymm4, ymmword ptr [rsp+0x390]
       vpmulld  ymm4, ymm4, ymmword ptr [rsp+0x60]
       vpsrad   ymm13, ymm4, 15
       vpxor    ymm4, ymm13, ymm4
       vbroadcastss ymm13, dword ptr [reloc @RWD136]
       vmovups  ymmword ptr [rsp+0x40], ymm13
       vpand    ymm4, ymm4, ymm13
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm4, ymm4, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm12, dword ptr [r10+4*xmm4], ymm13
       vmovups  ymmword ptr [rsp+0xE0], ymm12
       vbroadcastss ymm4, dword ptr [reloc @RWD140]
       vmovups  ymmword ptr [rsp+0x20], ymm4
       vpand    ymm13, ymm4, ymm12
       vxorps   ymm4, ymm4, ymm4
       vpcmpeqd ymm4, ymm4, ymm13
       vmovups  ymmword ptr [rsp+0x390], ymm4
       vpslld   ymm4, ymm12, 29
       vpand    ymm4, ymm4, ymm6
       vpxor    ymm4, ymm4, ymm0
       vmovups  ymm12, ymmword ptr [rsp+0x390]
       vblendvps ymm4, ymm4, ymm15, ymm12
       vmovups  ymmword ptr [rsp+0x390], ymm4
       vmovups  ymm12, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm12, ymm12, ymm13
       vmovups  ymm4, ymmword ptr [rsp+0xE0]
       vpslld   ymm4, ymm4, 28
       vpand    ymm4, ymm4, ymm6
       vpxor    ymm4, ymm4, ymm5
       vblendvps ymm4, ymm4, ymm15, ymm12
       vaddps   ymm4, ymm4, ymmword ptr [rsp+0x390]
       vbroadcastss ymm12, dword ptr [reloc @RWD144]
       vmovups  ymmword ptr [rsp], ymm12
       vpcmpeqd ymm13, ymm12, ymm13
       vmovups  ymm12, ymmword ptr [rsp+0xE0]
       vpslld   ymm12, ymm12, 27
       vpand    ymm12, ymm12, ymm6
       vpxor    ymm12, ymm12, ymm8
       vblendvps ymm12, ymm12, ymm15, ymm13
       vaddps   ymm4, ymm12, ymm4
       vmovups  ymm12, ymmword ptr [rsp+0x120]
       vmulps   ymm4, ymm12, ymm4
       vmovups  ymm12, ymmword ptr [rsp+0x260]
 
G_M000_IG05:                ;; offset=0x043C
       vandps   ymm4, ymm4, ymm12
       vandnps  ymm12, ymm12, ymm15
       vorps    ymm4, ymm12, ymm4
       vaddps   ymm9, ymm4, ymm9
       vmovups  ymmword ptr [rsp+0x280], ymm9
       vcmpnltps ymm4, ymm10, ymm11
       vcmpnltps ymm12, ymm10, ymm14
       vpand    ymm4, ymm12, ymm4
       vcmpgtps ymm12, ymm11, ymm10
       vcmpnltps ymm13, ymm11, ymm14
       vpand    ymm12, ymm13, ymm12
       vpandn   ymm12, ymm4, ymm12
       vpor     ymm13, ymm4, ymm12
       vmovups  ymmword ptr [rsp+0x390], ymm13
       vpcmpeqd ymm13, ymm13, ymm13
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x390]
       vmovups  ymmword ptr [rsp+0x240], ymm13
       vandps   ymm13, ymm10, ymm4
       vmovups  ymmword ptr [rsp+0x390], ymm13
       vandps   ymm13, ymm11, ymm12
       vmovups  ymmword ptr [rsp+0x370], ymm13
       vandnps  ymm13, ymm12, ymm14
       vorps    ymm13, ymm13, ymmword ptr [rsp+0x370]
       vandnps  ymm13, ymm4, ymm13
       vorps    ymm13, ymm13, ymmword ptr [rsp+0x390]
       vmovups  ymmword ptr [rsp+0x220], ymm13
       vaddps   ymm13, ymm3, ymm13
       vaddps   ymm13, ymm13, ymmword ptr [rsp+0x220]
       vsubps   ymm13, ymm13, ymmword ptr [reloc @RWD160]
       vmovups  ymm9, ymmword ptr [rsp+0x340]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x2E0]
       vpand    ymm9, ymm9, ymm4
       vmovups  ymmword ptr [rsp+0x390], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm4, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x390]
       vpsubd   ymm9, ymm1, ymm9
       vmovups  ymmword ptr [rsp+0x200], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x320]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x2C0]
       vpand    ymm9, ymm9, ymm12
       vmovups  ymmword ptr [rsp+0x390], ymm9
       vxorps   ymm9, ymm9, ymm9
       vpandn   ymm9, ymm12, ymm9
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x390]
       vpsubd   ymm9, ymm7, ymm9
       vmovups  ymmword ptr [rsp+0x1E0], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x300]
       vpmulld  ymm9, ymm9, ymmword ptr [rsp+0x2A0]
       vpand    ymm9, ymm9, ymmword ptr [rsp+0x240]
       vmovups  ymmword ptr [rsp+0x390], ymm9
       vxorps   ymm9, ymm9, ymm9
       vmovups  ymmword ptr [rsp+0x370], ymm9
       vmovups  ymm9, ymmword ptr [rsp+0x240]
       vpandn   ymm9, ymm9, ymmword ptr [rsp+0x370]
       vpor     ymm9, ymm9, ymmword ptr [rsp+0x390]
       vpsubd   ymm9, ymm2, ymm9
       vmovups  ymmword ptr [rsp+0x1C0], ymm9
       vcvtdq2ps ymm9, ymmword ptr [rsp+0x340]
 
G_M000_IG06:                ;; offset=0x05E1
       vandps   ymm9, ymm9, ymm4
       vandnps  ymm4, ymm4, ymm15
       vorps    ymm4, ymm4, ymm9
       vaddps   ymm0, ymm4, ymm0
       vmovups  ymmword ptr [rsp+0x1A0], ymm0
       vmovups  ymm9, ymmword ptr [rsp+0x320]
       vcvtdq2ps ymm4, ymm9
       vandps   ymm4, ymm4, ymm12
       vandnps  ymm12, ymm12, ymm15
       vorps    ymm4, ymm12, ymm4
       vaddps   ymm5, ymm4, ymm5
       vmovups  ymmword ptr [rsp+0x180], ymm5
       vmovups  ymm4, ymmword ptr [rsp+0x300]
       vcvtdq2ps ymm12, ymm4
       vmovups  ymm5, ymmword ptr [rsp+0x240]
       vandps   ymm12, ymm12, ymm5
       vandnps  ymm5, ymm5, ymm15
       vorps    ymm5, ymm5, ymm12
       vaddps   ymm5, ymm5, ymm8
       vmovups  ymmword ptr [rsp+0x160], ymm5
       vcmpgtps ymm8, ymm13, ymm15
       vmovups  ymmword ptr [rsp+0x140], ymm8
       vmulps   ymm12, ymm13, ymm13
       vmulps   ymm12, ymm12, ymm12
       vmovups  ymmword ptr [rsp+0x100], ymm12
       vmovups  ymm13, ymmword ptr [rsp+0x200]
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x80]
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x1E0]
       vpxor    ymm13, ymm13, ymmword ptr [rsp+0x1C0]
       vpmulld  ymm13, ymm13, ymmword ptr [rsp+0x60]
       vpsrad   ymm5, ymm13, 15
       vpxor    ymm5, ymm5, ymm13
       vpand    ymm13, ymm5, ymmword ptr [rsp+0x40]
       mov      r10, r8
       add      r10, 16
       vpsrld   ymm5, ymm13, 2
       vpcmpeqd ymm13, ymm13, ymm13
       vpgatherdd ymm0, dword ptr [r10+4*xmm5], ymm13
       vmovups  ymm5, ymmword ptr [rsp+0x20]
       vpand    ymm5, ymm5, ymm0
       vxorps   ymm13, ymm13, ymm13
       vpcmpeqd ymm13, ymm13, ymm5
       vpslld   ymm8, ymm0, 29
       vpand    ymm8, ymm8, ymm6
       vpxor    ymm8, ymm8, ymmword ptr [rsp+0x1A0]
       vblendvps ymm8, ymm8, ymm15, ymm13
       vmovups  ymm13, ymmword ptr [rsp+0xA0]
       vpcmpeqd ymm13, ymm13, ymm5
       vpslld   ymm12, ymm0, 28
       vpand    ymm12, ymm12, ymm6
       vpxor    ymm12, ymm12, ymmword ptr [rsp+0x180]
       vblendvps ymm12, ymm12, ymm15, ymm13
       vaddps   ymm8, ymm12, ymm8
       vmovups  ymm12, ymmword ptr [rsp]
       vpcmpeqd ymm5, ymm12, ymm5
       vpslld   ymm0, ymm0, 27
       vpand    ymm0, ymm0, ymm6
       vpxor    ymm0, ymm0, ymmword ptr [rsp+0x160]
       vblendvps ymm0, ymm0, ymm15, ymm5
 
G_M000_IG07:                ;; offset=0x0743
       vaddps   ymm0, ymm0, ymm8
       vmovups  ymm12, ymmword ptr [rsp+0x100]
       vmulps   ymm0, ymm12, ymm0
       vmovups  ymm8, ymmword ptr [rsp+0x140]
       vandps   ymm0, ymm0, ymm8
       vandnps  ymm5, ymm8, ymm15
       vorps    ymm0, ymm5, ymm0
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x280]
       cmp      eax, 1
       jne      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x077A
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rcx], ymm0
       mov      rax, rcx
 
G_M000_IG09:                ;; offset=0x0789
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x440]
       vmovaps  xmm7, xmmword ptr [rsp+0x430]
       vmovaps  xmm8, xmmword ptr [rsp+0x420]
       vmovaps  xmm9, xmmword ptr [rsp+0x410]
       vmovaps  xmm10, xmmword ptr [rsp+0x400]
       vmovaps  xmm11, xmmword ptr [rsp+0x3F0]
       vmovaps  xmm12, xmmword ptr [rsp+0x3E0]
       vmovaps  xmm13, xmmword ptr [rsp+0x3D0]
       vmovaps  xmm14, xmmword ptr [rsp+0x3C0]
       vmovaps  xmm15, xmmword ptr [rsp+0x3B0]
       add      rsp, 0x458
       ret      
 
G_M000_IG10:                ;; offset=0x07EE
       vmovups  ymm5, ymmword ptr [rsp+0xC0]
       vsubps   ymm10, ymm5, ymm10
       vsubps   ymm11, ymm5, ymm11
       vsubps   ymm14, ymm5, ymm14
       vmovups  ymm8, ymmword ptr [rsp+0x340]
       vcvtdq2ps ymm12, ymm8
       vmulps   ymm12, ymm12, ymm10
       vcvtdq2ps ymm13, ymm9
       vmulps   ymm13, ymm13, ymm11
       vmovups  ymmword ptr [rsp+0x300], ymm4
       vcvtdq2ps ymm5, ymm4
       vmulps   ymm5, ymm5, ymm14
       vaddps   ymm4, ymm11, ymm14
       vmovups  ymmword ptr [rsp+0x390], ymm4
       vbroadcastss ymm4, dword ptr [reloc @RWD224]
       vsubps   ymm4, ymm4, ymm10
       vsubps   ymm4, ymm4, ymmword ptr [rsp+0x390]
       vaddps   ymm3, ymm4, ymm3
       vpsrad   ymm4, ymm8, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x2E0]
       vpaddd   ymm1, ymm4, ymm1
       vpsrad   ymm4, ymm9, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x2C0]
       vpaddd   ymm7, ymm4, ymm7
       vmovups  ymm4, ymmword ptr [rsp+0x300]
       vpsrad   ymm4, ymm4, 1
       vpand    ymm4, ymm4, ymmword ptr [rsp+0x2A0]
       vpaddd   ymm2, ymm4, ymm2
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm8, ymm4, ymm8
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm9, ymm4, ymm9
       vxorps   ymm4, ymm4, ymm4
       vpsubd   ymm4, ymm4, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm4
       vpcmpeqd ymm4, ymm4, ymm4
       vpxor    ymm4, ymm4, ymmword ptr [rsp+0x80]
       vmovups  ymmword ptr [rdx], ymm4
       inc      eax
       vmovups  ymmword ptr [rsp+0x340], ymm8
       vmovups  ymmword ptr [rsp+0x320], ymm9
       vmovaps  ymm8, ymm5
       vmovaps  ymm5, ymm13
       vmovaps  ymm9, ymm0
       vmovaps  ymm0, ymm12
       jmp      G_M000_IG04
 
RWD00  	dd	BF000000h		;      -0.5
RWD04  	dd	3F000000h		;       0.5
RWD08  	dd	4F000000h		; 2.14748e+09
RWD12  	dd	7FFFFFFFh		;       nan
RWD16  	dd	00000001h		; 1.4013e-45
RWD20  	dd	BF800000h		;        -1
RWD24  	dd	80000000h		;        -0
RWD28  	dd	00000000h
RWD32  	dq	1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h, 1DDE90C91DDE90C9h
RWD64  	dq	43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh, 43C42E4D43C42E4Dh
RWD96  	dq	668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh, 668B6E2F668B6E2Fh
RWD128 	dd	3F19999Ah		;       0.6
RWD132 	dd	27D4EB2Dh		; 5.90968e-15
RWD136 	dd	000000FCh		; 3.53127e-43
RWD140 	dd	00000003h		; 4.2039e-45
RWD144 	dd	00000002h		; 2.8026e-45
RWD148 	dd	00000000h, 00000000h, 00000000h
RWD160 	dq	3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h, 3F8000003F800000h
RWD192 	dq	4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h, 4202C6F24202C6F2h
RWD224 	dd	3F400000h		;      0.75

; Total bytes of code 2307


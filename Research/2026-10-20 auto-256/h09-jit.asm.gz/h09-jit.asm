; Assembly listing for method (dynamicClass):lambda_method1(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 14 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 256
       vmovaps  xmmword ptr [rsp+0xF0], xmm6
       vmovaps  xmmword ptr [rsp+0xE0], xmm7
       vmovaps  xmmword ptr [rsp+0xD0], xmm8
       vmovaps  xmmword ptr [rsp+0xC0], xmm9
       vmovaps  xmmword ptr [rsp+0xB0], xmm10
       vmovaps  xmmword ptr [rsp+0xA0], xmm11
       vmovaps  xmmword ptr [rsp+0x90], xmm12
       vmovaps  xmmword ptr [rsp+0x80], xmm13
       vmovaps  xmmword ptr [rsp+0x70], xmm14
       vmovaps  xmmword ptr [rsp+0x60], xmm15
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0061
       mov      rsi, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       test     eax, eax
       je       G_M000_IG48
       vmovsd   xmm1, qword ptr [rcx]
       cmp      eax, 1
       jbe      G_M000_IG48
       vmovsd   xmm2, qword ptr [rcx+0x08]
       cmp      eax, 2
       jbe      G_M000_IG48
       vmovsd   xmm3, qword ptr [rcx+0x10]
       vcvtsd2ss xmm6, xmm6, xmm1
       vcvtsd2ss xmm7, xmm7, xmm2
       vcvtsd2ss xmm8, xmm8, xmm3
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 0
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x00CF
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD00]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm9, xmm1, xmm2
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 1
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x18]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x010E
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG35
 
G_M000_IG06:                ;; offset=0x0121
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD04]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm9
       vmovss   xmm9, dword ptr [reloc @RWD08]
       vaddss   xmm1, xmm1, xmm9
       vxorps   xmm10, xmm10, xmm10
       vmovaps  xmm2, xmm10
       vmovss   xmm11, dword ptr [reloc @RWD12]
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vcmpneqps xmm12, xmm2, xmm2
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vbroadcastss xmm13, dword ptr [reloc @RWD08]
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm14, xmm14, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 2
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x20]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01DE
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG36
 
G_M000_IG08:                ;; offset=0x01F1
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm15, xmm15, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 3
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x027E
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG37
 
G_M000_IG10:                ;; offset=0x0291
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD16]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vmovss   dword ptr [rsp+0x2C], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 4
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x30]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x02D6
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG38
 
G_M000_IG12:                ;; offset=0x02E9
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD20]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x2C]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x58], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 5
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x38]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x038A
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG39
 
G_M000_IG14:                ;; offset=0x039D
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vmovss   dword ptr [rsp+0x28], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 6
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x03DA
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG40
 
G_M000_IG16:                ;; offset=0x03ED
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, xmm11
       vaddss   xmm1, xmm1, xmm11
       vmulss   xmm1, xmm1, dword ptr [rsp+0x28]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x50], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0488
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG41
 
G_M000_IG18:                ;; offset=0x049B
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x48], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x052E
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG42
 
G_M000_IG20:                ;; offset=0x0541
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x40], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 9
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x58]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x05D4
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG43
 
G_M000_IG22:                ;; offset=0x05E7
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD24]
       vaddss   xmm1, xmm1, dword ptr [reloc @RWD28]
       vmovss   dword ptr [rsp+0x24], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 10
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x062C
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG44
 
G_M000_IG24:                ;; offset=0x063F
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD32]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x24]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x38], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 11
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x68]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x06E0
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG45
 
G_M000_IG26:                ;; offset=0x06F3
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x30], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0786
       mov      rax, 0x7FFC657CBC98
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG46
 
G_M000_IG28:                ;; offset=0x0799
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm9
       vmulss   xmm0, xmm0, xmm11
       vcmpeqps xmm1, xmm10, xmm0
       vxorps   xmm2, xmm2, xmm2
       vpcmpgtd xmm2, xmm2, xmm0
       vandps   xmm1, xmm2, xmm1
       vorps    xmm1, xmm1, xmm12
       vcmpltps xmm2, xmm0, xmm10
       vorps    xmm1, xmm2, xmm1
       vandps   xmm2, xmm10, xmm1
       vandnps  xmm0, xmm1, xmm0
       vorps    xmm0, xmm0, xmm2
       vxorps   xmm1, xmm1, xmm1
       vcmpltps xmm2, xmm13, xmm0
       vorps    xmm1, xmm2, xmm1
       vblendvps xmm0, xmm0, xmm13, xmm1
       vcvtss2sd xmm0, xmm0, xmm0
       vmovsd   xmm1, qword ptr [reloc @RWD40]
       vsubsd   xmm2, xmm1, xmm15
       vxorps   xmm3, xmm3, xmm3
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vsubsd   xmm5, xmm4, qword ptr [reloc @RWD48]
       vcmpeqpd xmm6, xmm3, xmm5
       vxorps   xmm7, xmm7, xmm7
       vpcmpgtq xmm7, xmm7, xmm5
       vandpd   xmm6, xmm7, xmm6
       vcmpneqpd xmm7, xmm3, xmm3
       vorpd    xmm6, xmm6, xmm7
       vcmpltpd xmm8, xmm5, xmm3
       vorpd    xmm6, xmm8, xmm6
       vandpd   xmm3, xmm3, xmm6
       vandnpd  xmm5, xmm6, xmm5
       vorpd    xmm3, xmm5, xmm3
       vmovsd   xmm6, qword ptr [rsp+0x30]
       vsubsd   xmm5, xmm6, qword ptr [reloc @RWD56]
       vaddsd   xmm5, xmm5, xmm5
       vxorps   xmm8, xmm8, xmm8
       vsubsd   xmm9, xmm6, qword ptr [reloc @RWD48]
       vdivsd   xmm9, xmm9, qword ptr [reloc @RWD64]
       vcmpeqpd xmm10, xmm8, xmm9
       vxorps   xmm11, xmm11, xmm11
       vpcmpgtq xmm11, xmm11, xmm9
       vandpd   xmm10, xmm11, xmm10
       vorpd    xmm10, xmm10, xmm7
       vcmpltpd xmm11, xmm9, xmm8
       vorpd    xmm10, xmm11, xmm10
       vandpd   xmm8, xmm8, xmm10
       vandnpd  xmm9, xmm10, xmm9
       vorpd    xmm8, xmm9, xmm8
       vmovddup xmm9, qword ptr [reloc @RWD40]
       vmovaps  xmm10, xmm9
 
G_M000_IG29:                ;; offset=0x08B9
       vxorps   xmm11, xmm11, xmm11
       vcmpltpd xmm12, xmm10, xmm8
       vorpd    xmm11, xmm12, xmm11
       vblendvpd xmm8, xmm8, xmm10, xmm11
       vmulsd   xmm10, xmm8, xmm8
       vaddsd   xmm8, xmm8, xmm8
       vmovsd   xmm11, qword ptr [reloc @RWD72]
       vsubsd   xmm8, xmm11, xmm8
       vmulsd   xmm8, xmm8, xmm10
       vsubsd   xmm10, xmm14, qword ptr [reloc @RWD80]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD88]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD96]
       vmovsd   xmm12, qword ptr [rsp+0x58]
       vsubsd   xmm13, xmm12, qword ptr [reloc @RWD56]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD104]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD112]
       vaddsd   xmm10, xmm10, xmm13
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD120]
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD128]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD136]
       vmulsd   xmm2, xmm3, xmm2
       vaddsd   xmm2, xmm10, xmm2
       vmulsd   xmm3, xmm5, qword ptr [reloc @RWD144]
       vaddsd   xmm2, xmm2, xmm3
       vmulsd   xmm3, xmm8, xmm0
       vmulsd   xmm3, xmm3, xmm0
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD152]
       vaddsd   xmm2, xmm2, xmm3
       vsubsd   xmm2, xmm2, qword ptr [reloc @RWD160]
       vmovaps  xmm3, xmm2
       vxorps   xmm5, xmm5, xmm5
       vmovsd   xmm8, qword ptr [rsp+0x38]
       vaddsd   xmm10, xmm8, xmm8
       vsubsd   xmm10, xmm10, xmm1
       vandps   xmm10, xmm10, xmmword ptr [reloc @RWD176]
       vsubsd   xmm10, xmm10, qword ptr [reloc @RWD192]
       vdivsd   xmm10, xmm10, qword ptr [reloc @RWD200]
       vcmpeqpd xmm13, xmm5, xmm10
       vxorps   xmm4, xmm4, xmm4
       vpcmpgtq xmm4, xmm4, xmm10
       vandpd   xmm4, xmm4, xmm13
       vorpd    xmm4, xmm4, xmm7
       vcmpltpd xmm13, xmm10, xmm5
       vorpd    xmm4, xmm13, xmm4
       vandpd   xmm5, xmm5, xmm4
       vandnpd  xmm4, xmm4, xmm10
       vorpd    xmm4, xmm4, xmm5
       vmovaps  xmm5, xmm9
       vxorps   xmm10, xmm10, xmm10
       vcmpltpd xmm13, xmm5, xmm4
       vorpd    xmm10, xmm13, xmm10
       vblendvpd xmm4, xmm4, xmm5, xmm10
       vmulsd   xmm5, xmm4, xmm4
       vaddsd   xmm4, xmm4, xmm4
       vsubsd   xmm4, xmm11, xmm4
       vmulsd   xmm4, xmm5, xmm4
       vsubsd   xmm4, xmm1, xmm4
       vxorps   xmm5, xmm5, xmm5
       vdivsd   xmm2, xmm2, qword ptr [reloc @RWD208]
 
G_M000_IG30:                ;; offset=0x0A05
       vcmpeqpd xmm10, xmm5, xmm2
       vxorps   xmm13, xmm13, xmm13
       vpcmpgtq xmm13, xmm13, xmm2
       vandpd   xmm10, xmm13, xmm10
       vorpd    xmm7, xmm10, xmm7
       vcmpltpd xmm10, xmm2, xmm5
       vorpd    xmm7, xmm10, xmm7
       vandpd   xmm5, xmm5, xmm7
       vandnpd  xmm2, xmm7, xmm2
       vorpd    xmm2, xmm2, xmm5
       vxorps   xmm5, xmm5, xmm5
       vcmpltpd xmm7, xmm9, xmm2
       vorpd    xmm5, xmm7, xmm5
       vblendvpd xmm2, xmm2, xmm9, xmm5
       vmulsd   xmm5, xmm2, xmm2
       vaddsd   xmm2, xmm2, xmm2
       vsubsd   xmm2, xmm11, xmm2
       vmulsd   xmm2, xmm5, xmm2
       vsubsd   xmm1, xmm1, xmm2
       vmulsd   xmm1, xmm1, xmm4
       vmulsd   xmm2, xmm12, qword ptr [reloc @RWD216]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD224]
       vucomisd xmm3, xmm2
       seta     dl
       movzx    rdx, dl
       vsubsd   xmm2, xmm2, xmm3
       vmulsd   xmm2, xmm2, xmm1
       vaddsd   xmm2, xmm2, xmm3
       test     edx, edx
       je       G_M000_IG33
 
G_M000_IG31:                ;; offset=0x0A8B
       cmp      edi, 10
       jle      G_M000_IG47
       vmovsd   qword ptr [rsi], xmm14
       vmovsd   qword ptr [rsi+0x08], xmm15
       vmovsd   qword ptr [rsi+0x10], xmm12
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       vmovsd   qword ptr [rsi+0x30], xmm8
       vmovsd   qword ptr [rsi+0x38], xmm6
       vmovsd   qword ptr [rsi+0x40], xmm0
       vmovsd   qword ptr [rsi+0x48], xmm2
       vmovsd   qword ptr [rsi+0x50], xmm1
 
G_M000_IG32:                ;; offset=0x0ADC
       vmovaps  xmm6, xmmword ptr [rsp+0xF0]
       vmovaps  xmm7, xmmword ptr [rsp+0xE0]
       vmovaps  xmm8, xmmword ptr [rsp+0xD0]
       vmovaps  xmm9, xmmword ptr [rsp+0xC0]
       vmovaps  xmm10, xmmword ptr [rsp+0xB0]
       vmovaps  xmm11, xmmword ptr [rsp+0xA0]
       vmovaps  xmm12, xmmword ptr [rsp+0x90]
       vmovaps  xmm13, xmmword ptr [rsp+0x80]
       vmovaps  xmm14, xmmword ptr [rsp+0x70]
       vmovaps  xmm15, xmmword ptr [rsp+0x60]
       add      rsp, 256
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG33:                ;; offset=0x0B3B
       vmovaps  xmm2, xmm3
       jmp      G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0B44
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG35:                ;; offset=0x0B4E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG36:                ;; offset=0x0B58
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG37:                ;; offset=0x0B62
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG38:                ;; offset=0x0B6C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG39:                ;; offset=0x0B76
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG40:                ;; offset=0x0B80
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG41:                ;; offset=0x0B8A
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG42:                ;; offset=0x0B94
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG43:                ;; offset=0x0B9E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG44:                ;; offset=0x0BA8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG45:                ;; offset=0x0BB2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG46:                ;; offset=0x0BBC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG47:                ;; offset=0x0BC6
       test     edi, edi
       je       G_M000_IG48
       vmovsd   qword ptr [rsi], xmm14
       cmp      edi, 1
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x08], xmm15
       cmp      edi, 2
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x10], xmm12
       cmp      edi, 3
       jbe      SHORT G_M000_IG48
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       cmp      edi, 4
       jbe      SHORT G_M000_IG48
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       cmp      edi, 5
       jbe      SHORT G_M000_IG48
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       cmp      edi, 6
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x30], xmm8
       cmp      edi, 7
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x38], xmm6
       cmp      edi, 8
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x40], xmm0
       cmp      edi, 9
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x48], xmm2
       cmp      edi, 10
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x50], xmm1
       jmp      G_M000_IG32
 
G_M000_IG48:                ;; offset=0x0C4D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	3F47AE14h		;      0.78
RWD04  	dd	3E6147AEh		;      0.22
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F51EB85h		;      0.82
RWD20  	dd	3E3851ECh		;      0.18
RWD24  	dd	3F666666h		;       0.9
RWD28  	dd	3E570A3Dh		;      0.21
RWD32  	dd	3DCCCCCDh		;       0.1
RWD36  	dd	00000000h
RWD40  	dq	3FF0000000000000h	;            1
RWD48  	dq	3FDEB851EB851EB8h	;         0.48
RWD56  	dq	3FE0000000000000h	;          0.5
RWD64  	dq	3FCEB851EB851EB8h	;         0.24
RWD72  	dq	4008000000000000h	;            3
RWD80  	dq	3FD6666666666666h	;         0.35
RWD88  	dq	4038000000000000h	;           24
RWD96  	dq	4000000000000000h	;            2
RWD104 	dq	4044000000000000h	;           40
RWD112 	dq	3FE1EB851EB851ECh	;         0.56
RWD120 	dq	4067C00000000000h	;          190
RWD128 	dq	3FF6666666666666h	;          1.4
RWD136 	dq	3FD3333333333333h	;          0.3
RWD144 	dq	4074000000000000h	;          320
RWD152 	dq	408F400000000000h	;         1000
RWD160 	dq	4010000000000000h	;            4
RWD168 	dd	00000000h, 00000000h
RWD176 	dq	7FFFFFFFFFFFFFFFh, 7FFFFFFFFFFFFFFFh
RWD192 	dq	3F9999999999999Ah	;        0.025
RWD200 	dq	3FB5C28F5C28F5C2h	;        0.085
RWD208 	dq	4042000000000000h	;           36
RWD216 	dq	3FF3333333333333h	;          1.2
RWD224 	dq	C014000000000000h	;           -5

; Total bytes of code 3155

; Assembly listing for method (dynamicClass):lambda_method2(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 16 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       lea      r11, [rsp-0x1AE0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       vmovaps  xmmword ptr [rsp+0x1AD0], xmm6
       vmovaps  xmmword ptr [rsp+0x1AC0], xmm7
       vmovaps  xmmword ptr [rsp+0x1AB0], xmm8
       vmovaps  xmmword ptr [rsp+0x1AA0], xmm9
       vmovaps  xmmword ptr [rsp+0x1A90], xmm10
       vmovaps  xmmword ptr [rsp+0x1A80], xmm11
       vmovaps  xmmword ptr [rsp+0x1A70], xmm12
       vmovaps  xmmword ptr [rsp+0x1A60], xmm13
       vmovaps  xmmword ptr [rsp+0x1A50], xmm14
       vmovaps  xmmword ptr [rsp+0x1A40], xmm15
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -0x1A10
       vmovdqa  xmmword ptr [rsp+rax+0x1A40], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x1A50], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x1A60], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r8
 
G_M000_IG02:                ;; offset=0x00AC
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG03:                ;; offset=0x00B9
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1A00]
       xor      r8d, r8d
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG04:                ;; offset=0x00D8
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG05:                ;; offset=0x00E5
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x19C0]
       mov      r8d, 1
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1980]
       mov      rdx, rdi
       mov      r8d, 2
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1960]
       lea      rdx, [rsp+0x1A00]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToFloat32(Tedd.FastNoise.Procedural.DoublePair):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1940]
       lea      rdx, [rsp+0x19C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToFloat32(Tedd.FastNoise.Procedural.DoublePair):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1920]
       lea      rdx, [rsp+0x1980]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToFloat32(Tedd.FastNoise.Procedural.DoublePair):System.Numerics.Vector`1[float]]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       test     ebp, ebp
       je       G_M000_IG909
       mov      r14, gword ptr [rdx+0x10]
       mov      r15, 0x7FFC658A3210
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x018B
       mov      rdx, r14
       mov      rcx, r15
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG07:                ;; offset=0x0197
       vmovups  ymm6, ymmword ptr [r14+0x08]
       mov      rdx, rdi
       cmp      ebp, 1
       jbe      G_M000_IG909
       mov      r14, gword ptr [rdx+0x18]
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01B2
       mov      rdx, r14
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG09:                ;; offset=0x01CA
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      ebp, 2
       jbe      G_M000_IG909
       mov      r14, gword ptr [rdx+0x20]
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x01F7
       mov      rdx, r14
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG11:                ;; offset=0x020F
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      ebp, 3
       jbe      G_M000_IG909
       mov      r14, gword ptr [rdx+0x28]
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x023C
       mov      rdx, r14
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG13:                ;; offset=0x0254
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      ebp, 4
       jbe      G_M000_IG909
       mov      r14, gword ptr [rdx+0x30]
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0281
       mov      rdx, r14
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG15:                ;; offset=0x0299
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      ebp, 5
       jbe      G_M000_IG909
       mov      r14, gword ptr [rdx+0x38]
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x0320
       mov      rdx, r14
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG17:                ;; offset=0x0338
       vmovups  ymm0, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      ebp, 6
       jbe      G_M000_IG909
       mov      r14, gword ptr [rdx+0x40]
       cmp      qword ptr [r14], r15
       je       SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x035C
       mov      rdx, r14
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG19:                ;; offset=0x0374
       vmovups  ymm0, ymmword ptr [r14+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      ebp, 7
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x48]
       mov      rbp, 0x7FFC6589D020
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x039F
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG21:                ;; offset=0x03B7
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 8
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x50]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x047D
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG23:                ;; offset=0x0495
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm8, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 9
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x58]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x04BB
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG25:                ;; offset=0x04DF
       vmulps   ymm0, ymm8, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 10
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x60]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0505
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG27:                ;; offset=0x051D
       vmovups  ymm8, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 11
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x68]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x053A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG29:                ;; offset=0x055E
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 12
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x70]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x057B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG31:                ;; offset=0x05AB
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm10
       vaddps   ymm0, ymm0, ymm8
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 13
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x78]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x05ED
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG33:                ;; offset=0x0605
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 14
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x80]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0637
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG35:                ;; offset=0x064F
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 15
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x88]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0681
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG37:                ;; offset=0x0699
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 16
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x90]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x06CB
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG39:                ;; offset=0x06E3
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 17
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x98]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0711
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG41:                ;; offset=0x0729
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 18
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xA0]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       je       SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x07F2
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG43:                ;; offset=0x080A
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm8, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 19
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xA8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0833
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG45:                ;; offset=0x0857
       vmulps   ymm0, ymm8, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 20
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xB0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x0880
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG47:                ;; offset=0x0898
       vmovups  ymm8, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 21
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xB8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x08B8
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG49:                ;; offset=0x08DC
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 22
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xC0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x08FC
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG51:                ;; offset=0x092C
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm10
       vaddps   ymm0, ymm0, ymm8
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 23
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xC8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0971
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG53:                ;; offset=0x0989
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 24
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xD0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x09BB
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG55:                ;; offset=0x09D3
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 25
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xD8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0A05
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG57:                ;; offset=0x0A1D
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 26
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0xE0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x0A4F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG59:                ;; offset=0x0A67
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 27
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0xE8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x0A95
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG61:                ;; offset=0x0AAD
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x380]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x340]
       lea      r8, [rsp+0x3C0]
       lea      r9, [rsp+0x3A0]
       vextractf128 xmm7, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 28
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0xF0]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       je       SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0B3F
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG63:                ;; offset=0x0B54
       mov      rdx, rdi
       cmp      r14d, 29
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0xF8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x0B6D
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG65:                ;; offset=0x0B82
       mov      rdx, rdi
       cmp      r14d, 30
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x100]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG67
 
G_M000_IG66:                ;; offset=0x0B9B
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG67:                ;; offset=0x0BB0
       mov      rdx, rdi
       cmp      r14d, 31
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x108]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x0BC9
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG69:                ;; offset=0x0BDE
       mov      rdx, rdi
       cmp      r14d, 32
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x110]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG71
 
G_M000_IG70:                ;; offset=0x0BF7
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG71:                ;; offset=0x0C0C
       mov      rdx, rdi
       cmp      r14d, 33
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x118]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x0C25
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG73:                ;; offset=0x0C3A
       mov      rdx, rdi
       cmp      r14d, 34
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x120]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x0C53
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG75:                ;; offset=0x0C68
       mov      rdx, rdi
       cmp      r14d, 35
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x128]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0C81
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG77:                ;; offset=0x0C96
       mov      rdx, rdi
       cmp      r14d, 36
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x130]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG79
 
G_M000_IG78:                ;; offset=0x0CAF
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG79:                ;; offset=0x0CC4
       mov      rdx, rdi
       cmp      r14d, 37
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x138]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x0CDE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG81:                ;; offset=0x0CF6
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vaddps   ymm0, ymm0, ymm6
       vmovups  ymmword ptr [rsp+0x1900], ymm0
       mov      rdx, rdi
       cmp      r14d, 38
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x140]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0D2C
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG83:                ;; offset=0x0D44
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 39
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x148]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG85
 
G_M000_IG84:                ;; offset=0x0D76
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG85:                ;; offset=0x0D8E
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 40
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x150]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG87
 
G_M000_IG86:                ;; offset=0x0DC0
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG87:                ;; offset=0x0DD8
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 41
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x158]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x0E0A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG89:                ;; offset=0x0E22
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 42
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x160]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x0EAE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG91:                ;; offset=0x0EC6
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 43
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x168]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x0EEF
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG93:                ;; offset=0x0F07
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 44
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x170]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x0F2C
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG95:                ;; offset=0x0F44
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 45
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x178]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       je       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x100D
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG97:                ;; offset=0x1025
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vaddps   ymm8, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 46
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x180]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x104E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG99:                ;; offset=0x1072
       vmulps   ymm0, ymm8, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 47
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x188]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x109B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG101:                ;; offset=0x10B3
       vmovups  ymm8, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 48
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x190]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x10D3
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG103:                ;; offset=0x10F7
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 49
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x198]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x1117
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG105:                ;; offset=0x1147
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm10
       vaddps   ymm0, ymm0, ymm8
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 50
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x1A0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x118C
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG107:                ;; offset=0x11A4
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 51
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x1A8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x11D6
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG109:                ;; offset=0x11EE
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 52
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x1B0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x1220
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG111:                ;; offset=0x1238
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 53
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x1B8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x126A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG113:                ;; offset=0x1282
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 54
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x1C0]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x12B0
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG115:                ;; offset=0x12C8
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x320]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x360]
       lea      r8, [rsp+0x2E0]
       lea      r9, [rsp+0x300]
       vextractf128 xmm7, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 55
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x1C8]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       je       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x135A
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG117:                ;; offset=0x136F
       mov      rdx, rdi
       cmp      r14d, 56
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x1D0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x1388
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG119:                ;; offset=0x139D
       mov      rdx, rdi
       cmp      r14d, 57
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x1D8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x13B6
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG121:                ;; offset=0x13CB
       mov      rdx, rdi
       cmp      r14d, 58
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x1E0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x13E4
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG123:                ;; offset=0x13F9
       mov      rdx, rdi
       cmp      r14d, 59
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x1E8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x1412
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG125:                ;; offset=0x1427
       mov      rdx, rdi
       cmp      r14d, 60
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x1F0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x1440
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG127:                ;; offset=0x1455
       mov      rdx, rdi
       cmp      r14d, 61
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x1F8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x146E
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG129:                ;; offset=0x1483
       mov      rdx, rdi
       cmp      r14d, 62
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x200]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x149C
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG131:                ;; offset=0x14B1
       mov      rdx, rdi
       cmp      r14d, 63
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x208]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x14CA
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG133:                ;; offset=0x14DF
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x18E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 64
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x210]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x150B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG135:                ;; offset=0x1523
       vmovups  ymm0, ymmword ptr [rsp+0x18E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x1900]
       vmovups  ymmword ptr [rsp+0x18C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 65
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x218]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG137
 
G_M000_IG136:                ;; offset=0x1562
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG137:                ;; offset=0x157A
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x18A0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x18C0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x1880], ymm0
       cmp      r14d, 66
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x220]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG139
 
G_M000_IG138:                ;; offset=0x15BA
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
 
G_M000_IG139:                ;; offset=0x15D2
       vmovups  ymm8, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmulps   ymm0, ymm8, ymmword ptr [rsp+0x1880]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1860]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1840]
       lea      r8, [rsp+0x1860]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1800]
       lea      rdx, [rsp+0x1840]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 67
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x228]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG141
 
G_M000_IG140:                ;; offset=0x1690
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG141:                ;; offset=0x16B4
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 68
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x230]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG143
 
G_M000_IG142:                ;; offset=0x16E6
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG143:                ;; offset=0x170A
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 69
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x238]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG145
 
G_M000_IG144:                ;; offset=0x173C
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG145:                ;; offset=0x1760
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 70
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x240]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG147
 
G_M000_IG146:                ;; offset=0x1792
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG147:                ;; offset=0x17B6
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 71
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x248]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG149
 
G_M000_IG148:                ;; offset=0x1842
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG149:                ;; offset=0x1866
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 72
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x250]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x188F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG151:                ;; offset=0x18B3
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 73
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x258]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG153
 
G_M000_IG152:                ;; offset=0x18D8
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG153:                ;; offset=0x18FC
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 74
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x260]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG155
 
G_M000_IG154:                ;; offset=0x19D1
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG155:                ;; offset=0x19F5
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 75
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x268]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG157
 
G_M000_IG156:                ;; offset=0x1A1E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG157:                ;; offset=0x1A4E
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 76
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x270]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG159
 
G_M000_IG158:                ;; offset=0x1A77
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG159:                ;; offset=0x1A9B
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 77
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x278]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG161
 
G_M000_IG160:                ;; offset=0x1ABB
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG161:                ;; offset=0x1AEB
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 78
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x280]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG163
 
G_M000_IG162:                ;; offset=0x1B0B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG163:                ;; offset=0x1B47
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 79
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x288]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG165
 
G_M000_IG164:                ;; offset=0x1B8C
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG165:                ;; offset=0x1BB0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 80
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x290]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x1BE2
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG167:                ;; offset=0x1C06
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 81
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x298]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG169
 
G_M000_IG168:                ;; offset=0x1C38
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG169:                ;; offset=0x1C5C
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 82
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2A0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x1C8E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG171:                ;; offset=0x1CB2
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 83
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x2A8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG173
 
G_M000_IG172:                ;; offset=0x1CE0
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG173:                ;; offset=0x1D04
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 84
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2B0]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG175
 
G_M000_IG174:                ;; offset=0x1DD9
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG175:                ;; offset=0x1DFD
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 85
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2B8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x1E26
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG177:                ;; offset=0x1E56
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 86
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2C0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG179
 
G_M000_IG178:                ;; offset=0x1E7F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG179:                ;; offset=0x1EA3
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 87
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2C8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG181
 
G_M000_IG180:                ;; offset=0x1EC3
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG181:                ;; offset=0x1EF3
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 88
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2D0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG183
 
G_M000_IG182:                ;; offset=0x1F13
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG183:                ;; offset=0x1F4F
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 89
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2D8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG185
 
G_M000_IG184:                ;; offset=0x1F94
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG185:                ;; offset=0x1FB8
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 90
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2E0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG187
 
G_M000_IG186:                ;; offset=0x1FEA
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG187:                ;; offset=0x200E
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 91
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2E8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG189
 
G_M000_IG188:                ;; offset=0x2040
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG189:                ;; offset=0x2064
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 92
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x2F0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG191
 
G_M000_IG190:                ;; offset=0x2096
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG191:                ;; offset=0x20BA
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 93
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x2F8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG193
 
G_M000_IG192:                ;; offset=0x20E8
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG193:                ;; offset=0x210C
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x380]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x340]
       lea      r8, [rsp+0x3C0]
       lea      r9, [rsp+0x3A0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 94
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x300]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG195
 
G_M000_IG194:                ;; offset=0x21AA
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG195:                ;; offset=0x21CB
       mov      rdx, rdi
       cmp      r14d, 95
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x308]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG197
 
G_M000_IG196:                ;; offset=0x21E4
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG197:                ;; offset=0x2205
       mov      rdx, rdi
       cmp      r14d, 96
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x310]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG199
 
G_M000_IG198:                ;; offset=0x221E
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG199:                ;; offset=0x223F
       mov      rdx, rdi
       cmp      r14d, 97
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x318]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG201
 
G_M000_IG200:                ;; offset=0x2258
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG201:                ;; offset=0x2279
       mov      rdx, rdi
       cmp      r14d, 98
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x320]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG203
 
G_M000_IG202:                ;; offset=0x2292
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG203:                ;; offset=0x22B3
       mov      rdx, rdi
       cmp      r14d, 99
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x328]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG205
 
G_M000_IG204:                ;; offset=0x22CC
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG205:                ;; offset=0x22ED
       mov      rdx, rdi
       cmp      r14d, 100
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x330]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG207
 
G_M000_IG206:                ;; offset=0x2306
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG207:                ;; offset=0x2327
       mov      rdx, rdi
       cmp      r14d, 101
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x338]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x2340
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG209:                ;; offset=0x2361
       cmp      r14d, 102
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdi+0x340]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG211
 
G_M000_IG210:                ;; offset=0x2377
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG211:                ;; offset=0x2398
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmulps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x17E0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x17C0]
       lea      r8, [rsp+0x17E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1780]
       lea      rdx, [rsp+0x17C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 103
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x348]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG213
 
G_M000_IG212:                ;; offset=0x246C
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG213:                ;; offset=0x2490
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 104
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x350]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG215
 
G_M000_IG214:                ;; offset=0x24C2
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG215:                ;; offset=0x24E6
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 105
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x358]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG217
 
G_M000_IG216:                ;; offset=0x2518
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG217:                ;; offset=0x253C
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 106
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x360]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x256E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG219:                ;; offset=0x2592
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 107
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x368]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG221
 
G_M000_IG220:                ;; offset=0x261E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG221:                ;; offset=0x2642
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 108
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x370]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG223
 
G_M000_IG222:                ;; offset=0x266B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG223:                ;; offset=0x268F
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 109
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x378]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG225
 
G_M000_IG224:                ;; offset=0x26B4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG225:                ;; offset=0x26D8
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 110
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x380]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG227
 
G_M000_IG226:                ;; offset=0x27AD
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG227:                ;; offset=0x27D1
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 111
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x388]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG229
 
G_M000_IG228:                ;; offset=0x27FA
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG229:                ;; offset=0x282A
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 112
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x390]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG231
 
G_M000_IG230:                ;; offset=0x2853
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG231:                ;; offset=0x2877
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 113
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x398]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG233
 
G_M000_IG232:                ;; offset=0x2897
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG233:                ;; offset=0x28C7
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 114
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x3A0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG235
 
G_M000_IG234:                ;; offset=0x28E7
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG235:                ;; offset=0x2923
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 115
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x3A8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG237
 
G_M000_IG236:                ;; offset=0x2968
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG237:                ;; offset=0x298C
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 116
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x3B0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG239
 
G_M000_IG238:                ;; offset=0x29BE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG239:                ;; offset=0x29E2
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 117
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x3B8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG241
 
G_M000_IG240:                ;; offset=0x2A14
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG241:                ;; offset=0x2A38
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 118
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x3C0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG243
 
G_M000_IG242:                ;; offset=0x2A6A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG243:                ;; offset=0x2A8E
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 119
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x3C8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG245
 
G_M000_IG244:                ;; offset=0x2ABC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG245:                ;; offset=0x2AE0
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 120
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x3D0]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG247
 
G_M000_IG246:                ;; offset=0x2BB5
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG247:                ;; offset=0x2BD9
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 121
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x3D8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG249
 
G_M000_IG248:                ;; offset=0x2C02
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG249:                ;; offset=0x2C32
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 122
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x3E0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG251
 
G_M000_IG250:                ;; offset=0x2C5B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG251:                ;; offset=0x2C7F
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 123
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x03E8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG253
 
G_M000_IG252:                ;; offset=0x2C9F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG253:                ;; offset=0x2CCF
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 124
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x03F0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG255
 
G_M000_IG254:                ;; offset=0x2CEF
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG255:                ;; offset=0x2D2B
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 125
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x03F8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG257
 
G_M000_IG256:                ;; offset=0x2D70
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG257:                ;; offset=0x2D94
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 126
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0400]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG259
 
G_M000_IG258:                ;; offset=0x2DC6
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG259:                ;; offset=0x2DEA
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 127
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0408]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG261
 
G_M000_IG260:                ;; offset=0x2E1C
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG261:                ;; offset=0x2E40
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 128
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0410]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG263
 
G_M000_IG262:                ;; offset=0x2E75
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG263:                ;; offset=0x2E99
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 129
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0418]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG265
 
G_M000_IG264:                ;; offset=0x2ECA
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG265:                ;; offset=0x2EEE
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x320]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x360]
       lea      r8, [rsp+0x2E0]
       lea      r9, [rsp+0x300]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 130
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0420]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG267
 
G_M000_IG266:                ;; offset=0x2F8F
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG267:                ;; offset=0x2FB0
       mov      rdx, rdi
       cmp      r14d, 131
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0428]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG269
 
G_M000_IG268:                ;; offset=0x2FCC
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG269:                ;; offset=0x2FED
       mov      rdx, rdi
       cmp      r14d, 132
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0430]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG271
 
G_M000_IG270:                ;; offset=0x3009
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG271:                ;; offset=0x302A
       mov      rdx, rdi
       cmp      r14d, 133
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0438]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG273
 
G_M000_IG272:                ;; offset=0x3046
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG273:                ;; offset=0x3067
       mov      rdx, rdi
       cmp      r14d, 134
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0440]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG275
 
G_M000_IG274:                ;; offset=0x3083
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG275:                ;; offset=0x30A4
       mov      rdx, rdi
       cmp      r14d, 135
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0448]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG277
 
G_M000_IG276:                ;; offset=0x30C0
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG277:                ;; offset=0x30E1
       mov      rdx, rdi
       cmp      r14d, 136
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0450]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG279
 
G_M000_IG278:                ;; offset=0x30FD
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG279:                ;; offset=0x311E
       mov      rdx, rdi
       cmp      r14d, 137
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0458]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG281
 
G_M000_IG280:                ;; offset=0x313A
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG281:                ;; offset=0x315B
       mov      rdx, rdi
       cmp      r14d, 138
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0460]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG283
 
G_M000_IG282:                ;; offset=0x3177
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG283:                ;; offset=0x3198
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x1760], ymm0
       mov      rdx, rdi
       cmp      r14d, 139
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0468]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0x31C7
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG285:                ;; offset=0x31EB
       vmovups  ymm0, ymmword ptr [rsp+0x1760]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vaddps   ymm0, ymm0, ymm6
       vmovups  ymmword ptr [rsp+0x1740], ymm0
       mov      rdx, rdi
       cmp      r14d, 140
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0470]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG287
 
G_M000_IG286:                ;; offset=0x3224
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG287:                ;; offset=0x3248
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 141
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0478]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG289
 
G_M000_IG288:                ;; offset=0x327D
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG289:                ;; offset=0x32A1
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 142
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0480]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG291
 
G_M000_IG290:                ;; offset=0x32D6
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG291:                ;; offset=0x32FA
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 143
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0488]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG293
 
G_M000_IG292:                ;; offset=0x332F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG293:                ;; offset=0x3353
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 144
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0490]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG295
 
G_M000_IG294:                ;; offset=0x33E2
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG295:                ;; offset=0x3406
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 145
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0498]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG297
 
G_M000_IG296:                ;; offset=0x3432
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG297:                ;; offset=0x3456
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 146
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x04A0]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG299
 
G_M000_IG298:                ;; offset=0x347E
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG299:                ;; offset=0x34A2
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 147
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04A8]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG301
 
G_M000_IG300:                ;; offset=0x357A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG301:                ;; offset=0x359E
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 148
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04B0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG303
 
G_M000_IG302:                ;; offset=0x35CA
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG303:                ;; offset=0x35FA
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 149
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04B8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG305
 
G_M000_IG304:                ;; offset=0x3626
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG305:                ;; offset=0x364A
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 150
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04C0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG307
 
G_M000_IG306:                ;; offset=0x366D
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG307:                ;; offset=0x369D
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 151
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04C8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG309
 
G_M000_IG308:                ;; offset=0x36C0
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG309:                ;; offset=0x36FC
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 152
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04D0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG311
 
G_M000_IG310:                ;; offset=0x3744
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG311:                ;; offset=0x3768
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 153
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04D8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG313
 
G_M000_IG312:                ;; offset=0x379D
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG313:                ;; offset=0x37C1
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 154
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04E0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG315
 
G_M000_IG314:                ;; offset=0x37F6
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG315:                ;; offset=0x381A
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 155
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x04E8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG317
 
G_M000_IG316:                ;; offset=0x384F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG317:                ;; offset=0x3873
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 156
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x04F0]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG319
 
G_M000_IG318:                ;; offset=0x38A4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG319:                ;; offset=0x38C8
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x380]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x340]
       lea      r8, [rsp+0x3C0]
       lea      r9, [rsp+0x3A0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 157
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x04F8]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG321
 
G_M000_IG320:                ;; offset=0x3969
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG321:                ;; offset=0x398A
       mov      rdx, rdi
       cmp      r14d, 158
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0500]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG323
 
G_M000_IG322:                ;; offset=0x39A6
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG323:                ;; offset=0x39C7
       mov      rdx, rdi
       cmp      r14d, 159
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0508]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG325
 
G_M000_IG324:                ;; offset=0x39E3
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG325:                ;; offset=0x3A04
       mov      rdx, rdi
       cmp      r14d, 160
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0510]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG327
 
G_M000_IG326:                ;; offset=0x3A20
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG327:                ;; offset=0x3A41
       mov      rdx, rdi
       cmp      r14d, 161
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0518]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG329
 
G_M000_IG328:                ;; offset=0x3A5D
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG329:                ;; offset=0x3A7E
       mov      rdx, rdi
       cmp      r14d, 162
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0520]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG331
 
G_M000_IG330:                ;; offset=0x3A9A
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG331:                ;; offset=0x3ABB
       mov      rdx, rdi
       cmp      r14d, 163
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0528]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG333
 
G_M000_IG332:                ;; offset=0x3AD7
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG333:                ;; offset=0x3AF8
       mov      rdx, rdi
       cmp      r14d, 164
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0530]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG335
 
G_M000_IG334:                ;; offset=0x3B14
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG335:                ;; offset=0x3B35
       mov      rdx, rdi
       cmp      r14d, 165
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0538]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG337
 
G_M000_IG336:                ;; offset=0x3B51
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG337:                ;; offset=0x3B72
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x1720], ymm0
       cmp      r14d, 166
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0540]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG339
 
G_M000_IG338:                ;; offset=0x3B9D
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG339:                ;; offset=0x3BC1
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1720]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x1740]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmulps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1700]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x16E0]
       lea      r8, [rsp+0x1700]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x16A0]
       lea      rdx, [rsp+0x16E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 167
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0548]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG341
 
G_M000_IG340:                ;; offset=0x3C9D
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG341:                ;; offset=0x3CC1
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 168
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0550]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG343
 
G_M000_IG342:                ;; offset=0x3CF6
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG343:                ;; offset=0x3D1A
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 169
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0558]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG345
 
G_M000_IG344:                ;; offset=0x3D4F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG345:                ;; offset=0x3D73
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 170
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0560]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x3DA8
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG347:                ;; offset=0x3DCC
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 171
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0568]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG349
 
G_M000_IG348:                ;; offset=0x3E5B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG349:                ;; offset=0x3E7F
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 172
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0570]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG351
 
G_M000_IG350:                ;; offset=0x3EAB
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG351:                ;; offset=0x3ECF
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 173
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0578]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG353
 
G_M000_IG352:                ;; offset=0x3EF7
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG353:                ;; offset=0x3F1B
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 174
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0580]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG355
 
G_M000_IG354:                ;; offset=0x3FE9
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG355:                ;; offset=0x400D
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 175
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0588]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG357
 
G_M000_IG356:                ;; offset=0x4039
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG357:                ;; offset=0x4069
       vaddps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 176
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0590]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG359
 
G_M000_IG358:                ;; offset=0x40A7
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG359:                ;; offset=0x40CB
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x360]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 177
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0598]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG361
 
G_M000_IG360:                ;; offset=0x4100
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG361:                ;; offset=0x4124
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 178
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05A0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG363
 
G_M000_IG362:                ;; offset=0x4147
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG363:                ;; offset=0x4177
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 179
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05A8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG365
 
G_M000_IG364:                ;; offset=0x419A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG365:                ;; offset=0x41D6
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 180
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05B0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG367
 
G_M000_IG366:                ;; offset=0x421E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG367:                ;; offset=0x4242
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 181
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05B8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG369
 
G_M000_IG368:                ;; offset=0x4277
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG369:                ;; offset=0x429B
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 182
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05C0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG371
 
G_M000_IG370:                ;; offset=0x42D0
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG371:                ;; offset=0x42F4
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 183
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05C8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG373
 
G_M000_IG372:                ;; offset=0x4329
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG373:                ;; offset=0x434D
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 184
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x05D0]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG375
 
G_M000_IG374:                ;; offset=0x437E
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG375:                ;; offset=0x43A2
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 185
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05D8]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG377
 
G_M000_IG376:                ;; offset=0x4470
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG377:                ;; offset=0x4494
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 186
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05E0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG379
 
G_M000_IG378:                ;; offset=0x44C0
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG379:                ;; offset=0x44F0
       vaddps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 187
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05E8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG381
 
G_M000_IG380:                ;; offset=0x452E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG381:                ;; offset=0x4552
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x360]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 188
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05F0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG383
 
G_M000_IG382:                ;; offset=0x4587
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG383:                ;; offset=0x45AB
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 189
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x05F8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG385
 
G_M000_IG384:                ;; offset=0x45CE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG385:                ;; offset=0x45FE
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 190
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0600]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG387
 
G_M000_IG386:                ;; offset=0x4621
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG387:                ;; offset=0x465D
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 191
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0608]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG389
 
G_M000_IG388:                ;; offset=0x46A5
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG389:                ;; offset=0x46C9
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 192
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0610]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG391
 
G_M000_IG390:                ;; offset=0x46FE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG391:                ;; offset=0x4722
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 193
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0618]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG393
 
G_M000_IG392:                ;; offset=0x4757
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG393:                ;; offset=0x477B
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 194
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0620]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG395
 
G_M000_IG394:                ;; offset=0x47B0
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG395:                ;; offset=0x47D4
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 195
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0628]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG397
 
G_M000_IG396:                ;; offset=0x4805
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG397:                ;; offset=0x4829
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 196
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0630]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG399
 
G_M000_IG398:                ;; offset=0x48F7
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG399:                ;; offset=0x491B
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 197
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0638]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG401
 
G_M000_IG400:                ;; offset=0x4947
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG401:                ;; offset=0x4977
       vaddps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 198
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0640]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG403
 
G_M000_IG402:                ;; offset=0x49B5
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG403:                ;; offset=0x49D9
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x360]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 199
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0648]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG405
 
G_M000_IG404:                ;; offset=0x4A0E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG405:                ;; offset=0x4A32
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 200
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0650]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG407
 
G_M000_IG406:                ;; offset=0x4A55
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG407:                ;; offset=0x4A85
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 201
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0658]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG409
 
G_M000_IG408:                ;; offset=0x4AA8
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG409:                ;; offset=0x4AE4
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 202
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0660]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG411
 
G_M000_IG410:                ;; offset=0x4B2C
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG411:                ;; offset=0x4B50
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 203
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0668]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG413
 
G_M000_IG412:                ;; offset=0x4B85
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG413:                ;; offset=0x4BA9
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 204
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0670]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG415
 
G_M000_IG414:                ;; offset=0x4BDE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG415:                ;; offset=0x4C02
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 205
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0678]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG417
 
G_M000_IG416:                ;; offset=0x4C37
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG417:                ;; offset=0x4C5B
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 206
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0680]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG419
 
G_M000_IG418:                ;; offset=0x4C8C
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG419:                ;; offset=0x4CB0
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x320]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x360]
       lea      r8, [rsp+0x2E0]
       lea      r9, [rsp+0x300]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 207
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0688]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG421
 
G_M000_IG420:                ;; offset=0x4D48
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG421:                ;; offset=0x4D6C
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 208
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0690]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG423
 
G_M000_IG422:                ;; offset=0x4D98
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG423:                ;; offset=0x4DC8
       vaddps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 209
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0698]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG425
 
G_M000_IG424:                ;; offset=0x4E05
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG425:                ;; offset=0x4E26
       mov      rdx, rdi
       cmp      r14d, 210
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x06A0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG427
 
G_M000_IG426:                ;; offset=0x4E42
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG427:                ;; offset=0x4E63
       mov      rdx, rdi
       cmp      r14d, 211
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x06A8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG429
 
G_M000_IG428:                ;; offset=0x4E7F
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG429:                ;; offset=0x4EA0
       mov      rdx, rdi
       cmp      r14d, 212
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x06B0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG431
 
G_M000_IG430:                ;; offset=0x4EBC
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG431:                ;; offset=0x4EDD
       mov      rdx, rdi
       cmp      r14d, 213
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x06B8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG433
 
G_M000_IG432:                ;; offset=0x4EF9
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG433:                ;; offset=0x4F1A
       mov      rdx, rdi
       cmp      r14d, 214
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x06C0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG435
 
G_M000_IG434:                ;; offset=0x4F36
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG435:                ;; offset=0x4F57
       mov      rdx, rdi
       cmp      r14d, 215
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x06C8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG437
 
G_M000_IG436:                ;; offset=0x4F73
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG437:                ;; offset=0x4F94
       mov      rdx, rdi
       cmp      r14d, 216
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x06D0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG439
 
G_M000_IG438:                ;; offset=0x4FB0
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG439:                ;; offset=0x4FD1
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vaddps   ymm0, ymm0, ymm6
       vmovups  ymmword ptr [rsp+0x1680], ymm0
       mov      rdx, rdi
       cmp      r14d, 217
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x06D8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG441
 
G_M000_IG440:                ;; offset=0x500D
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG441:                ;; offset=0x5031
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 218
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x06E0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG443
 
G_M000_IG442:                ;; offset=0x5066
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG443:                ;; offset=0x508A
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 219
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x06E8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG445
 
G_M000_IG444:                ;; offset=0x50BF
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG445:                ;; offset=0x50E3
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 220
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x06F0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG447
 
G_M000_IG446:                ;; offset=0x5118
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG447:                ;; offset=0x513C
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 221
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x06F8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG449
 
G_M000_IG448:                ;; offset=0x51CB
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG449:                ;; offset=0x51EF
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 222
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0700]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG451
 
G_M000_IG450:                ;; offset=0x521B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG451:                ;; offset=0x523F
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 223
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0708]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG453
 
G_M000_IG452:                ;; offset=0x5267
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG453:                ;; offset=0x528B
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 224
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0710]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG455
 
G_M000_IG454:                ;; offset=0x5363
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG455:                ;; offset=0x5387
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 225
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0718]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG457
 
G_M000_IG456:                ;; offset=0x53B3
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG457:                ;; offset=0x53E3
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 226
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0720]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG459
 
G_M000_IG458:                ;; offset=0x540F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG459:                ;; offset=0x5433
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 227
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0728]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG461
 
G_M000_IG460:                ;; offset=0x5456
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG461:                ;; offset=0x5486
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 228
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0730]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG463
 
G_M000_IG462:                ;; offset=0x54A9
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG463:                ;; offset=0x54E5
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 229
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0738]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG465
 
G_M000_IG464:                ;; offset=0x552D
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG465:                ;; offset=0x5551
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 230
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0740]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG467
 
G_M000_IG466:                ;; offset=0x5586
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG467:                ;; offset=0x55AA
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 231
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0748]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG469
 
G_M000_IG468:                ;; offset=0x55DF
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG469:                ;; offset=0x5603
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 232
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0750]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG471
 
G_M000_IG470:                ;; offset=0x5638
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG471:                ;; offset=0x565C
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 233
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0758]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG473
 
G_M000_IG472:                ;; offset=0x568D
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG473:                ;; offset=0x56B1
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x380]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x340]
       lea      r8, [rsp+0x3C0]
       lea      r9, [rsp+0x3A0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 234
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0760]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG475
 
G_M000_IG474:                ;; offset=0x5752
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG475:                ;; offset=0x5773
       mov      rdx, rdi
       cmp      r14d, 235
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0768]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG477
 
G_M000_IG476:                ;; offset=0x578F
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG477:                ;; offset=0x57B0
       mov      rdx, rdi
       cmp      r14d, 236
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0770]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG479
 
G_M000_IG478:                ;; offset=0x57CC
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG479:                ;; offset=0x57ED
       mov      rdx, rdi
       cmp      r14d, 237
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0778]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG481
 
G_M000_IG480:                ;; offset=0x5809
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG481:                ;; offset=0x582A
       mov      rdx, rdi
       cmp      r14d, 238
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0780]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG483
 
G_M000_IG482:                ;; offset=0x5846
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG483:                ;; offset=0x5867
       mov      rdx, rdi
       cmp      r14d, 239
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0788]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG485
 
G_M000_IG484:                ;; offset=0x5883
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG485:                ;; offset=0x58A4
       mov      rdx, rdi
       cmp      r14d, 240
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0790]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG487
 
G_M000_IG486:                ;; offset=0x58C0
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG487:                ;; offset=0x58E1
       mov      rdx, rdi
       cmp      r14d, 241
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0798]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG489
 
G_M000_IG488:                ;; offset=0x58FD
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG489:                ;; offset=0x591E
       cmp      r14d, 242
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdi+0x07A0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG491
 
G_M000_IG490:                ;; offset=0x5937
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG491:                ;; offset=0x5958
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmulps   ymm0, ymm8, ymmword ptr [rsp+0x320]
       vaddps   ymm0, ymm0, ymm8
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x1680]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmulps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1660]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1640]
       lea      r8, [rsp+0x1660]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1600]
       lea      rdx, [rsp+0x1640]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 243
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07A8]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG493
 
G_M000_IG492:                ;; offset=0x5A30
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG493:                ;; offset=0x5A54
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 244
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07B0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG495
 
G_M000_IG494:                ;; offset=0x5A89
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG495:                ;; offset=0x5AAD
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 245
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07B8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG497
 
G_M000_IG496:                ;; offset=0x5AE2
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG497:                ;; offset=0x5B06
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 246
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07C0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG499
 
G_M000_IG498:                ;; offset=0x5B3B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG499:                ;; offset=0x5B5F
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 247
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07C8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG501
 
G_M000_IG500:                ;; offset=0x5BEE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG501:                ;; offset=0x5C12
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 248
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07D0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG503
 
G_M000_IG502:                ;; offset=0x5C3E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG503:                ;; offset=0x5C62
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 249
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x07D8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG505
 
G_M000_IG504:                ;; offset=0x5C8A
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG505:                ;; offset=0x5CAE
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 250
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07E0]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG507
 
G_M000_IG506:                ;; offset=0x5D86
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG507:                ;; offset=0x5DAA
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 251
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07E8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG509
 
G_M000_IG508:                ;; offset=0x5DD6
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG509:                ;; offset=0x5E06
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 252
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07F0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG511
 
G_M000_IG510:                ;; offset=0x5E32
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG511:                ;; offset=0x5E56
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 253
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x07F8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG513
 
G_M000_IG512:                ;; offset=0x5E79
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG513:                ;; offset=0x5EA9
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 254
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0800]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG515
 
G_M000_IG514:                ;; offset=0x5ECC
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG515:                ;; offset=0x5F08
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 255
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0808]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG517
 
G_M000_IG516:                ;; offset=0x5F50
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG517:                ;; offset=0x5F74
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 256
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0810]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG519
 
G_M000_IG518:                ;; offset=0x5FA9
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG519:                ;; offset=0x5FCD
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 257
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0818]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG521
 
G_M000_IG520:                ;; offset=0x6002
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG521:                ;; offset=0x6026
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 258
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0820]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG523
 
G_M000_IG522:                ;; offset=0x605B
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG523:                ;; offset=0x607F
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 259
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0828]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG525
 
G_M000_IG524:                ;; offset=0x60B0
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG525:                ;; offset=0x60D4
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 260
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0830]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG527
 
G_M000_IG526:                ;; offset=0x61AC
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG527:                ;; offset=0x61D0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 261
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0838]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG529
 
G_M000_IG528:                ;; offset=0x61FC
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG529:                ;; offset=0x622C
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 262
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0840]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG531
 
G_M000_IG530:                ;; offset=0x6258
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG531:                ;; offset=0x627C
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 263
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0848]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG533
 
G_M000_IG532:                ;; offset=0x629F
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG533:                ;; offset=0x62CF
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 264
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0850]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG535
 
G_M000_IG534:                ;; offset=0x62F2
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG535:                ;; offset=0x632E
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 265
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0858]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG537
 
G_M000_IG536:                ;; offset=0x6376
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG537:                ;; offset=0x639A
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 266
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0860]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG539
 
G_M000_IG538:                ;; offset=0x63CF
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG539:                ;; offset=0x63F3
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 267
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0868]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG541
 
G_M000_IG540:                ;; offset=0x6428
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG541:                ;; offset=0x644C
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 268
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0870]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG543
 
G_M000_IG542:                ;; offset=0x6481
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG543:                ;; offset=0x64A5
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       cmp      r14d, 269
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0878]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG545
 
G_M000_IG544:                ;; offset=0x64D6
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG545:                ;; offset=0x64FA
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x320]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x360]
       lea      r8, [rsp+0x2E0]
       lea      r9, [rsp+0x300]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 270
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0880]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG547
 
G_M000_IG546:                ;; offset=0x659B
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG547:                ;; offset=0x65BC
       mov      rdx, rdi
       cmp      r14d, 271
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0888]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG549
 
G_M000_IG548:                ;; offset=0x65D8
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG549:                ;; offset=0x65F9
       mov      rdx, rdi
       cmp      r14d, 272
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0890]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG551
 
G_M000_IG550:                ;; offset=0x6615
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG551:                ;; offset=0x6636
       mov      rdx, rdi
       cmp      r14d, 273
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0898]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG553
 
G_M000_IG552:                ;; offset=0x6652
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG553:                ;; offset=0x6673
       mov      rdx, rdi
       cmp      r14d, 274
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x08A0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG555
 
G_M000_IG554:                ;; offset=0x668F
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG555:                ;; offset=0x66B0
       mov      rdx, rdi
       cmp      r14d, 275
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x08A8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG557
 
G_M000_IG556:                ;; offset=0x66CC
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG557:                ;; offset=0x66ED
       mov      rdx, rdi
       cmp      r14d, 276
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x08B0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG559
 
G_M000_IG558:                ;; offset=0x6709
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG559:                ;; offset=0x672A
       mov      rdx, rdi
       cmp      r14d, 277
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x08B8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG561
 
G_M000_IG560:                ;; offset=0x6746
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG561:                ;; offset=0x6767
       cmp      r14d, 278
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdi+0x08C0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG563
 
G_M000_IG562:                ;; offset=0x6780
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG563:                ;; offset=0x67A1
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmulps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x15E0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x15C0]
       lea      r8, [rsp+0x15E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1580]
       lea      rdx, [rsp+0x15C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 279
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x08C8]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG565
 
G_M000_IG564:                ;; offset=0x6878
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG565:                ;; offset=0x689C
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 280
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x08D0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG567
 
G_M000_IG566:                ;; offset=0x68D1
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG567:                ;; offset=0x68F5
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 281
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x08D8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG569
 
G_M000_IG568:                ;; offset=0x692A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG569:                ;; offset=0x694E
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 282
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x08E0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG571
 
G_M000_IG570:                ;; offset=0x6983
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG571:                ;; offset=0x69A7
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 283
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x08E8]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG573
 
G_M000_IG572:                ;; offset=0x6A36
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG573:                ;; offset=0x6A5A
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, rdi
       cmp      r14d, 284
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x08F0]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG575
 
G_M000_IG574:                ;; offset=0x6A86
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG575:                ;; offset=0x6AAA
       vmovups  ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 285
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x08F8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG577
 
G_M000_IG576:                ;; offset=0x6AD2
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG577:                ;; offset=0x6AF6
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 286
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0900]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG579
 
G_M000_IG578:                ;; offset=0x6BCE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG579:                ;; offset=0x6BF2
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 287
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0908]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG581
 
G_M000_IG580:                ;; offset=0x6C1E
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG581:                ;; offset=0x6C4E
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 288
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0910]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG583
 
G_M000_IG582:                ;; offset=0x6C7A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG583:                ;; offset=0x6C9E
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 289
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0918]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG585
 
G_M000_IG584:                ;; offset=0x6CC1
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG585:                ;; offset=0x6CF1
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 290
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0920]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG587
 
G_M000_IG586:                ;; offset=0x6D14
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG587:                ;; offset=0x6D50
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 291
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0928]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG589
 
G_M000_IG588:                ;; offset=0x6D98
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG589:                ;; offset=0x6DBC
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 292
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0930]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG591
 
G_M000_IG590:                ;; offset=0x6DF1
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG591:                ;; offset=0x6E15
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 293
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0938]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG593
 
G_M000_IG592:                ;; offset=0x6E4A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG593:                ;; offset=0x6E6E
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 294
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0940]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG595
 
G_M000_IG594:                ;; offset=0x6EA3
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG595:                ;; offset=0x6EC7
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 295
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0948]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG597
 
G_M000_IG596:                ;; offset=0x6EF8
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG597:                ;; offset=0x6F1C
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      r14d, dword ptr [rdx+0x08]
       cmp      r14d, 296
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0950]
       cmp      qword ptr [r13], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG599
 
G_M000_IG598:                ;; offset=0x6FF4
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG599:                ;; offset=0x7018
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm10, ymm0, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 297
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0958]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG601
 
G_M000_IG600:                ;; offset=0x7044
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG601:                ;; offset=0x7074
       vmulps   ymm0, ymm10, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, rdi
       cmp      r14d, 298
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0960]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG603
 
G_M000_IG602:                ;; offset=0x70A0
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG603:                ;; offset=0x70C4
       vmovups  ymm10, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 299
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0968]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG605
 
G_M000_IG604:                ;; offset=0x70E7
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG605:                ;; offset=0x7117
       vmovups  ymm12, ymmword ptr [r13+0x08]
       mov      rdx, rdi
       cmp      r14d, 300
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0970]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG607
 
G_M000_IG606:                ;; offset=0x713A
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG607:                ;; offset=0x7176
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, rdi
       cmp      r14d, 301
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0978]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG609
 
G_M000_IG608:                ;; offset=0x71BE
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG609:                ;; offset=0x71E2
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, rdi
       cmp      r14d, 302
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0980]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG611
 
G_M000_IG610:                ;; offset=0x7217
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG611:                ;; offset=0x723B
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, rdi
       cmp      r14d, 303
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0988]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG613
 
G_M000_IG612:                ;; offset=0x7270
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG613:                ;; offset=0x7294
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, rdi
       cmp      r14d, 304
       jbe      G_M000_IG909
       mov      r13, gword ptr [rdx+0x0990]
       cmp      qword ptr [r13], r15
       je       SHORT G_M000_IG615
 
G_M000_IG614:                ;; offset=0x72C9
       mov      rdx, r13
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG615:                ;; offset=0x72ED
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [r13+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       cmp      r14d, 305
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdi+0x0998]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG617
 
G_M000_IG616:                ;; offset=0x731E
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG617:                ;; offset=0x7342
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x380]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x340]
       lea      r8, [rsp+0x3C0]
       lea      r9, [rsp+0x3A0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 306
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x09A0]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG619
 
G_M000_IG618:                ;; offset=0x73DF
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG619:                ;; offset=0x7400
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 307
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x09A8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG621
 
G_M000_IG620:                ;; offset=0x741C
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG621:                ;; offset=0x743D
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 308
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x09B0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG623
 
G_M000_IG622:                ;; offset=0x7459
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG623:                ;; offset=0x747A
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 309
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x09B8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG625
 
G_M000_IG624:                ;; offset=0x7496
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG625:                ;; offset=0x74B7
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 310
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x09C0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG627
 
G_M000_IG626:                ;; offset=0x74D3
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG627:                ;; offset=0x74F4
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 311
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x09C8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG629
 
G_M000_IG628:                ;; offset=0x7510
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG629:                ;; offset=0x7531
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 312
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x09D0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG631
 
G_M000_IG630:                ;; offset=0x754D
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG631:                ;; offset=0x756E
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 313
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x09D8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG633
 
G_M000_IG632:                ;; offset=0x758A
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG633:                ;; offset=0x75AB
       cmp      dword ptr [rdi+0x08], 314
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdi+0x09E0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG635
 
G_M000_IG634:                ;; offset=0x75C4
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG635:                ;; offset=0x75E5
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmulps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1560]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1540]
       lea      r8, [rsp+0x1560]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1500]
       lea      rdx, [rsp+0x1540]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 315
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x09E8]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG637
 
G_M000_IG636:                ;; offset=0x76B4
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG637:                ;; offset=0x76D8
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 316
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x09F0]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG639
 
G_M000_IG638:                ;; offset=0x770C
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG639:                ;; offset=0x7730
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 317
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x09F8]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG641
 
G_M000_IG640:                ;; offset=0x7764
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG641:                ;; offset=0x7788
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 318
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A00]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG643
 
G_M000_IG642:                ;; offset=0x77BC
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG643:                ;; offset=0x77E0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 319
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A08]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG645
 
G_M000_IG644:                ;; offset=0x786E
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG645:                ;; offset=0x7892
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x320]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x360]
       lea      r8, [rsp+0x2E0]
       lea      r9, [rsp+0x300]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 320
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A10]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG647
 
G_M000_IG646:                ;; offset=0x7908
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG647:                ;; offset=0x792C
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm10, ymm0, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 321
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A18]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG649
 
G_M000_IG648:                ;; offset=0x7957
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG649:                ;; offset=0x7987
       vmulps   ymm0, ymm10, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x14E0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 322
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A20]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG651
 
G_M000_IG650:                ;; offset=0x79B2
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG651:                ;; offset=0x79D6
       vmovups  ymm0, ymmword ptr [rsp+0x14E0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x14C0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 323
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A28]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG653
 
G_M000_IG652:                ;; offset=0x7A0A
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG653:                ;; offset=0x7A2E
       vmovups  ymm0, ymmword ptr [rsp+0x14C0]
       vaddps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x14A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 324
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A30]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG655
 
G_M000_IG654:                ;; offset=0x7A62
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG655:                ;; offset=0x7A86
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 325
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A38]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG657
 
G_M000_IG656:                ;; offset=0x7ABA
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG657:                ;; offset=0x7ADE
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 326
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A40]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG659
 
G_M000_IG658:                ;; offset=0x7B12
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG659:                ;; offset=0x7B36
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 327
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A48]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG661
 
G_M000_IG660:                ;; offset=0x7B6A
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG661:                ;; offset=0x7B8E
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 328
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A50]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG663
 
G_M000_IG662:                ;; offset=0x7C1C
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG663:                ;; offset=0x7C40
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 329
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A58]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG665
 
G_M000_IG664:                ;; offset=0x7C6B
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG665:                ;; offset=0x7C8F
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 330
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A60]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG667
 
G_M000_IG666:                ;; offset=0x7CBA
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG667:                ;; offset=0x7CDE
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 331
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A68]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG669
 
G_M000_IG668:                ;; offset=0x7DAE
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG669:                ;; offset=0x7DD2
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vaddps   ymm10, ymm0, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 332
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A70]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG671
 
G_M000_IG670:                ;; offset=0x7DFD
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG671:                ;; offset=0x7E2D
       vmulps   ymm0, ymm10, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 333
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A78]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG673
 
G_M000_IG672:                ;; offset=0x7E58
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG673:                ;; offset=0x7E7C
       vmovups  ymm10, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 334
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A80]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG675
 
G_M000_IG674:                ;; offset=0x7E9E
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG675:                ;; offset=0x7ECE
       vmovups  ymm12, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 335
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A88]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG677
 
G_M000_IG676:                ;; offset=0x7EF0
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG677:                ;; offset=0x7F2C
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 336
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A90]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG679
 
G_M000_IG678:                ;; offset=0x7F73
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG679:                ;; offset=0x7F97
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 337
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0A98]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG681
 
G_M000_IG680:                ;; offset=0x7FCB
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG681:                ;; offset=0x7FEF
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 338
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0AA0]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG683
 
G_M000_IG682:                ;; offset=0x8023
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG683:                ;; offset=0x8047
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 339
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0AA8]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG685
 
G_M000_IG684:                ;; offset=0x807B
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG685:                ;; offset=0x809F
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 340
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0AB0]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG687
 
G_M000_IG686:                ;; offset=0x80D3
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG687:                ;; offset=0x80F7
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x380]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x340]
       lea      r8, [rsp+0x3C0]
       lea      r9, [rsp+0x3A0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 341
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AB8]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG689
 
G_M000_IG688:                ;; offset=0x8191
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG689:                ;; offset=0x81B2
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 342
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AC0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG691
 
G_M000_IG690:                ;; offset=0x81CF
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG691:                ;; offset=0x81F0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 343
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AC8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG693
 
G_M000_IG692:                ;; offset=0x820D
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG693:                ;; offset=0x822E
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 344
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AD0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG695
 
G_M000_IG694:                ;; offset=0x824B
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG695:                ;; offset=0x826C
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 345
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AD8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG697
 
G_M000_IG696:                ;; offset=0x8289
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG697:                ;; offset=0x82AA
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 346
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AE0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG699
 
G_M000_IG698:                ;; offset=0x82C7
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG699:                ;; offset=0x82E8
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 347
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AE8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG701
 
G_M000_IG700:                ;; offset=0x8305
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG701:                ;; offset=0x8326
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 348
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AF0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG703
 
G_M000_IG702:                ;; offset=0x8343
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG703:                ;; offset=0x8364
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 349
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0AF8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG705
 
G_M000_IG704:                ;; offset=0x8381
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG705:                ;; offset=0x83A2
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x1480], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 350
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B00]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG707
 
G_M000_IG706:                ;; offset=0x83D1
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG707:                ;; offset=0x83F5
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1480]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x14A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmulps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1460]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1440]
       lea      r8, [rsp+0x1460]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1400]
       lea      rdx, [rsp+0x1440]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 351
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B08]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG709
 
G_M000_IG708:                ;; offset=0x84C9
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG709:                ;; offset=0x84ED
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 352
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B10]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG711
 
G_M000_IG710:                ;; offset=0x8521
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG711:                ;; offset=0x8545
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 353
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B18]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG713
 
G_M000_IG712:                ;; offset=0x8579
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG713:                ;; offset=0x859D
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 354
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B20]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG715
 
G_M000_IG714:                ;; offset=0x85D1
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG715:                ;; offset=0x85F5
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 355
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B28]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG717
 
G_M000_IG716:                ;; offset=0x8683
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG717:                ;; offset=0x86A7
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 356
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B30]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG719
 
G_M000_IG718:                ;; offset=0x86D2
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG719:                ;; offset=0x86F6
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 357
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B38]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG721
 
G_M000_IG720:                ;; offset=0x8721
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG721:                ;; offset=0x8745
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x360]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 358
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B40]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG723
 
G_M000_IG722:                ;; offset=0x8815
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG723:                ;; offset=0x8839
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vaddps   ymm10, ymm0, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 359
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B48]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG725
 
G_M000_IG724:                ;; offset=0x8864
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG725:                ;; offset=0x8894
       vmulps   ymm0, ymm10, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 360
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B50]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG727
 
G_M000_IG726:                ;; offset=0x88BF
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG727:                ;; offset=0x88E3
       vmovups  ymm10, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 361
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B58]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG729
 
G_M000_IG728:                ;; offset=0x8905
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG729:                ;; offset=0x8935
       vmovups  ymm12, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 362
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B60]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG731
 
G_M000_IG730:                ;; offset=0x8957
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG731:                ;; offset=0x8993
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vsubps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 363
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B68]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG733
 
G_M000_IG732:                ;; offset=0x89DA
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG733:                ;; offset=0x89FE
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 364
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B70]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG735
 
G_M000_IG734:                ;; offset=0x8A32
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG735:                ;; offset=0x8A56
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 365
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B78]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG737
 
G_M000_IG736:                ;; offset=0x8A8A
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG737:                ;; offset=0x8AAE
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 366
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B80]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG739
 
G_M000_IG738:                ;; offset=0x8AE2
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG739:                ;; offset=0x8B06
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 367
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0B88]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG741
 
G_M000_IG740:                ;; offset=0x8B3A
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG741:                ;; offset=0x8B5E
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x320]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x360]
       lea      r8, [rsp+0x2E0]
       lea      r9, [rsp+0x300]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 368
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0B90]
       cmp      qword ptr [rdx], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG743
 
G_M000_IG742:                ;; offset=0x8BF8
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG743:                ;; offset=0x8C19
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 369
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0B98]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG745
 
G_M000_IG744:                ;; offset=0x8C36
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG745:                ;; offset=0x8C57
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 370
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0BA0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG747
 
G_M000_IG746:                ;; offset=0x8C74
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG747:                ;; offset=0x8C95
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 371
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0BA8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG749
 
G_M000_IG748:                ;; offset=0x8CB2
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG749:                ;; offset=0x8CD3
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 372
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0BB0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG751
 
G_M000_IG750:                ;; offset=0x8CF0
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG751:                ;; offset=0x8D11
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 373
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0BB8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG753
 
G_M000_IG752:                ;; offset=0x8D2E
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG753:                ;; offset=0x8D4F
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 374
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0BC0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG755
 
G_M000_IG754:                ;; offset=0x8D6C
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG755:                ;; offset=0x8D8D
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 375
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0BC8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG757
 
G_M000_IG756:                ;; offset=0x8DAA
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG757:                ;; offset=0x8DCB
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 376
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0BD0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG759
 
G_M000_IG758:                ;; offset=0x8DE8
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG759:                ;; offset=0x8E09
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmulps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x13E0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x18A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x13C0]
       lea      r8, [rsp+0x13E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1380]
       lea      rdx, [rsp+0x13C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 377
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0BD8]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG761
 
G_M000_IG760:                ;; offset=0x8ED8
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG761:                ;; offset=0x8EFC
       vmovups  ymm0, ymmword ptr [rsp+0x1960]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 378
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0BE0]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG763
 
G_M000_IG762:                ;; offset=0x8F30
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG763:                ;; offset=0x8F54
       vmovups  ymm0, ymmword ptr [rsp+0x1940]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 379
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0BE8]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG765
 
G_M000_IG764:                ;; offset=0x8F88
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG765:                ;; offset=0x8FAC
       vmovups  ymm0, ymmword ptr [rsp+0x1920]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 380
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0BF0]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG767
 
G_M000_IG766:                ;; offset=0x8FE0
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG767:                ;; offset=0x9004
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x360], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x360]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 381
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0BF8]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG769
 
G_M000_IG768:                ;; offset=0x9092
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG769:                ;; offset=0x90B6
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 382
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C00]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG771
 
G_M000_IG770:                ;; offset=0x90E1
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG771:                ;; offset=0x9105
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 383
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C08]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG773
 
G_M000_IG772:                ;; offset=0x9130
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG773:                ;; offset=0x9154
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 384
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C10]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG775
 
G_M000_IG774:                ;; offset=0x921A
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG775:                ;; offset=0x923E
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm10, ymm0, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 385
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C18]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG777
 
G_M000_IG776:                ;; offset=0x9269
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG777:                ;; offset=0x9299
       vaddps   ymm0, ymm10, ymmword ptr [rdi+0x08]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 386
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C20]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG779
 
G_M000_IG778:                ;; offset=0x92D6
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG779:                ;; offset=0x92FA
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x340]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 387
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C28]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG781
 
G_M000_IG780:                ;; offset=0x932E
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG781:                ;; offset=0x9352
       vmovups  ymm10, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 388
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C30]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG783
 
G_M000_IG782:                ;; offset=0x9374
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG783:                ;; offset=0x93A4
       vmovups  ymm12, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 389
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C38]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG785
 
G_M000_IG784:                ;; offset=0x93C6
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG785:                ;; offset=0x9402
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 390
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C40]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG787
 
G_M000_IG786:                ;; offset=0x9449
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG787:                ;; offset=0x946D
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 391
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C48]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG789
 
G_M000_IG788:                ;; offset=0x94A1
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG789:                ;; offset=0x94C5
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 392
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C50]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG791
 
G_M000_IG790:                ;; offset=0x94F9
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG791:                ;; offset=0x951D
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 393
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C58]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG793
 
G_M000_IG792:                ;; offset=0x9551
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG793:                ;; offset=0x9575
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 394
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C60]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG795
 
G_M000_IG794:                ;; offset=0x95A9
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG795:                ;; offset=0x95CD
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x340]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 395
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C68]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG797
 
G_M000_IG796:                ;; offset=0x9693
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG797:                ;; offset=0x96B7
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm10, ymm0, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 396
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C70]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG799
 
G_M000_IG798:                ;; offset=0x96E2
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG799:                ;; offset=0x9712
       vaddps   ymm0, ymm10, ymmword ptr [rdi+0x08]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 397
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C78]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG801
 
G_M000_IG800:                ;; offset=0x974F
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG801:                ;; offset=0x9773
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vsubps   ymm0, ymm0, ymmword ptr [rsp+0x340]
       vmovups  ymmword ptr [rsp+0x2E0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 398
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C80]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG803
 
G_M000_IG802:                ;; offset=0x97A7
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG803:                ;; offset=0x97CB
       vmovups  ymm10, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 399
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C88]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG805
 
G_M000_IG804:                ;; offset=0x97ED
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG805:                ;; offset=0x981D
       vmovups  ymm12, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 400
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C90]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG807
 
G_M000_IG806:                ;; offset=0x983F
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       vextractf128 xmm13, ymm12
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
       vinsertf128 ymm12, ymm12, xmm13
 
G_M000_IG807:                ;; offset=0x987B
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vsubps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmulps   ymm0, ymm0, ymm12
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 401
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0C98]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG809
 
G_M000_IG808:                ;; offset=0x98C2
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG809:                ;; offset=0x98E6
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 402
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0CA0]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG811
 
G_M000_IG810:                ;; offset=0x991A
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG811:                ;; offset=0x993E
       vmovups  ymm0, ymmword ptr [rsp+0x3A0]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x3A0], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 403
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0CA8]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG813
 
G_M000_IG812:                ;; offset=0x9972
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG813:                ;; offset=0x9996
       vmovups  ymm0, ymmword ptr [rsp+0x380]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x380], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 404
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0CB0]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG815
 
G_M000_IG814:                ;; offset=0x99CA
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG815:                ;; offset=0x99EE
       vmovups  ymm0, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x300], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 405
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0CB8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG817
 
G_M000_IG816:                ;; offset=0x9A22
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG817:                ;; offset=0x9A46
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x120], ymm0
       lea      rdx, [rsp+0x380]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x120]
       lea      rcx, [rsp+0x340]
       lea      r8, [rsp+0x3C0]
       lea      r9, [rsp+0x3A0]
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD00]
       vmovups  ymmword ptr [rsp+0x340], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 406
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0CC0]
       cmp      qword ptr [rdi], r15
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       je       SHORT G_M000_IG819
 
G_M000_IG818:                ;; offset=0x9AD6
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG819:                ;; offset=0x9AFA
       vmovups  ymm0, ymmword ptr [rsp+0x340]
       vmulps   ymm10, ymm0, ymmword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 407
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0CC8]
       cmp      qword ptr [rdi], r15
       je       SHORT G_M000_IG821
 
G_M000_IG820:                ;; offset=0x9B25
       mov      rdx, rdi
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       vextractf128 xmm11, ymm10
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
       vinsertf128 ymm10, ymm10, xmm11
 
G_M000_IG821:                ;; offset=0x9B55
       vaddps   ymm0, ymm10, ymmword ptr [rdi+0x08]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x300]
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x320]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 408
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0CD0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG823
 
G_M000_IG822:                ;; offset=0x9B92
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG823:                ;; offset=0x9BB3
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 409
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0CD8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG825
 
G_M000_IG824:                ;; offset=0x9BD0
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG825:                ;; offset=0x9BF1
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 410
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0CE0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG827
 
G_M000_IG826:                ;; offset=0x9C0E
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG827:                ;; offset=0x9C2F
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 411
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0CE8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG829
 
G_M000_IG828:                ;; offset=0x9C4C
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG829:                ;; offset=0x9C6D
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 412
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0CF0]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG831
 
G_M000_IG830:                ;; offset=0x9C8A
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG831:                ;; offset=0x9CAB
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 413
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0CF8]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG833
 
G_M000_IG832:                ;; offset=0x9CC8
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG833:                ;; offset=0x9CE9
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 414
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0D00]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG835
 
G_M000_IG834:                ;; offset=0x9D06
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG835:                ;; offset=0x9D27
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 415
       jbe      G_M000_IG909
       mov      rdx, gword ptr [rdx+0x0D08]
       cmp      qword ptr [rdx], r15
       je       SHORT G_M000_IG837
 
G_M000_IG836:                ;; offset=0x9D44
       mov      rcx, r15
       vextractf128 xmm7, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm7
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG837:                ;; offset=0x9D65
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x18A0]
       vmulps   ymm0, ymm0, ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1360]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1340]
       lea      rdx, [rsp+0x18A0]
       lea      r8, [rsp+0x1360]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1300]
       lea      rdx, [rsp+0x1340]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 416
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D10]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       je       SHORT G_M000_IG839
 
G_M000_IG838:                ;; offset=0x9E14
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG839:                ;; offset=0x9E27
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       vmovdqu  ymm0, ymmword ptr [rsp+0x1780]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x12C0]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 417
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D18]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       je       SHORT G_M000_IG841
 
G_M000_IG840:                ;; offset=0x9EBB
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG841:                ;; offset=0x9EE6
       vmovups  ymm10, ymmword ptr [rdi+0x08]
       vmovups  ymm11, ymmword ptr [rdi+0x28]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 418
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D20]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       je       SHORT G_M000_IG843
 
G_M000_IG842:                ;; offset=0x9F17
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG843:                ;; offset=0x9F5A
       vmovups  ymm14, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x280], ymm14
       vmovups  ymm15, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x260], ymm15
       vmovdqu  ymm0, ymmword ptr [rsp+0x1600]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1620]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymmword ptr [rsp+0x40], ymm14
       vmovups  ymmword ptr [rsp+0x60], ymm15
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1280]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1240]
       lea      r8, [rsp+0x1280]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 419
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D28]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG845
 
G_M000_IG844:                ;; offset=0xA060
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG845:                ;; offset=0xA0A3
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x240], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x220], ymm1
       vmovdqu  ymm2, ymmword ptr [rsp+0x1380]
       vmovdqu  ymmword ptr [rsp+0x80], ymm2
       vmovdqu  ymm2, ymmword ptr [rsp+0x13A0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm2
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1200]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 420
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D30]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG847
 
G_M000_IG846:                ;; offset=0xA161
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG847:                ;; offset=0xA1A4
       vmovups  ymm8, ymmword ptr [rdi+0x08]
       vmovups  ymm9, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1200]
       lea      rcx, [rsp+0x11C0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1380]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13A0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x280]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x260]
       vmovups  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1180]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 421
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D38]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG849
 
G_M000_IG848:                ;; offset=0xA2BE
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG849:                ;; offset=0xA32D
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1180]
       lea      rcx, [rsp+0x1140]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmmword ptr [rsp+0x210], ymm8
       vextractf128 xmmword ptr [rsp+0x1F0], ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1100]
       lea      r8, [rsp+0x1140]
       vextractf128 xmm14, ymm10
       vextractf128 xmm15, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x10C0]
       lea      r8, [rsp+0x1100]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x10C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x10E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x10C0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x10E0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1080]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 422
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D40]
 
G_M000_IG850:                ;; offset=0xA4AE
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x210]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1F0]
       vinsertf128 ymm10, ymm10, xmm14
       vinsertf128 ymm11, ymm11, xmm15
       je       SHORT G_M000_IG852
 
G_M000_IG851:                ;; offset=0xA4EB
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG852:                ;; offset=0xA55A
       vmovups  ymm12, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x1C0], ymm12
       vmovups  ymm13, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x1A0], ymm13
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1040]
       lea      r8, [rsp+0x10C0]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmmword ptr [rsp+0x210], ymm8
       vextractf128 xmmword ptr [rsp+0x1F0], ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       vextractf128 xmm12, ymm13
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x1C0]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vinsertf128 ymm13, ymm13, xmm12
       vmovups  ymmword ptr [rsp+0xA0], ymm13
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1000]
       lea      r8, [rsp+0x1040]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xFC0]
       lea      rdx, [rsp+0x1080]
       lea      r8, [rsp+0x1000]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 423
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D48]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x210]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1F0]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG854
 
G_M000_IG853:                ;; offset=0xA6A0
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmmword ptr [rsp+0x1F0], ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1F0]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG854:                ;; offset=0xA719
       vmovdqu  ymm0, ymmword ptr [rsp+0x1800]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1820]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xF80]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 424
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D50]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG856
 
G_M000_IG855:                ;; offset=0xA7F1
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG856:                ;; offset=0xA860
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF80]
       lea      rcx, [rsp+0xF40]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF40]
       lea      rcx, [rsp+0xF00]
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x16A0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x16C0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x240]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x220]
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xEC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 425
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D58]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG858
 
G_M000_IG857:                ;; offset=0xA9C2
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG858:                ;; offset=0xAA31
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xEC0]
       lea      rcx, [rsp+0xE80]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 426
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D60]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG860
 
G_M000_IG859:                ;; offset=0xAAEE
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG860:                ;; offset=0xAB5D
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xE80]
       lea      rcx, [rsp+0xE40]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xE00]
       lea      rdx, [rsp+0xF00]
       lea      r8, [rsp+0xE40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 427
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D68]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG862
 
G_M000_IG861:                ;; offset=0xAC38
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG862:                ;; offset=0xACA7
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1240]
       lea      rcx, [rsp+0xDC0]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 428
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D70]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG864
 
G_M000_IG863:                ;; offset=0xAD64
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG864:                ;; offset=0xADD3
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xDC0]
       lea      rcx, [rsp+0xD80]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 429
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D78]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG866
 
G_M000_IG865:                ;; offset=0xAE90
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG866:                ;; offset=0xAEFF
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xD40]
       lea      r8, [rsp+0x12C0]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD00]
       lea      rdx, [rsp+0xD80]
       lea      r8, [rsp+0xD40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xCC0]
       lea      rdx, [rsp+0xE00]
       lea      r8, [rsp+0xD00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 430
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D80]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG868
 
G_M000_IG867:                ;; offset=0xAFF8
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG868:                ;; offset=0xB067
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x11C0]
       lea      rcx, [rsp+0xC80]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xC40]
       lea      rdx, [rsp+0xCC0]
       lea      r8, [rsp+0xC80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1300]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1320]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xFC0]
       lea      rcx, [rsp+0xC00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1300]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1320]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC00]
       lea      rcx, [rsp+0xBC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 431
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D88]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG870
 
G_M000_IG869:                ;; offset=0xB1C6
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG870:                ;; offset=0xB235
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xBC0]
       lea      rcx, [rsp+0xB80]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xB40]
       lea      rdx, [rsp+0xC40]
       lea      r8, [rsp+0xB80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 432
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D90]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG872
 
G_M000_IG871:                ;; offset=0xB310
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG872:                ;; offset=0xB37F
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB40]
       lea      rcx, [rsp+0xB00]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1400]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1420]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm8, ymm8, xmm12
       vmovups  ymmword ptr [rsp+0x40], ymm8
       vinsertf128 ymm9, ymm9, xmm13
       vmovups  ymmword ptr [rsp+0x60], ymm9
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xAC0]
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm14
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm15
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xAC0]
       lea      rcx, [rsp+0xA80]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xA40]
       lea      rdx, [rsp+0xA80]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Abs(Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 433
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0D98]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
 
G_M000_IG873:                ;; offset=0xB4DF
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG875
 
G_M000_IG874:                ;; offset=0xB4FD
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG875:                ;; offset=0xB56C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xA40]
       lea      rcx, [rsp+0xA00]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 434
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0DA0]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       je       SHORT G_M000_IG877
 
G_M000_IG876:                ;; offset=0xB629
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG877:                ;; offset=0xB698
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xA00]
       lea      rcx, [rsp+0x9C0]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x980]
       lea      r8, [rsp+0x9C0]
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm14
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm15
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x940]
       lea      r8, [rsp+0x980]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x940]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x960]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x940]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x960]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x900]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
 
G_M000_IG878:                ;; offset=0xB827
       lea      rcx, [rsp+0x8C0]
       lea      r8, [rsp+0x940]
       vextractf128 xmmword ptr [rsp+0x210], ymm8
       vextractf128 xmmword ptr [rsp+0x1F0], ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x1C0]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1A0]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x880]
       lea      r8, [rsp+0x8C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x840]
       lea      rdx, [rsp+0x900]
       lea      r8, [rsp+0x880]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm14
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm15
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x800]
       lea      r8, [rsp+0x840]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xB00]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xB20]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vmovups  ymmword ptr [rsp+0x40], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       vmovups  ymmword ptr [rsp+0x60], ymm11
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x7C0]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 435
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0DA8]
       mov      rdx, 0x7FFC658A0890
 
G_M000_IG879:                ;; offset=0xB98A
       cmp      qword ptr [rdi], rdx
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x210]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1F0]
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG881
 
G_M000_IG880:                ;; offset=0xB9BD
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm15
       vinsertf128 ymm8, ymm8, xmm12
       vinsertf128 ymm9, ymm9, xmm13
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
 
G_M000_IG881:                ;; offset=0xBA2C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x7C0]
       lea      rcx, [rsp+0x780]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       vextractf128 xmm12, ymm8
       vextractf128 xmm13, ymm9
       vextractf128 xmmword ptr [rsp+0x2D0], ymm10
       vextractf128 xmmword ptr [rsp+0x2B0], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x2D0]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x2B0]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x740]
       lea      r8, [rsp+0x780]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm14
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm15
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x700]
       lea      r8, [rsp+0x740]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x700]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x720]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x700]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x720]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x6C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x680]
       lea      r8, [rsp+0x700]
 
G_M000_IG882:                ;; offset=0xBBB5
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm12, ymmword ptr [rsp+0x1C0]
       vmovups  ymmword ptr [rsp+0x80], ymm12
       vmovups  ymm13, ymmword ptr [rsp+0x1A0]
       vmovups  ymmword ptr [rsp+0xA0], ymm13
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x640]
       lea      r8, [rsp+0x680]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x600]
       lea      rdx, [rsp+0x6C0]
       lea      r8, [rsp+0x640]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm14
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm15
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x5C0]
       lea      r8, [rsp+0x600]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x580]
       lea      rdx, [rsp+0x800]
       lea      r8, [rsp+0x5C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 436
       jbe      G_M000_IG909
       mov      rdi, gword ptr [rdx+0x0DB0]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rdi], rdx
       je       SHORT G_M000_IG884
 
G_M000_IG883:                ;; offset=0xBC9C
       mov      rdx, rdi
       mov      rcx, 0x7FFC658A0890
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG884:                ;; offset=0xBCAF
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x180], ymm0
       vmovups  ymm0, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x160], ymm0
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 437
       jbe      G_M000_IG909
       mov      rbx, gword ptr [rdx+0x0DB8]
       mov      rdx, 0x7FFC658A0890
       cmp      qword ptr [rbx], rdx
       je       SHORT G_M000_IG886
 
G_M000_IG885:                ;; offset=0xBCF2
       mov      rdx, rbx
       mov      rcx, 0x7FFC658A0890
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG886:                ;; offset=0xBD05
       vmovdqu  ymm0, ymmword ptr [rsp+0x16A0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x16C0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x540]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x500]
       lea      r8, [rsp+0x540]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x500]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x520]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xB00]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xB20]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x4E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:LessThan(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):System.Numerics.Vector`1[int]]
       vmovdqu  ymm0, ymmword ptr [rsp+0xB00]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xB20]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x500]
       lea      rcx, [rsp+0x4A0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x580]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x5A0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x4A0]
       lea      rcx, [rsp+0x460]
 
G_M000_IG887:                ;; offset=0xBE77
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xB00]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xB20]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x420]
       lea      r8, [rsp+0x460]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x3E0]
       lea      rdx, [rsp+0x4E0]
       lea      r8, [rsp+0x420]
       lea      r9, [rsp+0xB00]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Select(System.Numerics.Vector`1[int],Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG888:                ;; offset=0xBEE5
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG889:                ;; offset=0xBEEF
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1800]
       xor      edx, edx
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG890:                ;; offset=0xBF0A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG891:                ;; offset=0xBF14
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1780]
       mov      edx, 1
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG892:                ;; offset=0xBF32
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG893:                ;; offset=0xBF3C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x16A0]
       mov      edx, 2
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG894:                ;; offset=0xBF5A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG895:                ;; offset=0xBF64
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1600]
       mov      edx, 3
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG896:                ;; offset=0xBF82
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG897:                ;; offset=0xBF8C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1580]
       mov      edx, 4
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG898:                ;; offset=0xBFAA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG899:                ;; offset=0xBFB4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1500]
       mov      edx, 5
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG900:                ;; offset=0xBFD2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG901:                ;; offset=0xBFDC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1400]
       mov      edx, 6
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG902:                ;; offset=0xBFFA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG903:                ;; offset=0xC004
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1380]
       mov      edx, 7
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG904:                ;; offset=0xC022
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG905:                ;; offset=0xC02C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1300]
       mov      edx, 8
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG906:                ;; offset=0xC04A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG907:                ;; offset=0xC054
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x3E0]
       mov      edx, 9
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       lea      r9, [rsp+0x580]
       mov      rcx, rsi
       mov      edx, 10
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       nop      
 
G_M000_IG908:                ;; offset=0xC08F
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1AD0]
       vmovaps  xmm7, xmmword ptr [rsp+0x1AC0]
       vmovaps  xmm8, xmmword ptr [rsp+0x1AB0]
       vmovaps  xmm9, xmmword ptr [rsp+0x1AA0]
       vmovaps  xmm10, xmmword ptr [rsp+0x1A90]
       vmovaps  xmm11, xmmword ptr [rsp+0x1A80]
       vmovaps  xmm12, xmmword ptr [rsp+0x1A70]
       vmovaps  xmm13, xmmword ptr [rsp+0x1A60]
       vmovaps  xmm14, xmmword ptr [rsp+0x1A50]
       vmovaps  xmm15, xmmword ptr [rsp+0x1A40]
       add      rsp, 0x1AE0
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG909:                ;; offset=0xC0FE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh

; Total bytes of code 49412

; Assembly listing for method (dynamicClass):lambda_method3(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 14 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 256
       vmovaps  xmmword ptr [rsp+0xF0], xmm6
       vmovaps  xmmword ptr [rsp+0xE0], xmm7
       vmovaps  xmmword ptr [rsp+0xD0], xmm8
       vmovaps  xmmword ptr [rsp+0xC0], xmm9
       vmovaps  xmmword ptr [rsp+0xB0], xmm10
       vmovaps  xmmword ptr [rsp+0xA0], xmm11
       vmovaps  xmmword ptr [rsp+0x90], xmm12
       vmovaps  xmmword ptr [rsp+0x80], xmm13
       vmovaps  xmmword ptr [rsp+0x70], xmm14
       vmovaps  xmmword ptr [rsp+0x60], xmm15
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0061
       mov      rsi, bword ptr [r8]
       mov      edi, dword ptr [r8+0x08]
       mov      rcx, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       test     eax, eax
       je       G_M000_IG48
       vmovsd   xmm1, qword ptr [rcx]
       cmp      eax, 1
       jbe      G_M000_IG48
       vmovsd   xmm2, qword ptr [rcx+0x08]
       cmp      eax, 2
       jbe      G_M000_IG48
       vmovsd   xmm3, qword ptr [rcx+0x10]
       vcvtsd2ss xmm6, xmm6, xmm1
       vcvtsd2ss xmm7, xmm7, xmm2
       vcvtsd2ss xmm8, xmm8, xmm3
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 0
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x00BC
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x00CF
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD00]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm9, xmm1, xmm2
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 1
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x18]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x010E
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG35
 
G_M000_IG06:                ;; offset=0x0121
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD04]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, xmm9
       vmovss   xmm9, dword ptr [reloc @RWD08]
       vaddss   xmm1, xmm1, xmm9
       vxorps   xmm10, xmm10, xmm10
       vmovaps  xmm2, xmm10
       vmovss   xmm11, dword ptr [reloc @RWD12]
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vcmpneqps xmm12, xmm2, xmm2
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vbroadcastss xmm13, dword ptr [reloc @RWD08]
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm14, xmm14, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 2
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x20]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x01DE
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG36
 
G_M000_IG08:                ;; offset=0x01F1
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm15, xmm15, xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 3
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x027E
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG37
 
G_M000_IG10:                ;; offset=0x0291
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD16]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vmovss   dword ptr [rsp+0x2C], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 4
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x30]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x02D6
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG38
 
G_M000_IG12:                ;; offset=0x02E9
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD20]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x2C]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x58], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 5
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x38]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x038A
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG39
 
G_M000_IG14:                ;; offset=0x039D
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vmovss   dword ptr [rsp+0x28], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 6
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x03DA
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG40
 
G_M000_IG16:                ;; offset=0x03ED
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, xmm11
       vaddss   xmm1, xmm1, xmm11
       vmulss   xmm1, xmm1, dword ptr [rsp+0x28]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x50], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0488
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG41
 
G_M000_IG18:                ;; offset=0x049B
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x48], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x052E
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG42
 
G_M000_IG20:                ;; offset=0x0541
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x40], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 9
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x58]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x05D4
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG43
 
G_M000_IG22:                ;; offset=0x05E7
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD24]
       vaddss   xmm1, xmm1, dword ptr [reloc @RWD28]
       vmovss   dword ptr [rsp+0x24], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 10
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x062C
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG44
 
G_M000_IG24:                ;; offset=0x063F
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vmulss   xmm1, xmm0, dword ptr [reloc @RWD32]
       vxorps   xmm2, xmm2, xmm2
       vaddss   xmm1, xmm1, xmm2
       vaddss   xmm1, xmm1, dword ptr [rsp+0x24]
       vmovaps  xmm2, xmm10
       vaddss   xmm1, xmm1, xmm9
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x38], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 11
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x68]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x06E0
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG45
 
G_M000_IG26:                ;; offset=0x06F3
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm1, xmm0, xmm1
       vaddss   xmm1, xmm1, xmm9
       vmovaps  xmm2, xmm10
       vmulss   xmm1, xmm1, xmm11
       vcmpeqps xmm3, xmm2, xmm1
       vxorps   xmm0, xmm0, xmm0
       vpcmpgtd xmm0, xmm0, xmm1
       vandps   xmm3, xmm0, xmm3
       vorps    xmm3, xmm3, xmm12
       vcmpltps xmm0, xmm1, xmm2
       vorps    xmm3, xmm0, xmm3
       vandps   xmm2, xmm2, xmm3
       vandnps  xmm1, xmm3, xmm1
       vorps    xmm1, xmm1, xmm2
       vmovaps  xmm2, xmm13
       vxorps   xmm3, xmm3, xmm3
       vcmpltps xmm0, xmm2, xmm1
       vorps    xmm3, xmm0, xmm3
       vblendvps xmm1, xmm1, xmm2, xmm3
       vcvtss2sd xmm1, xmm1, xmm1
       vmovsd   qword ptr [rsp+0x30], xmm1
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG48
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0786
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG46
 
G_M000_IG28:                ;; offset=0x0799
       vmovaps  xmm1, xmm6
       vmovaps  xmm2, xmm7
       vmovaps  xmm3, xmm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3(float,float,float):float:this]
       vxorps   xmm1, xmm1, xmm1
       vaddss   xmm0, xmm0, xmm1
       vaddss   xmm0, xmm0, xmm9
       vmulss   xmm0, xmm0, xmm11
       vcmpeqps xmm1, xmm10, xmm0
       vxorps   xmm2, xmm2, xmm2
       vpcmpgtd xmm2, xmm2, xmm0
       vandps   xmm1, xmm2, xmm1
       vorps    xmm1, xmm1, xmm12
       vcmpltps xmm2, xmm0, xmm10
       vorps    xmm1, xmm2, xmm1
       vandps   xmm2, xmm10, xmm1
       vandnps  xmm0, xmm1, xmm0
       vorps    xmm0, xmm0, xmm2
       vxorps   xmm1, xmm1, xmm1
       vcmpltps xmm2, xmm13, xmm0
       vorps    xmm1, xmm2, xmm1
       vblendvps xmm0, xmm0, xmm13, xmm1
       vcvtss2sd xmm0, xmm0, xmm0
       vmovsd   xmm1, qword ptr [reloc @RWD40]
       vsubsd   xmm2, xmm1, xmm15
       vxorps   xmm3, xmm3, xmm3
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vsubsd   xmm5, xmm4, qword ptr [reloc @RWD48]
       vcmpeqpd xmm6, xmm3, xmm5
       vxorps   xmm7, xmm7, xmm7
       vpcmpgtq xmm7, xmm7, xmm5
       vandpd   xmm6, xmm7, xmm6
       vcmpneqpd xmm7, xmm3, xmm3
       vorpd    xmm6, xmm6, xmm7
       vcmpltpd xmm8, xmm5, xmm3
       vorpd    xmm6, xmm8, xmm6
       vandpd   xmm3, xmm3, xmm6
       vandnpd  xmm5, xmm6, xmm5
       vorpd    xmm3, xmm5, xmm3
       vmovsd   xmm6, qword ptr [rsp+0x30]
       vsubsd   xmm5, xmm6, qword ptr [reloc @RWD56]
       vaddsd   xmm5, xmm5, xmm5
       vxorps   xmm8, xmm8, xmm8
       vsubsd   xmm9, xmm6, qword ptr [reloc @RWD48]
       vdivsd   xmm9, xmm9, qword ptr [reloc @RWD64]
       vcmpeqpd xmm10, xmm8, xmm9
       vxorps   xmm11, xmm11, xmm11
       vpcmpgtq xmm11, xmm11, xmm9
       vandpd   xmm10, xmm11, xmm10
       vorpd    xmm10, xmm10, xmm7
       vcmpltpd xmm11, xmm9, xmm8
       vorpd    xmm10, xmm11, xmm10
       vandpd   xmm8, xmm8, xmm10
       vandnpd  xmm9, xmm10, xmm9
       vorpd    xmm8, xmm9, xmm8
       vmovddup xmm9, qword ptr [reloc @RWD40]
       vmovaps  xmm10, xmm9
 
G_M000_IG29:                ;; offset=0x08B9
       vxorps   xmm11, xmm11, xmm11
       vcmpltpd xmm12, xmm10, xmm8
       vorpd    xmm11, xmm12, xmm11
       vblendvpd xmm8, xmm8, xmm10, xmm11
       vmulsd   xmm10, xmm8, xmm8
       vaddsd   xmm8, xmm8, xmm8
       vmovsd   xmm11, qword ptr [reloc @RWD72]
       vsubsd   xmm8, xmm11, xmm8
       vmulsd   xmm8, xmm8, xmm10
       vsubsd   xmm10, xmm14, qword ptr [reloc @RWD80]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD88]
       vmulsd   xmm10, xmm10, qword ptr [reloc @RWD96]
       vmovsd   xmm12, qword ptr [rsp+0x58]
       vsubsd   xmm13, xmm12, qword ptr [reloc @RWD56]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD104]
       vmulsd   xmm13, xmm13, qword ptr [reloc @RWD112]
       vaddsd   xmm10, xmm10, xmm13
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD120]
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD128]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD136]
       vmulsd   xmm2, xmm3, xmm2
       vaddsd   xmm2, xmm10, xmm2
       vmulsd   xmm3, xmm5, qword ptr [reloc @RWD144]
       vaddsd   xmm2, xmm2, xmm3
       vmulsd   xmm3, xmm8, xmm0
       vmulsd   xmm3, xmm3, xmm0
       vmulsd   xmm3, xmm3, qword ptr [reloc @RWD152]
       vaddsd   xmm2, xmm2, xmm3
       vsubsd   xmm2, xmm2, qword ptr [reloc @RWD160]
       vmovaps  xmm3, xmm2
       vxorps   xmm5, xmm5, xmm5
       vmovsd   xmm8, qword ptr [rsp+0x38]
       vaddsd   xmm10, xmm8, xmm8
       vsubsd   xmm10, xmm10, xmm1
       vandps   xmm10, xmm10, xmmword ptr [reloc @RWD176]
       vsubsd   xmm10, xmm10, qword ptr [reloc @RWD192]
       vdivsd   xmm10, xmm10, qword ptr [reloc @RWD200]
       vcmpeqpd xmm13, xmm5, xmm10
       vxorps   xmm4, xmm4, xmm4
       vpcmpgtq xmm4, xmm4, xmm10
       vandpd   xmm4, xmm4, xmm13
       vorpd    xmm4, xmm4, xmm7
       vcmpltpd xmm13, xmm10, xmm5
       vorpd    xmm4, xmm13, xmm4
       vandpd   xmm5, xmm5, xmm4
       vandnpd  xmm4, xmm4, xmm10
       vorpd    xmm4, xmm4, xmm5
       vmovaps  xmm5, xmm9
       vxorps   xmm10, xmm10, xmm10
       vcmpltpd xmm13, xmm5, xmm4
       vorpd    xmm10, xmm13, xmm10
       vblendvpd xmm4, xmm4, xmm5, xmm10
       vmulsd   xmm5, xmm4, xmm4
       vaddsd   xmm4, xmm4, xmm4
       vsubsd   xmm4, xmm11, xmm4
       vmulsd   xmm4, xmm5, xmm4
       vsubsd   xmm4, xmm1, xmm4
       vxorps   xmm5, xmm5, xmm5
       vdivsd   xmm2, xmm2, qword ptr [reloc @RWD208]
 
G_M000_IG30:                ;; offset=0x0A05
       vcmpeqpd xmm10, xmm5, xmm2
       vxorps   xmm13, xmm13, xmm13
       vpcmpgtq xmm13, xmm13, xmm2
       vandpd   xmm10, xmm13, xmm10
       vorpd    xmm7, xmm10, xmm7
       vcmpltpd xmm10, xmm2, xmm5
       vorpd    xmm7, xmm10, xmm7
       vandpd   xmm5, xmm5, xmm7
       vandnpd  xmm2, xmm7, xmm2
       vorpd    xmm2, xmm2, xmm5
       vxorps   xmm5, xmm5, xmm5
       vcmpltpd xmm7, xmm9, xmm2
       vorpd    xmm5, xmm7, xmm5
       vblendvpd xmm2, xmm2, xmm9, xmm5
       vmulsd   xmm5, xmm2, xmm2
       vaddsd   xmm2, xmm2, xmm2
       vsubsd   xmm2, xmm11, xmm2
       vmulsd   xmm2, xmm5, xmm2
       vsubsd   xmm1, xmm1, xmm2
       vmulsd   xmm1, xmm1, xmm4
       vmulsd   xmm2, xmm12, qword ptr [reloc @RWD216]
       vaddsd   xmm2, xmm2, qword ptr [reloc @RWD224]
       vucomisd xmm3, xmm2
       seta     dl
       movzx    rdx, dl
       vsubsd   xmm2, xmm2, xmm3
       vmulsd   xmm2, xmm2, xmm1
       vaddsd   xmm2, xmm2, xmm3
       test     edx, edx
       je       G_M000_IG33
 
G_M000_IG31:                ;; offset=0x0A8B
       cmp      edi, 10
       jle      G_M000_IG47
       vmovsd   qword ptr [rsi], xmm14
       vmovsd   qword ptr [rsi+0x08], xmm15
       vmovsd   qword ptr [rsi+0x10], xmm12
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       vmovsd   qword ptr [rsi+0x30], xmm8
       vmovsd   qword ptr [rsi+0x38], xmm6
       vmovsd   qword ptr [rsi+0x40], xmm0
       vmovsd   qword ptr [rsi+0x48], xmm2
       vmovsd   qword ptr [rsi+0x50], xmm1
 
G_M000_IG32:                ;; offset=0x0ADC
       vmovaps  xmm6, xmmword ptr [rsp+0xF0]
       vmovaps  xmm7, xmmword ptr [rsp+0xE0]
       vmovaps  xmm8, xmmword ptr [rsp+0xD0]
       vmovaps  xmm9, xmmword ptr [rsp+0xC0]
       vmovaps  xmm10, xmmword ptr [rsp+0xB0]
       vmovaps  xmm11, xmmword ptr [rsp+0xA0]
       vmovaps  xmm12, xmmword ptr [rsp+0x90]
       vmovaps  xmm13, xmmword ptr [rsp+0x80]
       vmovaps  xmm14, xmmword ptr [rsp+0x70]
       vmovaps  xmm15, xmmword ptr [rsp+0x60]
       add      rsp, 256
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG33:                ;; offset=0x0B3B
       vmovaps  xmm2, xmm3
       jmp      G_M000_IG31
 
G_M000_IG34:                ;; offset=0x0B44
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG35:                ;; offset=0x0B4E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG36:                ;; offset=0x0B58
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG37:                ;; offset=0x0B62
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG38:                ;; offset=0x0B6C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG39:                ;; offset=0x0B76
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG40:                ;; offset=0x0B80
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG41:                ;; offset=0x0B8A
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG42:                ;; offset=0x0B94
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG43:                ;; offset=0x0B9E
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG44:                ;; offset=0x0BA8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG45:                ;; offset=0x0BB2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG46:                ;; offset=0x0BBC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG47:                ;; offset=0x0BC6
       test     edi, edi
       je       G_M000_IG48
       vmovsd   qword ptr [rsi], xmm14
       cmp      edi, 1
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x08], xmm15
       cmp      edi, 2
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x10], xmm12
       cmp      edi, 3
       jbe      SHORT G_M000_IG48
       vmovsd   xmm4, qword ptr [rsp+0x50]
       vmovsd   qword ptr [rsi+0x18], xmm4
       cmp      edi, 4
       jbe      SHORT G_M000_IG48
       vmovsd   xmm3, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rsi+0x20], xmm3
       cmp      edi, 5
       jbe      SHORT G_M000_IG48
       vmovsd   xmm5, qword ptr [rsp+0x40]
       vmovsd   qword ptr [rsi+0x28], xmm5
       cmp      edi, 6
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x30], xmm8
       cmp      edi, 7
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x38], xmm6
       cmp      edi, 8
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x40], xmm0
       cmp      edi, 9
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x48], xmm2
       cmp      edi, 10
       jbe      SHORT G_M000_IG48
       vmovsd   qword ptr [rsi+0x50], xmm1
       jmp      G_M000_IG32
 
G_M000_IG48:                ;; offset=0x0C4D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	3F47AE14h		;      0.78
RWD04  	dd	3E6147AEh		;      0.22
RWD08  	dd	3F800000h		;         1
RWD12  	dd	3F000000h		;       0.5
RWD16  	dd	3F51EB85h		;      0.82
RWD20  	dd	3E3851ECh		;      0.18
RWD24  	dd	3F666666h		;       0.9
RWD28  	dd	3E570A3Dh		;      0.21
RWD32  	dd	3DCCCCCDh		;       0.1
RWD36  	dd	00000000h
RWD40  	dq	3FF0000000000000h	;            1
RWD48  	dq	3FDEB851EB851EB8h	;         0.48
RWD56  	dq	3FE0000000000000h	;          0.5
RWD64  	dq	3FCEB851EB851EB8h	;         0.24
RWD72  	dq	4008000000000000h	;            3
RWD80  	dq	3FD6666666666666h	;         0.35
RWD88  	dq	4038000000000000h	;           24
RWD96  	dq	4000000000000000h	;            2
RWD104 	dq	4044000000000000h	;           40
RWD112 	dq	3FE1EB851EB851ECh	;         0.56
RWD120 	dq	4067C00000000000h	;          190
RWD128 	dq	3FF6666666666666h	;          1.4
RWD136 	dq	3FD3333333333333h	;          0.3
RWD144 	dq	4074000000000000h	;          320
RWD152 	dq	408F400000000000h	;         1000
RWD160 	dq	4010000000000000h	;            4
RWD168 	dd	00000000h, 00000000h
RWD176 	dq	7FFFFFFFFFFFFFFFh, 7FFFFFFFFFFFFFFFh
RWD192 	dq	3F9999999999999Ah	;        0.025
RWD200 	dq	3FB5C28F5C28F5C2h	;        0.085
RWD208 	dq	4042000000000000h	;           36
RWD216 	dq	3FF3333333333333h	;          1.2
RWD224 	dq	C014000000000000h	;           -5

; Total bytes of code 3155

; Assembly listing for method (dynamicClass):lambda_method4(System.Runtime.CompilerServices.Closure,System.ReadOnlySpan`1[double],System.Span`1[double]) (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 0 inlinees with PGO data; 384 single block inlinees; 6 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       lea      r11, [rsp-0x1BA0]
       call     CORINFO_HELP_STACK_PROBE
       mov      rsp, r11
       vmovaps  xmmword ptr [rsp+0x1B90], xmm6
       vmovaps  xmmword ptr [rsp+0x1B80], xmm7
       vmovaps  xmmword ptr [rsp+0x1B70], xmm8
       vmovaps  xmmword ptr [rsp+0x1B60], xmm9
       vmovaps  xmmword ptr [rsp+0x1B50], xmm10
       vmovaps  xmmword ptr [rsp+0x1B40], xmm11
       vmovaps  xmmword ptr [rsp+0x1B30], xmm12
       vmovaps  xmmword ptr [rsp+0x1B20], xmm13
       vmovaps  xmmword ptr [rsp+0x1B10], xmm14
       vmovaps  xmmword ptr [rsp+0x1B00], xmm15
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rsp+0x30], xmm4
       mov      rax, -0x1980
       vmovdqa  xmmword ptr [rsp+rax+0x19C0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x19D0], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x19E0], xmm4
       add      rax, 48
       jne      SHORT  -5 instr
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r8
 
G_M000_IG02:                ;; offset=0x00B2
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG03:                ;; offset=0x00BF
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1AC0]
       xor      r8d, r8d
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG04:                ;; offset=0x00DE
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x150], xmm0
 
G_M000_IG05:                ;; offset=0x00EB
       lea      rdx, [rsp+0x150]
       lea      rcx, [rsp+0x1A80]
       mov      r8d, 1
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1A40]
       mov      rdx, rdi
       mov      r8d, 2
       mov      r9d, 3
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x1AC0]
       vmovups  ymm1, ymmword ptr [rsp+0x1AE0]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1A20], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A80]
       vmovups  ymm1, ymmword ptr [rsp+0x1AA0]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x1A00], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A40]
       vmovups  ymm1, ymmword ptr [rsp+0x1A60]
       vcvtpd2ps ymm0, ymm0
       vcvtpd2ps ymm1, ymm1
       vinsertf128 ymm0, ymm0, xmm1
       vmovups  ymmword ptr [rsp+0x19E0], ymm0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 0
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x10]
       mov      r14, 0x7FFC658A3210
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x01CA
       mov      rdx, rbp
       mov      rcx, r14
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG07:                ;; offset=0x01D6
       vmovups  ymm6, ymmword ptr [rbp+0x08]
       cmp      dword ptr [rdi+0x08], 1
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x18]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x01F1
       mov      rcx, 0x7FFC658E3F00
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG180
 
G_M000_IG09:                ;; offset=0x0204
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm7, ymm0, ymmword ptr [rsp+0x1A20]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x1A00]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x19E0]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0234
       mov      edx, edx
       lea      r9, [reloc @RWD00]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG11:                ;; offset=0x024E
       vaddps   ymm0, ymm8, ymm7
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm7, ymm0, ymm7
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x026F
       vaddps   ymm0, ymm9, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm8, ymm8, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm8
       vaddps   ymm7, ymm1, ymm7
       vaddps   ymm9, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm8, ymm0, ymm8
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x02A0
       vaddps   ymm0, ymm8, ymm7
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm9
       vaddps   ymm7, ymm2, ymm7
       vaddps   ymm1, ymm8, ymm1
       vsubps   ymm8, ymm1, ymm9
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
 
G_M000_IG14:                ;; offset=0x02D3
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovss   xmm13, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x02FC
       cmp      r15d, 1
       jg       G_M000_IG154
 
G_M000_IG16:                ;; offset=0x0306
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm7
       vmovups  ymmword ptr [rsp+0xE0], ymm8
       vmovups  ymmword ptr [rsp+0xC0], ymm9
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x480]
       vextractf128 xmm14, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       vinsertf128 ymm6, ymm6, xmm14
       je       G_M000_IG159
 
G_M000_IG17:                ;; offset=0x037B
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG158
 
G_M000_IG18:                ;; offset=0x038C
       cmp      edx, 3
       je       G_M000_IG157
 
G_M000_IG19:                ;; offset=0x0395
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x480]
 
G_M000_IG20:                ;; offset=0x039E
       vbroadcastss ymm0, ymm13
       vmulps   ymm7, ymm0, ymm1
 
G_M000_IG21:                ;; offset=0x03A7
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 2
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x20]
       cmp      qword ptr [rbp], r14
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x03C2
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm14, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG23:                ;; offset=0x03E6
       vmulps   ymm0, ymm7, ymmword ptr [rbp+0x08]
       vaddps   ymm7, ymm0, ymm6
       vmovups  ymmword ptr [rsp+0x19C0], ymm7
       cmp      dword ptr [rdi+0x08], 3
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x28]
       mov      r8, rdx
       test     r8, r8
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x040E
       mov      rcx, 0x7FFC658E3F00
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG181
 
G_M000_IG25:                ;; offset=0x0421
       mov      edx, dword ptr [r8+0x64]
       vbroadcastss ymm0, dword ptr [r8+0x0C]
       vmulps   ymm8, ymm0, ymmword ptr [rsp+0x1A20]
       vmulps   ymm9, ymm0, ymmword ptr [rsp+0x1A00]
       vmulps   ymm10, ymm0, ymmword ptr [rsp+0x19E0]
       dec      edx
       cmp      edx, 2
       ja       G_M000_IG30
 
G_M000_IG26:                ;; offset=0x0451
       mov      edx, edx
       lea      r9, [reloc @RWD128]
       mov      r9d, dword ptr [r9+4*rdx]
       lea      rcx, G_M000_IG02
       add      r9, rcx
       jmp      r9
 
G_M000_IG27:                ;; offset=0x046B
       vaddps   ymm0, ymm9, ymm8
       vaddps   ymm0, ymm0, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vsubps   ymm8, ymm0, ymm8
       vsubps   ymm9, ymm0, ymm9
       vsubps   ymm10, ymm0, ymm10
       jmp      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x048E
       vaddps   ymm0, ymm10, ymm8
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm9, ymm9, ymmword ptr [reloc @RWD96]
       vsubps   ymm1, ymm1, ymm9
       vaddps   ymm8, ymm1, ymm8
       vaddps   ymm10, ymm1, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm9, ymm0, ymm9
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x04C1
       vaddps   ymm0, ymm9, ymm8
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm10, ymm10, ymmword ptr [reloc @RWD96]
       vsubps   ymm2, ymm1, ymm10
       vaddps   ymm8, ymm2, ymm8
       vaddps   ymm1, ymm9, ymm1
       vsubps   ymm9, ymm1, ymm10
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vaddps   ymm10, ymm0, ymm10
 
G_M000_IG30:                ;; offset=0x04F6
       lea      rdi, bword ptr [r8+0x74]
       mov      ebp, dword ptr [r8+0x08]
       mov      r15d, dword ptr [r8+0x1C]
       add      r8, 8
       vmovaps  ymm11, ymm8
       vmovaps  ymm12, ymm9
       vmovaps  ymm13, ymm10
       vmovss   xmm14, dword ptr [r8+0x38]
       cmp      dword ptr [rdi], 0
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x0520
       cmp      r15d, 1
       jg       G_M000_IG148
 
G_M000_IG32:                ;; offset=0x052A
       vmovd    xmm0, ebp
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm8
       vmovups  ymmword ptr [rsp+0xE0], ymm9
       vmovups  ymmword ptr [rsp+0xC0], ymm10
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x3A0]
       vextractf128 xmm15, ymm6
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rdi], 0
       vinsertf128 ymm6, ymm6, xmm15
       je       G_M000_IG153
 
G_M000_IG33:                ;; offset=0x059F
       vbroadcastss ymm0, dword ptr [rdi+0x18]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       je       G_M000_IG152
 
G_M000_IG34:                ;; offset=0x05B0
       cmp      edx, 3
       je       G_M000_IG151
 
G_M000_IG35:                ;; offset=0x05B9
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x3A0]
 
G_M000_IG36:                ;; offset=0x05C2
       vbroadcastss ymm0, ymm14
       vmulps   ymm8, ymm0, ymm1
 
G_M000_IG37:                ;; offset=0x05CB
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 4
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x30]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x05E7
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm9, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm8, ymm8, xmm9
 
G_M000_IG39:                ;; offset=0x060B
       vmulps   ymm0, ymm8, ymmword ptr [r15+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x19C0]
       mov      rdx, rdi
       cmp      ebp, 5
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x38]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x0633
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm8, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm7, ymm7, xmm8
 
G_M000_IG41:                ;; offset=0x0657
       vmovups  ymm0, ymmword ptr [r15+0x08]
       vmovups  ymmword ptr [rsp+0x19A0], ymm0
       vaddps   ymm7, ymm7, ymmword ptr [rsp+0x19A0]
       cmp      ebp, 6
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdi+0x40]
       cmp      qword ptr [rdi], r14
       je       SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0681
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm8, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm7, ymm7, xmm8
 
G_M000_IG43:                ;; offset=0x06A5
       vmovups  ymm9, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmulps   ymm0, ymm9, ymm7
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1980]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1960]
       lea      r8, [rsp+0x1980]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1920]
       lea      rdx, [rsp+0x1960]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 7
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x48]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0756
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG182
 
G_M000_IG45:                ;; offset=0x0769
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1900]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1900]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x18E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x18C0]
       lea      r8, [rsp+0x18E0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1880]
       lea      rdx, [rsp+0x18C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 8
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x50]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x08B0
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG183
 
G_M000_IG47:                ;; offset=0x08C3
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1860]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 9
       jbe      G_M000_IG193
       mov      rbp, gword ptr [rdx+0x58]
       cmp      qword ptr [rbp], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x0959
       mov      rdx, rbp
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG49:                ;; offset=0x097D
       vmovups  ymm0, ymmword ptr [rsp+0x1860]
       vmulps   ymm0, ymm0, ymmword ptr [rbp+0x08]
       vaddps   ymm8, ymm0, ymm6
       cmp      dword ptr [rdi+0x08], 10
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0x60]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x09A5
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG184
 
G_M000_IG51:                ;; offset=0x09B8
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1840]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 11
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x68]
       cmp      qword ptr [rdi], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
       je       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0A56
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG53:                ;; offset=0x0A86
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1840]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1820]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1800]
       lea      r8, [rsp+0x1820]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x17C0]
       lea      rdx, [rsp+0x1800]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 12
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x70]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0B53
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG185
 
G_M000_IG55:                ;; offset=0x0B66
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x17A0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vmovups  ymm0, ymmword ptr [rsp+0x17A0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm6, ymm6, xmm15
       vaddps   ymm8, ymm0, ymm6
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 13
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x78]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0C11
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG186
 
G_M000_IG57:                ;; offset=0x0C24
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1780]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm9, ymmword ptr [rsp+0x1780]
       vaddps   ymm0, ymm0, ymm9
       vinsertf128 ymm8, ymm8, xmm10
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1760]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1740]
       lea      r8, [rsp+0x1760]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1700]
       lea      rdx, [rsp+0x1740]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 14
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x80]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG58:                ;; offset=0x0D75
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0D77
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG187
 
G_M000_IG60:                ;; offset=0x0D8A
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x16E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x16E0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x16C0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x16A0]
       lea      r8, [rsp+0x16C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1660]
       lea      rdx, [rsp+0x16A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 15
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x88]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0ED4
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG188
 
G_M000_IG62:                ;; offset=0x0EE7
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1640]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1640]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1620]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1600]
       lea      r8, [rsp+0x1620]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x15C0]
       lea      rdx, [rsp+0x1600]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 16
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0x90]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x1031
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG189
 
G_M000_IG64:                ;; offset=0x1044
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x15A0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       mov      ebp, dword ptr [rdx+0x08]
       cmp      ebp, 17
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0x98]
       cmp      qword ptr [r15], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x10DE
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
 
G_M000_IG66:                ;; offset=0x1102
       vmovups  ymm0, ymmword ptr [rsp+0x15A0]
       vmulps   ymm8, ymm0, ymmword ptr [r15+0x08]
       mov      rdx, rdi
       cmp      ebp, 18
       jbe      G_M000_IG193
       mov      r15, gword ptr [rdx+0xA0]
       cmp      qword ptr [r15], r14
       je       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x1129
       mov      rdx, r15
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG68:                ;; offset=0x1159
       vaddps   ymm8, ymm8, ymmword ptr [r15+0x08]
       cmp      ebp, 19
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rdi+0xA8]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x1177
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG190
 
G_M000_IG70:                ;; offset=0x118A
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1580]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 20
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xB0]
       cmp      qword ptr [rdi], r14
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
       je       SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x122B
       mov      rdx, rdi
       mov      rcx, r14
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       vextractf128 xmm10, ymm8
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       vinsertf128 ymm8, ymm8, xmm10
 
G_M000_IG72:                ;; offset=0x125B
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1580]
       vmulps   ymm0, ymm0, ymmword ptr [rdi+0x08]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymm8
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1560]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x1540]
       lea      r8, [rsp+0x1560]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1500]
       lea      rdx, [rsp+0x1540]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 21
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0xB8]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x132B
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG191
 
G_M000_IG74:                ;; offset=0x133E
       vmovups  ymm0, ymmword ptr [rsp+0x1A20]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x1A00]
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x19E0]
       vmovups  ymmword ptr [rsp+0xC0], ymm0
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rdx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x14E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x14E0]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x14C0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       vmovups  ymm0, ymmword ptr [rsp+0x19A0]
       vmovups  ymmword ptr [rsp+0x100], ymm0
       lea      rdx, [rsp+0x100]
       lea      rcx, [rsp+0x14A0]
       lea      r8, [rsp+0x14C0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1460]
       lea      rdx, [rsp+0x14A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      dword ptr [rcx+0x08], 22
       jbe      G_M000_IG193
       mov      rdx, gword ptr [rcx+0xC0]
       mov      rcx, rdx
       test     rcx, rcx
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm9, ymm9, xmm7
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x1488
       mov      rax, 0x7FFC658E3F00
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG192
 
G_M000_IG76:                ;; offset=0x149B
       lea      rdx, [rsp+0x19E0]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x1440]
       lea      r8, [rsp+0x1A20]
       lea      r9, [rsp+0x1A00]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm9
       cmp      dword ptr [rcx], ecx
       call     [Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this]
       vinsertf128 ymm6, ymm6, xmm15
       vmovups  ymmword ptr [rsp+0x100], ymm6
       vmovups  ymm0, ymmword ptr [rsp+0x1440]
       vmulps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vaddps   ymm0, ymm0, ymm6
       vaddps   ymm0, ymm0, ymmword ptr [rsp+0x19A0]
       vinsertf128 ymm9, ymm9, xmm7
       vmulps   ymm0, ymm0, ymm9
       vmovups  ymmword ptr [rsp+0xE0], ymm0
       lea      rdx, [rsp+0x100]
       lea      r8, [rsp+0xE0]
       lea      rcx, [rsp+0x1420]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x1400]
       lea      rdx, [rsp+0x19A0]
       lea      r8, [rsp+0x1420]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       lea      rcx, [rsp+0x13C0]
       lea      rdx, [rsp+0x1400]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:ToDouble(System.Numerics.Vector`1[float]):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 23
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xC8]
       mov      rbp, 0x7FFC658E7DD8
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG78
 
G_M000_IG77:                ;; offset=0x158C
       mov      rdx, rdi
       mov      rcx, rbp
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG78:                ;; offset=0x1598
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       vmovdqu  ymm0, ymmword ptr [rsp+0x1880]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x18A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1380]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdx, rdi
       cmp      dword ptr [rdx+0x08], 24
       jbe      G_M000_IG193
       mov      r14, gword ptr [rdx+0xD0]
       cmp      qword ptr [r14], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       je       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x1622
       mov      rdx, r14
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG80:                ;; offset=0x1646
       vmovups  ymm10, ymmword ptr [r14+0x08]
       vmovups  ymm11, ymmword ptr [r14+0x28]
       cmp      dword ptr [rdi+0x08], 25
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdi+0xD8]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x1668
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG82:                ;; offset=0x16A4
       vmovups  ymm14, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x240], ymm14
       vmovups  ymm15, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x220], ymm15
       vmovdqu  ymm0, ymmword ptr [rsp+0x1700]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1720]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymmword ptr [rsp+0x40], ymm14
       vmovups  ymmword ptr [rsp+0x60], ymm15
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1340]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1300]
       lea      r8, [rsp+0x1340]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 26
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xE0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG84
 
G_M000_IG83:                ;; offset=0x179D
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG84:                ;; offset=0x17D9
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x200], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x1E0], ymm1
       vmovdqu  ymm2, ymmword ptr [rsp+0x1460]
       vmovdqu  ymmword ptr [rsp+0x80], ymm2
       vmovdqu  ymm2, ymmword ptr [rsp+0x1480]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm2
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x12C0]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 27
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xE8]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x188A
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
 
G_M000_IG86:                ;; offset=0x18C6
       vmovups  ymm8, ymmword ptr [rdi+0x08]
       vmovups  ymm9, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x12C0]
       lea      rcx, [rsp+0x1280]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1460]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1480]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x240]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x220]
       vmovups  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1240]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 28
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xF0]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x19D3
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG88:                ;; offset=0x1A3B
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1240]
       lea      rcx, [rsp+0x1200]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmmword ptr [rsp+0x1D0], ymm8
       vextractf128 xmmword ptr [rsp+0x1B0], ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x11C0]
       lea      r8, [rsp+0x1200]
       vextractf128 xmm14, ymm10
       vextractf128 xmm15, ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1180]
       lea      r8, [rsp+0x11C0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1180]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x11A0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1180]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x11A0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1140]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 29
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0xF8]
 
G_M000_IG89:                ;; offset=0x1BB9
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x1D0]
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x1B0]
       vinsertf128 ymm10, ymm10, xmm14
       vinsertf128 ymm11, ymm11, xmm15
       je       SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x1BEC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG91:                ;; offset=0x1C54
       vmovups  ymm0, ymmword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x180], ymm0
       vmovups  ymm1, ymmword ptr [rdi+0x28]
       vmovups  ymmword ptr [rsp+0x160], ymm1
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x1100]
       lea      r8, [rsp+0x1180]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x10C0]
       lea      r8, [rsp+0x1100]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x1080]
       lea      rdx, [rsp+0x1140]
       lea      r8, [rsp+0x10C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 30
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x100]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x1D76
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG93:                ;; offset=0x1DDE
       vmovdqu  ymm0, ymmword ptr [rsp+0x1920]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1940]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x1040]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 31
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x108]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x1EA9
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG95:                ;; offset=0x1F11
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1040]
       lea      rcx, [rsp+0x1000]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1000]
       lea      rcx, [rsp+0xFC0]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x17C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovups  ymm0, ymmword ptr [rsp+0x200]
       vmovups  ymmword ptr [rsp+0x40], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x1E0]
       vmovups  ymmword ptr [rsp+0x60], ymm1
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xF80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 32
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x110]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG97
 
G_M000_IG96:                ;; offset=0x2066
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG97:                ;; offset=0x20CE
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF80]
       lea      rcx, [rsp+0xF40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 33
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x118]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x217E
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG99:                ;; offset=0x21E6
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xF40]
       lea      rcx, [rsp+0xF00]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xEC0]
       lea      rdx, [rsp+0xFC0]
       lea      r8, [rsp+0xF00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 34
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x120]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x22B4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG101:                ;; offset=0x231C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1300]
       lea      rcx, [rsp+0xE80]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 35
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x128]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x23CC
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG103:                ;; offset=0x2434
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xE80]
       lea      rcx, [rsp+0xE40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 36
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x130]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x24E4
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG105:                ;; offset=0x254C
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xE00]
       lea      r8, [rsp+0x1380]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xDC0]
       lea      rdx, [rsp+0xE40]
       lea      r8, [rsp+0xE00]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD80]
       lea      rdx, [rsp+0xEC0]
       lea      r8, [rsp+0xDC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 37
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x138]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x2638
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG107:                ;; offset=0x26A0
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1280]
       lea      rcx, [rsp+0xD40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xD00]
       lea      rdx, [rsp+0xD80]
       lea      r8, [rsp+0xD40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x13C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x1080]
       lea      rcx, [rsp+0xCC0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x13C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x13E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xCC0]
       lea      rcx, [rsp+0xC80]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 38
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x140]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG109
 
G_M000_IG108:                ;; offset=0x27F2
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG109:                ;; offset=0x285A
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC80]
       lea      rcx, [rsp+0xC40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xC00]
       lea      rdx, [rsp+0xD00]
       lea      r8, [rsp+0xC40]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 39
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x148]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x2928
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG111:                ;; offset=0x2990
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xC00]
       lea      rcx, [rsp+0xBC0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x1500]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x1520]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x40], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0x60], ymm9
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0xB80]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB80]
       lea      rcx, [rsp+0xB40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0xB00]
       lea      rdx, [rsp+0xB40]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Abs(Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 40
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x150]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
 
G_M000_IG112:                ;; offset=0x2AE9
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG114
 
G_M000_IG113:                ;; offset=0x2B01
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG114:                ;; offset=0x2B69
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xB00]
       lea      rcx, [rsp+0xAC0]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 41
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x158]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       je       SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x2C19
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG116:                ;; offset=0x2C81
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0xAC0]
       lea      rcx, [rsp+0xA80]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xA40]
       lea      r8, [rsp+0xA80]
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0xA00]
       lea      r8, [rsp+0xA40]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xA00]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA20]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA00]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xA20]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x9C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
 
G_M000_IG117:                ;; offset=0x2E10
       lea      rcx, [rsp+0x980]
       lea      r8, [rsp+0xA00]
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x940]
       lea      r8, [rsp+0x980]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x900]
       lea      rdx, [rsp+0x9C0]
       lea      r8, [rsp+0x940]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x8C0]
       lea      r8, [rsp+0x900]
       vextractf128 xmmword ptr [rsp+0x2D0], ymm6
       vextractf128 xmmword ptr [rsp+0x2B0], ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x40], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0x60], ymm11
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x880]
       vextractf128 xmm12, ymm10
       vextractf128 xmm13, ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x08], 42
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x160]
       cmp      qword ptr [rdi], rbp
       vinsertf128 ymm6, ymm6, xmmword ptr [rsp+0x2D0]
 
G_M000_IG118:                ;; offset=0x2F74
       vinsertf128 ymm7, ymm7, xmmword ptr [rsp+0x2B0]
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmm12
       vinsertf128 ymm11, ymm11, xmm13
       je       SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x2F99
       mov      rdx, rdi
       mov      rcx, rbp
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm12
       vinsertf128 ymm7, ymm7, xmm13
       vinsertf128 ymm8, ymm8, xmm15
       vinsertf128 ymm9, ymm9, xmm14
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
 
G_M000_IG120:                ;; offset=0x3001
       vmovdqu  ymm0, ymmword ptr [rdi+0x08]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rdi+0x28]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x880]
       lea      rcx, [rsp+0x840]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       vextractf128 xmm15, ymm8
       vextractf128 xmm14, ymm9
       vextractf128 xmmword ptr [rsp+0x290], ymm10
       vextractf128 xmmword ptr [rsp+0x270], ymm11
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Division(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm10, ymm10, xmmword ptr [rsp+0x290]
       vmovups  ymmword ptr [rsp+0x80], ymm10
       vinsertf128 ymm11, ymm11, xmmword ptr [rsp+0x270]
       vmovups  ymmword ptr [rsp+0xA0], ymm11
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x800]
       lea      r8, [rsp+0x840]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Max(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x7C0]
       lea      r8, [rsp+0x800]
       vextractf128 xmm12, ymm6
       vextractf128 xmm13, ymm7
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Min(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x7C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7C0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x7E0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x780]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm8, ymm8, xmm15
       vmovups  ymmword ptr [rsp+0x80], ymm8
       vinsertf128 ymm9, ymm9, xmm14
       vmovups  ymmword ptr [rsp+0xA0], ymm9
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x740]
       lea      r8, [rsp+0x7C0]
 
G_M000_IG121:                ;; offset=0x318A
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovups  ymm0, ymmword ptr [rsp+0x180]
       vmovups  ymmword ptr [rsp+0x80], ymm0
       vmovups  ymm1, ymmword ptr [rsp+0x160]
       vmovups  ymmword ptr [rsp+0xA0], ymm1
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x700]
       lea      r8, [rsp+0x740]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x6C0]
       lea      rdx, [rsp+0x780]
       lea      r8, [rsp+0x700]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm12
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm13
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x680]
       lea      r8, [rsp+0x6C0]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x640]
       lea      rdx, [rsp+0x8C0]
       lea      r8, [rsp+0x680]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       mov      rbx, gword ptr [rbx+0x08]
       mov      rdx, rbx
       cmp      dword ptr [rdx+0x08], 43
       jbe      G_M000_IG193
       mov      rdi, gword ptr [rdx+0x168]
       cmp      qword ptr [rdi], rbp
       je       SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x3267
       mov      rdx, rdi
       mov      rcx, rbp
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG123:                ;; offset=0x3273
       vmovups  ymm6, ymmword ptr [rdi+0x08]
       vmovups  ymm7, ymmword ptr [rdi+0x28]
       cmp      dword ptr [rbx+0x08], 44
       jbe      G_M000_IG193
       mov      rbx, gword ptr [rbx+0x170]
       cmp      qword ptr [rbx], rbp
       je       SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x3293
       mov      rdx, rbx
       mov      rcx, rbp
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [CORINFO_HELP_UNBOX]
       vinsertf128 ymm6, ymm6, xmm8
       vinsertf128 ymm7, ymm7, xmm9
 
G_M000_IG125:                ;; offset=0x32B7
       vmovdqu  ymm0, ymmword ptr [rsp+0x17C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x17E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x08]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rbx+0x28]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x600]
       vextractf128 xmm8, ymm6
       vextractf128 xmm9, ymm7
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vinsertf128 ymm6, ymm6, xmm8
       vmovups  ymmword ptr [rsp+0x80], ymm6
       vinsertf128 ymm7, ymm7, xmm9
       vmovups  ymmword ptr [rsp+0xA0], ymm7
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x5C0]
       lea      r8, [rsp+0x600]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x5C0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x5E0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x40], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0x60], ymm0
       lea      rdx, [rsp+0x80]
       lea      r8, [rsp+0x40]
       lea      rcx, [rsp+0x5A0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:LessThan(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):System.Numerics.Vector`1[int]]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x5C0]
       lea      rcx, [rsp+0x560]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Subtraction(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0x640]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0x660]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      r8, [rsp+0x80]
       lea      rdx, [rsp+0x560]
       lea      rcx, [rsp+0x520]
 
G_M000_IG126:                ;; offset=0x342F
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Multiply(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       vmovdqu  ymm0, ymmword ptr [rsp+0xBC0]
       vmovdqu  ymmword ptr [rsp+0x80], ymm0
       vmovdqu  ymm0, ymmword ptr [rsp+0xBE0]
       vmovdqu  ymmword ptr [rsp+0xA0], ymm0
       lea      rdx, [rsp+0x80]
       lea      rcx, [rsp+0x4E0]
       lea      r8, [rsp+0x520]
       call     [Tedd.FastNoise.Procedural.DoublePair:op_Addition(Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
       lea      rcx, [rsp+0x4A0]
       lea      rdx, [rsp+0x5A0]
       lea      r8, [rsp+0x4E0]
       lea      r9, [rsp+0xBC0]
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Select(System.Numerics.Vector`1[int],Tedd.FastNoise.Procedural.DoublePair,Tedd.FastNoise.Procedural.DoublePair):Tedd.FastNoise.Procedural.DoublePair]
 
G_M000_IG127:                ;; offset=0x349D
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG128:                ;; offset=0x34A7
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1920]
       xor      edx, edx
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG129:                ;; offset=0x34C2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG130:                ;; offset=0x34CC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1880]
       mov      edx, 1
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG131:                ;; offset=0x34EA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG132:                ;; offset=0x34F4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x17C0]
       mov      edx, 2
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG133:                ;; offset=0x3512
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG134:                ;; offset=0x351C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1700]
       mov      edx, 3
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG135:                ;; offset=0x353A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG136:                ;; offset=0x3544
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1660]
       mov      edx, 4
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG137:                ;; offset=0x3562
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG138:                ;; offset=0x356C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x15C0]
       mov      edx, 5
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG139:                ;; offset=0x358A
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG140:                ;; offset=0x3594
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1500]
       mov      edx, 6
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG141:                ;; offset=0x35B2
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG142:                ;; offset=0x35BC
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x1460]
       mov      edx, 7
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG143:                ;; offset=0x35DA
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG144:                ;; offset=0x35E4
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x13C0]
       mov      edx, 8
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
 
G_M000_IG145:                ;; offset=0x3602
       vmovdqu  xmm0, xmmword ptr [rsi]
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
 
G_M000_IG146:                ;; offset=0x360C
       lea      rcx, [rsp+0x30]
       lea      r9, [rsp+0x4A0]
       mov      edx, 9
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       lea      r9, [rsp+0x640]
       mov      rcx, rsi
       mov      edx, 10
       mov      r8d, 11
       call     [Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair)]
       nop      
 
G_M000_IG147:                ;; offset=0x3647
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x1B90]
       vmovaps  xmm7, xmmword ptr [rsp+0x1B80]
       vmovaps  xmm8, xmmword ptr [rsp+0x1B70]
       vmovaps  xmm9, xmmword ptr [rsp+0x1B60]
       vmovaps  xmm10, xmmword ptr [rsp+0x1B50]
       vmovaps  xmm11, xmmword ptr [rsp+0x1B40]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B30]
       vmovaps  xmm13, xmmword ptr [rsp+0x1B20]
       vmovaps  xmm14, xmmword ptr [rsp+0x1B10]
       vmovaps  xmm15, xmmword ptr [rsp+0x1B00]
       add      rsp, 0x1BA0
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG148:                ;; offset=0x36B6
       vxorps   ymm8, ymm8, ymm8
       vmovups  ymmword ptr [rsp+0x380], ymm8
       vbroadcastss ymm9, dword ptr [rdi+0x18]
       vbroadcastss ymm10, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x340], ymm10
       vbroadcastss ymm0, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x320], ymm0
       vbroadcastss ymm1, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x300], ymm1
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG174
 
G_M000_IG149:                ;; offset=0x3703
       vmovups  ymm8, ymmword ptr [rsp+0x380]
 
G_M000_IG150:                ;; offset=0x370C
       jmp      G_M000_IG37
 
G_M000_IG151:                ;; offset=0x3711
       vbroadcastss ymm1, dword ptr [reloc @RWD140]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x3A0]
       vbroadcastss ymm3, dword ptr [rdi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD224], ymm4
       vcvtdq2ps ymm3, ymm3
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm3, ymm3, ymm15
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vsubps   ymm3, ymm15, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG36
 
G_M000_IG152:                ;; offset=0x3790
       vmovups  ymm1, ymmword ptr [rsp+0x3A0]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm2, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG36
 
G_M000_IG153:                ;; offset=0x37BF
       vmovups  ymm1, ymmword ptr [rsp+0x3A0]
       jmp      G_M000_IG36
 
G_M000_IG154:                ;; offset=0x37CD
       vxorps   ymm7, ymm7, ymm7
       vmovups  ymmword ptr [rsp+0x460], ymm7
       vbroadcastss ymm8, dword ptr [rdi+0x18]
       vbroadcastss ymm9, dword ptr [rdi+0x08]
       vmovups  ymmword ptr [rsp+0x420], ymm9
       vbroadcastss ymm14, dword ptr [rdi+0x0C]
       vmovups  ymmword ptr [rsp+0x400], ymm14
       vbroadcastss ymm15, dword ptr [rdi+0x10]
       vmovups  ymmword ptr [rsp+0x3E0], ymm15
       xor      r13d, r13d
       cmp      r13d, r15d
       jl       G_M000_IG164
 
G_M000_IG155:                ;; offset=0x3819
       vmovups  ymm7, ymmword ptr [rsp+0x460]
 
G_M000_IG156:                ;; offset=0x3822
       jmp      G_M000_IG21
 
G_M000_IG157:                ;; offset=0x3827
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm9, ymmword ptr [rsp+0x480]
       vbroadcastss ymm2, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm2, ymm1
       vmulps   ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm2, ymm2
       vandps   ymm2, ymm3, ymm2
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm2, ymm2
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm2, ymm2, ymm15
       vsubps   ymm1, ymm1, ymm2
       vcmpltps ymm2, ymm1, ymm9
       vsubps   ymm3, ymm15, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG20
 
G_M000_IG158:                ;; offset=0x38A7
       vmovups  ymm1, ymmword ptr [rsp+0x480]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD224]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm1, ymm9
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG20
 
G_M000_IG159:                ;; offset=0x38D7
       vmovups  ymm1, ymmword ptr [rsp+0x480]
       jmp      G_M000_IG20
 
G_M000_IG160:                ;; offset=0x38E5
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
       vbroadcastss ymm1, dword ptr [rdi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD224], ymm2
       vcvtdq2ps ymm1, ymm1
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm1, ymm1, ymm15
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm9
       vsubps   ymm2, ymm15, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       vmulps   ymm0, ymm0, ymm15
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       jmp      SHORT G_M000_IG162
 
G_M000_IG161:                ;; offset=0x397E
       vmovups  ymm0, ymmword ptr [rsp+0x3C0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x3C0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm0, ymm0, ymm8
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vsubps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
 
G_M000_IG162:                ;; offset=0x39C5
       vsubps   ymm0, ymm0, ymm9
       vmovups  ymm15, ymmword ptr [rsp+0x3E0]
       vmulps   ymm0, ymm0, ymm15
       vaddps   ymm0, ymm0, ymm9
       vmulps   ymm8, ymm0, ymm8
       vmovups  ymm9, ymmword ptr [rsp+0x420]
       vmulps   ymm10, ymm10, ymm9
       vmulps   ymm11, ymm11, ymm9
       vmulps   ymm12, ymm12, ymm9
       vmovups  ymm14, ymmword ptr [rsp+0x400]
       vmulps   ymm8, ymm8, ymm14
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG156
 
G_M000_IG163:                ;; offset=0x3A14
       vmovups  ymmword ptr [rsp+0x460], ymm7
 
G_M000_IG164:                ;; offset=0x3A1D
       vucomiss xmm13, dword ptr [reloc @RWD140]
       jp       SHORT G_M000_IG165
       je       SHORT G_M000_IG167
 
G_M000_IG165:                ;; offset=0x3A29
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x3A32
       vbroadcastss ymm0, ymm13
       vmulps   ymm8, ymm0, ymm8
 
G_M000_IG167:                ;; offset=0x3A3C
       lea      edx, [rbp+r13]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x120], ymm0
       vmovups  ymmword ptr [rsp+0x100], ymm10
       vmovups  ymmword ptr [rsp+0xE0], ymm11
       vmovups  ymmword ptr [rsp+0xC0], ymm12
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x3C0]
       vextractf128 xmm14, ymm6
       vextractf128 xmm15, ymm10
       vextractf128 xmm7, ymm11
       vextractf128 xmm9, ymm12
       vextractf128 xmmword ptr [rsp+0x450], ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm6, ymm6, xmm14
       vinsertf128 ymm10, ymm10, xmm15
       vinsertf128 ymm11, ymm11, xmm7
       vinsertf128 ymm12, ymm12, xmm9
       vinsertf128 ymm8, ymm8, xmmword ptr [rsp+0x450]
       je       G_M000_IG161
 
G_M000_IG168:                ;; offset=0x3AF2
       cmp      edx, 3
       je       G_M000_IG160
 
G_M000_IG169:                ;; offset=0x3AFB
       vmulps   ymm0, ymm8, ymmword ptr [rsp+0x3C0]
       vaddps   ymm7, ymm0, ymmword ptr [rsp+0x460]
       vbroadcastss ymm9, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm9, ymmword ptr [rsp+0x3C0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD160]
       jmp      G_M000_IG162
 
G_M000_IG170:                ;; offset=0x3B2C
       vbroadcastss ymm0, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x2E0]
       vbroadcastss ymm2, dword ptr [rdi+0x14]
       vmulps   ymm1, ymm2, ymm1
       vmulps   ymm2, ymm1, ymmword ptr [reloc @RWD160]
       vcmpeqps ymm3, ymm2, ymm2
       vandps   ymm2, ymm3, ymm2
       vcmpgeps ymm3, ymm2, ymmword ptr [reloc @RWD192]
       vcvttps2dq ymm2, ymm2
       vpblendvb ymm2, ymm2, ymmword ptr [reloc @RWD224], ymm3
       vcvtdq2ps ymm2, ymm2
       vbroadcastss ymm15, dword ptr [reloc @RWD256]
       vmulps   ymm2, ymm2, ymm15
       vsubps   ymm1, ymm1, ymm2
       vcmpltps ymm2, ymm1, ymm0
       vsubps   ymm3, ymm15, ymm1
       vblendvps ymm1, ymm3, ymm1, ymm2
       vmovups  ymmword ptr [rsp+0x2E0], ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmulps   ymm1, ymm1, ymm15
       vmulps   ymm1, ymm1, ymm9
       vaddps   ymm8, ymm1, ymmword ptr [rsp+0x380]
       vmovups  ymm1, ymmword ptr [rsp+0x2E0]
       vmovaps  ymm2, ymm0
       vmovaps  ymm0, ymm1
       vmovaps  ymm1, ymm2
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x3BD0
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vandps   ymm1, ymm0, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rsp+0x2E0], ymm1
       vmovups  ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vbroadcastss ymm1, dword ptr [reloc @RWD140]
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm0, ymm0, ymm9
       vaddps   ymm8, ymm0, ymmword ptr [rsp+0x380]
       vsubps   ymm0, ymm1, ymmword ptr [rsp+0x2E0]
 
G_M000_IG172:                ;; offset=0x3C1F
       vsubps   ymm0, ymm0, ymm1
       vmovups  ymm2, ymmword ptr [rsp+0x300]
       vmulps   ymm0, ymm0, ymm2
       vaddps   ymm0, ymm0, ymm1
       vmulps   ymm9, ymm0, ymm9
       vmovups  ymm10, ymmword ptr [rsp+0x340]
       vmulps   ymm11, ymm11, ymm10
       vmulps   ymm12, ymm12, ymm10
       vmulps   ymm13, ymm13, ymm10
       vmovups  ymm0, ymmword ptr [rsp+0x320]
       vmulps   ymm9, ymm9, ymm0
       inc      r13d
       cmp      r13d, r15d
       jge      G_M000_IG150
 
G_M000_IG173:                ;; offset=0x3C6A
       vmovups  ymmword ptr [rsp+0x380], ymm8
 
G_M000_IG174:                ;; offset=0x3C73
       vucomiss xmm14, dword ptr [reloc @RWD140]
       jp       SHORT G_M000_IG175
       je       SHORT G_M000_IG177
 
G_M000_IG175:                ;; offset=0x3C7F
       lea      edx, [r15-0x01]
       cmp      r13d, edx
       jne      SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x3C88
       vbroadcastss ymm2, ymm14
       vmulps   ymm9, ymm2, ymm9
 
G_M000_IG177:                ;; offset=0x3C92
       lea      edx, [rbp+r13]
       vmovd    xmm2, edx
       vpbroadcastd ymm2, ymm2
       vmovups  ymmword ptr [rsp+0x120], ymm2
       vmovups  ymmword ptr [rsp+0x100], ymm11
       vmovups  ymmword ptr [rsp+0xE0], ymm12
       vmovups  ymmword ptr [rsp+0xC0], ymm13
       lea      rdx, [rsp+0x120]
       lea      r8, [rsp+0x100]
       lea      r9, [rsp+0xE0]
       lea      rcx, [rsp+0xC0]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x2E0]
       vextractf128 xmm15, ymm6
       vextractf128 xmm7, ymm11
       vextractf128 xmm8, ymm12
       vextractf128 xmm10, ymm13
       vextractf128 xmmword ptr [rsp+0x370], ymm9
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rdi]
       cmp      edx, 2
       vinsertf128 ymm6, ymm6, xmm15
       vinsertf128 ymm11, ymm11, xmm7
       vinsertf128 ymm12, ymm12, xmm8
       vinsertf128 ymm13, ymm13, xmm10
       vinsertf128 ymm9, ymm9, xmmword ptr [rsp+0x370]
       je       G_M000_IG171
 
G_M000_IG178:                ;; offset=0x3D48
       cmp      edx, 3
       je       G_M000_IG170
 
G_M000_IG179:                ;; offset=0x3D51
       vmulps   ymm0, ymm9, ymmword ptr [rsp+0x2E0]
       vaddps   ymm8, ymm0, ymmword ptr [rsp+0x380]
       vbroadcastss ymm0, dword ptr [reloc @RWD140]
       vaddps   ymm1, ymm0, ymmword ptr [rsp+0x2E0]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD160]
       vmovaps  ymm2, ymm0
       vmovaps  ymm0, ymm1
       vmovaps  ymm1, ymm2
       jmp      G_M000_IG172
 
G_M000_IG180:                ;; offset=0x3D8E
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG181:                ;; offset=0x3D95
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG182:                ;; offset=0x3D9C
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG183:                ;; offset=0x3DA6
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG184:                ;; offset=0x3DB0
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG185:                ;; offset=0x3DBA
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG186:                ;; offset=0x3DC4
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG187:                ;; offset=0x3DCE
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG188:                ;; offset=0x3DD8
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG189:                ;; offset=0x3DE2
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG190:                ;; offset=0x3DEC
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG191:                ;; offset=0x3DF6
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG192:                ;; offset=0x3E00
       mov      rcx, rax
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG193:                ;; offset=0x3E0A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000001EEh ; case G_M000_IG13
       	dd	000001BDh ; case G_M000_IG12
       	dd	0000019Ch ; case G_M000_IG11
RWD12  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD32  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD64  	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD96  	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD128 	dd	0000040Fh ; case G_M000_IG29
       	dd	000003DCh ; case G_M000_IG28
       	dd	000003B9h ; case G_M000_IG27
RWD140 	dd	3F800000h		;         1
RWD144 	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD160 	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD192 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD224 	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD256 	dd	40000000h		;         2
RWD260 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD288 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h

; Total bytes of code 15888

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair (Tier0-FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier-0 switched to FullOpts code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 200.4397
; No PGO data
; 0 inlinees with PGO data; 8 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       sub      rsp, 40
       lea      rbp, [rsp+0x20]
       mov      rax, 0x5BDD21B0C6A9
       mov      qword ptr [rbp], rax
 
G_M000_IG02:                ;; offset=0x0019
       test     dword ptr [rsp], esp
       sub      rsp, 64
       lea      rax, [rsp+0x20]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rax], ymm0
       vmovdqu  ymmword ptr [rax+0x20], ymm0
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x0035
       mov      r11d, r10d
       imul     r11d, r9d
       add      r11d, r8d
       cmp      r11d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG07
       mov      rbx, bword ptr [rdx]
       vmovsd   xmm0, qword ptr [rbx+8*r11]
       vmovsd   qword ptr [rax+8*r10], xmm0
       inc      r10d
       cmp      r10d, 8
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x005D
       vmovups  ymm0, ymmword ptr [rax]
       add      rax, 32
       vmovups  ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rcx], ymm0
       vmovups  ymmword ptr [rcx+0x20], ymm1
       mov      rax, rcx
       mov      r8, 0x5BDD21B0C6A9
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG05
       call     CORINFO_HELP_FAIL_FAST
 
G_M000_IG05:                ;; offset=0x008A
       nop      
 
G_M000_IG06:                ;; offset=0x008B
       vzeroupper 
       lea      rsp, [rbp+0x08]
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0095
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 155

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC65916050
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC65916054
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:ReadFloat64(System.ReadOnlySpan`1[double],int,int):Tedd.FastNoise.Procedural.DoublePair (Tier0-FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier-0 switched to FullOpts code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 200.4397
; No PGO data
; 0 inlinees with PGO data; 8 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     rbx
       sub      rsp, 40
       lea      rbp, [rsp+0x20]
       mov      rax, 0x5BDD21B0C6A9
       mov      qword ptr [rbp], rax
 
G_M000_IG02:                ;; offset=0x0019
       test     dword ptr [rsp], esp
       sub      rsp, 64
       lea      rax, [rsp+0x20]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rax], ymm0
       vmovdqu  ymmword ptr [rax+0x20], ymm0
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x0035
       mov      r11d, r10d
       imul     r11d, r9d
       add      r11d, r8d
       cmp      r11d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG07
       mov      rbx, bword ptr [rdx]
       vmovsd   xmm0, qword ptr [rbx+8*r11]
       vmovsd   qword ptr [rax+8*r10], xmm0
       inc      r10d
       cmp      r10d, 8
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x005D
       vmovups  ymm0, ymmword ptr [rax]
       add      rax, 32
       vmovups  ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rcx], ymm0
       vmovups  ymmword ptr [rcx+0x20], ymm1
       mov      rax, rcx
       mov      r8, 0x5BDD21B0C6A9
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG05
       call     CORINFO_HELP_FAIL_FAST
 
G_M000_IG05:                ;; offset=0x008A
       nop      
 
G_M000_IG06:                ;; offset=0x008B
       vzeroupper 
       lea      rsp, [rbp+0x08]
       pop      rbx
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x0095
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 155

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC65918CF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC65918CF4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC65918CF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC65918CF4
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 352
       lea      rbp, [rsp+0x160]
       xor      eax, eax
       mov      qword ptr [rbp-0x10], rax
       mov      qword ptr [rbp-0x18], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      qword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x002A
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x60]
       call     [Tedd.FastNoise.Internal.Kernels.KernelConfig:get_Transform3D():int:this]
       mov      dword ptr [rbp-0x04], eax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Frequency():float:this]
       vmovss   dword ptr [rbp-0x98], xmm0
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x20], rax
       vmovss   xmm1, dword ptr [rbp-0x98]
       mov      ecx, dword ptr [rbp-0x04]
       mov      r8, bword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Internal.Kernels.NoisePipeline:Transform3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](int,float,byref,byref,byref)]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 96
       mov      bword ptr [rbp-0x10], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       add      rax, 116
       mov      bword ptr [rbp-0x18], rax
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Seed():int:this]
       mov      dword ptr [rbp-0x1C], eax
       mov      rax, bword ptr [rbp+0x20]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x50], ymm0
       mov      rax, bword ptr [rbp+0x28]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x70], ymm0
       mov      rax, bword ptr [rbp+0x30]
       vmovups  ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rbp-0x90], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_Octaves():int:this]
       mov      dword ptr [rbp-0x94], eax
       vmovups  ymm0, ymmword ptr [rbp-0x50]
       vmovups  ymmword ptr [rbp-0xD0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x70]
       vmovups  ymmword ptr [rbp-0xF0], ymm0
       vmovups  ymm0, ymmword ptr [rbp-0x90]
       vmovups  ymmword ptr [rbp-0x110], ymm0
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
 
G_M000_IG03:                ;; offset=0x012E
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x08]
       call     [Tedd.FastNoise.NoiseFillRequest3D:get_LastOctaveFade():float:this]
       vmovss   dword ptr [rbp-0x114], xmm0
       vmovss   xmm0, dword ptr [rbp-0x114]
       vmovss   dword ptr [rsp+0x40], xmm0
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xF0]
       mov      qword ptr [rsp+0x28], rax
       lea      rax, [rbp-0x110]
       mov      qword ptr [rsp+0x30], rax
       mov      rdx, bword ptr [rbp-0x10]
       mov      r8, bword ptr [rbp-0x18]
       mov      r9d, dword ptr [rbp-0x1C]
       mov      eax, dword ptr [rbp-0x94]
       mov      dword ptr [rsp+0x38], eax
       mov      rcx, qword ptr [rbp+0x18]
       call     [Tedd.FastNoise.Internal.Kernels.FractalKernel:OpenSimplex3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](byref,byref,int,System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],int,float):System.Numerics.Vector`1[float]]
       mov      rax, qword ptr [rbp+0x18]
 
G_M000_IG04:                ;; offset=0x019A
       vzeroupper 
       add      rsp, 352
       pop      rbp
       ret      
 
; Total bytes of code 422

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Instrumented Tier0)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      dword ptr [rbp+0x20], r8d
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x003B
       mov      dword ptr [rbp-0x98], 0x3E8
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004F
       mov      rcx, 0x7FFC65916050
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x3C]
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x74], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x80], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_Low():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x80]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       add      eax, 4
       imul     eax, dword ptr [rbp+0x20]
       add      eax, dword ptr [rbp+0x18]
       mov      dword ptr [rbp-0x84], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x84], eax
       jae      G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x84]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x90], rax
       lea      rdx, [rbp-0x70]
       mov      rcx, bword ptr [rbp+0x28]
       call     [Tedd.FastNoise.Procedural.DoublePair:get_High():System.Numerics.Vector`1[double]:this]
       lea      rcx, [rbp-0x70]
       mov      edx, dword ptr [rbp-0x3C]
       call     [System.Numerics.Vector`1[double]:get_Item(int):double:this]
       mov      rax, bword ptr [rbp-0x90]
       vmovsd   qword ptr [rax], xmm0
       mov      eax, dword ptr [rbp-0x3C]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x011C
       mov      eax, dword ptr [rbp-0x98]
       dec      eax
       mov      dword ptr [rbp-0x98], eax
       cmp      dword ptr [rbp-0x98], 0
       jg       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0133
       lea      rcx, [rbp-0x98]
       mov      edx, 72
       call     CORINFO_HELP_PATCHPOINT
 
G_M000_IG06:                ;; offset=0x0144
       cmp      dword ptr [rbp-0x3C], 4
       jl       G_M000_IG03
       mov      rcx, 0x7FFC65916054
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG07:                ;; offset=0x015E
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x0167
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 365

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 7744
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rsi
       push     rbx
       sub      rsp, 40
 
G_M000_IG02:                ;; offset=0x0006
       mov      rax, bword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x000F
       mov      r11d, r10d
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       mov      ebx, r10d
       mov      esi, ebx
       vmovsd   xmm0, qword ptr [r9+8*rsi]
       vmovsd   qword ptr [rax+8*r11], xmm0
       lea      r11d, [r10+0x04]
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       vmovsd   xmm0, qword ptr [r9+8*rbx+0x20]
       vmovsd   qword ptr [rax+8*r11], xmm0
       inc      r10d
       cmp      r10d, 4
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x0055
       add      rsp, 40
       pop      rbx
       pop      rsi
       ret      
 
G_M000_IG05:                ;; offset=0x005C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 98

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralNoise:SampleOpenSimplex3Wide(System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]:this (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; partially interruptible
; with Synthesized PGO: fgCalledCount is 100
; No PGO data
; 3 inlinees with PGO data; 182 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 544
       vmovaps  xmmword ptr [rsp+0x210], xmm6
       vmovaps  xmmword ptr [rsp+0x200], xmm7
       vmovaps  xmmword ptr [rsp+0x1F0], xmm8
       vmovaps  xmmword ptr [rsp+0x1E0], xmm9
       vmovaps  xmmword ptr [rsp+0x1D0], xmm10
       vmovaps  xmmword ptr [rsp+0x1C0], xmm11
       vmovaps  xmmword ptr [rsp+0x1B0], xmm12
       vmovaps  xmmword ptr [rsp+0x1A0], xmm13
       vmovaps  xmmword ptr [rsp+0x190], xmm14
       vmovaps  xmmword ptr [rsp+0x180], xmm15
       mov      rbx, rdx
       mov      rax, bword ptr [rsp+0x270]
 
G_M000_IG02:                ;; offset=0x0072
       mov      edx, dword ptr [rcx+0x64]
       vbroadcastss ymm0, dword ptr [rcx+0x0C]
       vmulps   ymm1, ymm0, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm1
       vmulps   ymm1, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       dec      edx
       cmp      edx, 2
       jne      G_M000_IG17
 
G_M000_IG03:                ;; offset=0x00A2
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm1, ymm0, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD00]
       vsubps   ymm0, ymm1, ymm0
       vmovups  ymmword ptr [r8], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       vsubps   ymm0, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x00D3
       lea      rsi, bword ptr [rcx+0x74]
       mov      edi, dword ptr [rcx+0x08]
       vmovups  ymm6, ymmword ptr [r8]
       vmovups  ymm7, ymmword ptr [r9]
       vmovups  ymm8, ymmword ptr [rax]
       mov      ebp, dword ptr [rcx+0x1C]
       add      rcx, 8
       vmovaps  ymm9, ymm6
       vmovaps  ymm10, ymm7
       vmovaps  ymm11, ymm8
       vmovss   xmm12, dword ptr [rcx+0x38]
       vmovss   dword ptr [rsp+0x14C], xmm12
       cmp      dword ptr [rsi], 0
       je       G_M000_IG15
       cmp      ebp, 1
       jle      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x011C
       vxorps   ymm6, ymm6, ymm6
       vmovups  ymmword ptr [rsp+0x110], ymm6
       vbroadcastss ymm7, dword ptr [rsi+0x18]
       vbroadcastss ymm8, dword ptr [rsi+0x08]
       vbroadcastss ymm13, dword ptr [rsi+0x0C]
       vmovups  ymmword ptr [rsp+0xF0], ymm13
       vbroadcastss ymm14, dword ptr [rsi+0x10]
       vmovups  ymmword ptr [rsp+0xD0], ymm14
       xor      r14d, r14d
       cmp      r14d, ebp
       jge      G_M000_IG12
 
G_M000_IG06:                ;; offset=0x015F
       vucomiss xmm12, dword ptr [reloc @RWD32]
       jp       G_M000_IG24
       jne      G_M000_IG24
 
G_M000_IG07:                ;; offset=0x0173
       lea      edx, [rdi+r14]
       vmovd    xmm0, edx
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm9
       vmovups  ymmword ptr [rsp+0x50], ymm10
       vmovups  ymmword ptr [rsp+0x30], ymm11
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0xB0]
       vextractf128 xmm15, ymm9
       vextractf128 xmm13, ymm10
       vextractf128 xmm14, ymm11
       vextractf128 xmm6, ymm7
       vextractf128 xmm12, ymm8
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       mov      edx, dword ptr [rsi]
       cmp      edx, 2
       vinsertf128 ymm9, ymm9, xmm15
       vinsertf128 ymm10, ymm10, xmm13
       vinsertf128 ymm11, ymm11, xmm14
       vinsertf128 ymm7, ymm7, xmm6
       vinsertf128 ymm8, ymm8, xmm12
       je       G_M000_IG11
 
G_M000_IG08:                ;; offset=0x020C
       cmp      edx, 3
       je       G_M000_IG25
       vmulps   ymm0, ymm7, ymmword ptr [rsp+0xB0]
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
 
G_M000_IG09:                ;; offset=0x0241
       vsubps   ymm0, ymm0, ymm12
       vmovups  ymm14, ymmword ptr [rsp+0xD0]
       vmulps   ymm0, ymm0, ymm14
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       vmulps   ymm9, ymm9, ymm8
       vmulps   ymm10, ymm10, ymm8
       vmulps   ymm11, ymm11, ymm8
       vmovups  ymm13, ymmword ptr [rsp+0xF0]
       vmulps   ymm7, ymm7, ymm13
       inc      r14d
       cmp      r14d, ebp
       vmovss   xmm12, dword ptr [rsp+0x14C]
       jge      SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x028B
       vmovups  ymmword ptr [rsp+0x110], ymm6
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x0299
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       vandps   ymm0, ymm0, ymmword ptr [reloc @RWD96]
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm0, ymm12
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vsubps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
G_M000_IG12:                ;; offset=0x02E4
       vmovups  ymm6, ymmword ptr [rsp+0x110]
 
G_M000_IG13:                ;; offset=0x02ED
       vmovups  ymmword ptr [rbx], ymm6
       mov      rax, rbx
 
G_M000_IG14:                ;; offset=0x02F4
       vzeroupper 
       vmovaps  xmm6, xmmword ptr [rsp+0x210]
       vmovaps  xmm7, xmmword ptr [rsp+0x200]
       vmovaps  xmm8, xmmword ptr [rsp+0x1F0]
       vmovaps  xmm9, xmmword ptr [rsp+0x1E0]
       vmovaps  xmm10, xmmword ptr [rsp+0x1D0]
       vmovaps  xmm11, xmmword ptr [rsp+0x1C0]
       vmovaps  xmm12, xmmword ptr [rsp+0x1B0]
       vmovaps  xmm13, xmmword ptr [rsp+0x1A0]
       vmovaps  xmm14, xmmword ptr [rsp+0x190]
       vmovaps  xmm15, xmmword ptr [rsp+0x180]
       add      rsp, 544
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG15:                ;; offset=0x035F
       vmovd    xmm0, edi
       vpbroadcastd ymm0, ymm0
       vmovups  ymmword ptr [rsp+0x90], ymm0
       vmovups  ymmword ptr [rsp+0x70], ymm6
       vmovups  ymmword ptr [rsp+0x50], ymm7
       vmovups  ymmword ptr [rsp+0x30], ymm8
       lea      rdx, [rsp+0x90]
       lea      r8, [rsp+0x70]
       lea      r9, [rsp+0x50]
       lea      rcx, [rsp+0x30]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rsp+0x150]
       call     [Tedd.FastNoise.Internal.Kernels.OpenSimplex2Kernel:Sample3[Tedd.FastNoise.Internal.VectorOps,System.Numerics.Vector`1[float],System.Numerics.Vector`1[int]](System.Numerics.Vector`1[int],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float],System.Numerics.Vector`1[float]):System.Numerics.Vector`1[float]]
       cmp      dword ptr [rsi], 0
       je       G_M000_IG23
       vbroadcastss ymm0, dword ptr [rsi+0x18]
       mov      eax, dword ptr [rsi]
       cmp      eax, 2
       je       G_M000_IG20
       cmp      eax, 3
       je       G_M000_IG22
       vmulps   ymm1, ymm0, ymmword ptr [rsp+0x150]
 
G_M000_IG16:                ;; offset=0x03D9
       vbroadcastss ymm0, ymm12
       vmulps   ymm6, ymm0, ymm1
       jmp      G_M000_IG13
 
G_M000_IG17:                ;; offset=0x03E7
       cmp      edx, 2
       ja       G_M000_IG04
       mov      edx, edx
       lea      r10, [reloc @RWD160]
       mov      r10d, dword ptr [r10+4*rdx]
       lea      r11, G_M000_IG02
       add      r10, r11
       jmp      r10
 
G_M000_IG18:                ;; offset=0x040A
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymm2, ymmword ptr [rax]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [rax], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [rax]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vaddps   ymm1, ymm1, ymmword ptr [r9]
       vsubps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [r9], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm0
       jmp      G_M000_IG04
 
G_M000_IG19:                ;; offset=0x045D
       vmovups  ymm0, ymmword ptr [r8]
       vaddps   ymm0, ymm0, ymmword ptr [rax]
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymm2, ymmword ptr [r9]
       vmulps   ymm2, ymm2, ymmword ptr [reloc @RWD224]
       vmovups  ymmword ptr [r9], ymm2
       vsubps   ymm2, ymm1, ymmword ptr [r9]
       vaddps   ymm2, ymm2, ymmword ptr [r8]
       vmovups  ymmword ptr [r8], ymm2
       vsubps   ymm1, ymm1, ymmword ptr [r9]
       vaddps   ymm1, ymm1, ymmword ptr [rax]
       vmovups  ymmword ptr [rax], ymm1
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD224]
       vaddps   ymm0, ymm0, ymmword ptr [r9]
       vmovups  ymmword ptr [r9], ymm0
       jmp      G_M000_IG04
 
G_M000_IG20:                ;; offset=0x04B3
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       vandps   ymm1, ymm1, ymmword ptr [reloc @RWD96]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD128]
       vbroadcastss ymm2, dword ptr [reloc @RWD32]
       vaddps   ymm1, ymm1, ymm2
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG16
 
G_M000_IG21:                ;; offset=0x04E2
       jmp      G_M000_IG07
 
G_M000_IG22:                ;; offset=0x04E7
       vbroadcastss ymm1, dword ptr [reloc @RWD32]
       vaddps   ymm2, ymm1, ymmword ptr [rsp+0x150]
       vbroadcastss ymm3, dword ptr [rsi+0x14]
       vmulps   ymm2, ymm3, ymm2
       vmulps   ymm3, ymm2, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm4, ymm3, ymm3
       vandps   ymm3, ymm4, ymm3
       vcmpgeps ymm4, ymm3, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm3, ymm3
       vpblendvb ymm3, ymm3, ymmword ptr [reloc @RWD96], ymm4
       vcvtdq2ps ymm3, ymm3
       vmulps   ymm3, ymm3, ymmword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm3
       vcmpltps ymm1, ymm2, ymm1
       vbroadcastss ymm3, dword ptr [reloc @RWD288]
       vsubps   ymm3, ymm3, ymm2
       vblendvps ymm1, ymm3, ymm2, ymm1
       vsubps   ymm1, ymm1, ymmword ptr [reloc @RWD64]
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vmulps   ymm1, ymm1, ymm0
       jmp      G_M000_IG16
 
G_M000_IG23:                ;; offset=0x056C
       vmovups  ymm1, ymmword ptr [rsp+0x150]
       jmp      G_M000_IG16
 
G_M000_IG24:                ;; offset=0x057A
       lea      edx, [rbp-0x01]
       cmp      r14d, edx
       jne      G_M000_IG21
       vbroadcastss ymm0, ymm12
       vmulps   ymm7, ymm0, ymm7
       jmp      G_M000_IG07
 
G_M000_IG25:                ;; offset=0x0594
       vbroadcastss ymm12, dword ptr [reloc @RWD32]
       vaddps   ymm0, ymm12, ymmword ptr [rsp+0xB0]
       vbroadcastss ymm1, dword ptr [rsi+0x14]
       vmulps   ymm0, ymm1, ymm0
       vmulps   ymm1, ymm0, ymmword ptr [reloc @RWD64]
       vcmpeqps ymm2, ymm1, ymm1
       vandps   ymm1, ymm2, ymm1
       vcmpgeps ymm2, ymm1, ymmword ptr [reloc @RWD256]
       vcvttps2dq ymm1, ymm1
       vpblendvb ymm1, ymm1, ymmword ptr [reloc @RWD96], ymm2
       vcvtdq2ps ymm1, ymm1
       vmulps   ymm1, ymm1, ymmword ptr [reloc @RWD288]
       vsubps   ymm0, ymm0, ymm1
       vcmpltps ymm1, ymm0, ymm12
       vbroadcastss ymm2, dword ptr [reloc @RWD288]
       vsubps   ymm2, ymm2, ymm0
       vblendvps ymm0, ymm2, ymm0, ymm1
       vmovups  ymmword ptr [rsp+0xB0], ymm0
       vsubps   ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vmulps   ymm0, ymm0, ymmword ptr [reloc @RWD288]
       vmulps   ymm0, ymm0, ymm7
       vaddps   ymm6, ymm0, ymmword ptr [rsp+0x110]
       vmovups  ymm0, ymmword ptr [rsp+0xB0]
       jmp      G_M000_IG09
 
RWD00  	dq	3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh, 3F2AAAAB3F2AAAABh
RWD32  	dd	3F800000h		;         1
RWD36  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD64  	dq	3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h, 3F0000003F000000h
RWD96  	dq	7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh, 7FFFFFFF7FFFFFFFh
RWD128 	dq	C0000000C0000000h, C0000000C0000000h, C0000000C0000000h, C0000000C0000000h
RWD160 	dd	00000398h ; case G_M000_IG18
       	dd	000003EBh ; case G_M000_IG19
       	dd	00000030h ; case G_M000_IG03
RWD172 	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h
RWD192 	dq	BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch, BE58658CBE58658Ch
RWD224 	dq	3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah, 3F13CD3A3F13CD3Ah
RWD256 	dq	4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h, 4F0000004F000000h
RWD288 	dq	4000000040000000h, 4000000040000000h, 4000000040000000h, 4000000040000000h

; Total bytes of code 1589

; Assembly listing for method Tedd.FastNoise.Procedural.ProceduralWideRuntime:Write(System.Span`1[double],int,int,Tedd.FastNoise.Procedural.DoublePair) (Tier1)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 9140
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rsi
       push     rbx
       sub      rsp, 40
 
G_M000_IG02:                ;; offset=0x0006
       mov      rax, bword ptr [rcx]
       mov      ecx, dword ptr [rcx+0x08]
       xor      r10d, r10d
       align    [0 bytes for IG03]
 
G_M000_IG03:                ;; offset=0x000F
       mov      r11d, r10d
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       mov      ebx, r10d
       mov      esi, ebx
       vmovsd   xmm0, qword ptr [r9+8*rsi]
       vmovsd   qword ptr [rax+8*r11], xmm0
       lea      r11d, [r10+0x04]
       imul     r11d, r8d
       add      r11d, edx
       cmp      r11d, ecx
       jae      SHORT G_M000_IG05
       vmovsd   xmm0, qword ptr [r9+8*rbx+0x20]
       vmovsd   qword ptr [rax+8*r11], xmm0
       inc      r10d
       cmp      r10d, 4
       jl       SHORT G_M000_IG03
 
G_M000_IG04:                ;; offset=0x0055
       add      rsp, 40
       pop      rbx
       pop      rsi
       ret      
 
G_M000_IG05:                ;; offset=0x005C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 98

